@echo off
setlocal
cd /d "%~dp0video-hub"
call open.cmd %*
