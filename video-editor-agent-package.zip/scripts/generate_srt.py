import os

# Helper to format seconds to SRT timestamp: 00:00:00,000
def to_srt_time(sec):
    hrs = int(sec // 3600)
    mins = int((sec % 3600) // 60)
    secs = int(sec % 60)
    mils = int(round((sec - int(sec)) * 1000))
    if mils >= 1000:
        secs += 1
        mils -= 1000
    return f"{hrs:02d}:{mins:02d}:{secs:02d},{mils:03d}"

# 1. Romanized Hinglish Subtitles (Exact words spoken by clinician)
hinglish_cues = [
    (0.15, 2.95, "Phone ko direct sunlight se apne room me le jao,"),
    (3.50, 6.35, "to brightness automatically adjust hoti hai, right?"),
    (7.00, 10.50, "Kuch hearing aids me environmental classifier bhi hota hai,"),
    (11.00, 13.45, "jo environment samajhne me help karta hai,"),
    (13.90, 17.25, "jaise ek quiet conversation ya ek busy restaurant."),
    (17.80, 21.00, "Phir device apne model aur fitting ke hisaab se,"),
    (21.40, 25.80, "settings ko automatically change kar sakta hai, ya blend kar sakta hai."),
    (26.30, 29.30, "Day to day life me patient ko har jagah ruk kar,"),
    (29.75, 32.90, "apna program switch karne ki problem, bilkul khatam."),
    (33.45, 35.30, "Yeh koi mind reader nahi hai,"),
    (35.55, 38.60, "aur na hi yeh noise ko bilkul poori tarah se khatam karta hai."),
    (39.20, 43.60, "Bas yeh room ya environment ka context samajhne me help karta hai,"),
    (44.20, 47.30, "aur patient ko baat-cheet samajhne me help karta hai,"),
    (47.60, 50.95, "aur patient ko har jagah ruk kar apne hearing aid ka,"),
    (51.05, 54.00, "remote control operator banne ki problem, bilkul khatam!")
]

# 2. English Translated Subtitles (Broadcast & International Reels style)
english_cues = [
    (0.15, 2.95, "When you bring your phone from direct sunlight indoors,"),
    (3.50, 6.35, "the display brightness automatically adjusts, right?"),
    (7.00, 10.50, "Similarly, modern hearing aids have an environmental classifier,"),
    (11.00, 13.45, "which automatically identifies the listening acoustic scene,"),
    (13.90, 17.25, "like a quiet one-on-one chat or a crowded restaurant."),
    (17.80, 21.00, "Based on the device model and your custom prescription,"),
    (21.40, 25.80, "it automatically changes or smoothly blends the sound settings."),
    (26.30, 29.30, "In everyday life, the hassle of stopping everywhere"),
    (29.75, 32.90, "to manually switch programs is completely eliminated."),
    (33.45, 35.30, "Now, it isn't a mind reader,"),
    (35.55, 38.60, "nor does it erase 100% of background noise."),
    (39.20, 43.60, "It simply understands the acoustic context of the room,"),
    (44.20, 47.30, "assisting the patient in following speech clearly,"),
    (47.60, 50.95, "so they never have to constantly fiddle around"),
    (51.05, 54.00, "acting like a remote control operator for their hearing aid!")
]

def write_srt(cues, file_path):
    with open(file_path, "w", encoding="utf-8") as f:
        for idx, (t0, t1, text) in enumerate(cues, 1):
            f.write(f"{idx}\n")
            f.write(f"{to_srt_time(t0)} --> {to_srt_time(t1)}\n")
            f.write(f"{text}\n\n")
    print(f"Wrote SRT to: {file_path}")

out_dirs = [
    r"f:\Antigravity\video editor\out",
    r"C:\Users\Lenovo\Downloads"
]

for d in out_dirs:
    os.makedirs(d, exist_ok=True)
    # Master default SRT (Spoken Hinglish)
    write_srt(hinglish_cues, os.path.join(d, "environmental_classifier_perfect_take.srt"))
    # Dedicated English Translation SRT
    write_srt(english_cues, os.path.join(d, "environmental_classifier_perfect_take_english.srt"))
    # Dedicated Hinglish SRT
    write_srt(hinglish_cues, os.path.join(d, "environmental_classifier_perfect_take_hinglish.srt"))

print("All SRT files successfully generated!")
