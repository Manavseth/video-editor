@echo off
set "PYTHON_EXE=%~dp0..\.venv\Scripts\python.exe"
if exist "%PYTHON_EXE%" (
    "%PYTHON_EXE%" "%~dp0audit_composite_audio.py" %*
) else (
    python "%~dp0audit_composite_audio.py" %*
)
