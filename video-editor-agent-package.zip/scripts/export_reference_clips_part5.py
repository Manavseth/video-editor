import os
import subprocess

dest_dir = r"C:\Users\Lenovo\Desktop\reels\audiogram_part5_reference_clips"
os.makedirs(dest_dir, exist_ok=True)

ffmpeg_bin = r"C:\Users\Lenovo\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"
src_video = r"C:\Users\Lenovo\Desktop\reels\unprofessional take\Edits_Audiogram_part_five_20261114_212107.mp4"

# Clip 1: 04.05s to 08.85s (4.80s)
clip1_wav = os.path.join(dest_dir, "clip1.wav")
clip1_mp3 = os.path.join(dest_dir, "clip1.mp3")

cmd1_wav = [ffmpeg_bin, "-y", "-ss", "04.05", "-to", "08.85", "-i", src_video, "-vn", "-acodec", "pcm_s16le", "-ar", "44100", "-ac", "2", clip1_wav]
cmd1_mp3 = [ffmpeg_bin, "-y", "-ss", "04.05", "-to", "08.85", "-i", src_video, "-vn", "-b:a", "320k", clip1_mp3]

subprocess.run(cmd1_wav, check=True)
subprocess.run(cmd1_mp3, check=True)
print("Clip 1 exported successfully.")

# Clip 2: 21.63s to 26.05s (4.42s)
clip2_wav = os.path.join(dest_dir, "clip2.wav")
clip2_mp3 = os.path.join(dest_dir, "clip2.mp3")

cmd2_wav = [ffmpeg_bin, "-y", "-ss", "21.63", "-to", "26.05", "-i", src_video, "-vn", "-acodec", "pcm_s16le", "-ar", "44100", "-ac", "2", clip2_wav]
cmd2_mp3 = [ffmpeg_bin, "-y", "-ss", "21.63", "-to", "26.05", "-i", src_video, "-vn", "-b:a", "320k", clip2_mp3]

subprocess.run(cmd2_wav, check=True)
subprocess.run(cmd2_mp3, check=True)
print("Clip 2 exported successfully.")

print("All clips exported to:", dest_dir)
for f in os.listdir(dest_dir):
    p = os.path.join(dest_dir, f)
    print(f"  {f} - {os.path.getsize(p)} bytes")
