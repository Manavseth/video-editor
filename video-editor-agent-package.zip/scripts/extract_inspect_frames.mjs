import { execSync } from 'child_process';
import fs from 'fs';

if (!fs.existsSync('work/inspect_frames')) {
  fs.mkdirSync('work/inspect_frames', { recursive: true });
}

const frames = [30, 100, 200, 350, 480, 650, 850, 1000, 1150];
for (const f of frames) {
  const time = (f / 30).toFixed(2);
  execSync(`ffmpeg -y -ss ${time} -i out/bells_phenomenon_procedural_master.mp4 -vframes 1 work/inspect_frames/frame_${f}.jpg`, { stdio: 'inherit' });
}
console.log('Extraction complete');
