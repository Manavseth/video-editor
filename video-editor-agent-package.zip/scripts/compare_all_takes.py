import numpy as np
import scipy.io.wavfile as wavfile
import sys
from faster_whisper import WhisperModel

sys.stdout.reconfigure(encoding='utf-8')

wav_path = r"f:\Antigravity\video editor\work\rough_cut_classifier\audio.wav"
sr, data = wavfile.read(wav_path)

print("Loading Whisper model...")
model = WhisperModel("base", device="cpu", compute_type="int8")

sections_to_check = [
    # HOOK & CLASSIFIER TAKES
    ("Hook Take 1", 0.0, 17.5),
    ("Hook Take 2", 48.0, 65.0),
    ("Hook Take 3 (part a)", 99.0, 112.0),
    ("Hook Take 3 (part b: 111-125s)", 111.0, 126.0),
    
    # SETTINGS / BLEND TAKES
    ("Settings Take 1", 17.0, 24.5),
    ("Settings Take 2", 65.0, 74.0),
    ("Settings Take 3", 123.5, 127.0),
    
    # DAY-TO-DAY LIFE TAKES
    ("Day-to-day Take 1", 24.5, 31.5),
    ("Day-to-day Take 2", 74.0, 81.0),
    ("Day-to-day Take 3", 126.5, 134.0),
    
    # CAVEAT (MIND READER) TAKES
    ("Caveat Take 1", 31.5, 36.0),
    ("Caveat Take 2", 81.0, 85.0),
    ("Caveat Take 3", 133.5, 139.5),
    
    # CONTEXT & PUNCHLINE TAKES
    ("Punchline from Take 2 zone", 95.0, 100.0),
    ("Context & Punchline from Take 3 zone", 139.5, 154.8)
]

print("\n" + "="*80)
for name, t0, t1 in sections_to_check:
    s0 = int(t0 * sr)
    s1 = int(t1 * sr)
    slice_data = data[s0:s1]
    
    # Check RMS energy
    f_data = slice_data.astype(np.float32) / 32768.0
    rms = np.sqrt(np.mean(f_data**2))
    rms_db = 20 * np.log10(rms + 1e-9)
    peak_db = 20 * np.log10(np.max(np.abs(f_data)) + 1e-9)
    
    # Transcribe slice
    tmp_path = r"f:\Antigravity\video editor\work\rough_cut_classifier\tmp_slice.wav"
    wavfile.write(tmp_path, sr, slice_data)
    
    segs, info = model.transcribe(tmp_path, language="hi", beam_size=1)
    text = " ".join(s.text.strip() for s in segs)
    
    print(f"\n[{name}] ({t0:5.1f}s -> {t1:5.1f}s | dur {t1-t0:4.1f}s) | RMS: {rms_db:5.1f} dB | Peak: {peak_db:5.1f} dB")
    print(f"  --> \"{text}\"")
