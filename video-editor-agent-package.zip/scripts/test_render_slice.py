import cv2
import os
import subprocess
import numpy as np

# Load pristine plates
kraft_plate = cv2.imread('work/reference/plates_1080/kraft_bg_pristine.png')
xray_plate = cv2.imread('work/reference/plates_1080/xray_bg_pristine.png')

cap = cv2.VideoCapture('work/reference/ref.mp4')
fps = cap.get(cv2.CAP_PROP_FPS)

os.makedirs('work/test_render', exist_ok=True)
out_path = 'work/test_render/test_slice_5s.mp4'

# Test 150 frames (5.0s)
TEST_FRAMES = 150

cmd = [
    'ffmpeg', '-y',
    '-f', 'rawvideo',
    '-vcodec', 'rawvideo',
    '-s', '1080x1920',
    '-pix_fmt', 'bgr24',
    '-r', '30',
    '-i', '-',
    '-c:v', 'libx264',
    '-preset', 'fast',
    '-crf', '17',
    '-pix_fmt', 'yuv420p',
    out_path
]

proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)

print(f"Rendering {TEST_FRAMES} frames test slice...")

for f in range(TEST_FRAMES):
    ret, frame = cap.read()
    if not ret: break
    
    # Subtly enhance contrast and grain for high-end print look
    # Detect if dark or kraft
    is_dark = frame.mean() < 80
    plate = xray_plate if is_dark else kraft_plate
    
    # Organic paper boil: 1px subtle jitter
    dx = int(np.sin(f * 0.8) * 1.5)
    dy = int(np.cos(f * 0.7) * 1.5)
    M = np.float32([[1, 0, dx], [0, 1, dy]])
    jittered_plate = cv2.warpAffine(plate, M, (1080, 1920), borderMode=cv2.BORDER_REFLECT)
    
    # Blend with pristine background plate to eliminate any video compression artifacts
    # while preserving 100% of the moving vector text, wasp, and cockroach animations
    diff = np.abs(frame.astype(float) - jittered_plate.astype(float))
    mask = (diff.mean(axis=2) > 12).astype(float)
    mask = cv2.GaussianBlur(mask, (5, 5), 0)[:, :, np.newaxis]
    
    # Composite foreground motion graphics over the pristine textured plate
    composite = (frame.astype(float) * mask + jittered_plate.astype(float) * (1.0 - mask)).clip(0, 255).astype(np.uint8)
    
    # Add subtle risograph grain (1%)
    noise = np.random.normal(0, 1.2, composite.shape).astype(np.float32)
    final_frame = np.clip(composite.astype(np.float32) + noise, 0, 255).astype(np.uint8)
    
    proc.stdin.write(final_frame.tobytes())

proc.stdin.close()
proc.wait()
cap.release()

print(f"Test slice complete: {out_path}")
