#!/usr/bin/env python3
"""
========================================================================================
AUDIT COMPOSITE AUDIO — AUTOMATED PRE-FLIGHT QUALITY GATE
Deterministic Quality Assurance Gate for Short-Form Video & Audio Pipelines.
Prevents:
  1. Multi-take audio splicing collisions and word duplications (e.g. "isiliye... isiliye").
  2. Spoken false-start repetitions and stutters (e.g. "yaad rakho, yaad rakho").
  3. Trailing conversational filler / mutters (e.g. "remove that part", sighs, mic bumps).
  4. Incomplete sentences or clipped words at cut boundaries.

Usage:
  python scripts/audit_composite_audio.py <audio_or_video_file> [--expected-end-word "karo"]
Exits 0 if 100% clean; Exits 1 if errors or duplications detected.
========================================================================================
"""

import sys, os, re, subprocess, wave, argparse
sys.stdout.reconfigure(encoding='utf-8')

# ----------------------------------------------------------------------------------------
# Self-Healing Interpreter Resolution:
# If faster_whisper is missing in the current Python environment, automatically delegate
# to the provisioned ASR virtualenv on this machine.
# ----------------------------------------------------------------------------------------
try:
    import faster_whisper
except ImportError:
    KNOWN_VENVS = [
        os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".venv", "Scripts", "python.exe")),
        r"E:\codex\Documentry\.asr-venv\Scripts\python.exe",
        r"E:\Antigravity\Documentry\.asr-venv\Scripts\python.exe",
        r"F:\codex\Documentry\.asr-venv\Scripts\python.exe",
        os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "codex", "Documentry", ".asr-venv", "Scripts", "python.exe")),
    ]
    target_py = next((p for p in KNOWN_VENVS if os.path.exists(p) and os.path.abspath(p) != os.path.abspath(sys.executable)), None)
    if target_py:
        res = subprocess.run([target_py, os.path.abspath(__file__)] + sys.argv[1:])
        sys.exit(res.returncode)
    else:
        print("ERROR: faster-whisper not installed and no ASR virtualenv found.", file=sys.stderr)
        sys.exit(1)

import numpy as np

def extract_audio_16k(input_path, tmp_wav="tmp_audit_16k.wav"):
    cmd = [
        "ffmpeg", "-y", "-i", input_path,
        "-vn", "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", tmp_wav
    ]
    res = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if res.returncode != 0:
        raise RuntimeError(f"FFmpeg failed to extract audio from: {input_path}")
    
    with wave.open(tmp_wav, "rb") as w:
        raw = w.readframes(w.getnframes())
        sr = w.getframerate()
        audio = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    
    if os.path.exists(tmp_wav):
        os.remove(tmp_wav)
    return sr, audio

def normalize_word(w):
    # Strip punctuation and convert to lowercase, preserving Unicode combining marks / Devanagari matras
    w = re.sub(r'[^\w\s\u0900-\u097F]', '', w).strip().lower()
    return w

def audit_audio(input_file, expected_end_word=None, max_repeat_gap=2.5):
    print("=" * 80)
    print("AUDIT COMPOSITE AUDIO — PRE-FLIGHT INTEGRITY GATE")
    print(f"Target Input: {input_file}")
    print("=" * 80)

    sr, audio = extract_audio_16k(input_file)
    total_duration = len(audio) / 16000.0
    print(f"✓ Audio extracted: {total_duration:.3f} seconds @ {sr} Hz")

    # Ingest Whisper
    from faster_whisper import WhisperModel
    candidate_model_dirs = [
        r"E:\Antigravity\Documentry\.asr-models",
        r"E:\codex\Documentry\.asr-models",
        r"F:\codex\Documentry\.asr-models",
    ]
    model_dir = next((d for d in candidate_model_dirs if os.path.exists(d)), None)
    
    print("Loading ASR model for phonetic word alignment...")
    model = WhisperModel(
        "small", device="cpu", compute_type="int8", num_workers=1,
        download_root=model_dir, local_files_only=(model_dir is not None)
    )

    segments, info = model.transcribe(audio, beam_size=5, word_timestamps=True)
    all_words = []
    full_text_segments = []

    for s in segments:
        full_text_segments.append(s.text.strip())
        for w in (s.words or []):
            clean = normalize_word(w.word)
            if clean:
                all_words.append({
                    "word": clean,
                    "raw": w.word,
                    "start": round(w.start, 3),
                    "end": round(w.end, 3),
                    "prob": round(w.probability, 3)
                })

    print(f"✓ Transcribed {len(all_words)} words across {len(full_text_segments)} phrases.")
    print("-" * 80)

    violations = []

    # 1. Check for Duplicate Consecutive Words / Immediate Repetitions
    # Whitelist legitimate grammatical Hindi reduplications (e.g. "alag alag" / "अलग अलग")
    LEGITIMATE_REDUPLICATIONS = {"alag", "गलग", "अलग", "saath", "साथ", "dheere", "धीरे", "chote", "छोटे"}
    for i in range(len(all_words) - 1):
        w1 = all_words[i]
        w2 = all_words[i + 1]
        gap = w2["start"] - w1["end"]

        # Check exact word match
        if w1["word"] == w2["word"] and gap < max_repeat_gap:
            if w1["word"] in LEGITIMATE_REDUPLICATIONS:
                continue
            # Flag immediate repeat
            violations.append({
                "type": "DUPLICATE_WORD_REPETITION",
                "time": f"{w1['start']:.2f}s - {w2['end']:.2f}s",
                "detail": f"Word '{w1['raw']}' repeated consecutively within {gap:.2f}s (Starts at {w1['start']}s and {w2['start']}s)",
                "severity": "CRITICAL"
            })

    # 2. Check for 2-word N-Gram Duplications (e.g. "yaad rakho, yaad rakho" or "sabse important... sabse important")
    for i in range(len(all_words) - 3):
        p1 = f"{all_words[i]['word']} {all_words[i+1]['word']}"
        p2 = f"{all_words[i+2]['word']} {all_words[i+3]['word']}"
        gap = all_words[i+2]['start'] - all_words[i+1]['end']

        if p1 == p2 and gap < 3.0:
            violations.append({
                "type": "DUPLICATE_PHRASE_REPETITION",
                "time": f"{all_words[i]['start']:.2f}s - {all_words[i+3]['end']:.2f}s",
                "detail": f"Phrase '{p1}' repeated consecutively within {gap:.2f}s",
                "severity": "CRITICAL"
            })

    # 3. Check for Trailing Vocal Mutter / Conversational Outtakes at end
    if len(all_words) > 0:
        last_word = all_words[-1]
        remaining_time = total_duration - last_word["end"]
        
        # If expected_end_word is provided, check if speech occurs after it
        if expected_end_word:
            clean_expected = normalize_word(expected_end_word)
            found_idx = -1
            for idx in range(len(all_words) - 1, -1, -1):
                if all_words[idx]["word"] == clean_expected:
                    found_idx = idx
                    break
            
            if found_idx != -1 and found_idx < len(all_words) - 1:
                trailing = " ".join([w["raw"] for w in all_words[found_idx + 1:]])
                violations.append({
                    "type": "TRAILING_UNWANTED_SPEECH",
                    "time": f"{all_words[found_idx+1]['start']:.2f}s - {all_words[-1]['end']:.2f}s",
                    "detail": f"Spoken words detected AFTER expected ending word '{expected_end_word}': '{trailing}'",
                    "severity": "CRITICAL"
                })

        # Check energy in the final 1.5s to ensure no loud breathing or muttering survives
        tail_start_sec = max(0, total_duration - 1.2)
        tail_start_samp = int(tail_start_sec * 16000)
        tail_audio = audio[tail_start_samp:]
        tail_rms = np.sqrt(np.mean(tail_audio ** 2)) if len(tail_audio) > 0 else 0
        tail_db = 20 * np.log10(tail_rms + 1e-9)

        if tail_db > -28.0 and last_word["end"] < total_duration - 1.5:
            violations.append({
                "type": "DIRTY_AUDIO_TAIL",
                "time": f"{tail_start_sec:.2f}s - {total_duration:.2f}s",
                "detail": f"High energy ({tail_db:.1f} dBFS) detected in trailing pause after speech has ended. Possible unmuted breath or mic bump.",
                "severity": "WARNING"
            })

    # 4. Check Cut-Boundary Word Duration Anomalies
    for w in all_words:
        dur = w["end"] - w["start"]
        if dur > 1.2:
            violations.append({
                "type": "STRETCHED_WORD_ANOMALY",
                "time": f"{w['start']:.2f}s - {w['end']:.2f}s",
                "detail": f"Word '{w['raw']}' has duration {dur:.2f}s (> 1.2s), indicating an obscured pause or collapsed cut boundary.",
                "severity": "WARNING"
            })

    # Output Results
    print("\nAUDIT SUMMARY:")
    if not violations:
        print("★ STATUS: PASSED (0 Flaws Detected)")
        print("✓ Composite master audio is clean, continuous, and free of stutter/repetition.")
        print(f"✓ Speech ends cleanly at {all_words[-1]['end']:.2f}s (Total duration: {total_duration:.2f}s)")
        print("=" * 80)
        return True
    else:
        critical_count = sum(1 for v in violations if v["severity"] == "CRITICAL")
        warn_count = sum(1 for v in violations if v["severity"] == "WARNING")
        status_flag = "FAILED" if critical_count > 0 else "PASSED WITH WARNINGS"
        print(f"★ STATUS: {status_flag} ({critical_count} Critical Violations, {warn_count} Warnings)")
        for idx, v in enumerate(violations, 1):
            flag = "CRITICAL FAIL" if v["severity"] == "CRITICAL" else "WARNING"
            print(f"  [{idx}] [{flag}] {v['type']} @ {v['time']}")
            print(f"      Details: {v['detail']}")
        print("=" * 80)
        return critical_count == 0

def main():
    parser = argparse.ArgumentParser(description="Audit composite audio for speech duplication and boundary defects.")
    parser.add_argument("input", help="Path to composite audio (.wav, .mp3) or video (.mp4)")
    parser.add_argument("--end-word", default=None, help="Expected final word of the script (e.g. 'karo')")
    parser.add_argument("--max-gap", type=float, default=2.5, help="Max gap between identical words to trigger duplication flag")

    args = parser.parse_args()
    if not os.path.exists(args.input):
        print(f"Error: File not found: {args.input}", file=sys.stderr)
        sys.exit(1)

    success = audit_audio(args.input, expected_end_word=args.end_word, max_repeat_gap=args.max_gap)
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()
