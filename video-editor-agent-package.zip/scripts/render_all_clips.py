import os
import subprocess
import json

raw_video = r"E:\Courses\WhatsApp Video 2026-10-25 at 9.04.58 PM.mp4"
code_video = r"f:\Antigravity\video editor\out\ClassifierMasterReel_Revised_35s.mp4"
out_dir = r"f:\Antigravity\video editor\out\individual_clips"
os.makedirs(out_dir, exist_ok=True)

# 11 Clips definition
clips = [
    {
        "filename": "clip_01_host_hook.mp4",
        "type": "host",
        "ss": 41.15,
        "duration": 3.2,
        "desc": "Host hook: Kuch hearing aids mein environmental classifier..."
    },
    {
        "filename": "clip_02_code_chaos.mp4",
        "type": "code",
        "ss": 0.0,
        "duration": 3.2,
        "desc": "Code Scene 1: Acoustic babble (82 dB SPL) attacking ear"
    },
    {
        "filename": "clip_03_host_concept.mp4",
        "type": "host",
        "ss": 44.35,
        "duration": 3.2,
        "desc": "Host concept: ...jo environment pehchanne ki koshish karta hai..."
    },
    {
        "filename": "clip_04_code_dsp_chip.mp4",
        "type": "code",
        "ss": 9.6,
        "duration": 3.2,
        "desc": "Code Scene 4: Blueprint DSP classifier core"
    },
    {
        "filename": "clip_05_code_modulation.mp4",
        "type": "code",
        "ss": 12.8,
        "duration": 3.2,
        "desc": "Code Scene 5: Speech modulation & dynamic noise attenuation"
    },
    {
        "filename": "clip_06_host_settings.mp4",
        "type": "host",
        "ss": 79.50,
        "duration": 3.2,
        "desc": "Host settings: Hearing aid settings ko apne model aur fitting ke hisaab se..."
    },
    {
        "filename": "clip_07_code_matrix.mp4",
        "type": "code",
        "ss": 28.8,
        "duration": 3.2,
        "desc": "Code Scene 10: Autonomous scene switching matrix"
    },
    {
        "filename": "clip_08_host_caveat.mp4",
        "type": "host",
        "ss": 141.20,
        "duration": 3.2,
        "desc": "Host caveat: Par yeh mind reader nahi hai..."
    },
    {
        "filename": "clip_09_code_subtraction.mp4",
        "type": "code",
        "ss": 16.0,
        "duration": 3.2,
        "desc": "Code Scene 6: Noise attenuation and SNR advantage"
    },
    {
        "filename": "clip_10_host_context.mp4",
        "type": "host",
        "ss": 155.50,
        "duration": 3.2,
        "desc": "Host context: Yeh bas room ka context samajhne mein help karta hai..."
    },
    {
        "filename": "clip_11_host_punchline.mp4",
        "type": "host",
        "ss": 167.50,
        "duration": 3.5,
        "desc": "Host punchline: Taaki patient ko remote control operator na banna pade!"
    }
]

print(f"Rendering {len(clips)} individual clips to {out_dir}...")

for idx, c in enumerate(clips):
    target = os.path.join(out_dir, c["filename"])
    print(f"\n[{idx+1}/{len(clips)}] Rendering {c['filename']} ({c['duration']}s)...")
    
    if c["type"] == "host":
        # Crop 9:16 from centered horizontal video, boost audio by +32dB, render exactly to duration
        cmd = [
            "ffmpeg", "-y",
            "-ss", str(c["ss"]),
            "-t", str(c["duration"]),
            "-i", raw_video,
            "-vf", "crop=608:1080:656:0,scale=1080:1920,setsar=1:1,fps=30",
            "-af", "volume=32dB,aresample=48000",
            "-c:v", "libx264", "-preset", "slow", "-crf", "18", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
            "-avoid_negative_ts", "make_zero",
            target
        ]
    else:
        # Cut exact slice from Remotion code animation
        cmd = [
            "ffmpeg", "-y",
            "-ss", str(c["ss"]),
            "-t", str(c["duration"]),
            "-i", code_video,
            "-vf", "scale=1080:1920,setsar=1:1,fps=30",
            "-c:v", "libx264", "-preset", "slow", "-crf", "18", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
            "-avoid_negative_ts", "make_zero",
            target
        ]
        
    ret = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if ret.returncode != 0:
        print(f"Error rendering {c['filename']}:\n{ret.stderr[-500:]}")
        raise RuntimeError(f"Failed to render {c['filename']}")
    else:
        # Check size and duration
        size_kb = os.path.getsize(target) / 1024.0
        print(f"[OK] Rendered: {c['filename']} ({size_kb:.1f} KB)")

print("\nAll 11 individual clips rendered successfully!")
