import json
import numpy as np
import scipy.io.wavfile as wavfile

with open("work/reel_whatsapp/words.json", encoding="utf-8") as f:
    words = json.load(f)

# Let's inspect words around each take
sections = [
    ("Take 1 (Hook & Classifier)", 30.0, 54.0),
    ("Take 2 (Settings / Blend)", 68.0, 86.0),
    ("Take 3 (Mind reader / Erase)", 130.0, 148.0),
    ("Take 4 (Context)", 153.0, 160.0),
    ("Take 5 (Punchline)", 164.0, 173.0),
]

for title, t0, t1 in sections:
    print(f"\n=== {title} ({t0}s - {t1}s) ===")
    w_in_sec = [w for w in words if t0 <= w["start"] <= t1]
    sentence = " ".join(w["word"] for w in w_in_sec)
    print(f"Text: {sentence}")
    if w_in_sec:
        print(f"Start: {w_in_sec[0]['start']:.2f}s, End: {w_in_sec[-1]['end']:.2f}s")
