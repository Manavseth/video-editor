#!/usr/bin/env python3
import sys, os, subprocess, wave
import numpy as np
from faster_whisper import WhisperModel

sys.stdout.reconfigure(encoding='utf-8')

def get_audio(path):
    tmp = "tmp_inspect.wav"
    cmd = ["ffmpeg", "-y", "-i", path, "-vn", "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", tmp]
    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
    with wave.open(tmp, "rb") as w:
        raw = w.readframes(w.getnframes())
        audio = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    if os.path.exists(tmp):
        os.remove(tmp)
    return audio

model_dir = r"F:\codex\Documentry\.asr-models"
model = WhisperModel("small", device="cpu", compute_type="int8", download_root=model_dir)

clips = [
    ("Clip 1", r"E:\Courses\mhl clip1.mp4"),
    ("Clip 2", r"E:\Courses\mhl clip2.mp4"),
    ("Clip 3", r"E:\Courses\mhl clip3.mp4"),
    ("Clip 4", r"E:\Courses\mhl clip4.mp4")
]

for label, c in clips:
    print("=" * 70)
    print(f"{label}: {c}")
    audio = get_audio(c)
    dur = len(audio) / 16000.0
    print(f"Duration: {dur:.3f}s")
    segs, info = model.transcribe(audio, beam_size=5, word_timestamps=True)
    for s in segs:
        print(f"[{s.start:.2f}s - {s.end:.2f}s] {s.text}")
        for w in (s.words or []):
            print(f"    {w.start:5.2f}s - {w.end:5.2f}s : {w.word}")
