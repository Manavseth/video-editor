import os
import glob
import json
import subprocess
import cv2
import numpy as np
from PIL import Image

WORK_DIR = r"f:\Antigravity\video editor\work\style-refs\faithvsfact"
OUT_FRAMES_DIR = os.path.join(WORK_DIR, "analysis")
os.makedirs(OUT_FRAMES_DIR, exist_ok=True)

videos = glob.glob(os.path.join(WORK_DIR, "*.mp4"))

analysis_summary = {}

for vpath in sorted(videos):
    vid_name = os.path.splitext(os.path.basename(vpath))[0]
    vid_analysis_dir = os.path.join(OUT_FRAMES_DIR, vid_name)
    os.makedirs(vid_analysis_dir, exist_ok=True)

    cap = cv2.VideoCapture(vpath)
    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    duration = total_frames / fps if fps > 0 else 0

    print(f"--- Analyzing {vid_name} ---")
    print(f"Dimensions: {width}x{height}, FPS: {fps:.2f}, Frames: {total_frames}, Duration: {duration:.2f}s")

    # Extract 1 frame per second
    saved_frames = []
    interval = max(1, int(round(fps)))
    frame_idx = 0
    sec_idx = 0

    # For scene cut detection
    cuts = []
    prev_gray = None

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Compute diff for cut detection
        small = cv2.resize(frame, (180, 320))
        gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
        if prev_gray is not None:
            diff = cv2.absdiff(gray, prev_gray)
            mean_diff = np.mean(diff)
            if mean_diff > 35.0: # Scene cut threshold
                cut_sec = frame_idx / fps
                cuts.append(round(cut_sec, 2))
        prev_gray = gray

        if frame_idx % interval == 0:
            frame_file = os.path.join(vid_analysis_dir, f"sec_{sec_idx:03d}.jpg")
            # Save small version for analysis and contact sheet
            cv2.imwrite(frame_file, frame)
            saved_frames.append(frame_file)
            sec_idx += 1

        frame_idx += 1

    cap.release()

    # Create contact sheet (e.g. 5 columns)
    if saved_frames:
        num_frames = min(len(saved_frames), 25)
        # sample evenly up to 25 frames
        step = max(1, len(saved_frames) // 25)
        selected_files = saved_frames[::step][:25]
        
        cols = 5
        rows = (len(selected_files) + cols - 1) // cols
        thumb_w, thumb_h = 216, 384
        sheet = Image.new("RGB", (cols * thumb_w, rows * thumb_h), (20, 20, 20))

        for idx, fpath in enumerate(selected_files):
            img = Image.open(fpath)
            img = img.resize((thumb_w, thumb_h), Image.Resampling.LANCZOS)
            r = idx // cols
            c = idx % cols
            sheet.paste(img, (c * thumb_w, r * thumb_h))

        sheet_path = os.path.join(OUT_FRAMES_DIR, f"{vid_name}_contact_sheet.jpg")
        sheet.save(sheet_path, quality=85)
        print(f"Contact sheet saved: {sheet_path}")

    # Audio loudness / probe via ffmpeg
    cmd = [
        "ffmpeg", "-i", vpath,
        "-af", "loudnorm=print_format=json",
        "-f", "null", "-"
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    loudness_info = {}
    if proc.stderr:
        for line in proc.stderr.split("\n"):
            if "input_i" in line or "input_tp" in line or "input_lra" in line or "input_thresh" in line:
                parts = line.strip().split(":")
                if len(parts) == 2:
                    loudness_info[parts[0].strip(' "')] = parts[1].strip(' ",')

    cuts_per_min = (len(cuts) / duration * 60) if duration > 0 else 0
    asl = (duration / (len(cuts) + 1)) if duration > 0 else 0

    analysis_summary[vid_name] = {
        "width": width,
        "height": height,
        "fps": fps,
        "duration": round(duration, 2),
        "total_cuts": len(cuts),
        "cuts_per_min": round(cuts_per_min, 1),
        "asl": round(asl, 2),
        "cuts_timestamps": cuts[:15],
        "loudness": loudness_info
    }

with open(os.path.join(OUT_FRAMES_DIR, "summary.json"), "w", encoding="utf-8") as f:
    json.dump(analysis_summary, f, indent=2)

print("\n--- Summary ---")
print(json.dumps(analysis_summary, indent=2))
