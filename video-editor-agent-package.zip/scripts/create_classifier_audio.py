import numpy as np
import scipy.io.wavfile as wavfile
import subprocess
import os

sample_rate = 48000
duration = 35.50  # Exactly 1065 frames @ 30 FPS
total_samples = int(sample_rate * duration)
t = np.linspace(0, duration, total_samples, endpoint=False)

# 1. Base Cinematic Drone Bed (Dark, Atmospheric, Mystical)
drone = (
    0.35 * np.sin(2 * np.pi * 55 * t) +
    0.20 * np.sin(2 * np.pi * 110 * t + 0.5) +
    0.10 * np.sin(2 * np.pi * 165 * t + 1.2) +
    0.05 * np.sin(2 * np.pi * 220 * t + 2.0)
)
# Add subtle LFO pulse (0.2 Hz)
lfo = 0.8 + 0.2 * np.sin(2 * np.pi * 0.15 * t)
drone = drone * lfo

# 2. SFX Layer
sfx = np.zeros(total_samples)

def add_impact(time_sec, freq_start=130, freq_end=35, decay_sec=1.5, amp=0.7):
    idx = int(time_sec * sample_rate)
    length = int(decay_sec * sample_rate)
    if idx + length > total_samples:
        length = total_samples - idx
    st = np.linspace(0, decay_sec, length, endpoint=False)
    freq = np.linspace(freq_start, freq_end, length)
    phase = 2 * np.pi * np.cumsum(freq) / sample_rate
    env = np.exp(-st * 4.0)
    sfx[idx:idx+length] += amp * np.sin(phase) * env

def add_click(time_sec, amp=0.4):
    idx = int(time_sec * sample_rate)
    length = int(0.05 * sample_rate)
    if idx + length > total_samples:
        length = total_samples - idx
    st = np.linspace(0, 0.05, length, endpoint=False)
    noise = np.random.uniform(-1, 1, length) * np.exp(-st * 90)
    sfx[idx:idx+length] += amp * noise

def add_whoosh(time_sec, duration_sec=0.45, amp=0.35):
    idx = int(time_sec * sample_rate)
    length = int(duration_sec * sample_rate)
    if idx + length > total_samples:
        length = total_samples - idx
    st = np.linspace(0, duration_sec, length, endpoint=False)
    noise = np.random.uniform(-1, 1, length)
    env = np.sin(np.pi * st / duration_sec) ** 2
    sfx[idx:idx+length] += amp * noise * env

def add_chime(time_sec, freqs=[523.25, 659.25, 783.99, 1046.50], decay_sec=2.5, amp=0.35):
    idx = int(time_sec * sample_rate)
    length = int(decay_sec * sample_rate)
    if idx + length > total_samples:
        length = total_samples - idx
    st = np.linspace(0, decay_sec, length, endpoint=False)
    chord = np.zeros(length)
    env = np.exp(-st * 1.8)
    for f in freqs:
        chord += np.sin(2 * np.pi * f * st)
    sfx[idx:idx+length] += (amp / len(freqs)) * chord * env

# Trigger events on each scene cut (every 3.2s!)
scene_cuts = [0.0, 3.2, 6.4, 9.6, 12.8, 16.0, 19.2, 22.4, 25.6, 28.8, 32.0]

for idx, cut in enumerate(scene_cuts):
    if idx == 0:
        add_impact(0.05, freq_start=140, freq_end=35, decay_sec=1.8, amp=0.8)
        add_whoosh(0.0, duration_sec=0.6, amp=0.3)
    elif idx == len(scene_cuts) - 1: # Scene 11 (32.0s)
        add_impact(cut, freq_start=100, freq_end=35, decay_sec=2.5, amp=0.8)
        add_chime(cut + 0.1, freqs=[440.0, 554.37, 659.25, 880.0, 1108.7], decay_sec=3.2, amp=0.5)
    else:
        add_whoosh(max(0, cut - 0.2), duration_sec=0.4, amp=0.3)
        add_impact(cut, freq_start=110, freq_end=45, decay_sec=1.0, amp=0.55)
        add_click(cut + 0.25, amp=0.4)

# Combine and normalize
mix = drone * 0.42 + sfx * 0.58
# Soft fade in / out
fade_in_len = int(sample_rate * 0.3)
mix[:fade_in_len] *= np.linspace(0, 1, fade_in_len)
mix[-fade_in_len:] *= np.linspace(1, 0, fade_in_len)

mix = np.clip(mix, -0.95, 0.95)
stereo_mix = np.column_stack((mix, mix))
int16_mix = (stereo_mix * 32767).astype(np.int16)

raw_wav = r"f:\Antigravity\video editor\remotion_ci_reel\public\classifier_raw.wav"
norm_wav = r"f:\Antigravity\video editor\remotion_ci_reel\public\classifier_soundtrack.wav"
wavfile.write(raw_wav, sample_rate, int16_mix)

# Master to exact -14.0 LUFS with ffmpeg loudnorm
cmd = [
    "ffmpeg", "-y", "-i", raw_wav,
    "-af", "loudnorm=I=-14.0:TP=-1.0:LRA=7.0",
    "-ar", "48000",
    norm_wav
]
subprocess.run(cmd, check=True)
print(f"Mastered revised soundtrack generated (35.5s): {norm_wav}")
