import numpy as np
import scipy.io.wavfile as wavfile
import os

work_dir = r"f:\Antigravity\video editor\work\reel_whatsapp"
clean_source_wav = os.path.join(work_dir, "audio_denoised_clean.wav")
out_master_voice = os.path.join(work_dir, "clean_voice_master.wav")

sr, data = wavfile.read(clean_source_wav)
print(f"Source sample rate: {sr}, shape: {data.shape}, dtype: {data.dtype}")
if data.ndim == 1:
    data = np.column_stack([data, data])

# Target timeline parameters:
target_duration = 35.865  # seconds
total_samples = int(round(target_duration * sr))
master_voice = np.zeros((total_samples, 2), dtype=np.float32)

# Convert source to float32 (-1.0 to 1.0)
src_float = data.astype(np.float32) / 32768.0

# Define placement of speech segments onto master timeline:
# Each segment: (src_start_sec, src_dur_sec, dst_start_sec)
segments = [
    # Beat 1: Covers S01 (0-3.2s), S02 (3.2-6.4s), S03 (6.4-9.6s), S04 (9.6-12.0s)
    # Starts at 41.15s in raw audio, total duration 12.0s
    {
        "name": "Beat 1 (Hook + Classifier + Environments)",
        "src_start": 41.15,
        "src_dur": 12.00,
        "dst_start": 0.00,
        "fade_in": 0.05,
        "fade_out": 0.15
    },
    # Beat 2: Covers S06 (16.0-19.2s) and S07 (19.2-22.0s)
    # Starts at 79.20s in raw audio, duration 5.80s
    {
        "name": "Beat 2 (Settings blend)",
        "src_start": 79.20,
        "src_dur": 5.80,
        "dst_start": 16.00,
        "fade_in": 0.05,
        "fade_out": 0.15
    },
    # Beat 3: Covers S08 (22.4-25.6s) and S09 (25.6-28.3s)
    # Starts at 134.30s in raw audio, duration 5.90s
    {
        "name": "Beat 3 (Mind reader caveat)",
        "src_start": 134.30,
        "src_dur": 5.90,
        "dst_start": 22.40,
        "fade_in": 0.05,
        "fade_out": 0.15
    },
    # Beat 4: Covers S10 (28.8-32.0s)
    # Starts at 155.20s in raw audio, duration 3.20s
    {
        "name": "Beat 4 (Room context)",
        "src_start": 155.20,
        "src_dur": 3.20,
        "dst_start": 28.80,
        "fade_in": 0.05,
        "fade_out": 0.08
    },
    # Beat 5: Covers S11 (32.0-35.865s)
    # Starts at 166.50s in raw audio, duration 3.865s
    {
        "name": "Beat 5 (Remote operator punchline)",
        "src_start": 166.50,
        "src_dur": 3.865,
        "dst_start": 32.00,
        "fade_in": 0.05,
        "fade_out": 0.10
    }
]

def apply_cosine_fades(audio_chunk, fade_in_sec, fade_out_sec, sample_rate):
    chunk = audio_chunk.copy()
    n_in = int(fade_in_sec * sample_rate)
    n_out = int(fade_out_sec * sample_rate)
    
    if n_in > 0 and n_in < len(chunk):
        # 0.5 * (1 - cos(pi * x))
        ramp = 0.5 * (1.0 - np.cos(np.pi * np.linspace(0, 1, n_in)[:, None]))
        chunk[:n_in] *= ramp
        
    if n_out > 0 and n_out < len(chunk):
        ramp = 0.5 * (1.0 + np.cos(np.pi * np.linspace(0, 1, n_out)[:, None]))
        chunk[-n_out:] *= ramp
        
    return chunk

for seg in segments:
    s_idx = int(round(seg["src_start"] * sr))
    len_idx = int(round(seg["src_dur"] * sr))
    d_idx = int(round(seg["dst_start"] * sr))
    
    chunk = src_float[s_idx:s_idx + len_idx]
    chunk = apply_cosine_fades(chunk, seg["fade_in"], seg["fade_out"], sr)
    
    # Place into master
    actual_len = min(len(chunk), total_samples - d_idx)
    master_voice[d_idx:d_idx + actual_len] += chunk[:actual_len]
    print(f"Placed {seg['name']}: {seg['dst_start']:.2f}s -> {seg['dst_start'] + seg['src_dur']:.2f}s")

# Ensure no clipping in the speech stem
peak = np.max(np.abs(master_voice))
print(f"Master voice peak before scaling: {peak:.3f}")
if peak > 0.95:
    master_voice = (master_voice / peak) * 0.95
    print(f"Scaled master voice to 0.95 peak.")

# Save master voice stem
int_voice = np.clip(master_voice * 32767.0, -32768, 32767).astype(np.int16)
wavfile.write(out_master_voice, sr, int_voice)
print(f"Saved clean voice master to: {out_master_voice}")
print(f"Total duration: {len(int_voice) / sr:.3f}s (Samples: {len(int_voice)})")
