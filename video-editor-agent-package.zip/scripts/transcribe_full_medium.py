import json
from faster_whisper import WhisperModel

model = WhisperModel('medium', device='cpu', compute_type='int8')
segs, info = model.transcribe(r'f:\Antigravity\video editor\work\audiogram_part5\raw_audio.wav', word_timestamps=True, language='hi')

data = {'duration': info.duration, 'language': info.language, 'segments': []}
for s in segs:
    words = [{'word': w.word, 'start': round(w.start, 2), 'end': round(w.end, 2), 'prob': round(w.probability, 2)} for w in (s.words or [])]
    data['segments'].append({'start': round(s.start, 2), 'end': round(s.end, 2), 'text': s.text.strip(), 'words': words})

with open(r'f:\Antigravity\video editor\work\audiogram_part5\transcription_medium.json', 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2, ensure_ascii=False)

print(f"Transcription complete! Segments: {len(data['segments'])}")
for s in data['segments']:
    print(f"[{s['start']:05.2f} - {s['end']:05.2f}] {s['text']}")
