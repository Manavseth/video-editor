import subprocess
import os
import sys
import shutil

sys.stdout.reconfigure(encoding='utf-8')

OUT_DIR = 'out'
os.makedirs(OUT_DIR, exist_ok=True)

concat_txt = 'scratch/final_concat_list.txt'
segments = [
    'host_01.mp4',
    'motion_01.mp4',
    'host_02.mp4',
    'motion_02.mp4',
    'host_03.mp4',
    'motion_03.mp4',
    'host_04.mp4'
]

print("Verifying 7 video segments...")
for seg in segments:
    p = os.path.join('scratch', seg)
    if not os.path.exists(p):
        print(f"ERROR: Segment missing: {p}")
        sys.exit(1)
    # Check resolution & duration
    info = subprocess.check_output([
        'ffprobe', '-v', 'error', '-select_streams', 'v:0',
        '-show_entries', 'stream=width,height,r_frame_rate,duration',
        '-of', 'default=noprint_wrappers=1:nokey=1', p
    ], text=True).splitlines()
    print(f"  ✓ {seg}: {info[0]}x{info[1]}, fps={info[2]}, dur={float(info[3]):.3f}s")

with open(concat_txt, 'w', encoding='utf-8') as f:
    for seg in segments:
        abs_p = os.path.abspath(os.path.join('scratch', seg)).replace('\\', '/')
        f.write(f"file '{abs_p}'\n")

print(f"\n[OK] Concat list ready: {concat_txt}")

# Master output paths
master_output = os.path.join(OUT_DIR, 'environmental_classifier_master_reel.mp4')
soundtrack = 'scratch/master_soundtrack_14lufs.wav'

# Pre-Flight Audio Integrity Audit (Zero-Mistake Gate)
print(f"\n[AUDIT] Running pre-flight composite audio integrity audit on: {soundtrack}...")
audit_script = os.path.join(os.path.dirname(__file__), 'audit_composite_audio.py')
candidate_venvs = [
    os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".venv", "Scripts", "python.exe")),
    r"E:\codex\Documentry\.asr-venv\Scripts\python.exe",
    sys.executable
]
py_exec = next((p for p in candidate_venvs if os.path.exists(p)), sys.executable)
res = subprocess.run([py_exec, audit_script, soundtrack])
if res.returncode != 0:
    print("❌ CRITICAL FAIL: Composite soundtrack failed pre-flight audit! Aborting mux.")
    sys.exit(1)
print("✓ Composite soundtrack audit PASSED. Proceeding to delivery mux.")

print(f"\nMuxing 7 video segments with calibrated soundtrack: {soundtrack}...")
cmd = [
    'ffmpeg', '-y',
    '-f', 'concat',
    '-safe', '0',
    '-i', concat_txt,
    '-i', soundtrack,
    '-c:v', 'libx264',
    '-crf', '17',
    '-preset', 'fast',
    '-pix_fmt', 'yuv420p',
    '-c:a', 'aac',
    '-b:a', '192k',
    '-ar', '48000',
    '-shortest',
    master_output
]

res = subprocess.run(cmd, capture_output=True, text=True)
if res.returncode != 0:
    print("FFmpeg error:", res.stderr)
    sys.exit(1)

print(f"\n[OK] Final Master Reel encoded successfully: {master_output}")

# Measure final integrated loudness directly on the encoded MP4 file
print("\nMeasuring final loudness on encoded MP4 file (EBU R128)...")
loud_check = subprocess.run(
    ['ffmpeg', '-i', master_output, '-af', 'ebur128', '-f', 'null', '-'],
    capture_output=True, text=True
)
summary = False
for line in loud_check.stderr.splitlines():
    if 'Summary:' in line:
        summary = True
    if summary:
        print(line)

# Copy to required target delivery destinations
targets = [
    'F:/codex/Video Editor/environmental_classifier_reference_clips/environmental_classifier_master_reel.mp4',
    'F:/codex/Documentry/environmental_classifier_master_reel.mp4'
]

print("\nDeploying deliverables...")
for t in targets:
    try:
        os.makedirs(os.path.dirname(t), exist_ok=True)
        shutil.copy2(master_output, t)
        print(f"  ✓ Copied deliverable to: {t}")
    except Exception as e:
        print(f"  ! Note on copy to {t}: {e}")

print("\n" + "=" * 64)
print("PRODUCTION COMPLETE: FINAL MASTER REEL READY FOR INSTAGRAM")
print("=" * 64)
