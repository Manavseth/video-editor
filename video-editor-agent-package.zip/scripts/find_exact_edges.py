import numpy as np
import scipy.io.wavfile as wavfile
import sys

sys.stdout.reconfigure(encoding='utf-8')

wav_path = r"f:\Antigravity\video editor\work\rough_cut_classifier\audio.wav"
sr, data = wavfile.read(wav_path)
data = data.astype(np.float32) / 32768.0

# 1. Inspect head of Take 3 (99.5s to 101.5s)
s0 = int(99.5 * sr)
s1 = int(101.5 * sr)
chunk_head = data[s0:s1]

# Find speech onset: walk forward with 10ms window
win = int(0.01 * sr)
for i in range(0, len(chunk_head) - win, int(0.005 * sr)):
    rms = np.sqrt(np.mean(chunk_head[i:i+win]**2))
    t = 99.5 + i / sr
    if rms > 0.003: # voiced onset
        print(f"Voiced onset detected at: {t:.3f}s (RMS: {rms:.4f})")
        break

# 2. Inspect tail of Take 3 (153.5s to 154.8s)
s0 = int(153.5 * sr)
s1 = int(154.8 * sr)
chunk_tail = data[s0:s1]

# Walk backward to find speech release
for i in range(len(chunk_tail) - win, 0, -int(0.005 * sr)):
    rms = np.sqrt(np.mean(chunk_tail[i:i+win]**2))
    t = 153.5 + (i + win) / sr
    if rms > 0.003: # voiced release
        print(f"Voiced release detected at: {t:.3f}s (RMS: {rms:.4f})")
        break
