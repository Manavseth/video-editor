import os
import math
import random
from PIL import Image, ImageDraw

art_dir = r"C:\Users\Lenovo\.gemini\antigravity\brain\41ef0fe8-618e-4426-a591-9b8597667e48"
os.makedirs(art_dir, exist_ok=True)

W, H = 1080, 1920

def create_base_canvas():
    img = Image.new("RGB", (W, H), (10, 15, 29)) # Midnight slate
    draw = ImageDraw.Draw(img, "RGBA")
    
    # Radial glow in center
    for r in range(600, 0, -20):
        alpha = int(32 * (1.0 - (r / 600.0)) ** 1.8)
        draw.ellipse([W//2 - r, H//2 - 120 - r, W//2 + r, H//2 - 120 + r], fill=(255, 200, 100, alpha))
        
    # Ambient particles
    random.seed(101)
    for _ in range(30):
        px = random.randint(80, W - 80)
        py = random.randint(150, H - 350)
        pr = random.randint(2, 5)
        pa = random.randint(60, 170)
        draw.ellipse([px-pr, py-pr, px+pr, py+pr], fill=(255, 220, 130, pa))
        
    return img, draw

# ==============================================================
# FRAME 1: The Acoustic Chaos (Restaurant Noise vs Speech)
# ==============================================================
f1, d1 = create_base_canvas()
cx, cy = W // 2, H // 2 - 120

# Stylized Patient Silhouette Profile (Paper-cut vector style)
# Head & Neck
d1.ellipse([cx - 100, cy - 220, cx + 100, cy - 20], fill=(210, 190, 175, 255))
d1.rectangle([cx - 40, cy - 40, cx + 40, cy + 160], fill=(200, 180, 165, 255))
# Shoulders
d1.polygon([(cx - 240, cy + 240), (cx + 240, cy + 240), (cx + 140, cy + 140), (cx - 140, cy + 140)], fill=(35, 45, 65, 255))

# Ear & Hearing Aid
d1.ellipse([cx + 20, cy - 130, cx + 75, cy - 65], fill=(230, 200, 185, 255), outline=(190, 160, 145, 255), width=2)
# Glowing discreet RIC Hearing Aid on ear
d1.line([cx + 60, cy - 135, cx + 75, cy - 110, cx + 55, cy - 85], fill=(255, 205, 50, 255), width=7)
d1.ellipse([cx + 50, cy - 90, cx + 60, cy - 80], fill=(255, 230, 100, 255))

# Chaotic red/gray noise waves attacking from all directions
for r in [200, 280, 360, 440]:
    d1.arc([cx - r, cy - 100 - r, cx + r, cy - 100 + r], start=120, end=240, fill=(240, 80, 80, 180), width=3)
    d1.arc([cx - r + 80, cy - 80 - r, cx + r + 80, cy - 80 + r], start=-60, end=60, fill=(160, 180, 200, 140), width=3)

# Caliper badge: ACOUSTIC BABBLE: 82 dB
d1.rectangle([cx - 250, cy + 280, cx + 250, cy + 340], fill=(15, 20, 35, 220), outline=(240, 90, 90, 220), width=2)
d1.text((cx - 175, cy + 300), "RESTAURANT BABBLE: 82 dB SPL (CHAOTIC NOISE)", fill=(255, 180, 180, 255))

# Subtitle
d1.rectangle([cx - 480, 1500, cx + 480, 1620], fill=(0, 0, 0, 160))
d1.text((cx - 380, 1520), "WHY DO TRADITIONAL HEARING AIDS STRUGGLE", fill=(255, 255, 255, 255))
d1.text((cx - 300, 1565), "IN A CROWDED, NOISY ROOM?", fill=(255, 200, 60, 255))

# ==============================================================
# FRAME 2: The DSP Classifier Chip (Blueprint Wireframe)
# ==============================================================
f2, d2 = create_base_canvas()
# Blueprint technical grid lines
for gx in range(100, W, 80):
    d2.line([gx, 150, gx, H - 350], fill=(30, 45, 70, 70), width=1)
for gy in range(150, H - 350, 80):
    d2.line([100, gy, W - 100, gy], fill=(30, 45, 70, 70), width=1)

# Large Glowing Central Chip
d2.rectangle([cx - 180, cy - 180, cx + 180, cy + 180], fill=(12, 22, 38, 240), outline=(255, 205, 50, 255), width=4)
# Gold circuit trace lines
for offset in [-120, -60, 0, 60, 120]:
    d2.line([cx - 180, cy + offset, cx - 240, cy + offset], fill=(255, 200, 60, 200), width=3)
    d2.line([cx + 180, cy + offset, cx + 240, cy + offset], fill=(255, 200, 60, 200), width=3)
    d2.ellipse([cx - 246, cy + offset - 6, cx - 234, cy + offset + 6], fill=(255, 220, 100, 255))
    d2.ellipse([cx + 234, cy + offset - 6, cx + 246, cy + offset + 6], fill=(255, 220, 100, 255))

d2.text((cx - 140, cy - 70), "ENVIRONMENTAL", fill=(255, 255, 255, 255))
d2.text((cx - 120, cy - 30), "CLASSIFIER", fill=(255, 205, 50, 255))
d2.text((cx - 110, cy + 20), "DSP / NEURAL CORE", fill=(100, 210, 255, 220))

# Caliper dimension line
d2.line([cx - 240, cy + 240, cx + 240, cy + 240], fill=(255, 200, 70, 200), width=2)
d2.line([cx - 240, cy + 230, cx - 240, cy + 250], fill=(255, 200, 70, 255), width=3)
d2.line([cx + 240, cy + 230, cx + 240, cy + 250], fill=(255, 200, 70, 255), width=3)
d2.text((cx - 180, cy + 260), "SAMPLING RATE: 500 SCANS PER SECOND", fill=(255, 215, 100, 240))

# Subtitle
d2.rectangle([cx - 480, 1500, cx + 480, 1620], fill=(0, 0, 0, 160))
d2.text((cx - 390, 1520), "MODERN HEARING AIDS DON'T JUST AMPLIFY.", fill=(255, 255, 255, 255))
d2.text((cx - 330, 1565), "THEY CLASSIFY THE ACOUSTIC SCENE.", fill=(255, 200, 60, 255))

# ==============================================================
# FRAME 3: Feature Extraction (Speech Envelope vs Noise)
# ==============================================================
f3, d3 = create_base_canvas()

# Upper wave: Speech Modulation Envelope (Rhythmic, Golden)
d3.rectangle([cx - 380, cy - 250, cx + 380, cy - 70], fill=(15, 25, 45, 200), outline=(255, 205, 50, 180), width=2)
d3.text((cx - 340, cy - 235), "TARGET SPEECH: 3-4 Hz MODULATION ENVELOPE", fill=(255, 215, 80, 255))
pts_speech = []
for x in range(cx - 360, cx + 360, 5):
    y = (cy - 140) + math.sin((x - cx) * 0.04) * 35 * math.sin((x - cx) * 0.008)
    pts_speech.append((x, y))
for i in range(len(pts_speech) - 1):
    d3.line([pts_speech[i], pts_speech[i+1]], fill=(255, 210, 60, 255), width=4)

# Lower wave: Steady-State Noise (Random, Slate/Red)
d3.rectangle([cx - 380, cy - 30, cx + 380, cy + 150], fill=(15, 25, 45, 200), outline=(100, 180, 255, 140), width=2)
d3.text((cx - 340, cy - 15), "BACKGROUND NOISE: RANDOM / STEADY AMPLITUDE", fill=(160, 190, 220, 255))
pts_noise = []
random.seed(99)
for x in range(cx - 360, cx + 360, 6):
    y = (cy + 70) + random.uniform(-18, 18)
    pts_noise.append((x, y))
for i in range(len(pts_noise) - 1):
    d3.line([pts_noise[i], pts_noise[i+1]], fill=(120, 160, 200, 200), width=3)

# Caliper comparison tag
d3.rectangle([cx - 260, cy + 200, cx + 260, cy + 260], fill=(20, 30, 50, 240), outline=(100, 220, 255, 200), width=2)
d3.text((cx - 210, cy + 220), "SNR SEPARATION: +8.5 dB ADVANTAGE", fill=(100, 240, 255, 255))

# Subtitle
d3.rectangle([cx - 480, 1500, cx + 480, 1620], fill=(0, 0, 0, 160))
d3.text((cx - 370, 1520), "THE CHIP EXTRACTS SPEECH ENVELOPES", fill=(255, 255, 255, 255))
d3.text((cx - 340, 1565), "FROM CONSTANT BACKGROUND NOISE.", fill=(255, 200, 60, 255))

# ==============================================================
# FRAME 4: 4 Dynamic Environmental Cards (Faith vs Fact Tablet Style)
# ==============================================================
f4, d4 = create_base_canvas()

# 4 Floating scene tablets (2x2 grid)
cards = [
    ("QUIET HOME", "Omnidirectional 360°", "Max Acoustic Comfort", cx - 210, cy - 140),
    ("NOISY DINNER", "Narrow Beamforming", "-12dB Rear Babble", cx + 210, cy - 140),
    ("OUTDOOR WIND", "Phase Cancellation", "Zero Wind Turbulence", cx - 210, cy + 120),
    ("LIVE MUSIC", "Extended Headroom", "Full Dynamic Range", cx + 210, cy + 120)
]

for title, mode, benefit, c_x, c_y in cards:
    # Golden tablet border like manuscript card
    d4.rectangle([c_x - 180, c_y - 90, c_x + 180, c_y + 90], fill=(16, 26, 44, 230), outline=(255, 205, 50, 220), width=3)
    d4.text((c_x - 140, c_y - 65), title, fill=(255, 220, 80, 255))
    d4.text((c_x - 150, c_y - 15), f"Mode: {mode}", fill=(240, 240, 240, 220))
    d4.text((c_x - 150, c_y + 25), f"Gain: {benefit}", fill=(100, 220, 255, 220))

# Subtitle
d4.rectangle([cx - 480, 1500, cx + 480, 1620], fill=(0, 0, 0, 160))
d4.text((cx - 400, 1520), "IT INSTANTLY SWITCHES BETWEEN ENVIRONMENTS", fill=(255, 255, 255, 255))
d4.text((cx - 280, 1565), "WITHOUT TOUCHING A SINGLE BUTTON.", fill=(255, 200, 60, 255))

# ==============================================================
# FRAME 5: The Clarity Dome & Clinical Benefit
# ==============================================================
f5, d5 = create_base_canvas()

# Patient inside an illuminated golden Acoustic Protection Dome
for r in range(380, 200, -15):
    alpha = int(40 * (1.0 - ((r-200)/180.0)))
    d5.ellipse([cx - r, cy - 40 - r, cx + r, cy - 40 + r], outline=(255, 215, 60, alpha), width=3)

# Patient in center (serene, focused)
d5.ellipse([cx - 70, cy - 140, cx + 70, cy], fill=(225, 205, 190, 255))
d5.rectangle([cx - 30, cy, cx + 30, cy + 140], fill=(215, 195, 180, 255))
d5.polygon([(cx - 160, cy + 200), (cx + 160, cy + 200), (cx + 90, cy + 120), (cx - 90, cy + 120)], fill=(40, 55, 80, 255))
# Glowing hearing aid
d5.line([cx + 45, cy - 80, cx + 55, cy - 60, cx + 40, cy - 40], fill=(255, 215, 50, 255), width=6)

# Clinical stats badge
d5.rectangle([cx - 300, cy + 230, cx + 300, cy + 310], fill=(12, 22, 38, 240), outline=(255, 205, 50, 255), width=2)
d5.text((cx - 270, cy + 250), "LISTENING FATIGUE: -40% | CLARITY: +65%", fill=(255, 220, 80, 255))
d5.text((cx - 220, cy + 280), "SEAMLESS AUTOMATIC ACOUSTIC COMFORT", fill=(100, 220, 255, 220))

# Subtitle
d5.rectangle([cx - 480, 1500, cx + 480, 1620], fill=(0, 0, 0, 160))
d5.text((cx - 340, 1520), "ZERO EFFORT. ZERO STRUGGLE.", fill=(255, 255, 255, 255))
d5.text((cx - 360, 1565), "JUST EFFORTLESS, NATURAL CONVERSATION.", fill=(255, 200, 60, 255))

# Save all 5 frames
frame_paths = []
for idx, frame in enumerate([f1, f2, f3, f4, f5], 1):
    fp = os.path.join(art_dir, f"beat_{idx}_frame.jpg")
    frame.save(fp, quality=90)
    frame_paths.append(fp)
    print(f"Saved Beat {idx}: {fp}")

# Compile into a 5-frame contact sheet strip (1080x384 each -> 1080 x 1920 or 5 columns)
sheet_w, sheet_h = 1080, 1920
strip_h = sheet_h // 5
contact_sheet = Image.new("RGB", (sheet_w, sheet_h), (10, 10, 10))
for idx, fp in enumerate(frame_paths):
    img = Image.open(fp)
    thumb = img.resize((sheet_w, strip_h), Image.Resampling.LANCZOS)
    contact_sheet.paste(thumb, (0, idx * strip_h))

contact_sheet_path = os.path.join(art_dir, "storyboard_classifier_contact_sheet.jpg")
contact_sheet.save(contact_sheet_path, quality=85)
print(f"Saved master contact sheet: {contact_sheet_path}")
