import puppeteer from 'puppeteer-core';
import fs from 'fs';
import path from 'path';

const edgePath = 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const OUT_DIR = path.resolve('scratch/subtitles');
fs.mkdirSync(OUT_DIR, { recursive: true });

const CUES = [
  { id: 1,  lines: ['Phone ko <span style="color:#2D8C85;font-weight:700">direct sunlight</span> se', 'apne room me le jao,'] },
  { id: 2,  lines: ['to brightness <span style="color:#2D8C85;font-weight:700">automatically adjust</span>', 'hoti hai, right?'] },
  { id: 3,  lines: ['Kuch hearing aids me <span style="color:#2D8C85;font-weight:700">environmental classifier</span>', 'bhi hota hai,'] },
  { id: 4,  lines: ['jo <span style="color:#2D8C85;font-weight:700">environment</span> samajhne me', 'help karta hai,'] },
  { id: 5,  lines: ['jaise ek <span style="color:#2D8C85;font-weight:700">quiet conversation</span>', 'ya ek <span style="color:#2D8C85;font-weight:700">busy restaurant</span>.'] },
  { id: 6,  lines: ['Phir device apne <span style="color:#2D8C85;font-weight:700">model aur fitting</span>', 'ke hisaab se,'] },
  { id: 7,  lines: ['settings ko automatically <span style="color:#2D8C85;font-weight:700">change</span> kar sakta hai,', 'ya <span style="color:#2D8C85;font-weight:700">blend</span> kar sakta hai.'] },
  { id: 8,  lines: ['Day to day life me patient ko', 'har jagah ruk kar,'] },
  { id: 9,  lines: ['apna program switch karne ki problem,', '<span style="color:#2D8C85;font-weight:700">bilkul khatam</span>.'] },
  { id: 10, lines: ['Yeh koi <span style="color:#2D8C85;font-weight:700">mind reader</span> nahi hai,'] },
  { id: 11, lines: ['aur na hi yeh <span style="color:#2D8C85;font-weight:700">noise</span> ko bilkul', 'poori tarah se khatam karta hai.'] },
  { id: 12, lines: ['Bas yeh room ya environment ka <span style="color:#2D8C85;font-weight:700">context</span>', 'samajhne me help karta hai,'] },
  { id: 13, lines: ['aur patient ko <span style="color:#2D8C85;font-weight:700">baat-cheet samajhne</span> me', 'help karta hai,'] },
  { id: 14, lines: ['aur patient ko har jagah ruk kar', 'apne hearing aid ka,'] },
  { id: 15, lines: ['<span style="color:#2D8C85;font-weight:700">remote control operator</span> banne ki problem,', '<span style="color:#2D8C85;font-weight:700">bilkul khatam!</span>'] }
];

async function main() {
  console.log('Rendering 15 standardized subtitle plates (ultra-fast offline)...');
  const browser = await puppeteer.launch({
    executablePath: edgePath,
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1080, height: 1920, deviceScaleFactor: 1 });

  const initialHtml = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    width: 1080px;
    height: 1920px;
    background: transparent;
    overflow: hidden;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  }
  .caption-container {
    position: absolute;
    left: 72px;
    top: 1460px;
    width: 858px;
    height: 148px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    background: rgba(251, 250, 247, 0.96);
    border: 2.5px solid #20252B;
    border-radius: 24px;
    box-shadow: 0 10px 30px rgba(32, 37, 43, 0.12);
    padding: 16px 28px;
  }
  #caption-text {
    font-size: 40px;
    font-weight: 600;
    line-height: 1.35;
    color: #20252B;
  }
</style>
</head>
<body>
  <div class="caption-container">
    <div id="caption-text"></div>
  </div>
</body>
</html>`;

  await page.setContent(initialHtml, { waitUntil: 'domcontentloaded' });

  for (const cue of CUES) {
    await page.evaluate((lines, singleLine) => {
      const el = document.getElementById('caption-text');
      el.style.fontSize = singleLine ? '46px' : '40px';
      el.innerHTML = lines.join('<br>');
    }, cue.lines, cue.lines.length === 1);

    const outPath = path.join(OUT_DIR, `sub_${String(cue.id).padStart(2, '0')}.png`);
    await page.screenshot({ path: outPath, omitBackground: true });
    console.log(`  ✓ Subtitle Cue ${cue.id} saved: ${outPath}`);
  }

  await browser.close();
  console.log('✓ All 15 subtitle plates rendered successfully!');
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
