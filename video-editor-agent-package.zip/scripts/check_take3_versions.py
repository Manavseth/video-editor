import whisper
import scipy.io.wavfile as wavfile

model = whisper.load_model("base")
raw_wav = r"f:\Antigravity\video editor\work\reel_whatsapp\audio_boosted.wav"
sr, data = wavfile.read(raw_wav)

for t0, t1 in [(133.0, 140.0), (141.0, 148.0)]:
    s0 = int(t0 * sr)
    s1 = int(t1 * sr)
    chunk = data[s0:s1]
    temp_wav = f"work/reel_whatsapp/temp_check_{int(t0)}.wav"
    wavfile.write(temp_wav, sr, chunk)
    res = model.transcribe(temp_wav, language="hi")
    print(f"\n[{t0}s - {t1}s]: {res['text']}")
