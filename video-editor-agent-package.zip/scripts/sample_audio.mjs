import { execSync } from 'child_process';
import fs from 'fs';

// Let's analyze the audio content of each ref:
// 1. Is there speech? We can inspect silence, harmonic content, or use a speech activity detector or transcode to text if whisper is available or inspect spectral distribution.
// 2. Let's dump spectral distribution across bands: Sub-bass (20-100Hz), Bass (100-300Hz), Mid (300-2000Hz), Presence (2000-5000Hz), Brilliance (5000-20000Hz).

for (let i = 1; i <= 8; i++) {
  const file = `work/style-refs/so_thats_how/all_videos/ref_${i}.mp4`;
  // Extract 15s audio wav
  const wavPath = `work/style-refs/so_thats_how/deep_analysis/ref_${i}_sample.wav`;
  execSync(`ffmpeg -y -i "${file}" -t 15 -ac 1 -ar 16000 "${wavPath}" 2>NUL`);
  
  // Run astats on the wav
  const astats = execSync(`ffmpeg -i "${wavPath}" -af "astats=metadata=1:reset=1,ametadata=print:key=lavfi.astats.Overall.RMS_level" -f null NUL 2>&1`).toString();
  const rmsLevels = [...astats.matchAll(/RMS_level=([-\d.]+)/g)].map(m => parseFloat(m[1]));
  const avgRms = rmsLevels.length ? (rmsLevels.reduce((a, b) => a + b, 0) / rmsLevels.length).toFixed(1) : 'N/A';

  console.log(`Ref ${i}: Avg RMS = ${avgRms} dBFS, length = 15s`);
}
