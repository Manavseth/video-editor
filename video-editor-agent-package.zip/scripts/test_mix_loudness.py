import subprocess
import os

work_dir = r"f:\Antigravity\video editor\work\reel_whatsapp"
voice_wav = os.path.join(work_dir, "clean_voice_master.wav")
bed_wav = r"f:\Antigravity\video editor\remotion_ci_reel\public\classifier_soundtrack.wav"
out_mixed = os.path.join(work_dir, "master_audio_mixed.wav")

cmd = [
    "ffmpeg", "-y",
    "-i", voice_wav,
    "-i", bed_wav,
    "-filter_complex",
    "[0:a]volume=2.0[voice];"
    "[1:a]aloop=loop=-1:size=2e+09,atrim=0:35.865,volume=0.18[bed];"
    "[voice][bed]amix=inputs=2:duration=first:weights=1.0 0.25,"
    "loudnorm=I=-14.0:TP=-1.0:LRA=7.0:print_format=json[aout]",
    "-map", "[aout]",
    "-ar", "48000",
    "-ac", "2",
    out_mixed
]

ret = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
print("=== FFmpeg Output ===")
for line in ret.stderr.splitlines():
    if "input_i" in line or "output_i" in line or "output_tp" in line or "output_lra" in line:
        print(line)
