import os
import subprocess
import json

raw_video = r"E:\Courses\WhatsApp Video 2026-10-25 at 9.04.58 PM.mp4"
code_video = r"f:\Antigravity\video editor\out\ClassifierMasterReel_Revised_35s.mp4"
master_audio = r"f:\Antigravity\video editor\work\reel_whatsapp\master_audio_mixed.wav"
out_dir = r"f:\Antigravity\video editor\out\individual_clips"
work_dir = r"f:\Antigravity\video editor\work\reel_whatsapp"
os.makedirs(out_dir, exist_ok=True)

# 11 Clips specification with precise audio & video sync
clips = [
    {
        "id": "S01",
        "filename": "clip_01_host_hook.mp4",
        "type": "host",
        "raw_ss": 41.15,
        "timeline_start": 0.000,
        "duration": 3.200,
        "desc": "Host hook: Kuch hearing aids mein environmental classifier..."
    },
    {
        "id": "S02",
        "filename": "clip_02_code_chaos.mp4",
        "type": "code",
        "code_ss": 0.000,
        "timeline_start": 3.200,
        "duration": 3.200,
        "desc": "Code Scene 1: Acoustic babble (82 dB SPL) attacking ear"
    },
    {
        "id": "S03",
        "filename": "clip_03_host_concept.mp4",
        "type": "host",
        "raw_ss": 47.55,
        "timeline_start": 6.400,
        "duration": 3.200,
        "desc": "Host concept: ...jo environment pehchanne ki koshish karta hai..."
    },
    {
        "id": "S04",
        "filename": "clip_04_code_dsp_chip.mp4",
        "type": "code",
        "code_ss": 9.600,
        "timeline_start": 9.600,
        "duration": 3.200,
        "desc": "Code Scene 4: Blueprint DSP classifier core"
    },
    {
        "id": "S05",
        "filename": "clip_05_code_modulation.mp4",
        "type": "code",
        "code_ss": 12.800,
        "timeline_start": 12.800,
        "duration": 3.200,
        "desc": "Code Scene 5: Speech modulation & dynamic noise attenuation"
    },
    {
        "id": "S06",
        "filename": "clip_06_host_settings.mp4",
        "type": "host",
        "raw_ss": 79.20,
        "timeline_start": 16.000,
        "duration": 3.200,
        "desc": "Host settings: Hearing aid settings ko apne model aur fitting ke hisaab se..."
    },
    {
        "id": "S07",
        "filename": "clip_07_code_matrix.mp4",
        "type": "code",
        "code_ss": 28.800,
        "timeline_start": 19.200,
        "duration": 3.200,
        "desc": "Code Scene 10: Autonomous scene switching matrix"
    },
    {
        "id": "S08",
        "filename": "clip_08_host_caveat.mp4",
        "type": "host",
        "raw_ss": 134.30,
        "timeline_start": 22.400,
        "duration": 3.200,
        "desc": "Host caveat: Par yeh mind reader nahi hai..."
    },
    {
        "id": "S09",
        "filename": "clip_09_code_subtraction.mp4",
        "type": "code",
        "code_ss": 16.000,
        "timeline_start": 25.600,
        "duration": 3.200,
        "desc": "Code Scene 6: Noise attenuation and SNR advantage"
    },
    {
        "id": "S10",
        "filename": "clip_10_host_context.mp4",
        "type": "host",
        "raw_ss": 155.20,
        "timeline_start": 28.800,
        "duration": 3.200,
        "desc": "Host context: Yeh bas room ka context samajhne mein help karta hai..."
    },
    {
        "id": "S11",
        "filename": "clip_11_host_punchline.mp4",
        "type": "host",
        "raw_ss": 166.50,
        "timeline_start": 32.000,
        "duration": 3.865,
        "desc": "Host punchline: Taaki patient ko remote control operator na banna pade!"
    }
]

print(f"=== Rendering {len(clips)} Individual Production Clips ===")

for idx, c in enumerate(clips):
    target = os.path.join(out_dir, c["filename"])
    print(f"\n[{idx+1}/{len(clips)}] Rendering {c['filename']} ({c['duration']}s)...")
    
    # Extract audio slice for this clip from master_audio_mixed.wav
    temp_audio = os.path.join(work_dir, f"temp_audio_{c['id']}.wav")
    cmd_audio = [
        "ffmpeg", "-y",
        "-ss", str(c["timeline_start"]),
        "-t", str(c["duration"]),
        "-i", master_audio,
        "-c:a", "pcm_s16le",
        "-ar", "48000",
        "-ac", "2",
        temp_audio
    ]
    subprocess.run(cmd_audio, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    if c["type"] == "host":
        # Video from raw camera footage + Audio from continuous master stem
        cmd = [
            "ffmpeg", "-y",
            "-ss", str(c["raw_ss"]),
            "-t", str(c["duration"]),
            "-i", raw_video,
            "-i", temp_audio,
            "-vf", "crop=608:1080:656:0,scale=1080:1920,setsar=1:1,fps=30",
            "-map", "0:v:0",
            "-map", "1:a:0",
            "-c:v", "libx264", "-preset", "slow", "-crf", "18", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2",
            "-fps_mode", "cfr",
            "-avoid_negative_ts", "make_zero",
            target
        ]
    else:
        # Video from Remotion code animation + Audio from continuous master stem
        cmd = [
            "ffmpeg", "-y",
            "-ss", str(c["code_ss"]),
            "-t", str(c["duration"]),
            "-i", code_video,
            "-i", temp_audio,
            "-vf", "scale=1080:1920,setsar=1:1,fps=30",
            "-map", "0:v:0",
            "-map", "1:a:0",
            "-c:v", "libx264", "-preset", "slow", "-crf", "18", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2",
            "-fps_mode", "cfr",
            "-avoid_negative_ts", "make_zero",
            target
        ]
        
    ret = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if ret.returncode != 0:
        print(f"Error rendering {c['filename']}:\n{ret.stderr[-500:]}")
        raise RuntimeError(f"Failed to render {c['filename']}")
    else:
        size_kb = os.path.getsize(target) / 1024.0
        print(f"[OK] Rendered: {c['filename']} ({size_kb:.1f} KB)")

print("\nAll 11 individual clips rendered successfully with 48kHz Stereo audio!")
