import subprocess
import os
import sys
import io

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

OUT_DIR = 'out'
os.makedirs(OUT_DIR, exist_ok=True)

# 1. Write concat list
concat_txt = 'scratch/concat_list.txt'
segments = [
    'host_01.mp4',
    'motion_01.mp4',
    'host_02.mp4',
    'motion_02.mp4',
    'host_03.mp4',
    'motion_03.mp4',
    'host_04.mp4'
]

with open(concat_txt, 'w', encoding='utf-8') as f:
    for seg in segments:
        abs_path = os.path.abspath(os.path.join('scratch', seg)).replace('\\', '/')
        f.write(f"file '{abs_path}'\n")

print(f"✓ Concat list written: {concat_txt}")

# 2. Concat video stream and mux with calibrated -14 LUFS audio
master_output = os.path.join(OUT_DIR, 'environmental_classifier_master_reel.mp4')
voice_audio = 'scratch/audio_v2/master_voice_from_download.wav'

# Pre-Flight Audio Integrity Audit (Zero-Mistake Gate)
print(f"\n[AUDIT] Running pre-flight composite audio integrity audit on: {voice_audio}...")
audit_script = os.path.join(os.path.dirname(__file__), 'audit_composite_audio.py')
candidate_venvs = [
    os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".venv", "Scripts", "python.exe")),
    r"E:\codex\Documentry\.asr-venv\Scripts\python.exe",
    sys.executable
]
py_exec = next((p for p in candidate_venvs if os.path.exists(p)), sys.executable)
res = subprocess.run([py_exec, audit_script, voice_audio])
if res.returncode != 0:
    print("❌ CRITICAL FAIL: Voice audio failed pre-flight audit! Aborting mux.")
    sys.exit(1)
print("✓ Voice audio audit PASSED. Proceeding to delivery mux.")

print("Muxing 7 video segments with normalized audio...")
cmd = [
    'ffmpeg', '-y',
    '-f', 'concat',
    '-safe', '0',
    '-i', concat_txt,
    '-i', voice_audio,
    '-c:v', 'libx264',
    '-crf', '17',
    '-preset', 'fast',
    '-pix_fmt', 'yuv420p',
    '-af', 'loudnorm=I=-14:LRA=7:tp=-1.0',
    '-c:a', 'aac',
    '-b:a', '192k',
    '-ar', '48000',
    '-shortest',
    master_output
]

res = subprocess.run(cmd, capture_output=True, text=True)
if res.returncode != 0:
    print("FFmpeg error:", res.stderr)
    exit(1)

print(f"✓ Master Reel encoded successfully: {master_output}")

# 3. Verify final loudness on the encoded MP4 file
print("\nMeasuring final loudness on encoded file (EBU R128)...")
loud_check = subprocess.run(['ffmpeg', '-i', master_output, '-af', 'ebur128', '-f', 'null', '-'], capture_output=True, text=True)
summary = False
for line in loud_check.stderr.splitlines():
    if 'Summary:' in line:
        summary = True
    if summary:
        print(line)

# 4. Copy to target delivery directories
targets = [
    'F:/codex/Documentry/environmental_classifier_master_reel.mp4',
    'F:/codex/Video Editor/environmental_classifier_reference_clips/environmental_classifier_master_reel.mp4'
]

for t in targets:
    try:
        os.makedirs(os.path.dirname(t), exist_ok=True)
        import shutil
        shutil.copy2(master_output, t)
        print(f"✓ Copied deliverable to: {t}")
    except Exception as e:
        print(f"! Note on copy to {t}: {e}")

print("\n================================================================")
print("PRODUCTION COMPLETE: MASTER REEL ASSEMBLED AND DELIVERED")
print("================================================================")
