import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open(r"f:\Antigravity\video editor\work\rough_cut_classifier\transcription.json", encoding="utf-8") as f:
    data = json.load(f)

words = data["words"]

print("=== ALL WORDS WITH TIMESTAMPS ===")
line = []
for i, w in enumerate(words):
    line.append(w)
    # Break line on punctuation or pause > 0.5s
    is_break = False
    if i < len(words) - 1:
        gap = words[i+1]["start"] - w["end"]
        if gap > 0.4:
            is_break = True
    else:
        is_break = True
    
    if any(p in w["word"] for p in [".", ",", "!", "?"]) or is_break:
        t0 = line[0]["start"]
        t1 = line[-1]["end"]
        txt = "".join(x["word"] for x in line)
        gap_next = f"(gap: {words[i+1]['start'] - t1:.2f}s)" if i < len(words) - 1 else ""
        print(f"[{t0:6.2f} - {t1:6.2f}] (dur {t1-t0:4.2f}s) {txt:<50} {gap_next}")
        line = []
