import subprocess
import json
import os
import sys
from faster_whisper import WhisperModel

sys.stdout.reconfigure(encoding='utf-8')

video_path = r"f:\Antigravity\video editor\out\environmental_classifier_perfect_take.mp4"
work_dir = r"f:\Antigravity\video editor\work\rough_cut_classifier"
cut_wav = os.path.join(work_dir, "perfect_take_cut.wav")

cmd = ["ffmpeg", "-y", "-i", video_path, "-vn", "-ac", "1", "-ar", "16000", cut_wav]
subprocess.run(cmd, check=True)

print("Audio extracted from cut video. Loading Whisper model...")
model = WhisperModel("small", device="cpu", compute_type="int8")

# 1. Hindi transcription with word timestamps
print("Transcribing Hindi/Hinglish words...")
segs_hi, _ = model.transcribe(cut_wav, language="hi", word_timestamps=True)
words_hi = []
for s in segs_hi:
    print(f"[{s.start:5.2f} - {s.end:5.2f}] {s.text}")
    for w in s.words:
        words_hi.append({"word": w.word, "start": round(w.start, 3), "end": round(w.end, 3)})

# 2. English translation with word timestamps
print("\nTranslating to English words...")
segs_en, _ = model.transcribe(cut_wav, task="translate", word_timestamps=True)
words_en = []
for s in segs_en:
    print(f"[{s.start:5.2f} - {s.end:5.2f}] {s.text}")
    for w in s.words:
        words_en.append({"word": w.word, "start": round(w.start, 3), "end": round(w.end, 3)})

out_data = {
    "hindi_words": words_hi,
    "english_words": words_en
}
with open(os.path.join(work_dir, "perfect_take_words.json"), "w", encoding="utf-8") as f:
    json.dump(out_data, f, indent=2, ensure_ascii=False)

print("Transcription and translation complete!")
