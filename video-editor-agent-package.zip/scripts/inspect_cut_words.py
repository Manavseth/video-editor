import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open(r"f:\Antigravity\video editor\work\rough_cut_classifier\perfect_take_words.json", encoding="utf-8") as f:
    data = json.load(f)

print("=== HINDI WORDS ===")
for i, w in enumerate(data["hindi_words"]):
    print(f"{i:03d}: [{w['start']:5.2f} - {w['end']:5.2f}] {w['word']}")
