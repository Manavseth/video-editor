import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open(r"f:\Antigravity\video editor\work\rough_cut_classifier\transcription.json", encoding="utf-8") as f:
    data = json.load(f)

words = data["words"]

# Let's inspect words in the 3 major take zones:
# Take 1: 0s - 45s
# Take 2: 45s - 95s
# Take 3: 95s - 155s

for name, t0, t1 in [("TAKE ZONE 1", 0.0, 47.0), ("TAKE ZONE 2", 47.0, 96.0), ("TAKE ZONE 3", 96.0, 155.0)]:
    w_zone = [w for w in words if t0 <= w["start"] < t1]
    print(f"\n{'='*20} {name} ({t0}s - {t1}s, {len(w_zone)} words) {'='*20}")
    # Group into sentences
    cur = []
    for w in w_zone:
        cur.append(w)
        if any(p in w["word"] for p in [".", ",", "!", "?"]) or (cur and w["end"] - cur[0]["start"] > 4.0):
            print(f"[{cur[0]['start']:6.2f} - {cur[-1]['end']:6.2f}] {''.join(x['word'] for x in cur)}")
            cur = []
    if cur:
        print(f"[{cur[0]['start']:6.2f} - {cur[-1]['end']:6.2f}] {''.join(x['word'] for x in cur)}")
