import numpy as np
import scipy.io.wavfile as wavfile
import sys

sys.stdout.reconfigure(encoding='utf-8')

wav_path = r"f:\Antigravity\video editor\work\rough_cut_classifier\audio.wav"
sr, data = wavfile.read(wav_path)
data = data.astype(np.float32) / 32768.0

# Focus on 99.0s to 154.8s
t_start = 99.0
t_end = 154.866
s0 = int(t_start * sr)
s1 = int(t_end * sr)
chunk = data[s0:s1]

hop = int(0.01 * sr) # 10ms
win = int(0.03 * sr) # 30ms
n_frames = (len(chunk) - win) // hop
rms = np.zeros(n_frames)
for i in range(n_frames):
    rms[i] = np.sqrt(np.mean(chunk[i*hop : i*hop + win]**2))

noise_floor = np.percentile(rms, 15)
thresh = noise_floor * 3.0

print(f"Noise floor: {noise_floor:.5f}, Speech thresh: {thresh:.5f}")

# Find all pauses > 0.35s in Take 3
is_silent = rms < thresh
min_silent_frames = int(0.35 / 0.01)

pauses = []
in_silence = False
sil_start = 0

for i, sil in enumerate(is_silent):
    if sil:
        if not in_silence:
            in_silence = True
            sil_start = i
    else:
        if in_silence:
            dur_f = i - sil_start
            if dur_f >= min_silent_frames:
                t0_p = t_start + sil_start * 0.01
                t1_p = t_start + i * 0.01
                pauses.append((t0_p, t1_p, t1_p - t0_p))
            in_silence = False

print(f"\nFound {len(pauses)} pauses > 0.35s in Take 3 (99.0s - 154.8s):")
for p0, p1, dur in pauses:
    print(f"Pause: {p0:6.2f}s -> {p1:6.2f}s (dur: {dur:4.2f}s)")
