import numpy as np
import scipy.io.wavfile as wavfile
import sys
from faster_whisper import WhisperModel

sys.stdout.reconfigure(encoding='utf-8')

wav_path = r"f:\Antigravity\video editor\work\rough_cut_classifier\audio.wav"
sr, data = wavfile.read(wav_path)

model = WhisperModel("small", device="cpu", compute_type="int8")

# Let's inspect the entire segment from 98.0s to 154.8s with word timestamps
t0 = 98.0
t1 = 154.866
s0 = int(t0 * sr)
s1 = int(t1 * sr)
chunk = data[s0:s1]

tmp_path = r"f:\Antigravity\video editor\work\rough_cut_classifier\take3_full.wav"
wavfile.write(tmp_path, sr, chunk)

print(f"Transcribing Take 3 region ({t0}s - {t1}s)...")
segs, info = model.transcribe(tmp_path, word_timestamps=True, language="hi")

print(f"Detected language: {info.language}")
for seg in segs:
    print(f"\n--- Segment [{t0 + seg.start:.2f}s -> {t0 + seg.end:.2f}s]: {seg.text}")
    for w in seg.words:
        print(f"    [{t0 + w.start:6.2f} - {t0 + w.end:6.2f}] (prob {w.probability:.2f}) {w.word}")
