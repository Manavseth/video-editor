import wave, struct, math

w = wave.open(r"f:\Antigravity\video editor\work\audiogram_part5\raw_audio.wav", "rb")
sr = w.getframerate()
n_frames = w.getnframes()
raw = w.readframes(n_frames)
samples = struct.unpack("<" + "h" * n_frames, raw)

def get_energy_profile(t_start, t_end, step_ms=50):
    step_samples = int(sr * step_ms / 1000.0)
    start_sample = int(t_start * sr)
    end_sample = int(t_end * sr)
    print(f"Energy profile from {t_start:.2f}s to {t_end:.2f}s (step={step_ms}ms):")
    for s_idx in range(start_sample, end_sample, step_samples):
        cur_t = s_idx / sr
        chunk = samples[s_idx : s_idx + step_samples]
        rms = math.sqrt(sum(s**2 for s in chunk) / len(chunk)) if chunk else 0
        db = 20 * math.log10(rms) if rms > 0 else -100
        print(f"  {cur_t:06.3f}s: RMS={rms:6.1f} | dB={db:5.1f}")

print("=== CLIP 1 HEAD (around 04.14s) ===")
get_energy_profile(3.8, 4.4, step_ms=50)

print("\n=== CLIP 1 TAIL (around 08.82s) ===")
get_energy_profile(8.5, 9.1, step_ms=50)

print("\n=== CLIP 2 HEAD (around 21.66s) ===")
get_energy_profile(21.4, 22.0, step_ms=50)

print("\n=== CLIP 2 TAIL (around 26.08s) ===")
get_energy_profile(25.8, 26.4, step_ms=50)
