import os
import subprocess

clip_dir = r"f:\Antigravity\video editor\out\individual_clips"
work_dir = r"f:\Antigravity\video editor\work\reel_whatsapp"
master_audio = os.path.join(work_dir, "master_audio_mixed.wav")
out_master = r"f:\Antigravity\video editor\out\ClassifierMasterReel_Hybrid_35s.mp4"

# 1. Create concat file list
concat_list_path = os.path.join(work_dir, "concat_clips.txt")
clips = [
    "clip_01_host_hook.mp4",
    "clip_02_code_chaos.mp4",
    "clip_03_host_concept.mp4",
    "clip_04_code_dsp_chip.mp4",
    "clip_05_code_modulation.mp4",
    "clip_06_host_settings.mp4",
    "clip_07_code_matrix.mp4",
    "clip_08_host_caveat.mp4",
    "clip_09_code_subtraction.mp4",
    "clip_10_host_context.mp4",
    "clip_11_host_punchline.mp4"
]

with open(concat_list_path, "w", encoding="utf-8") as f:
    for c in clips:
        p = os.path.join(clip_dir, c).replace("\\", "/")
        f.write(f"file '{p}'\n")

print("Concat list written.")

# 2. Concat video stream and mux with full 35.865s master audio
cmd_assemble = [
    "ffmpeg", "-y",
    "-f", "concat", "-safe", "0",
    "-i", concat_list_path,
    "-i", master_audio,
    "-map", "0:v:0",
    "-map", "1:a:0",
    "-c:v", "libx264", "-preset", "slow", "-crf", "18", "-pix_fmt", "yuv420p",
    "-r", "30",
    "-fps_mode", "cfr",
    "-t", "35.865",
    "-c:a", "aac", "-b:a", "256k", "-ar", "48000",
    "-movflags", "+faststart",
    out_master
]

print("Assembling final Master Reel...")
subprocess.run(cmd_assemble, check=True)
print(f"Master Reel successfully assembled at: {out_master}")

# 3. Print probe verification
cmd_probe = [
    "ffprobe", "-v", "error",
    "-show_entries", "format=duration,size:stream=codec_type,codec_name,width,height,r_frame_rate,channels,sample_rate",
    "-of", "json",
    out_master
]
res = subprocess.run(cmd_probe, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
print("\n=== Probe Verification ===")
print(res.stdout)
