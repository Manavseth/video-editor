import json

with open(r"f:\Antigravity\video editor\work\audiogram_part5\transcription_medium.json", encoding="utf-8") as f:
    d = json.load(f)

for i, seg in enumerate(d['segments']):
    print(f"=== SEGMENT {i} [{seg['start']} - {seg['end']}] ===")
    print("Text:", seg['text'])
    for w in seg.get('words', []):
        print(f"  {w['start']:05.2f} - {w['end']:05.2f}: {w['word']}")
