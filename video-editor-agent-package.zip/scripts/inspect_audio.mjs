import { execSync } from 'child_process';

for (let i = 1; i <= 8; i++) {
  const file = `work/style-refs/so_thats_how/all_videos/ref_${i}.mp4`;
  try {
    const out = execSync(`ffmpeg -i "${file}" -t 30 -af volumedetect -f null NUL 2>&1`).toString();
    const mean = out.match(/mean_volume:\s+([-\d.]+)\s+dB/);
    const max = out.match(/max_volume:\s+([-\d.]+)\s+dB/);
    console.log(`Ref ${i}: ${mean ? mean[0] : 'N/A'}, ${max ? max[0] : 'N/A'}`);
  } catch (err) {
    console.error(`Ref ${i} error:`, err.message);
  }
}
