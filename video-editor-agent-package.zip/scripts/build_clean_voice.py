import numpy as np
import scipy.io.wavfile as wavfile
import subprocess
import os

work_dir = r"f:\Antigravity\video editor\work\reel_whatsapp"
raw_audio = os.path.join(work_dir, "audio_boosted.wav")

# 1. Apply high-pass + afftdn noise reduction to the whole boosted audio
clean_audio = os.path.join(work_dir, "audio_denoised_clean.wav")
cmd_denoise = [
    "ffmpeg", "-y",
    "-i", raw_audio,
    "-af", "highpass=f=80,afftdn=nf=-30:tn=1,acompressor=threshold=-22dB:ratio=2.5:attack=15:release=100,volume=3dB",
    "-ar", "48000",
    "-ac", "2",
    clean_audio
]
subprocess.run(cmd_denoise, check=True)
print("Denoised audio created successfully.")

sr, data = wavfile.read(clean_audio)
print(f"Sample rate: {sr}, channels: {data.shape[1]}")
