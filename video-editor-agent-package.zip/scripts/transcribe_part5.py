import os
import sys
import subprocess
import json
from faster_whisper import WhisperModel

video_path = r"C:\Users\Lenovo\Desktop\reels\unprofessional take\Edits_Audiogram_part_five_20261114_212107.mp4"
work_dir = r"f:\Antigravity\video editor\work\audiogram_part5"
os.makedirs(work_dir, exist_ok=True)
audio_wav = os.path.join(work_dir, "raw_audio.wav")

ffmpeg_bin = r"C:\Users\Lenovo\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"
cmd = [ffmpeg_bin, "-y", "-i", video_path, "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1", audio_wav]
subprocess.run(cmd, check=True)

print("Audio extracted successfully.")
model = WhisperModel("base", device="cpu", compute_type="int8")
segments, info = model.transcribe(audio_wav, word_timestamps=True, vad_filter=False)

data = {"duration": info.duration, "language": info.language, "segments": []}
for seg in segments:
    words = [{"word": w.word, "start": round(w.start, 2), "end": round(w.end, 2), "prob": round(w.probability, 2)} for w in (seg.words or [])]
    data["segments"].append({"start": round(seg.start, 2), "end": round(seg.end, 2), "text": seg.text.strip(), "words": words})

with open(os.path.join(work_dir, "transcription.json"), "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)

print(f"Detected language: {info.language}, Duration: {info.duration:.2f}s")
for s in data["segments"]:
    print(f"[{s['start']:05.2f} - {s['end']:05.2f}] {s['text']}")
