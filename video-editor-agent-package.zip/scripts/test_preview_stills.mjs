import puppeteer from 'puppeteer-core';
import http from 'http';
import fs from 'fs';
import path from 'path';

const PORT = 4996;
const server = http.createServer((req, res) => {
  let filePath = path.join('work/bells_procedural_engine', req.url === '/' ? 'index.html' : req.url);
  if (!fs.existsSync(filePath)) {
    res.writeHead(404);
    res.end();
    return;
  }
  const ext = path.extname(filePath);
  const mime = ext === '.html' ? 'text/html' : ext === '.js' ? 'application/javascript' : 'text/plain';
  res.writeHead(200, { 'Content-Type': mime });
  res.end(fs.readFileSync(filePath));
});

server.listen(PORT, async () => {
  console.log(`Server listening on ${PORT}`);
  const browser = await puppeteer.launch({
    executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1080, height: 1920, deviceScaleFactor: 1 });
  await page.goto(`http://localhost:${PORT}/index.html`);
  await page.waitForFunction(() => window.READY === true);

  const previewFrames = [
    { frame: 60, name: 'act1_f060_sleep_onset.jpg' },
    { frame: 210, name: 'act2_f210_phenomenon_90pct.jpg' },
    { frame: 350, name: 'act3_f350_cornea_dome.jpg' },
    { frame: 490, name: 'act4_f490_lagophthalmos_gap.jpg' },
    { frame: 680, name: 'act5_f680_protective_harbor.jpg' },
    { frame: 860, name: 'act6_f860_brainstem_synapses.jpg' },
    { frame: 1030, name: 'act7_f1030_superior_rectus.jpg' },
    { frame: 1180, name: 'act8_f1180_clinical_proof.jpg' }
  ];

  const previewDir = 'work/bells_procedural_engine/preview_stills';
  if (!fs.existsSync(previewDir)) fs.mkdirSync(previewDir, { recursive: true });

  for (const p of previewFrames) {
    const dataUrl = await page.evaluate(fIdx => window.grabFrame(fIdx), p.frame);
    const buf = Buffer.from(dataUrl.split(',')[1], 'base64');
    fs.writeFileSync(path.join(previewDir, p.name), buf);
    console.log(`Captured preview still: ${p.name}`);
  }

  await browser.close();
  server.close();
  console.log('All preview frames generated.');
});
