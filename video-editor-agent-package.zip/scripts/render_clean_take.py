import subprocess
import os

input_video = r"C:\Users\Lenovo\Downloads\environmental classifier.mp4"
out_dir = r"f:\Antigravity\video editor\out"
os.makedirs(out_dir, exist_ok=True)

out_file = os.path.join(out_dir, "environmental_classifier_perfect_take.mp4")

# Start at 100.60s (breath onset), duration 54.10s (ends at 154.70s release)
t_start = 100.60
t_dur = 54.10

cmd = [
    "ffmpeg", "-y",
    "-ss", str(t_start),
    "-i", input_video,
    "-t", str(t_dur),
    "-c:v", "libx264",
    "-preset", "slow",
    "-crf", "17",
    "-pix_fmt", "yuv420p",
    "-r", "30",
    "-fps_mode", "cfr",
    "-af", "afade=t=in:ss=0:d=0.03,afade=t=out:st=54.07:d=0.03",
    "-c:a", "aac",
    "-b:a", "256k",
    "-ar", "48000",
    "-movflags", "+faststart",
    out_file
]

print("Rendering perfect take...")
subprocess.run(cmd, check=True)
print(f"Render complete: {out_file}")

# Probe output
cmd_probe = [
    "ffprobe", "-v", "error",
    "-show_entries", "format=duration,size,bit_rate:stream=codec_type,codec_name,width,height,r_frame_rate",
    "-of", "json",
    out_file
]
res = subprocess.run(cmd_probe, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
print("\nProbe result:")
print(res.stdout)
