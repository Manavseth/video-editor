const fs = require('fs');
const path = require('path');

const targetPath = path.resolve('remotion_ci_reel/src/audiogram4/AudiogramPart4Master.tsx');

const content = `import React from 'react';
import {
  useCurrentFrame,
  Sequence,
  Audio,
  OffthreadVideo,
  staticFile,
} from 'remotion';

// =============================================================================
// MINIMALISTIC CLINICAL TOKENS & SYSTEM
// =============================================================================
const W = 1080;
const H = 1920;
const PAPER = '#F6F2E9';
const GRID = '#E4DECC';
const INK = '#20252B';
const INK_SOFT = '#5B5970';
const TEAL = '#2D8C85';
const TEAL_LIGHT = '#E6F4F2';
const AIR = '#DF7A2B';
const AIR_LIGHT = '#FDF2E9';
const BONE = '#2E56C9';
const OK = '#2E9E6B';
const OK_LIGHT = '#EAF7EE';
const STOP = '#C63B3B';
const STOP_LIGHT = '#FDF0F0';
const PALE_CARD = '#FFFDF8';

// Safe Area Layout Constants (Instagram Reels 9:16)
// Top Safe Area: 145px, Bottom Safe Area: 280px, Right Gutter: 120px (clear of Like/Comment/Share)
const CARD_TOP = 145;
const CARD_LEFT = 60;
const CARD_WIDTH = 900;
const CARD_HEIGHT = 1290; // Reaches y = 1435px

// Frequency axis coordinates
const OCTAVES = [250, 500, 1000, 2000, 4000, 8000];
const fx = (f: number) => 160 + 152 * Math.log2(f / 250);
const dy = (db: number) => 380 + 7.5 * db;

// Easing helpers
const clamp = (v: number, min = 0, max = 1) => Math.max(min, Math.min(max, v));
const easeOutCubic = (t: number) => 1 - Math.pow(1 - clamp(t), 3);

// Captions data (Master Hindi dialogue)
const CUES = [
  { start: 0.00, end: 1.50, text: "Tumne pichhli reel mein dekha tha:" },
  { start: 1.50, end: 4.08, text: "Sirf 10 dB ka gap batata hai", hl: "10 dB ka gap" },
  { start: 4.08, end: 6.48, text: "problem parde mein hai ya nerve mein.", hl: "parde ya nerve" },
  { start: 6.48, end: 9.42, text: "As an audiologist, audiogram mere liye", hl: "As an audiologist" },
  { start: 9.42, end: 11.26, text: "aapke kaan ka ek Sound Equalizer hai,", hl: "Sound Equalizer" },
  { start: 11.26, end: 12.96, text: "jahan left pe Bass hota hai", hl: "left pe Bass" },
  { start: 12.96, end: 15.80, text: "aur right pe Treble, yaani Speech Clarity.", hl: "Treble = Speech Clarity" },
  { start: 15.80, end: 17.78, text: "Agar graph right side se drop ho,", hl: "right side se drop" },
  { start: 17.78, end: 20.85, text: "yaani Sloping Hearing Loss...", hl: "Sloping Hearing Loss" },
  { start: 20.85, end: 24.54, text: "Volume toh sunai deta hai, par words muffled lagte hain,", hl: "words muffled lagte hain" },
  { start: 24.54, end: 27.29, text: "jo natural aging ka ek classic sign hai.", hl: "natural aging (Presbycusis)" },
  { start: 27.29, end: 30.16, text: "Aur agar 4000 Hz par ek sharp notch ho,", hl: "4000 Hz sharp notch" },
  { start: 30.16, end: 35.04, text: "yeh loud headphones aur noise exposure ka direct proof hai.", hl: "Noise Exposure Proof" },
  { start: 35.04, end: 38.14, text: "Audiogram tumhari hearing health ka blueprint hai,", hl: "Hearing Health Blueprint" },
  { start: 38.14, end: 40.76, text: "jo kabhi jhooth nahi bolta.", hl: "kabhi jhooth nahi bolta" },
  { start: 40.76, end: 43.32, text: "Next part mein: do logon ka graph", hl: "Next part mein" },
  { start: 43.32, end: 45.02, text: "bilkul same hone par bhi,", hl: "same hone par bhi" },
  { start: 45.02, end: 47.16, text: "Clarity alag kyun hoti hai?", hl: "Clarity alag kyun?" },
  { start: 47.16, end: 48.64, text: "Ispe baat karenge.", hl: "Follow for Part 5" },
];

export const AudiogramPart4Master: React.FC = () => {
  const frame = useCurrentFrame();
  const time = frame / 30;

  // Active caption
  const activeCue = CUES.find((c) => time >= c.start && time < c.end);

  // Host Take Registers (Spot-on Lip Sync with intra-only 30fps sub-clips)
  const isHostClip1 = frame >= 625 && frame < 739;        // Scene 08: 20.85s - 24.65s (3.80s · 114 frames)
  const isHostClip2 = frame >= 1053 && frame < 1222;      // Scene 12: 35.10s - 40.73s (5.63s · 169 frames)

  return (
    <div
      style={{
        width: W,
        height: H,
        backgroundColor: PAPER,
        position: 'relative',
        overflow: 'hidden',
        fontFamily: 'Inter, "Segoe UI", system-ui, sans-serif',
      }}
    >
      {/* 1. Master Audio from Original File */}
      <Audio src={staticFile('audiogram4_master_voice.wav')} />

      {/* 2. Global Technical Background Grid */}
      <svg
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: W,
          height: H,
          pointerEvents: 'none',
        }}
      >
        <defs>
          <pattern
            id="part4-grid"
            width={48}
            height={48}
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M 48 0 L 0 0 0 48"
              fill="none"
              stroke={GRID}
              strokeWidth={1.5}
              opacity={0.65}
            />
          </pattern>
        </defs>
        <rect width={W} height={H} fill="url(#part4-grid)" />
      </svg>

      {/* =====================================================================
          SCENE 1: (0.00s - 3.80s · Frames 0 - 114) · Duration: 3.80s
          ARCHETYPE MG-02: GATE-SPLIT DECISION ENGINE
          "Tumne pichhli reel mein dekha tha: Sirf 10 dB ka gap batata hai..."
          Full safe area height (1290px), large readable text for doomscrollers.
          ===================================================================== */}
      {frame < 114 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: CARD_TOP,
              left: CARD_LEFT,
              width: CARD_WIDTH,
              height: CARD_HEIGHT,
              backgroundColor: '#FFFFFF',
              border: \`4px solid \${INK}\`,
              borderRadius: 28,
              boxShadow: '0 16px 48px rgba(32, 37, 43, 0.12)',
              padding: '28px 32px',
              boxSizing: 'border-box',
              display: 'flex',
              flexDirection: 'column',
            }}
          >
            {/* Header with clear badges */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 34, fontWeight: 900, color: INK, letterSpacing: '0.5px' }}>
                  PART 3 RECAP: THE 10 dB CRITERION
                </div>
                <div style={{ fontSize: 20, color: INK_SOFT, fontWeight: 700, marginTop: 4 }}>
                  Air-Bone Gap: Diagnostic separator between conductive & nerve issues
                </div>
              </div>
              <div style={{ display: 'flex', gap: 12 }}>
                <span
                  style={{
                    fontSize: 20,
                    fontWeight: 900,
                    backgroundColor: OK_LIGHT,
                    color: OK,
                    border: \`2px solid \${OK}\`,
                    padding: '8px 18px',
                    borderRadius: 16,
                  }}
                >
                  NORMAL: ≤ 20 dB
                </span>
                <span
                  style={{
                    fontSize: 20,
                    fontWeight: 900,
                    backgroundColor: TEAL_LIGHT,
                    color: TEAL,
                    border: \`2px solid \${TEAL}\`,
                    padding: '8px 18px',
                    borderRadius: 16,
                  }}
                >
                  AIR-BONE GAP
                </span>
              </div>
            </div>

            {/* Audiological Grid SVG */}
            <svg width={836} height={780} viewBox="70 280 910 800" style={{ marginTop: 16 }}>
              {/* Frequency Top Labels */}
              {OCTAVES.map((f) => (
                <text
                  key={f}
                  x={fx(f)}
                  y={330}
                  textAnchor="middle"
                  fill={INK}
                  fontSize={30}
                  fontWeight={900}
                >
                  {f < 1000 ? \`\${f}Hz\` : \`\${f / 1000}k\`}
                </text>
              ))}

              {/* dB HL Lines (0 to 100 dB) */}
              {[0, 20, 40, 60, 80, 100].map((db) => (
                <g key={db}>
                  <line
                    x1={140}
                    y1={dy(db)}
                    x2={940}
                    y2={dy(db)}
                    stroke={db === 20 ? OK : GRID}
                    strokeWidth={db === 20 ? 3.5 : 2}
                    strokeDasharray={db === 20 ? "8 5" : "none"}
                  />
                  <text
                    x={125}
                    y={dy(db) + 8}
                    textAnchor="end"
                    fill={db === 20 ? OK : INK_SOFT}
                    fontSize={26}
                    fontWeight={800}
                  >
                    {db}
                  </text>
                </g>
              ))}

              {/* Shaded Normal Zone */}
              <rect x={140} y={dy(0)} width={800} height={dy(20) - dy(0)} fill="rgba(46, 158, 107, 0.10)" />

              {/* Normal Threshold Zone Label */}
              <text x={155} y={415} textAnchor="start" fill={OK} fontSize={22} fontWeight={900}>
                ● NORMAL AUDITORY SENSITIVITY (0 - 20 dB HL)
              </text>

              {/* Bone Conduction (<) at 10 dB */}
              {OCTAVES.map((f) => (
                <g key={\`b-\${f}\`}>
                  <text x={fx(f)} y={dy(10) + 12} textAnchor="middle" fill={BONE} fontSize={36} fontWeight={900}>
                    &lt;
                  </text>
                </g>
              ))}

              {/* Air Conduction (O) at 20 dB */}
              {OCTAVES.map((f) => (
                <g key={\`a-\${f}\`}>
                  <circle cx={fx(f)} cy={dy(20)} r={12} fill="#FFFFFF" stroke={AIR} strokeWidth={4.5} />
                </g>
              ))}

              {/* 10 dB Caliper Highlight */}
              {(() => {
                const anim = easeOutCubic(frame / 30);
                const cy = dy(15);
                return (
                  <g opacity={anim}>
                    <line x1={fx(1000) + 25} y1={dy(10)} x2={fx(1000) + 55} y2={dy(10)} stroke={TEAL} strokeWidth={4} />
                    <line x1={fx(1000) + 40} y1={dy(10)} x2={fx(1000) + 40} y2={dy(20)} stroke={TEAL} strokeWidth={5} />
                    <line x1={fx(1000) + 25} y1={dy(20)} x2={fx(1000) + 55} y2={dy(20)} stroke={TEAL} strokeWidth={4} />

                    <rect x={fx(1000) + 68} y={cy - 28} width={300} height={56} rx={14} fill={TEAL} />
                    <text x={fx(1000) + 218} y={cy + 9} textAnchor="middle" fill="#FFFFFF" fontSize={24} fontWeight={900}>
                      GAP = 10 dB (NORMAL)
                    </text>
                  </g>
                );
              })()}
            </svg>

            {/* Bottom Decision Split Banner (Integrated inside card to eliminate empty look) */}
            <div
              style={{
                marginTop: 'auto',
                display: 'flex',
                gap: 20,
              }}
            >
              <div
                style={{
                  flex: 1,
                  backgroundColor: '#F8FAF9',
                  border: \`3px solid \${TEAL}\`,
                  borderRadius: 20,
                  padding: '20px 24px',
                }}
              >
                <div style={{ fontSize: 18, fontWeight: 900, color: TEAL, letterSpacing: 1 }}>CRITERION RULE</div>
                <div style={{ fontSize: 30, fontWeight: 900, color: INK, marginTop: 4 }}>Gap ≤ 10 dB</div>
                <div style={{ fontSize: 20, color: INK_SOFT, marginTop: 4, fontWeight: 700 }}>
                  Bone &amp; Air saath chalte hain (No Conductive Block)
                </div>
              </div>
              <div
                style={{
                  flex: 1,
                  backgroundColor: '#FFF8F2',
                  border: \`3px solid \${AIR}\`,
                  borderRadius: 20,
                  padding: '20px 24px',
                }}
              >
                <div style={{ fontSize: 18, fontWeight: 900, color: AIR, letterSpacing: 1 }}>CONDUCTIVE GAP</div>
                <div style={{ fontSize: 30, fontWeight: 900, color: INK, marginTop: 4 }}>Gap ≥ 15 dB</div>
                <div style={{ fontSize: 20, color: INK_SOFT, marginTop: 4, fontWeight: 700 }}>
                  Parda ya middle ear block ka direct indicator
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 2: (3.80s - 6.48s · Frames 114 - 194) · Duration: 2.68s
          ARCHETYPE MG-03: ANATOMICAL TWIN COMPARISON (Parda vs Nerve)
          "problem parde mein hai ya nerve mein."
          Anatomical Ear Canal, Tympanic Membrane, Cochlea Snail & CN VIII Fascicle.
          Large, doomscroller-friendly typography & high-density anatomical rig.
          ===================================================================== */}
      {frame >= 114 && frame < 194 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          {/* Top Question Header */}
          <div
            style={{
              position: 'absolute',
              top: CARD_TOP,
              left: CARD_LEFT,
              width: CARD_WIDTH,
              backgroundColor: INK,
              borderRadius: 20,
              padding: '16px 28px',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              boxShadow: '0 12px 32px rgba(32,37,43,0.18)',
              zIndex: 10,
              boxSizing: 'border-box',
            }}
          >
            <span style={{ fontSize: 24, fontWeight: 900, color: '#FFFFFF', letterSpacing: '1px' }}>
              DIAGNOSTIC QUESTION: WHERE IS THE ISSUE?
            </span>
            <span style={{ fontSize: 20, fontWeight: 900, backgroundColor: TEAL, color: '#FFFFFF', padding: '6px 18px', borderRadius: 12 }}>
              PARDA YA NAS?
            </span>
          </div>

          <div
            style={{
              position: 'absolute',
              top: CARD_TOP + 76,
              left: CARD_LEFT,
              width: CARD_WIDTH,
              display: 'flex',
              gap: 20,
              boxSizing: 'border-box',
            }}
          >
            {/* Left Card: Anatomical Ear Canal & Eardrum (Parda) */}
            <div
              style={{
                flex: 1,
                height: CARD_HEIGHT - 76,
                backgroundColor: '#FFFFFF',
                border: \`4px solid \${AIR}\`,
                borderRadius: 24,
                boxShadow: '0 16px 40px rgba(223, 122, 43, 0.15)',
                padding: '24px 22px',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                boxSizing: 'border-box',
              }}
            >
              <div style={{ alignSelf: 'flex-start', backgroundColor: AIR_LIGHT, color: AIR, padding: '8px 16px', borderRadius: 14, fontSize: 18, fontWeight: 900 }}>
                CONDUCTIVE SITE · AIR PATHWAY
              </div>
              <div style={{ fontSize: 34, fontWeight: 900, color: INK, marginTop: 10, textAlign: 'center' }}>
                👂 PARDA (Ear Drum)
              </div>
              <div style={{ fontSize: 20, color: INK_SOFT, textAlign: 'center', marginTop: 2, fontWeight: 700 }}>
                Ear Canal &amp; Vibrating Eardrum
              </div>

              {/* Anatomical Ear Canal & Tympanic Membrane SVG */}
              <svg width={380} height={520} viewBox="0 0 380 500" style={{ marginTop: 16 }}>
                {/* Canal Cartilage/Bone Walls */}
                <path
                  d="M 25 120 C 55 130, 80 145, 120 145 C 160 145, 195 155, 230 160"
                  fill="none"
                  stroke={INK}
                  strokeWidth={7}
                  strokeLinecap="round"
                />
                <path
                  d="M 25 280 C 55 270, 80 255, 120 255 C 160 255, 195 265, 240 280"
                  fill="none"
                  stroke={INK}
                  strokeWidth={7}
                  strokeLinecap="round"
                />
                {/* Canal Lumen Flesh Tint */}
                <path
                  d="M 25 120 C 55 130, 80 145, 120 145 C 160 145, 195 155, 230 160 L 240 280 C 195 265, 160 255, 120 255 C 80 255, 55 270, 25 280 Z"
                  fill="#FAF4EB"
                  opacity={0.9}
                />

                {/* Animated Incoming Acoustic Sound Waves */}
                {(() => {
                  const waveStep = ((frame - 114) * 5) % 60;
                  return (
                    <g>
                      <path d={\`M \${40 + waveStep} 150 A 45 45 0 0 1 \${40 + waveStep} 240\`} fill="none" stroke={AIR} strokeWidth={6} strokeLinecap="round" opacity={1 - waveStep / 80} />
                      <path d={\`M \${75 + waveStep} 155 A 40 40 0 0 1 \${75 + waveStep} 235\`} fill="none" stroke={AIR} strokeWidth={6} strokeLinecap="round" opacity={1 - waveStep / 80} />
                      <path d={\`M \${110 + waveStep} 160 A 35 35 0 0 1 \${110 + waveStep} 230\`} fill="none" stroke={AIR} strokeWidth={6} strokeLinecap="round" opacity={1 - waveStep / 80} />
                    </g>
                  );
                })()}
                <text x={85} y={130} fill={AIR} fontSize={18} fontWeight={900} textAnchor="middle">
                  SOUND WAVES
                </text>

                {/* Oblique Tympanic Membrane (Parda) with Vibration */}
                {(() => {
                  const vib = Math.sin(frame * 1.2) * 3;
                  return (
                    <g>
                      <path
                        d={\`M 230 160 Q \${242 + vib} 220 240 280\`}
                        fill="none"
                        stroke={AIR}
                        strokeWidth={10}
                        strokeLinecap="round"
                      />
                      <ellipse cx={236 + vib} cy={220} rx={10} ry={55} fill="rgba(223, 122, 43, 0.35)" />
                      <circle cx={236 + vib} cy={220} r={7} fill={INK} />
                    </g>
                  );
                })()}

                {/* Middle Ear Cavity & Ossicular Chain */}
                <path d="M 252 140 L 236 220" stroke={INK} strokeWidth={7} strokeLinecap="round" />
                <circle cx={252} cy={140} r={10} fill={INK} />
                <path d="M 252 140 L 285 148 L 280 195" fill="none" stroke={INK} strokeWidth={7} strokeLinecap="round" strokeLinejoin="round" />
                <circle cx={280} cy={195} r={6} fill={INK} />
                <path d="M 280 195 L 302 186 L 318 186 M 280 195 L 302 204 L 318 204" fill="none" stroke={INK} strokeWidth={5} strokeLinecap="round" />
                <line x1={318} y1={180} x2={318} y2={210} stroke={INK} strokeWidth={7} strokeLinecap="round" />

                {/* Anatomical Callouts & Leader Lines */}
                <line x1={120} y1={255} x2={120} y2={325} stroke={INK_SOFT} strokeWidth={2.5} strokeDasharray="4 3" />
                <text x={120} y={350} fill={INK} fontSize={20} fontWeight={900} textAnchor="middle">
                  EAR CANAL
                </text>
                <text x={120} y={372} fill={INK_SOFT} fontSize={16} fontWeight={700} textAnchor="middle">
                  External Auditory Meatus
                </text>

                <line x1={236} y1={280} x2={236} y2={395} stroke={AIR} strokeWidth={2.5} strokeDasharray="4 3" />
                <rect x={145} y={400} width={182} height={48} rx={12} fill={AIR_LIGHT} stroke={AIR} strokeWidth={2.5} />
                <text x={236} y={424} fill={AIR} fontSize={18} fontWeight={900} textAnchor="middle">
                  EARDRUM (PARDA)
                </text>
                <text x={236} y={442} fill={INK_SOFT} fontSize={14} fontWeight={800} textAnchor="middle">
                  Vibrating Tympanic Membrane
                </text>

                <line x1={290} y1={148} x2={330} y2={125} stroke={INK} strokeWidth={2.5} strokeDasharray="4 3" />
                <text x={330} y={115} fill={INK} fontSize={18} fontWeight={900} textAnchor="middle">
                  OSSICLES
                </text>
                <text x={330} y={132} fill={INK_SOFT} fontSize={14} fontWeight={700} textAnchor="middle">
                  Hammer/Anvil/Stirrup
                </text>
              </svg>

              <div style={{ width: '100%', backgroundColor: '#FDF8F3', border: \`2px solid \${AIR}\`, borderRadius: 18, padding: '16px 20px', marginTop: 12 }}>
                <div style={{ fontSize: 18, fontWeight: 900, color: AIR, letterSpacing: 0.5 }}>
                  COMMON CONDUCTIVE BLOCKS:
                </div>
                <div style={{ fontSize: 18, color: INK, marginTop: 6, fontWeight: 700, lineHeight: 1.45 }}>
                  • Kaan ka Mail (Wax Blockage)<br/>
                  • Parda Phatna (Tympanic Tear)<br/>
                  • Middle Ear Fluid / Infection
                </div>
              </div>

              <div style={{ marginTop: 'auto', width: '100%', backgroundColor: AIR_LIGHT, border: \`3px solid \${AIR}\`, borderRadius: 18, padding: '16px', textAlign: 'center' }}>
                <div style={{ fontSize: 24, fontWeight: 900, color: AIR }}>
                  Air-Bone Gap ≥ 15 dB
                </div>
                <div style={{ fontSize: 16, color: INK_SOFT, marginTop: 4, fontWeight: 700 }}>
                  Acoustic sound wave is physically blocked
                </div>
              </div>
            </div>

            {/* Right Card: Anatomical Snail Cochlea & Cranial Nerve VIII Fascicle */}
            <div
              style={{
                flex: 1,
                height: CARD_HEIGHT - 76,
                backgroundColor: '#FFFFFF',
                border: \`4px solid \${TEAL}\`,
                borderRadius: 24,
                boxShadow: '0 16px 40px rgba(45, 140, 133, 0.15)',
                padding: '24px 22px',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                boxSizing: 'border-box',
              }}
            >
              <div style={{ alignSelf: 'flex-start', backgroundColor: TEAL_LIGHT, color: TEAL, padding: '8px 16px', borderRadius: 14, fontSize: 18, fontWeight: 900 }}>
                SENSORINEURAL SITE · BONE PATHWAY
              </div>
              <div style={{ fontSize: 34, fontWeight: 900, color: INK, marginTop: 10, textAlign: 'center' }}>
                ⚡ NAS (Auditory Nerve)
              </div>
              <div style={{ fontSize: 20, color: INK_SOFT, textAlign: 'center', marginTop: 2, fontWeight: 700 }}>
                Cochlea Snail &amp; CN VIII Nerve Wire
              </div>

              {/* Anatomical Snail Cochlea & Myelinated Axon Fascicle SVG */}
              <svg width={380} height={520} viewBox="0 0 380 500" style={{ marginTop: 16 }}>
                {/* Cochlea Snail Spiral Shell Body */}
                <path
                  d="M 95 160 C 55 180, 40 235, 68 285 C 100 340, 175 345, 215 300 C 248 260, 240 200, 192 175 C 150 155, 115 180, 120 220 C 124 252, 155 262, 172 245 C 185 230, 180 208, 162 204 C 148 200, 138 214, 148 222"
                  fill="#E8F4F2"
                  stroke={TEAL}
                  strokeWidth={7}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />

                {/* Snail Shell Internal Basilar Partition */}
                <path
                  d="M 88 230 C 98 280, 160 290, 190 255 C 212 225, 204 190, 172 180"
                  fill="none"
                  stroke={TEAL}
                  strokeWidth={3.5}
                  strokeDasharray="6 4"
                />

                {/* Stapes Oval Window Entrance */}
                <ellipse cx={96} cy={160} rx={12} ry={7} fill="#FFFFFF" stroke={TEAL} strokeWidth={3.5} />

                {/* Multi-fiber Auditory Nerve Fascicle (Cranial Nerve VIII) */}
                <rect x={195} y={190} width={178} height={80} rx={16} fill="#F6FAF9" stroke={TEAL} strokeWidth={4.5} />

                {/* 3 Parallel Axon Tracks */}
                <line x1={200} y1={210} x2={368} y2={210} stroke={INK} strokeWidth={3.5} />
                <line x1={200} y1={230} x2={368} y2={230} stroke={INK} strokeWidth={3.5} />
                <line x1={200} y1={250} x2={368} y2={250} stroke={INK} strokeWidth={3.5} />

                {/* Myelin Sheaths with Nodes of Ranvier */}
                <rect x={215} y={202} width={30} height={16} rx={4} fill="#D1ECE8" stroke={TEAL} strokeWidth={2} />
                <rect x={260} y={202} width={34} height={16} rx={4} fill="#D1ECE8" stroke={TEAL} strokeWidth={2} />
                <rect x={310} y={202} width={32} height={16} rx={4} fill="#D1ECE8" stroke={TEAL} strokeWidth={2} />

                <rect x={215} y={222} width={30} height={16} rx={4} fill="#D1ECE8" stroke={TEAL} strokeWidth={2} />
                <rect x={260} y={222} width={34} height={16} rx={4} fill="#D1ECE8" stroke={TEAL} strokeWidth={2} />
                <rect x={310} y={222} width={32} height={16} rx={4} fill="#D1ECE8" stroke={TEAL} strokeWidth={2} />

                <rect x={215} y={242} width={30} height={16} rx={4} fill="#D1ECE8" stroke={TEAL} strokeWidth={2} />
                <rect x={260} y={242} width={34} height={16} rx={4} fill="#D1ECE8" stroke={TEAL} strokeWidth={2} />
                <rect x={310} y={242} width={32} height={16} rx={4} fill="#D1ECE8" stroke={TEAL} strokeWidth={2} />

                {/* Animated Electrical Action Potentials */}
                {(() => {
                  const nodeX = [252, 302, 350][Math.floor(((frame - 114) / 6) % 3)];
                  return (
                    <g>
                      <circle cx={nodeX} cy={210} r={8} fill="#DF7A2B" stroke="#FFFFFF" strokeWidth={2.5} />
                      <circle cx={nodeX} cy={230} r={8} fill="#DF7A2B" stroke="#FFFFFF" strokeWidth={2.5} />
                      <circle cx={nodeX} cy={250} r={8} fill="#DF7A2B" stroke="#FFFFFF" strokeWidth={2.5} />
                    </g>
                  );
                })()}

                <text x={265} y={164} fill="#DF7A2B" fontSize={16} fontWeight={900} textAnchor="middle">
                  ⚡ ELECTRICAL PULSES
                </text>

                <text x={370} y={184} fill={TEAL} fontSize={20} fontWeight={900} textAnchor="end">
                  → BRAIN
                </text>

                {/* Labels and Leader Lines */}
                <line x1={120} y1={335} x2={120} y2={395} stroke={TEAL} strokeWidth={2.5} strokeDasharray="4 3" />
                <rect x={50} y={400} width={150} height={48} rx={12} fill={TEAL_LIGHT} stroke={TEAL} strokeWidth={2.5} />
                <text x={125} y={424} fill={TEAL} fontSize={18} fontWeight={900} textAnchor="middle">
                  COCHLEA
                </text>
                <text x={125} y={442} fill={INK_SOFT} fontSize={14} fontWeight={800} textAnchor="middle">
                  Snail Shell · Hair Cells
                </text>

                <line x1={290} y1={270} x2={290} y2={355} stroke={TEAL} strokeWidth={2.5} strokeDasharray="4 3" />
                <text x={290} y={375} fill={INK} fontSize={20} fontWeight={900} textAnchor="middle">
                  AUDITORY NERVE
                </text>
                <text x={290} y={395} fill={INK_SOFT} fontSize={15} fontWeight={800} textAnchor="middle">
                  CN VIII Fascicle Wire
                </text>
              </svg>

              <div style={{ width: '100%', backgroundColor: '#F0FDF4', border: \`2px solid \${TEAL}\`, borderRadius: 18, padding: '16px 20px', marginTop: 12 }}>
                <div style={{ fontSize: 18, fontWeight: 900, color: TEAL, letterSpacing: 0.5 }}>
                  COMMON NERVE DAMAGE:
                </div>
                <div style={{ fontSize: 18, color: INK, marginTop: 6, fontWeight: 700, lineHeight: 1.45 }}>
                  • Sensory Hair Cell Loss (Aging)<br/>
                  • Loud Sound Acoustic Trauma<br/>
                  • Auditory Nerve Signal Loss
                </div>
              </div>

              <div style={{ marginTop: 'auto', width: '100%', backgroundColor: TEAL_LIGHT, border: \`3px solid \${TEAL}\`, borderRadius: 18, padding: '16px', textAlign: 'center' }}>
                <div style={{ fontSize: 24, fontWeight: 900, color: TEAL }}>
                  No Gap (≤ 10 dB)
                </div>
                <div style={{ fontSize: 16, color: INK_SOFT, marginTop: 4, fontWeight: 700 }}>
                  Nerve or inner ear hair cells damaged
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 3: (6.48s - 9.42s · Frames 194 - 282) · Duration: 2.94s
          ARCHETYPE MG-01: THE AUDIOLOGIST'S DIAGNOSTIC CONSOLE
          "As an audiologist, audiogram mere liye aapke kaan ka ek..."
          ===================================================================== */}
      {frame >= 194 && frame < 282 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: CARD_TOP,
              left: CARD_LEFT,
              width: CARD_WIDTH,
              height: CARD_HEIGHT,
              backgroundColor: '#FFFFFF',
              border: \`4px solid \${INK}\`,
              borderRadius: 28,
              boxShadow: '0 16px 48px rgba(32, 37, 43, 0.12)',
              padding: '40px',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              boxSizing: 'border-box',
            }}
          >
            <div style={{ backgroundColor: TEAL_LIGHT, color: TEAL, border: \`2px solid \${TEAL}\`, padding: '10px 24px', borderRadius: 20, fontSize: 22, fontWeight: 900, letterSpacing: 1.5 }}>
              CLINICAL METAPHOR INTRO
            </div>
            <div style={{ fontSize: 48, fontWeight: 900, color: INK, marginTop: 20, textAlign: 'center' }}>
              HOW AUDIOLOGISTS SEE IT
            </div>
            <div style={{ fontSize: 26, color: INK_SOFT, marginTop: 10, fontWeight: 700, textAlign: 'center' }}>
              Not just lines on paper — an interactive sound equalizer console
            </div>

            <svg width={820} height={680} viewBox="0 0 820 680" style={{ marginTop: 30 }}>
              <rect x={40} y={40} width={740} height={600} rx={28} fill="#FDFCF9" stroke={INK} strokeWidth={4} />
              <circle cx={80} cy={85} r={10} fill={OK} />
              <circle cx={115} cy={85} r={10} fill={AIR} />
              <circle cx={150} cy={85} r={10} fill={TEAL} />
              <text x={740} y={92} textAnchor="end" fill={INK_SOFT} fontSize={22} fontWeight={900} letterSpacing={2}>
                AUDIOMETRIC SOUND CONSOLE
              </text>

              <rect x={70} y={130} width={680} height={340} rx={20} fill={INK} />
              <path
                d={(() => {
                  let d = 'M 80 300';
                  for (let x = 80; x <= 740; x += 10) {
                    const wave = Math.sin((x + frame * 8) * 0.05) * 65 * Math.sin(x * 0.01);
                    d += \` L \${x} \${300 + wave}\`;
                  }
                  return d;
                })()}
                fill="none"
                stroke={TEAL}
                strokeWidth={5}
                strokeLinecap="round"
              />
              <line x1={70} y1={300} x2={750} y2={300} stroke="rgba(255,255,255,0.2)" strokeWidth={2} strokeDasharray="8 8" />
              <line x1={410} y1={130} x2={410} y2={470} stroke="rgba(255,255,255,0.2)" strokeWidth={2} strokeDasharray="8 8" />

              <g transform="translate(160, 540)">
                <circle cx={0} cy={0} r={42} fill="#FFFFFF" stroke={INK} strokeWidth={4.5} />
                <line x1={0} y1={0} x2={-18} y2={-24} stroke={TEAL} strokeWidth={6} strokeLinecap="round" />
                <text x={0} y={64} textAnchor="middle" fill={INK} fontSize={22} fontWeight={900}>BASS</text>
              </g>
              <g transform="translate(410, 540)">
                <circle cx={0} cy={0} r={42} fill="#FFFFFF" stroke={INK} strokeWidth={4.5} />
                <line x1={0} y1={0} x2={0} y2={-30} stroke={OK} strokeWidth={6} strokeLinecap="round" />
                <text x={0} y={64} textAnchor="middle" fill={INK} fontSize={22} fontWeight={900}>MID</text>
              </g>
              <g transform="translate(660, 540)">
                <circle cx={0} cy={0} r={42} fill="#FFFFFF" stroke={INK} strokeWidth={4.5} />
                <line x1={0} y1={0} x2={22} y2={-22} stroke={AIR} strokeWidth={6} strokeLinecap="round" />
                <text x={0} y={64} textAnchor="middle" fill={INK} fontSize={22} fontWeight={900}>TREBLE</text>
              </g>
            </svg>

            <div
              style={{
                marginTop: 'auto',
                backgroundColor: TEAL,
                color: '#FFFFFF',
                borderRadius: 20,
                padding: '20px 48px',
                fontSize: 26,
                fontWeight: 900,
                boxShadow: '0 12px 32px rgba(45, 140, 133, 0.3)',
              }}
            >
              🎛️ KAAN KA SOUND EQUALIZER
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 4: (9.42s - 12.96s · Frames 282 - 389) · Duration: 3.54s
          ARCHETYPE MG-07: EQUALIZER CONSOLE — BASS SLIDERS ON THE LEFT
          "...Sound Equalizer hai, jahan left pe Bass hota hai..."
          ===================================================================== */}
      {frame >= 282 && frame < 389 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: CARD_TOP,
              left: CARD_LEFT,
              width: CARD_WIDTH,
              height: CARD_HEIGHT,
              backgroundColor: '#FFFFFF',
              border: \`4px solid \${INK}\`,
              borderRadius: 28,
              boxShadow: '0 16px 48px rgba(32, 37, 43, 0.12)',
              padding: '36px',
              display: 'flex',
              flexDirection: 'column',
              boxSizing: 'border-box',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 38, fontWeight: 900, color: INK }}>
                LEFT REGION: BASS &amp; VOLUME
              </span>
              <span style={{ backgroundColor: TEAL_LIGHT, color: TEAL, border: \`2px solid \${TEAL}\`, padding: '8px 22px', borderRadius: 20, fontSize: 22, fontWeight: 900 }}>
                250Hz - 500Hz
              </span>
            </div>
            <div style={{ fontSize: 24, color: INK_SOFT, marginTop: 6, fontWeight: 700 }}>
              Responsible for acoustic fullness, background room tone, and vowel power
            </div>

            <svg width={836} height={680} viewBox="0 0 836 680" style={{ marginTop: 24 }}>
              <rect x={40} y={30} width={280} height={620} rx={24} fill="rgba(45, 140, 133, 0.08)" stroke={TEAL} strokeWidth={3.5} strokeDasharray="10 8" />
              <text x={180} y={75} textAnchor="middle" fill={TEAL} fontSize={24} fontWeight={900}>
                BASS ZONE (INTACT)
              </text>

              {OCTAVES.map((freq, i) => {
                const trackX = 115 + i * 120;
                const isBass = freq <= 500;
                const faderLevel = isBass
                  ? 240 + Math.sin((frame + i * 15) * 0.15) * 45
                  : 460;
                const activeColor = isBass ? TEAL : GRID;

                return (
                  <g key={freq}>
                    <line x1={trackX} y1={120} x2={trackX} y2={560} stroke={activeColor} strokeWidth={isBass ? 10 : 5} strokeLinecap="round" />
                    {[180, 260, 340, 420, 500].map((tickY) => (
                      <line key={tickY} x1={trackX - 14} y1={tickY} x2={trackX + 14} y2={tickY} stroke={GRID} strokeWidth={2.5} />
                    ))}
                    <rect
                      x={trackX - 32}
                      y={faderLevel - 22}
                      width={64}
                      height={44}
                      rx={10}
                      fill={isBass ? TEAL : '#FFFFFF'}
                      stroke={INK}
                      strokeWidth={3.5}
                    />
                    <line x1={trackX - 18} y1={faderLevel} x2={trackX + 18} y2={faderLevel} stroke="#FFFFFF" strokeWidth={3.5} />
                    <text x={trackX} y={610} textAnchor="middle" fill={isBass ? TEAL : INK_SOFT} fontSize={28} fontWeight={900}>
                      {freq < 1000 ? \`\${freq}Hz\` : \`\${freq / 1000}k\`}
                    </text>
                  </g>
                );
              })}

              {(() => {
                const waveR = ((frame - 282) * 6) % 100;
                return (
                  <g transform="translate(180, 360)">
                    <circle cx={0} cy={0} r={waveR + 25} fill="none" stroke={TEAL} strokeWidth={3.5} opacity={1 - waveR / 100} />
                    <circle cx={0} cy={0} r={waveR + 60} fill="none" stroke={TEAL} strokeWidth={3.5} opacity={1 - waveR / 100} />
                  </g>
                );
              })()}
            </svg>

            <div
              style={{
                marginTop: 'auto',
                backgroundColor: TEAL_LIGHT,
                border: \`3px solid \${TEAL}\`,
                borderRadius: 22,
                padding: '24px 32px',
                display: 'flex',
                alignItems: 'center',
                gap: 24,
              }}
            >
              <div style={{ fontSize: 44 }}>🔊</div>
              <div>
                <div style={{ fontSize: 26, fontWeight: 900, color: TEAL }}>VOWEL POWER &amp; VOLUME</div>
                <div style={{ fontSize: 20, color: INK, marginTop: 4, fontWeight: 700 }}>
                  A, E, I, O, U ke sounds aur ambient background isi frequency mein aate hain.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 5: (12.96s - 15.80s · Frames 389 - 474) · Duration: 2.84s
          ARCHETYPE MG-07: EQUALIZER CONSOLE — TREBLE SLIDERS (CLARITY)
          "...aur right pe Treble, yaani Speech Clarity."
          ===================================================================== */}
      {frame >= 389 && frame < 474 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: CARD_TOP,
              left: CARD_LEFT,
              width: CARD_WIDTH,
              height: CARD_HEIGHT,
              backgroundColor: '#FFFFFF',
              border: \`4px solid \${INK}\`,
              borderRadius: 28,
              boxShadow: '0 16px 48px rgba(32, 37, 43, 0.12)',
              padding: '36px',
              display: 'flex',
              flexDirection: 'column',
              boxSizing: 'border-box',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 38, fontWeight: 900, color: INK }}>
                RIGHT REGION: TREBLE &amp; CLARITY
              </span>
              <span style={{ backgroundColor: AIR_LIGHT, color: AIR, border: \`2px solid \${AIR}\`, padding: '8px 22px', borderRadius: 20, fontSize: 22, fontWeight: 900 }}>
                2000Hz - 8000Hz
              </span>
            </div>
            <div style={{ fontSize: 24, color: INK_SOFT, marginTop: 6, fontWeight: 700 }}>
              Responsible for consonant sharpness, speech understanding, and word definition
            </div>

            <svg width={836} height={680} viewBox="0 0 836 680" style={{ marginTop: 24 }}>
              <rect x={430} y={30} width={380} height={620} rx={24} fill="rgba(223, 122, 43, 0.08)" stroke={AIR} strokeWidth={3.5} strokeDasharray="10 8" />
              <text x={620} y={75} textAnchor="middle" fill={AIR} fontSize={24} fontWeight={900}>
                TREBLE ZONE: SPEECH CLARITY
              </text>

              {OCTAVES.map((freq, i) => {
                const trackX = 115 + i * 120;
                const isTreble = freq >= 2000;
                const faderLevel = isTreble
                  ? 240 + Math.sin((frame + i * 20) * 0.18) * 45
                  : 460;
                const activeColor = isTreble ? AIR : GRID;

                return (
                  <g key={freq}>
                    <line x1={trackX} y1={120} x2={trackX} y2={560} stroke={activeColor} strokeWidth={isTreble ? 10 : 5} strokeLinecap="round" />
                    {[180, 260, 340, 420, 500].map((tickY) => (
                      <line key={tickY} x1={trackX - 14} y1={tickY} x2={trackX + 14} y2={tickY} stroke={GRID} strokeWidth={2.5} />
                    ))}
                    <rect
                      x={trackX - 32}
                      y={faderLevel - 22}
                      width={64}
                      height={44}
                      rx={10}
                      fill={isTreble ? AIR : '#FFFFFF'}
                      stroke={INK}
                      strokeWidth={3.5}
                    />
                    <line x1={trackX - 18} y1={faderLevel} x2={trackX + 18} y2={faderLevel} stroke="#FFFFFF" strokeWidth={3.5} />
                    <text x={trackX} y={610} textAnchor="middle" fill={isTreble ? AIR : INK_SOFT} fontSize={28} fontWeight={900}>
                      {freq < 1000 ? \`\${freq}Hz\` : \`\${freq / 1000}k\`}
                    </text>
                  </g>
                );
              })}
            </svg>

            <div
              style={{
                marginTop: 'auto',
                backgroundColor: AIR_LIGHT,
                border: \`3px solid \${AIR}\`,
                borderRadius: 22,
                padding: '24px 32px',
                display: 'flex',
                alignItems: 'center',
                gap: 24,
              }}
            >
              <div style={{ fontSize: 44 }}>🎯</div>
              <div>
                <div style={{ fontSize: 26, fontWeight: 900, color: AIR }}>CONSONANT RESOLUTION</div>
                <div style={{ fontSize: 20, color: INK, marginTop: 4, fontWeight: 700 }}>
                  S, F, TH, SH, T, P jaise sounds isi high-pitch zone mein decipher hote hain.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 6: (15.80s - 18.50s · Frames 474 - 555) · Duration: 2.70s
          ARCHETYPE MG-04: DYNAMIC AUDIOGRAM PLOTTER (The Sloping Dive)
          "Agar graph right side se drop ho..."
          ===================================================================== */}
      {frame >= 474 && frame < 555 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: CARD_TOP,
              left: CARD_LEFT,
              width: CARD_WIDTH,
              height: CARD_HEIGHT,
              backgroundColor: '#FFFFFF',
              border: \`4px solid \${INK}\`,
              borderRadius: 28,
              boxShadow: '0 16px 48px rgba(32, 37, 43, 0.12)',
              padding: '28px 32px',
              display: 'flex',
              flexDirection: 'column',
              boxSizing: 'border-box',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <span style={{ fontSize: 36, fontWeight: 900, color: INK }}>
                  HIGH-FREQUENCY DROP DETECTED
                </span>
                <div style={{ fontSize: 20, color: INK_SOFT, fontWeight: 700, marginTop: 4 }}>
                  Normal bass hearing, but steep cliff at 2000 Hz — 8000 Hz
                </div>
              </div>
              <span style={{ backgroundColor: STOP_LIGHT, color: STOP, border: \`2px solid \${STOP}\`, padding: '8px 20px', borderRadius: 20, fontSize: 22, fontWeight: 900 }}>
                RIGHT DROP
              </span>
            </div>

            {/* Audiogram SVG Plotter */}
            <svg width={836} height={780} viewBox="70 280 910 800" style={{ marginTop: 16 }}>
              {OCTAVES.map((f) => (
                <text
                  key={f}
                  x={fx(f)}
                  y={330}
                  textAnchor="middle"
                  fill={f >= 2000 ? STOP : INK}
                  fontSize={30}
                  fontWeight={900}
                >
                  {f < 1000 ? \`\${f}Hz\` : \`\${f / 1000}k\`}
                </text>
              ))}

              {[0, 20, 40, 60, 80, 100].map((db) => (
                <g key={db}>
                  <line x1={140} y1={dy(db)} x2={940} y2={dy(db)} stroke={db === 20 ? OK : GRID} strokeWidth={db === 20 ? 3.5 : 2} strokeDasharray={db === 20 ? "8 5" : "none"} />
                  <text x={125} y={dy(db) + 8} textAnchor="end" fill={db === 20 ? OK : INK_SOFT} fontSize={26} fontWeight={800}>
                    {db}
                  </text>
                </g>
              ))}

              {/* Sloping Curve Animation */}
              {(() => {
                const anim = easeOutCubic((frame - 474) / 45);
                const pts = [
                  { f: 250, db: 15 },
                  { f: 500, db: 15 },
                  { f: 1000, db: 20 },
                  { f: 2000, db: 20 + anim * 20 },  // Drops to 40 dB
                  { f: 4000, db: 20 + anim * 40 },  // Drops to 60 dB
                  { f: 8000, db: 20 + anim * 55 },  // Drops to 75 dB
                ];
                const d = pts.map((p, i) => \`\${i === 0 ? 'M' : 'L'} \${fx(p.f)} \${dy(p.db)}\`).join(' ');

                return (
                  <g>
                    <path d={d} fill="none" stroke={STOP} strokeWidth={8} strokeLinecap="round" />
                    {pts.map((p) => (
                      <circle key={p.f} cx={fx(p.f)} cy={dy(p.db)} r={11} fill="#FFFFFF" stroke={STOP} strokeWidth={4.5} />
                    ))}
                    {/* Slope Arrow */}
                    <g transform={\`translate(\${fx(6000)}, \${dy(50)})\`}>
                      <line x1={-30} y1={-30} x2={30} y2={30} stroke={STOP} strokeWidth={6} strokeLinecap="round" />
                      <polygon points="35,15 35,35 15,35" fill={STOP} />
                      <text x={-40} y={0} textAnchor="end" fill={STOP} fontSize={24} fontWeight={900}>
                        ⚠️ HIGH-FREQUENCY CLIFF
                      </text>
                    </g>
                  </g>
                );
              })()}
            </svg>

            {/* Bottom Insight Card */}
            <div
              style={{
                marginTop: 'auto',
                display: 'flex',
                gap: 20,
              }}
            >
              <div
                style={{
                  flex: 1,
                  backgroundColor: '#F0FDF4',
                  border: \`3px solid \${OK}\`,
                  borderRadius: 20,
                  padding: '20px 24px',
                }}
              >
                <div style={{ fontSize: 18, fontWeight: 900, color: OK }}>250 Hz - 1 kHz: INTACT</div>
                <div style={{ fontSize: 26, fontWeight: 900, color: INK, marginTop: 4 }}>Bass Volume Intact</div>
                <div style={{ fontSize: 18, color: INK_SOFT, marginTop: 4, fontWeight: 700 }}>
                  Aawaz aati hai, normal sunai deta hai
                </div>
              </div>
              <div
                style={{
                  flex: 1,
                  backgroundColor: '#FEF2F2',
                  border: \`3px solid \${STOP}\`,
                  borderRadius: 20,
                  padding: '20px 24px',
                }}
              >
                <div style={{ fontSize: 18, fontWeight: 900, color: STOP }}>2 kHz - 8 kHz: IMPAIRED</div>
                <div style={{ fontSize: 26, fontWeight: 900, color: STOP, marginTop: 4 }}>Clarity Dropped</div>
                <div style={{ fontSize: 18, color: INK_SOFT, marginTop: 4, fontWeight: 700 }}>
                  Consonants miss ho jate hain
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 7: (18.50s - 20.85s · Frames 555 - 625) · Duration: 2.35s
          ARCHETYPE MG-06: BLOCK-RESULT — SLOPING HEARING LOSS VERDICT
          "yaani Sloping Hearing Loss..."
          ===================================================================== */}
      {frame >= 555 && frame < 625 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: CARD_TOP,
              left: CARD_LEFT,
              width: CARD_WIDTH,
              height: CARD_HEIGHT,
              backgroundColor: '#FFFFFF',
              border: \`4px solid \${INK}\`,
              borderRadius: 28,
              boxShadow: '0 16px 48px rgba(32, 37, 43, 0.12)',
              padding: '36px',
              display: 'flex',
              flexDirection: 'column',
              boxSizing: 'border-box',
            }}
          >
            <div style={{ alignSelf: 'flex-start', backgroundColor: STOP_LIGHT, color: STOP, border: \`2px solid \${STOP}\`, padding: '8px 22px', borderRadius: 20, fontSize: 22, fontWeight: 900 }}>
              DIAGNOSTIC CLASSIFICATION
            </div>
            <div style={{ fontSize: 50, fontWeight: 900, color: STOP, marginTop: 16, letterSpacing: 1.5 }}>
              SLOPING HEARING LOSS
            </div>
            <div style={{ fontSize: 24, fontWeight: 700, color: INK_SOFT, marginTop: 6 }}>
              High-Frequency Sensorineural Impairment (HF-SNHL)
            </div>

            <div style={{ display: 'flex', gap: 24, marginTop: 32, flex: 1 }}>
              {/* Left Box: Volume is Heard */}
              <div
                style={{
                  flex: 1,
                  backgroundColor: '#F0FDF4',
                  border: \`3.5px solid \${OK}\`,
                  borderRadius: 24,
                  padding: '28px',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  textAlign: 'center',
                }}
              >
                <div style={{ fontSize: 56 }}>🔊</div>
                <div style={{ fontSize: 32, fontWeight: 900, color: TEAL, marginTop: 12 }}>
                  VOLUME IS HEARD
                </div>
                <div style={{ fontSize: 22, fontWeight: 800, color: OK, marginTop: 6 }}>
                  Bass at 15-20 dB (Normal)
                </div>
                <div style={{ fontSize: 20, color: INK, marginTop: 18, lineHeight: 1.45, fontWeight: 700 }}>
                  Patient says:<br/>
                  <span style={{ fontSize: 24, color: TEAL, fontWeight: 900 }}>"Mujhe aawaz toh aati hai!"</span>
                </div>
              </div>

              {/* Right Box: Words are Muffled */}
              <div
                style={{
                  flex: 1,
                  backgroundColor: '#FEF2F2',
                  border: \`3.5px solid \${STOP}\`,
                  borderRadius: 24,
                  padding: '28px',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  textAlign: 'center',
                }}
              >
                <div style={{ fontSize: 56 }}>🌫️</div>
                <div style={{ fontSize: 32, fontWeight: 900, color: STOP, marginTop: 12 }}>
                  WORDS ARE MUFFLED
                </div>
                <div style={{ fontSize: 22, fontWeight: 800, color: STOP, marginTop: 6 }}>
                  Treble at 55-75 dB (Impaired)
                </div>
                <div style={{ fontSize: 20, color: INK, marginTop: 18, lineHeight: 1.45, fontWeight: 700 }}>
                  Patient says:<br/>
                  <span style={{ fontSize: 24, color: STOP, fontWeight: 900 }}>"Par samajh nahi aata kya bola!"</span>
                </div>
              </div>
            </div>

            <div
              style={{
                marginTop: 'auto',
                backgroundColor: INK,
                color: '#FFFFFF',
                borderRadius: 22,
                padding: '22px 32px',
                textAlign: 'center',
              }}
            >
              <div style={{ fontSize: 22, fontWeight: 900, color: '#F7C948' }}>
                THE CLASSIC AUDIOLOGICAL PARADOX
              </div>
              <div style={{ fontSize: 20, marginTop: 6, fontWeight: 700, color: PAPER }}>
                Ear canal passes sound energy normally, but cochlea base misses consonant precision.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 8: (20.85s - 24.65s · Frames 625 - 739) · Duration: 3.80s (114 frames)
          PROFESSIONAL HOST CLINICIAN REGISTER [CLIP 1]
          "Volume toh sunai deta hai, par words muffled lagte hain..."
          Master audio continuous, sub-clip muted, spot-on lip sync!
          Large readable context cards across chest safe zone clear of face.
          ===================================================================== */}
      {isHostClip1 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H, backgroundColor: PAPER }}>
          <Sequence from={625} durationInFrames={114}>
            <OffthreadVideo
              src={staticFile('clips/audiogram4_clip1_synced.mp4')}
              style={{ width: W, height: H, objectFit: 'cover' }}
              muted
            />
          </Sequence>

          {/* Top Context Pill for Silent Viewers */}
          <div
            style={{
              position: 'absolute',
              top: CARD_TOP,
              left: CARD_LEFT,
              width: CARD_WIDTH,
              backgroundColor: 'rgba(32, 37, 43, 0.95)',
              borderRadius: 20,
              padding: '16px 28px',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              boxShadow: '0 12px 32px rgba(32,37,43,0.22)',
              zIndex: 9000,
            }}
          >
            <span style={{ fontSize: 24, fontWeight: 900, color: '#FFFFFF', letterSpacing: '1px' }}>
              THE SLOPING LOSS PARADOX
            </span>
            <span style={{ fontSize: 20, fontWeight: 900, backgroundColor: STOP, color: '#FFFFFF', padding: '6px 18px', borderRadius: 12 }}>
              AAWAZ HAI, PAR CLARITY NAHI
            </span>
          </div>

          {/* Lower Diagnostic Comparison Badges across Chest Safe Zone */}
          <div
            style={{
              position: 'absolute',
              top: 1260,
              left: CARD_LEFT,
              width: CARD_WIDTH,
              display: 'flex',
              justifyContent: 'space-between',
              gap: 24,
              zIndex: 9000,
            }}
          >
            <div
              style={{
                flex: 1,
                backgroundColor: 'rgba(255, 255, 255, 0.98)',
                border: \`3px solid \${OK}\`,
                borderRadius: 22,
                padding: '20px 24px',
                boxShadow: '0 12px 32px rgba(32,37,43,0.18)',
              }}
            >
              <div style={{ fontSize: 18, fontWeight: 900, color: OK, textTransform: 'uppercase' }}>
                VOLUME / LOUDNESS
              </div>
              <div style={{ fontSize: 32, fontWeight: 900, color: INK, marginTop: 4 }}>
                HEARING: OK
              </div>
              <div style={{ fontSize: 18, color: INK_SOFT, marginTop: 4, fontWeight: 700 }}>
                Low-frequency bass intact (≤ 20 dB)
              </div>
            </div>

            <div
              style={{
                flex: 1,
                backgroundColor: 'rgba(255, 255, 255, 0.98)',
                border: \`3px solid \${STOP}\`,
                borderRadius: 22,
                padding: '20px 24px',
                boxShadow: '0 12px 32px rgba(32,37,43,0.18)',
              }}
            >
              <div style={{ fontSize: 18, fontWeight: 900, color: STOP, textTransform: 'uppercase' }}>
                SPEECH CLARITY
              </div>
              <div style={{ fontSize: 32, fontWeight: 900, color: STOP, marginTop: 4 }}>
                WORDS: MUFFLED
              </div>
              <div style={{ fontSize: 18, color: INK_SOFT, marginTop: 4, fontWeight: 700 }}>
                High-frequency treble dropped (≥ 60 dB)
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 9: (24.65s - 27.29s · Frames 739 - 818) · Duration: 2.64s (79 frames)
          MINIMALISTIC ARCHETYPE MG-01: BIOLOGICAL TIMELINE (PRESBYCUSIS)
          "jo natural aging ka ek classic sign hai."
          ===================================================================== */}
      {frame >= 739 && frame < 818 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: CARD_TOP,
              left: CARD_LEFT,
              width: CARD_WIDTH,
              height: CARD_HEIGHT,
              backgroundColor: '#FFFFFF',
              border: \`4px solid \${INK}\`,
              borderRadius: 28,
              boxShadow: '0 16px 48px rgba(32, 37, 43, 0.12)',
              padding: '32px 36px',
              display: 'flex',
              flexDirection: 'column',
              boxSizing: 'border-box',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ fontSize: 20, fontWeight: 900, color: INK_SOFT, letterSpacing: '1.5px', textTransform: 'uppercase' }}>
                BIOLOGICAL TIMELINE
              </div>
              <div style={{ backgroundColor: TEAL_LIGHT, color: TEAL, border: \`2px solid \${TEAL}\`, padding: '8px 20px', borderRadius: 20, fontSize: 20, fontWeight: 900 }}>
                NATURAL AGING (PRESBYCUSIS)
              </div>
            </div>

            <div style={{ fontSize: 44, fontWeight: 900, color: INK, marginTop: 8 }}>
              COGNITIVE AGING PROGRESSION
            </div>
            <div style={{ fontSize: 24, color: INK_SOFT, marginTop: 4, fontWeight: 700 }}>
              Gradual wear and tear of sensory hair cells at the base of the cochlea
            </div>

            {/* Biological Multi-Age Audiogram SVG */}
            <svg width={828} height={660} viewBox="0 0 828 660" style={{ marginTop: 20 }}>
              <rect x={20} y={20} width={788} height={620} rx={24} fill="#FDFCF9" stroke={GRID} strokeWidth={2} />

              {/* Frequency Axis */}
              {OCTAVES.map((f, i) => (
                <text key={f} x={100 + i * 115} y={70} textAnchor="middle" fill={INK} fontSize={28} fontWeight={900}>
                  {f < 1000 ? \`\${f}Hz\` : \`\${f / 1000}k\`}
                </text>
              ))}

              {/* dB Levels */}
              {[0, 20, 40, 60, 80].map((db, i) => (
                <g key={db}>
                  <line x1={60} y1={120 + i * 100} x2={760} y2={120 + i * 100} stroke={db === 20 ? OK : GRID} strokeWidth={db === 20 ? 3 : 1.5} strokeDasharray={db === 20 ? "8 6" : "none"} />
                  <text x={45} y={128 + i * 100} textAnchor="end" fill={db === 20 ? OK : INK_SOFT} fontSize={24} fontWeight={800}>{db}</text>
                </g>
              ))}

              {/* Age 20 Curve (Flat Normal) */}
              <path d="M 100 170 L 215 170 L 330 170 L 445 175 L 560 180 L 675 185" fill="none" stroke={OK} strokeWidth={6} strokeLinecap="round" />
              <text x={690} y={190} fill={OK} fontSize={22} fontWeight={900}>AGE 20 (Normal)</text>

              {/* Age 45 Curve (Mild Treble Drop) */}
              <path d="M 100 180 L 215 180 L 330 190 L 445 230 L 560 280 L 675 320" fill="none" stroke={AIR} strokeWidth={6} strokeLinecap="round" />
              <text x={690} y={325} fill={AIR} fontSize={22} fontWeight={900}>AGE 45 (Mild Drop)</text>

              {/* Age 70 Curve (Classic Presbycusis) */}
              <path d="M 100 195 L 215 205 L 330 250 L 445 380 L 560 480 L 675 530" fill="none" stroke={STOP} strokeWidth={7} strokeLinecap="round" />
              <text x={690} y={535} fill={STOP} fontSize={22} fontWeight={900}>AGE 70 (Presbycusis)</text>
            </svg>

            {/* Bottom Clinical Facts Box */}
            <div
              style={{
                marginTop: 'auto',
                display: 'flex',
                gap: 20,
              }}
            >
              <div
                style={{
                  flex: 1,
                  backgroundColor: '#F8FAF9',
                  border: \`3px solid \${TEAL}\`,
                  borderRadius: 20,
                  padding: '20px 24px',
                }}
              >
                <div style={{ fontSize: 18, fontWeight: 900, color: TEAL }}>BIOLOGICAL CAUSE</div>
                <div style={{ fontSize: 26, fontWeight: 900, color: INK, marginTop: 4 }}>Hair Cell Atrophy</div>
                <div style={{ fontSize: 18, color: INK_SOFT, marginTop: 4, fontWeight: 700 }}>
                  High-pitch hair cells enter cochlea entrance, receiving maximum sound friction.
                </div>
              </div>
              <div
                style={{
                  flex: 1,
                  backgroundColor: '#FEF2F2',
                  border: \`3px solid \${STOP}\`,
                  borderRadius: 20,
                  padding: '20px 24px',
                }}
              >
                <div style={{ fontSize: 18, fontWeight: 900, color: STOP }}>CLINICAL REALITY</div>
                <div style={{ fontSize: 26, fontWeight: 900, color: STOP, marginTop: 4 }}>Irreversible Without Tech</div>
                <div style={{ fontSize: 18, color: INK_SOFT, marginTop: 4, fontWeight: 700 }}>
                  Damaged hair cells don't regrow. Modern hearing tech restores missing clarity.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 10: (27.29s - 30.16s · Frames 818 - 905) · Duration: 2.87s
          ARCHETYPE MG-05: PRECISION RETICLE — 4000 Hz ACOUSTIC NOISE NOTCH
          "Aur agar 4000 Hz par ek sharp notch ho..."
          Gradual notch animation (frames 828-868) with tracking reticle and recovery badge!
          ===================================================================== */}
      {frame >= 818 && frame < 905 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: CARD_TOP,
              left: CARD_LEFT,
              width: CARD_WIDTH,
              height: CARD_HEIGHT,
              backgroundColor: '#FFFFFF',
              border: \`4px solid \${INK}\`,
              borderRadius: 28,
              boxShadow: '0 16px 48px rgba(32, 37, 43, 0.12)',
              padding: '28px 32px',
              boxSizing: 'border-box',
              display: 'flex',
              flexDirection: 'column',
            }}
          >
            {(() => {
              // Gradual Notch Animation
              // Frames 818 - 828: Baseline normal flat line (~18 dB)
              // Frames 828 - 868: Progressive dive from 18 dB down to 60 dB
              // Frames 868 - 905: Locked notch at 60 dB with pulsing reticle
              const diveProg = Math.min(1, Math.max(0, (frame - 828) / 38));
              const easeDive = 1 - Math.pow(1 - diveProg, 3);
              const curDb4k = 18 + easeDive * 42; // Dives from 18 dB to 60 dB
              const curDb8k = 20 + easeDive * 5;  // Rebounds from 20 dB to 25 dB
              const isForming = diveProg > 0 && diveProg < 1;
              const isLocked = diveProg >= 1;

              const notchPts = [
                { f: 250, db: 15 },
                { f: 500, db: 15 },
                { f: 1000, db: 15 },
                { f: 2000, db: 18 },
                { f: 4000, db: curDb4k },
                { f: 8000, db: curDb8k },
              ];
              const d = notchPts.map((p, i) => \`\${i === 0 ? 'M' : 'L'} \${fx(p.f)} \${dy(p.db)}\`).join(' ');
              const reticleR = isLocked
                ? 26 + Math.sin(frame * 0.3) * 6
                : 40 - easeDive * 14;

              return (
                <>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <div style={{ fontSize: 38, fontWeight: 900, color: isLocked ? STOP : INK }}>
                        4000 Hz ACOUSTIC NOISE NOTCH
                      </div>
                      <div style={{ fontSize: 22, color: INK_SOFT, fontWeight: 700, marginTop: 4 }}>
                        {isLocked
                          ? '🚨 Sharp -42 dB Acoustic Trauma Drop Detected'
                          : isForming
                          ? '⚠️ Progressive Notch Developing at 4 kHz...'
                          : 'Normal High-Frequency Baseline'}
                      </div>
                    </div>
                    <div
                      style={{
                        backgroundColor: isLocked ? STOP_LIGHT : '#FEF3C7',
                        color: isLocked ? STOP : '#B45309',
                        border: \`2.5px solid \${isLocked ? STOP : '#F59E0B'}\`,
                        padding: '10px 22px',
                        borderRadius: 20,
                        fontSize: 22,
                        fontWeight: 900,
                        letterSpacing: 0.5,
                      }}
                    >
                      {isLocked
                        ? '🚨 4 kHz NOTCH: 60 dB'
                        : isForming
                        ? \`DIPPING: -\${Math.round(curDb4k)} dB\`
                        : 'MONITORING 4 kHz'}
                    </div>
                  </div>

                  <svg width={836} height={780} viewBox="70 280 910 800" style={{ marginTop: 16 }}>
                    {OCTAVES.map((f) => (
                      <text
                        key={f}
                        x={fx(f)}
                        y={330}
                        textAnchor="middle"
                        fill={f === 4000 ? STOP : INK}
                        fontSize={f === 4000 ? 34 : 30}
                        fontWeight={900}
                      >
                        {f < 1000 ? \`\${f}Hz\` : \`\${f / 1000}k\`}
                      </text>
                    ))}

                    {[0, 20, 40, 60, 80, 100].map((db) => (
                      <g key={db}>
                        <line x1={140} y1={dy(db)} x2={940} y2={dy(db)} stroke={GRID} strokeWidth={2} />
                        <text x={125} y={dy(db) + 8} textAnchor="end" fill={INK_SOFT} fontSize={26} fontWeight={800}>
                          {db}
                        </text>
                      </g>
                    ))}

                    {/* Normal 20 dB Reference Boundary */}
                    <line x1={140} y1={dy(20)} x2={940} y2={dy(20)} stroke={OK} strokeWidth={2.5} strokeDasharray="8 5" opacity={0.7} />

                    {/* Connecting Notch Path */}
                    <path d={d} fill="none" stroke={isLocked ? STOP : '#D97706'} strokeWidth={9} strokeLinecap="round" />

                    {/* All points */}
                    {notchPts.map((p) => {
                      const isNotchPt = p.f === 4000;
                      return (
                        <circle
                          key={p.f}
                          cx={fx(p.f)}
                          cy={dy(p.db)}
                          r={isNotchPt ? 14 : 9}
                          fill={isNotchPt ? STOP : '#FFFFFF'}
                          stroke={isNotchPt ? '#FFFFFF' : INK}
                          strokeWidth={isNotchPt ? 4 : 3}
                        />
                      );
                    })}

                    {/* Dynamic Notch Depth Caliper */}
                    {curDb4k > 25 && (
                      <g>
                        <line x1={fx(4000) - 45} y1={dy(20)} x2={fx(4000) - 20} y2={dy(20)} stroke={STOP} strokeWidth={3} />
                        <line x1={fx(4000) - 30} y1={dy(20)} x2={fx(4000) - 30} y2={dy(curDb4k)} stroke={STOP} strokeWidth={4} strokeDasharray="4 3" />
                        <line x1={fx(4000) - 45} y1={dy(curDb4k)} x2={fx(4000) - 20} y2={dy(curDb4k)} stroke={STOP} strokeWidth={3} />
                        <text x={fx(4000) - 55} y={dy((20 + curDb4k) / 2) + 6} textAnchor="end" fill={STOP} fontSize={22} fontWeight={900}>
                          -{Math.round(curDb4k - 20)} dB DIP
                        </text>
                      </g>
                    )}

                    {/* Precision Reticle on 4000 Hz Notch */}
                    <g transform={\`translate(\${fx(4000)}, \${dy(curDb4k)})\`}>
                      <circle cx={0} cy={0} r={reticleR} fill="none" stroke={STOP} strokeWidth={3.5} strokeDasharray={isLocked ? "6 4" : "none"} opacity={0.9} />
                      <circle cx={0} cy={0} r={6} fill={STOP} />
                      <line x1={-reticleR - 12} y1={0} x2={-reticleR + 2} y2={0} stroke={STOP} strokeWidth={3.5} />
                      <line x1={reticleR - 2} y1={0} x2={reticleR + 12} y2={0} stroke={STOP} strokeWidth={3.5} />
                      <line x1={0} y1={-reticleR - 12} x2={0} y2={-reticleR + 2} stroke={STOP} strokeWidth={3.5} />
                      <line x1={0} y1={reticleR - 2} x2={0} y2={reticleR + 12} stroke={STOP} strokeWidth={3.5} />

                      <rect x={18} y={-42} width={180} height={36} rx={8} fill={STOP} />
                      <text x={108} y={-18} textAnchor="middle" fill="#FFFFFF" fontSize={20} fontWeight={900}>
                        4 kHz: {Math.round(curDb4k)} dB HL
                      </text>
                    </g>

                    {/* 8000 Hz Recovery Arrow & Badge */}
                    {isLocked && (
                      <g>
                        <path
                          d={\`M \${fx(4000) + 20} \${dy(60) - 10} Q \${fx(6000)} \${dy(40)} \${fx(8000) - 15} \${dy(25) + 10}\`}
                          fill="none"
                          stroke={OK}
                          strokeWidth={4.5}
                          strokeDasharray="6 4"
                        />
                        <polygon points={\`\${fx(8000) - 10},\${dy(25) + 5} \${fx(8000) - 5},\${dy(25) + 22} \${fx(8000) - 25},\${dy(25) + 16}\`} fill={OK} />
                        <rect x={fx(8000) - 135} y={dy(25) - 45} width={135} height={32} rx={6} fill={OK_LIGHT} stroke={OK} strokeWidth={2} />
                        <text x={fx(8000) - 67} y={dy(25) - 24} textAnchor="middle" fill={OK} fontSize={15} fontWeight={900}>
                          8 kHz RECOVERY
                        </text>
                      </g>
                    )}
                  </svg>

                  {/* Bottom Analysis Box */}
                  <div
                    style={{
                      marginTop: 'auto',
                      backgroundColor: isLocked ? STOP_LIGHT : '#FFFDF5',
                      border: \`3px solid \${isLocked ? STOP : '#F59E0B'}\`,
                      borderRadius: 20,
                      padding: '20px 28px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                    }}
                  >
                    <div>
                      <div style={{ fontSize: 24, fontWeight: 900, color: isLocked ? STOP : INK }}>
                        FORENSIC PROOF OF NOISE EXPOSURE
                      </div>
                      <div style={{ fontSize: 18, color: INK, marginTop: 4, fontWeight: 700 }}>
                        4 kHz dip is the signature anatomical injury from earphones &amp; gunfire/industrial noise.
                      </div>
                    </div>
                    <div
                      style={{
                        backgroundColor: isLocked ? STOP : '#D97706',
                        color: '#FFFFFF',
                        padding: '10px 22px',
                        borderRadius: 14,
                        fontSize: 20,
                        fontWeight: 900,
                        whiteSpace: 'nowrap',
                      }}
                    >
                      ACOUSTIC TRAUMA
                    </div>
                  </div>
                </>
              );
            })()}
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 11: (30.16s - 35.10s · Frames 905 - 1053) · Duration: 4.93s
          ARCHETYPE MG-01: ACOUSTIC TRAUMA FORENSIC PROOF
          "yeh loud headphones aur noise exposure ka direct proof hai."
          ===================================================================== */}
      {frame >= 905 && frame < 1053 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: CARD_TOP,
              left: CARD_LEFT,
              width: CARD_WIDTH,
              height: CARD_HEIGHT,
              backgroundColor: '#FFFFFF',
              border: \`4px solid \${INK}\`,
              borderRadius: 28,
              boxShadow: '0 16px 48px rgba(32, 37, 43, 0.12)',
              padding: '36px',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              boxSizing: 'border-box',
            }}
          >
            <div style={{ backgroundColor: STOP_LIGHT, color: STOP, border: \`2px solid \${STOP}\`, padding: '10px 24px', borderRadius: 20, fontSize: 22, fontWeight: 900 }}>
              FORENSIC AUDIOLOGY EVIDENCE
            </div>
            <div style={{ fontSize: 44, fontWeight: 900, color: INK, marginTop: 16, textAlign: 'center' }}>
              DIRECT PROOF OF NOISE DAMAGE
            </div>
            <div style={{ fontSize: 24, color: INK_SOFT, marginTop: 6, fontWeight: 700, textAlign: 'center' }}>
              High sound pressure destroys sensitive stereocilia at the 4 kHz resonance site
            </div>

            {/* Visual Headphone Acoustic Trauma Graphic */}
            <svg width={560} height={420} viewBox="0 0 500 360" style={{ marginTop: 24 }}>
              {/* Headband */}
              <path d="M 120 180 A 130 130 0 0 1 380 180" fill="none" stroke={INK} strokeWidth={14} strokeLinecap="round" />
              {/* Left Cup */}
              <rect x={90} y={160} width={45} height={90} rx={18} fill={INK} />
              <rect x={125} y={170} width={15} height={70} rx={6} fill={STOP} />
              {/* Right Cup */}
              <rect x={365} y={160} width={45} height={90} rx={18} fill={INK} />
              <rect x={360} y={170} width={15} height={70} rx={6} fill={STOP} />

              {/* Sound waves from ear cups */}
              {(() => {
                const s1 = ((frame - 905) * 4) % 40;
                return (
                  <g>
                    <path d={\`M \${145 + s1} 185 A 25 25 0 0 1 \${145 + s1} 225\`} fill="none" stroke={STOP} strokeWidth={4.5} opacity={1 - s1 / 40} />
                    <path d={\`M \${355 - s1} 185 A 25 25 0 0 0 \${355 - s1} 225\`} fill="none" stroke={STOP} strokeWidth={4.5} opacity={1 - s1 / 40} />
                  </g>
                );
              })()}

              {/* Central Danger Decibel Badge */}
              <g transform="translate(250, 210)">
                <circle cx={0} cy={0} r={75} fill={STOP_LIGHT} stroke={STOP} strokeWidth={5} />
                <text x={0} y={-8} textAnchor="middle" fill={STOP} fontSize={36} fontWeight={950}>
                  &gt; 85 dB
                </text>
                <text x={0} y={24} textAnchor="middle" fill={INK} fontSize={18} fontWeight={900}>
                  SPL DANGER
                </text>
              </g>
            </svg>

            {/* Bottom 3-Card Clinical Comparison Grid */}
            <div style={{ display: 'flex', gap: 20, width: '100%', marginTop: 'auto' }}>
              <div
                style={{
                  flex: 1,
                  backgroundColor: '#FEF2F2',
                  border: \`3px solid \${STOP}\`,
                  borderRadius: 20,
                  padding: '20px',
                  textAlign: 'center',
                }}
              >
                <div style={{ fontSize: 18, fontWeight: 900, color: STOP }}>LOUD MUSIC</div>
                <div style={{ fontSize: 26, fontWeight: 900, color: INK, marginTop: 4 }}>&gt; 85 dB SPL</div>
                <div style={{ fontSize: 16, color: INK_SOFT, marginTop: 4, fontWeight: 700 }}>Continuous headphone blast</div>
              </div>

              <div
                style={{
                  flex: 1,
                  backgroundColor: '#FEF2F2',
                  border: \`3px solid \${STOP}\`,
                  borderRadius: 20,
                  padding: '20px',
                  textAlign: 'center',
                }}
              >
                <div style={{ fontSize: 18, fontWeight: 900, color: STOP }}>CANAL RESONANCE</div>
                <div style={{ fontSize: 26, fontWeight: 900, color: INK, marginTop: 4 }}>3-4 kHz BOOST</div>
                <div style={{ fontSize: 16, color: INK_SOFT, marginTop: 4, fontWeight: 700 }}>Ear canal amplifies notch</div>
              </div>

              <div
                style={{
                  flex: 1,
                  backgroundColor: '#FEF2F2',
                  border: \`3.5px solid \${STOP}\`,
                  borderRadius: 20,
                  padding: '20px',
                  textAlign: 'center',
                }}
              >
                <div style={{ fontSize: 18, fontWeight: 900, color: STOP }}>PERMANENT</div>
                <div style={{ fontSize: 26, fontWeight: 900, color: STOP, marginTop: 4 }}>HAIR DAMAGE</div>
                <div style={{ fontSize: 16, color: INK_SOFT, marginTop: 4, fontWeight: 700 }}>Non-reversible notch</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 12: (35.10s - 40.73s · Frames 1053 - 1222) · Duration: 5.63s (169 frames)
          PROFESSIONAL HOST CLINICIAN REGISTER [CLIP 2]
          "Audiogram tumhari hearing health ka blueprint hai, jo kabhi jhooth nahi bolta."
          Master audio continuous, sub-clip muted, spot-on lip sync!
          Large blueprint authority card across chest safe zone clear of face.
          ===================================================================== */}
      {isHostClip2 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H, backgroundColor: PAPER }}>
          <Sequence from={1053} durationInFrames={169}>
            <OffthreadVideo
              src={staticFile('clips/audiogram4_clip2_synced.mp4')}
              style={{ width: W, height: H, objectFit: 'cover' }}
              muted
            />
          </Sequence>

          {/* Lower Blueprint Authority Card across Chest Safe Zone */}
          <div
            style={{
              position: 'absolute',
              top: 1260,
              left: CARD_LEFT,
              width: CARD_WIDTH,
              backgroundColor: 'rgba(255, 255, 255, 0.98)',
              border: \`4px solid \${INK}\`,
              borderRadius: 24,
              padding: '26px 32px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              boxShadow: '0 16px 40px rgba(32, 37, 43, 0.22)',
              zIndex: 9000,
            }}
          >
            <div>
              <div style={{ fontSize: 18, fontWeight: 900, color: TEAL, letterSpacing: '1.5px', textTransform: 'uppercase' }}>
                05 / CLINICAL EVIDENCE
              </div>
              <div style={{ fontSize: 32, fontWeight: 900, color: INK, marginTop: 4 }}>
                KABHI JHOOTH NAHI BOLTA
              </div>
              <div style={{ fontSize: 20, color: INK_SOFT, marginTop: 4, fontWeight: 700 }}>
                Hearing Health Ka 100% Objective Blueprint
              </div>
            </div>
            <div
              style={{
                backgroundColor: TEAL_LIGHT,
                border: \`3px solid \${TEAL}\`,
                borderRadius: 18,
                padding: '14px 24px',
                fontSize: 20,
                fontWeight: 900,
                color: TEAL,
              }}
            >
              OBJECTIVE BIOMARKER
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 14: (40.76s - 44.50s · Frames 1222 - 1335) · Duration: 3.74s
          ARCHETYPE MG-03: THE PART 5 MYSTERY (Two Identical Audiograms)
          "Next part mein: do logon ka graph bilkul same hone par bhi..."
          Full safe area height (1290px), large readable twin audiograms,
          synchronous laser sweep, and paradox visualizer!
          ===================================================================== */}
      {frame >= 1222 && frame < 1335 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: CARD_TOP,
              left: CARD_LEFT,
              width: CARD_WIDTH,
              height: CARD_HEIGHT,
              backgroundColor: '#FFFFFF',
              border: \`4px solid \${INK}\`,
              borderRadius: 28,
              boxShadow: '0 16px 48px rgba(32, 37, 43, 0.12)',
              padding: '28px 32px',
              display: 'flex',
              flexDirection: 'column',
              boxSizing: 'border-box',
            }}
          >
            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ backgroundColor: TEAL_LIGHT, color: TEAL, border: \`2px solid \${TEAL}\`, padding: '8px 22px', borderRadius: 20, fontSize: 20, fontWeight: 900 }}>
                ⚡ COMING IN PART 5 · CLINICAL MYSTERY
              </div>
              <div style={{ backgroundColor: '#F3F4F6', color: INK, padding: '8px 18px', borderRadius: 16, fontSize: 18, fontWeight: 900 }}>
                AUDIOGRAM PARADOX
              </div>
            </div>

            <div style={{ fontSize: 40, fontWeight: 900, color: INK, marginTop: 12 }}>
              TWO 100% IDENTICAL AUDIOGRAMS
            </div>
            <div style={{ fontSize: 22, color: INK_SOFT, fontWeight: 700, marginTop: 4 }}>
              Both patients have identical 40 dB moderate loss... yet hear completely differently!
            </div>

            {/* Side-by-Side Twin Audiograms with Synchronous Laser Sweep */}
            {(() => {
              const sweepX = 40 + ((frame - 1222) * 4) % 320;
              const twinPts = [
                { f: 250, x: 50, y: 75, db: 15 },
                { f: 500, x: 110, y: 105, db: 20 },
                { f: 1000, x: 175, y: 145, db: 25 },
                { f: 2000, x: 240, y: 205, db: 35 },
                { f: 4000, x: 305, y: 255, db: 42 },
                { f: 8000, x: 360, y: 275, db: 45 },
              ];
              const twinD = twinPts.map((p, i) => \`\${i === 0 ? 'M' : 'L'} \${p.x} \${p.y}\`).join(' ');

              return (
                <div style={{ display: 'flex', gap: 20, marginTop: 16, position: 'relative' }}>
                  {/* Patient A Card */}
                  <div
                    style={{
                      flex: 1,
                      border: \`3px solid #2E9E6B\`,
                      borderRadius: 22,
                      padding: '18px',
                      backgroundColor: '#F0FDF4',
                      boxShadow: '0 8px 24px rgba(46, 158, 107, 0.1)',
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontSize: 24, fontWeight: 900, color: INK }}>👤 PATIENT A</span>
                      <span style={{ backgroundColor: '#DCFCE7', color: '#166534', padding: '4px 14px', borderRadius: 12, fontSize: 16, fontWeight: 900 }}>
                        40 dB LOSS
                      </span>
                    </div>

                    <svg width={380} height={340} viewBox="0 0 390 330" style={{ marginTop: 12, backgroundColor: '#FFFFFF', borderRadius: 16, border: \`1.5px solid \${GRID}\` }}>
                      {/* Freq text */}
                      {['250', '500', '1k', '2k', '4k', '8k'].map((txt, i) => (
                        <text key={txt} x={50 + i * 62} y={26} textAnchor="middle" fill={INK} fontSize={18} fontWeight={900}>
                          {txt}
                        </text>
                      ))}
                      {/* dB grid lines */}
                      {[0, 20, 40, 60, 80].map((db, i) => (
                        <g key={db}>
                          <line x1={30} y1={50 + i * 58} x2={375} y2={50 + i * 58} stroke={db === 20 ? OK : GRID} strokeWidth={db === 20 ? 2 : 1.5} strokeDasharray={db === 20 ? "5 4" : "none"} />
                          <text x={24} y={56 + i * 58} textAnchor="end" fill={INK_SOFT} fontSize={16} fontWeight={800}>{db}</text>
                        </g>
                      ))}
                      {/* Threshold Path */}
                      <path d={twinD} fill="none" stroke="#2E9E6B" strokeWidth={6} strokeLinecap="round" />
                      {twinPts.map((p) => (
                        <circle key={p.f} cx={p.x} cy={p.y} r={8} fill="#FFFFFF" stroke="#2E9E6B" strokeWidth={4} />
                      ))}
                      {/* Active Laser Line */}
                      <line x1={sweepX} y1={35} x2={sweepX} y2={310} stroke="#2E9E6B" strokeWidth={3.5} opacity={0.85} />
                      <line x1={sweepX} y1={35} x2={sweepX} y2={310} stroke="#A7F3D0" strokeWidth={10} opacity={0.35} />
                    </svg>
                    <div style={{ marginTop: 10, fontSize: 18, fontWeight: 900, color: '#166534', textAlign: 'center' }}>
                      Hearing Threshold: 40 dB HL
                    </div>
                  </div>

                  {/* Patient B Card */}
                  <div
                    style={{
                      flex: 1,
                      border: \`3px solid #E06830\`,
                      borderRadius: 22,
                      padding: '18px',
                      backgroundColor: '#FFF7ED',
                      boxShadow: '0 8px 24px rgba(224, 104, 48, 0.1)',
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontSize: 24, fontWeight: 900, color: INK }}>👤 PATIENT B</span>
                      <span style={{ backgroundColor: '#FFEDD5', color: '#9A3412', padding: '4px 14px', borderRadius: 12, fontSize: 16, fontWeight: 900 }}>
                        40 dB LOSS
                      </span>
                    </div>

                    <svg width={380} height={340} viewBox="0 0 390 330" style={{ marginTop: 12, backgroundColor: '#FFFFFF', borderRadius: 16, border: \`1.5px solid \${GRID}\` }}>
                      {/* Freq text */}
                      {['250', '500', '1k', '2k', '4k', '8k'].map((txt, i) => (
                        <text key={txt} x={50 + i * 62} y={26} textAnchor="middle" fill={INK} fontSize={18} fontWeight={900}>
                          {txt}
                        </text>
                      ))}
                      {/* dB grid lines */}
                      {[0, 20, 40, 60, 80].map((db, i) => (
                        <g key={db}>
                          <line x1={30} y1={50 + i * 58} x2={375} y2={50 + i * 58} stroke={db === 20 ? OK : GRID} strokeWidth={db === 20 ? 2 : 1.5} strokeDasharray={db === 20 ? "5 4" : "none"} />
                          <text x={24} y={56 + i * 58} textAnchor="end" fill={INK_SOFT} fontSize={16} fontWeight={800}>{db}</text>
                        </g>
                      ))}
                      {/* Threshold Path */}
                      <path d={twinD} fill="none" stroke="#E06830" strokeWidth={6} strokeLinecap="round" />
                      {twinPts.map((p) => (
                        <circle key={p.f} cx={p.x} cy={p.y} r={8} fill="#FFFFFF" stroke="#E06830" strokeWidth={4} />
                      ))}
                      {/* Active Laser Line */}
                      <line x1={sweepX} y1={35} x2={sweepX} y2={310} stroke="#E06830" strokeWidth={3.5} opacity={0.85} />
                      <line x1={sweepX} y1={35} x2={sweepX} y2={310} stroke="#FED7AA" strokeWidth={10} opacity={0.35} />
                    </svg>
                    <div style={{ marginTop: 10, fontSize: 18, fontWeight: 900, color: '#9A3412', textAlign: 'center' }}>
                      Hearing Threshold: 40 dB HL
                    </div>
                  </div>

                  {/* Central 100% Identical Link Badge */}
                  <div
                    style={{
                      position: 'absolute',
                      top: '50%',
                      left: '50%',
                      transform: 'translate(-50%, -50%)',
                      backgroundColor: INK,
                      color: '#FFFFFF',
                      border: \`3px solid #F7C948\`,
                      padding: '10px 22px',
                      borderRadius: 24,
                      fontSize: 18,
                      fontWeight: 900,
                      boxShadow: '0 12px 32px rgba(0,0,0,0.3)',
                      zIndex: 20,
                      whiteSpace: 'nowrap',
                    }}
                  >
                    🔒 100% IDENTICAL GRAPHS
                  </div>
                </div>
              );
            })()}

            {/* Middle Diagnostic Takeaway Bar */}
            <div
              style={{
                backgroundColor: '#F8F6F0',
                border: \`3px solid \${INK}\`,
                borderRadius: 20,
                padding: '16px 24px',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                margin: '16px 0',
              }}
            >
              <div>
                <div style={{ fontSize: 22, fontWeight: 900, color: INK }}>THRESHOLD DELTA = 0.0 dB HL</div>
                <div style={{ fontSize: 18, color: INK_SOFT, fontWeight: 700, marginTop: 4 }}>
                  Dono kaano ko sound detect karne ke liye exact same volume chahiye
                </div>
              </div>
              <div style={{ backgroundColor: TEAL, color: '#FFFFFF', padding: '8px 18px', borderRadius: 14, fontSize: 18, fontWeight: 900 }}>
                100% IDENTICAL
              </div>
            </div>

            {/* Bottom Clinical Paradox Bar: High contrast, mute-friendly storytelling */}
            <div
              style={{
                marginTop: 'auto',
                backgroundColor: INK,
                borderRadius: 22,
                padding: '24px 28px',
                boxShadow: '0 16px 40px rgba(32, 37, 43, 0.22)',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 22, fontWeight: 900, color: '#F7C948', letterSpacing: 1 }}>
                  ❓ THE MYSTERY
                </span>
                <span style={{ fontSize: 18, color: PAPER, opacity: 0.85, fontWeight: 800 }}>
                  PART 5 TEASER
                </span>
              </div>
              <div style={{ fontSize: 30, fontWeight: 900, color: '#FFFFFF', marginTop: 8 }}>
                Graph bilkul same... par sunai alag kyun?
              </div>

              <div style={{ display: 'flex', gap: 20, marginTop: 16 }}>
                <div style={{ flex: 1, backgroundColor: 'rgba(46, 158, 107, 0.25)', border: '2px solid #2E9E6B', borderRadius: 16, padding: '14px 18px' }}>
                  <div style={{ color: '#A7F3D0', fontSize: 16, fontWeight: 900 }}>PATIENT A EXPERIENCE:</div>
                  <div style={{ color: '#FFFFFF', fontSize: 20, fontWeight: 800, marginTop: 4 }}>
                    "Har word crystal clear samajh aata hai!"
                  </div>
                </div>
                <div style={{ flex: 1, backgroundColor: 'rgba(224, 104, 48, 0.25)', border: '2px solid #E06830', borderRadius: 16, padding: '14px 18px' }}>
                  <div style={{ color: '#FED7AA', fontSize: 16, fontWeight: 900 }}>PATIENT B EXPERIENCE:</div>
                  <div style={{ color: '#FFFFFF', fontSize: 20, fontWeight: 800, marginTop: 4 }}>
                    "Awaaz aati hai, par words jumbled lagte hain!"
                  </div>
                </div>
              </div>

              <div style={{ marginTop: 16, fontSize: 18, color: '#E2E8F0', textAlign: 'center', fontWeight: 700 }}>
                👂 Kaan sirf microphone hai · Asli speech decoding Brain karta hai
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 15: (44.50s - 48.64s · Frames 1335 - 1459) · Duration: 4.14s
          ARCHETYPE MG-06: BRAIN SPEECH DISCRIMINATION TEASER & CLINIC CTA
          "Clarity alag kyun hoti hai? Ispe baat karenge."
          Dynamic rolling counters (0 -> 92% vs 0 -> 48%), concrete speech
          waveform demonstration ("CHAMPION" test), and pulsing Follow CTA!
          ===================================================================== */}
      {frame >= 1335 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: CARD_TOP,
              left: CARD_LEFT,
              width: CARD_WIDTH,
              height: CARD_HEIGHT,
              backgroundColor: '#FFFFFF',
              border: \`4px solid \${INK}\`,
              borderRadius: 28,
              boxShadow: '0 16px 48px rgba(32, 37, 43, 0.12)',
              padding: '28px 32px',
              display: 'flex',
              flexDirection: 'column',
              boxSizing: 'border-box',
            }}
          >
            {(() => {
              // Dynamic Rolling Counters
              const rollProg = Math.min(1, Math.max(0, (frame - 1335) / 26));
              const easeRoll = 1 - Math.pow(1 - rollProg, 3);
              const scoreA = Math.round(easeRoll * 92);
              const scoreB = Math.round(easeRoll * 48);
              const ctaPulse = 1 + Math.sin(frame * 0.15) * 0.04;

              return (
                <>
                  {/* Header */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ backgroundColor: TEAL_LIGHT, color: TEAL, border: \`2px solid \${TEAL}\`, padding: '8px 22px', borderRadius: 20, fontSize: 20, fontWeight: 900 }}>
                      🔬 PART 5 DEEP DIVE · CLINICAL REVELATION
                    </div>
                    <div style={{ backgroundColor: '#F3F4F6', color: INK, padding: '8px 18px', borderRadius: 16, fontSize: 18, fontWeight: 900 }}>
                      SDS SCORE
                    </div>
                  </div>

                  <div style={{ fontSize: 40, fontWeight: 900, color: INK, marginTop: 12 }}>
                    THE BRAIN SPEECH CLARITY GAP
                  </div>
                  <div style={{ fontSize: 22, color: INK_SOFT, fontWeight: 700, marginTop: 4 }}>
                    Speech Discrimination Score (SDS) · Word Recognition in Quiet
                  </div>

                  {/* Twin Brain Cards with Dynamic Rolling Counters & Concrete Waveforms */}
                  <div style={{ display: 'flex', gap: 20, marginTop: 16 }}>
                    {/* Patient A Brain */}
                    <div
                      style={{
                        flex: 1,
                        backgroundColor: '#F0FDF4',
                        border: \`3.5px solid #2E9E6B\`,
                        borderRadius: 22,
                        padding: '20px 18px',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        boxShadow: '0 10px 28px rgba(46, 158, 107, 0.12)',
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
                        <span style={{ fontSize: 24, fontWeight: 900, color: INK }}>🧠 PATIENT A</span>
                        <span style={{ backgroundColor: '#DCFCE7', color: '#166534', padding: '4px 12px', borderRadius: 12, fontSize: 16, fontWeight: 900 }}>
                          HEALTHY CORTEX
                        </span>
                      </div>

                      {/* Animated Circular Ring Gauge */}
                      <svg width={140} height={140} viewBox="0 0 140 140" style={{ margin: '12px 0 6px 0' }}>
                        <circle cx={70} cy={70} r={56} fill="none" stroke="#DCFCE7" strokeWidth={12} />
                        <circle
                          cx={70}
                          cy={70}
                          r={56}
                          fill="none"
                          stroke="#166534"
                          strokeWidth={12}
                          strokeDasharray={351.8}
                          strokeDashoffset={351.8 * (1 - scoreA / 100)}
                          strokeLinecap="round"
                          transform="rotate(-90 70 70)"
                        />
                        <text x={70} y={84} textAnchor="middle" fill="#166534" fontSize={44} fontWeight={950}>
                          {scoreA}%
                        </text>
                      </svg>
                      <div style={{ fontSize: 18, fontWeight: 900, color: '#166534', textAlign: 'center' }}>
                        EXCELLENT WORD CLARITY
                      </div>

                      {/* Concrete Word Test Visualizer */}
                      <div style={{ backgroundColor: '#FFFFFF', borderRadius: 16, padding: '14px 16px', border: '2px solid #BBF7D0', marginTop: 12, width: '100%', boxSizing: 'border-box' }}>
                        <div style={{ fontSize: 15, fontWeight: 900, color: INK_SOFT }}>CLINICAL WORD TEST:</div>
                        <div style={{ fontSize: 26, fontWeight: 900, color: '#166534', marginTop: 2, letterSpacing: 0.5 }}>
                          HEARD: "CHAMPION"
                        </div>
                        {/* Crisp Waveform */}
                        <svg width={330} height={46} viewBox="0 0 330 46" style={{ marginTop: 6 }}>
                          <path
                            d="M 10 23 Q 30 2, 50 23 T 90 23 T 130 6 T 170 40 T 210 10 T 250 36 T 290 23 T 320 23"
                            fill="none"
                            stroke="#2E9E6B"
                            strokeWidth={4}
                            strokeLinecap="round"
                          />
                        </svg>
                        <div style={{ fontSize: 16, fontWeight: 900, color: '#166534', marginTop: 4 }}>
                          ✓ 10/10 Consonants Decoded Accurately
                        </div>
                      </div>
                    </div>

                    {/* Patient B Brain */}
                    <div
                      style={{
                        flex: 1,
                        backgroundColor: '#FEF2F2',
                        border: \`3.5px solid #E06830\`,
                        borderRadius: 22,
                        padding: '20px 18px',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        boxShadow: '0 10px 28px rgba(224, 104, 48, 0.12)',
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
                        <span style={{ fontSize: 24, fontWeight: 900, color: INK }}>🧠 PATIENT B</span>
                        <span style={{ backgroundColor: '#FEE2E2', color: '#991B1B', padding: '4px 12px', borderRadius: 12, fontSize: 16, fontWeight: 900 }}>
                          CORTICAL DISTORTION
                        </span>
                      </div>

                      {/* Animated Circular Ring Gauge */}
                      <svg width={140} height={140} viewBox="0 0 140 140" style={{ margin: '12px 0 6px 0' }}>
                        <circle cx={70} cy={70} r={56} fill="none" stroke="#FEE2E2" strokeWidth={12} />
                        <circle
                          cx={70}
                          cy={70}
                          r={56}
                          fill="none"
                          stroke="#DC2626"
                          strokeWidth={12}
                          strokeDasharray={351.8}
                          strokeDashoffset={351.8 * (1 - scoreB / 100)}
                          strokeLinecap="round"
                          transform="rotate(-90 70 70)"
                        />
                        <text x={70} y={84} textAnchor="middle" fill="#DC2626" fontSize={44} fontWeight={950}>
                          {scoreB}%
                        </text>
                      </svg>
                      <div style={{ fontSize: 18, fontWeight: 900, color: '#DC2626', textAlign: 'center' }}>
                        WORDS MUFFLED &amp; BLURRED
                      </div>

                      {/* Concrete Word Test Visualizer */}
                      <div style={{ backgroundColor: '#FFFFFF', borderRadius: 16, padding: '14px 16px', border: '2px solid #FECACA', marginTop: 12, width: '100%', boxSizing: 'border-box' }}>
                        <div style={{ fontSize: 15, fontWeight: 900, color: INK_SOFT }}>CLINICAL WORD TEST:</div>
                        <div style={{ fontSize: 26, fontWeight: 900, color: '#DC2626', marginTop: 2, letterSpacing: 0.5 }}>
                          HEARD: "CH... M... ON"
                        </div>
                        {/* Distorted / Flattened Waveform */}
                        <svg width={330} height={46} viewBox="0 0 330 46" style={{ marginTop: 6 }}>
                          <path
                            d="M 10 23 Q 35 18, 60 23 T 110 23 T 160 28 T 210 19 T 260 23 T 310 23 T 320 23"
                            fill="none"
                            stroke="#DC2626"
                            strokeWidth={4}
                            strokeLinecap="round"
                            strokeDasharray="7 5"
                          />
                        </svg>
                        <div style={{ fontSize: 16, fontWeight: 900, color: '#DC2626', marginTop: 4 }}>
                          ✗ 5/10 Consonants Lost in Brain Processing
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Middle Clinical Takeaway Bar */}
                  <div
                    style={{
                      backgroundColor: '#F8F6F0',
                      border: \`3px solid \${INK}\`,
                      borderRadius: 20,
                      padding: '18px 24px',
                      display: 'flex',
                      justifyContent: 'space-around',
                      alignItems: 'center',
                      margin: '18px 0',
                    }}
                  >
                    <div style={{ textAlign: 'center', flex: 1 }}>
                      <div style={{ fontSize: 16, fontWeight: 900, color: INK_SOFT }}>AUDIOGRAM MEASURES:</div>
                      <div style={{ fontSize: 22, fontWeight: 900, color: INK, marginTop: 4 }}>👂 VOLUME (Did you hear the beep?)</div>
                    </div>
                    <div style={{ width: 2.5, height: 44, backgroundColor: GRID }} />
                    <div style={{ textAlign: 'center', flex: 1 }}>
                      <div style={{ fontSize: 16, fontWeight: 900, color: INK_SOFT }}>BRAIN SDS MEASURES:</div>
                      <div style={{ fontSize: 22, fontWeight: 900, color: TEAL, marginTop: 4 }}>🧠 CLARITY (Did you understand the word?)</div>
                    </div>
                  </div>

                  {/* High-Energy Follow CTA Card at Bottom */}
                  <div
                    style={{
                      marginTop: 'auto',
                      backgroundColor: INK,
                      borderRadius: 22,
                      padding: '22px 28px',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      boxShadow: '0 16px 40px rgba(32, 37, 43, 0.28)',
                      border: \`3px solid \${TEAL}\`,
                    }}
                  >
                    <div>
                      <div style={{ color: '#FFFFFF', fontSize: 28, fontWeight: 900 }}>
                        PART 5 DECODED SOON 🔔
                      </div>
                      <div style={{ color: PAPER, opacity: 0.9, fontSize: 18, marginTop: 4, fontWeight: 700 }}>
                        Follow to understand why the brain decodes speech differently
                      </div>
                    </div>
                    <div
                      style={{
                        transform: \`scale(\${ctaPulse})\`,
                        backgroundColor: TEAL,
                        color: '#FFFFFF',
                        padding: '14px 28px',
                        borderRadius: 16,
                        fontSize: 22,
                        fontWeight: 900,
                        boxShadow: '0 6px 20px rgba(45, 140, 133, 0.45)',
                      }}
                    >
                      FOLLOW →
                    </div>
                  </div>
                </>
              );
            })()}
          </div>
        </div>
      )}

      {/* =====================================================================
          GLOBAL CAPTIONS OVERLAY (Fixed safe zone plate at bottom)
          Positioned safely at bottom: 280px to clear Instagram's bottom 280px UI!
          Large 40px font size with high-contrast badge for effortless doomscrolling readability.
          ===================================================================== */}
      {activeCue && (
        <div
          style={{
            position: 'absolute',
            bottom: 280,
            left: CARD_LEFT,
            width: CARD_WIDTH,
            display: 'flex',
            justifyContent: 'center',
            zIndex: 9500,
          }}
        >
          <div
            style={{
              backgroundColor: 'rgba(32, 37, 43, 0.96)',
              backdropFilter: 'blur(16px)',
              padding: '20px 36px',
              borderRadius: 22,
              width: '100%',
              textAlign: 'center',
              boxShadow: '0 16px 44px rgba(0, 0, 0, 0.35)',
              border: '2.5px solid rgba(255, 255, 255, 0.2)',
              boxSizing: 'border-box',
            }}
          >
            {activeCue.hl && activeCue.text.toLowerCase().includes(activeCue.hl.toLowerCase()) ? (
              <span
                style={{
                  fontSize: 40,
                  fontWeight: 900,
                  color: '#FFFFFF',
                  lineHeight: 1.35,
                  letterSpacing: '0.2px',
                }}
              >
                {(() => {
                  const idx = activeCue.text.toLowerCase().indexOf(activeCue.hl.toLowerCase());
                  const before = activeCue.text.slice(0, idx);
                  const match = activeCue.text.slice(idx, idx + activeCue.hl.length);
                  const after = activeCue.text.slice(idx + activeCue.hl.length);
                  return (
                    <>
                      {before}
                      <span style={{ color: '#F7C948', fontWeight: 950 }}>
                        {match}
                      </span>
                      {after}
                    </>
                  );
                })()}
              </span>
            ) : (
              <span
                style={{
                  fontSize: 40,
                  fontWeight: 900,
                  color: '#FFFFFF',
                  lineHeight: 1.35,
                  letterSpacing: '0.2px',
                }}
              >
                {activeCue.text}
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
\`;

fs.writeFileSync(targetPath, content, 'utf8');
console.log('Successfully wrote updated AudiogramPart4Master.tsx with full safe area & large typography!');
