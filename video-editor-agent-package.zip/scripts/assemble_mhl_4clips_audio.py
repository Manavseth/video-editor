#!/usr/bin/env python3
import sys, os, subprocess, wave
import numpy as np

sys.stdout.reconfigure(encoding='utf-8')

def extract_wav(src, out_wav, start=None, dur=None):
    cmd = ["ffmpeg", "-y"]
    if start is not None:
        cmd.extend(["-ss", str(start)])
    cmd.extend(["-i", src])
    if dur is not None:
        cmd.extend(["-t", str(dur)])
    cmd.extend(["-vn", "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le", out_wav])
    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)

def read_wav(path):
    with wave.open(path, "rb") as w:
        frames = w.getnframes()
        sr = w.getframerate()
        raw = w.readframes(frames)
        data = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
        # reshape to (samples, 2)
        data = data.reshape(-1, 2)
        return sr, data

def write_wav(path, data, sr=48000):
    data = np.clip(data, -1.0, 1.0)
    int_data = (data * 32767.0).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(int_data.tobytes())

# Source files
MHL_RAW = r"work/mhl_reel/raw/mhl_rough_take.mp4"
C1 = r"work/mhl_reel/raw/c1_native_48k.wav"
C2 = r"work/mhl_reel/raw/c2_native_48k.wav"
C3 = r"work/mhl_reel/raw/c3_native_48k.wav"
C4 = r"work/mhl_reel/raw/c4_native_48k.wav"

# Extract intermediate narration bridges from MHL_RAW
B1_WAV = "work/mhl_reel/raw/b1_5620_21800.wav"
B2_WAV = "work/mhl_reel/raw/b2_29280_44780.wav"

print("Extracting intermediate narration bridges...")
extract_wav(MHL_RAW, B1_WAV, start=5.620, dur=16.180) # 5.620s to 21.800s
extract_wav(MHL_RAW, B2_WAV, start=29.280, dur=15.500) # 29.280s to 44.780s

sr, c1_data = read_wav(C1)
sr, b1_data = read_wav(B1_WAV)
sr, c2_data = read_wav(C2)
sr, b2_data = read_wav(B2_WAV)
sr, c3_data = read_wav(C3)
sr, c4_data = read_wav(C4)

print(f"C1 duration: {len(c1_data)/sr:.3f}s")
print(f"B1 duration: {len(b1_data)/sr:.3f}s")
print(f"C2 duration: {len(c2_data)/sr:.3f}s")
print(f"B2 duration: {len(b2_data)/sr:.3f}s")
print(f"C3 duration: {len(c3_data)/sr:.3f}s")
print(f"C4 duration: {len(c4_data)/sr:.3f}s")

# Let's crossfade with a 30ms equal-power window (1440 samples)
xfade_len = int(sr * 0.030) # 30ms

def crossfade(a, b, xfade_samples):
    t = np.linspace(0, 1, xfade_samples, endpoint=False)[:, None]
    fade_out = np.cos(t * np.pi / 2)
    fade_in = np.sin(t * np.pi / 2)
    overlap = a[-xfade_samples:] * fade_out + b[:xfade_samples] * fade_in
    return np.vstack([a[:-xfade_samples], overlap, b[xfade_samples:]])

# Stitch: c1 + b1 + c2 + b2 + c3 + c4
m1 = crossfade(c1_data, b1_data, xfade_len)
m2 = crossfade(m1, c2_data, xfade_len)
m3 = crossfade(m2, b2_data, xfade_len)
m4 = crossfade(m3, c3_data, xfade_len)
final_audio = crossfade(m4, c4_data, xfade_len)

total_dur = len(final_audio) / sr
print(f"Assembled Raw Duration: {total_dur:.3f}s")

raw_composite_wav = "work/mhl_reel/raw/mhl_4clips_raw_composite.wav"
write_wav(raw_composite_wav, final_audio, sr)

# Now normalize to -14.0 LUFS with ffmpeg loudnorm
out_14lufs = "work/mhl_reel/raw/mhl_4clips_master_soundtrack_14lufs.wav"
cmd = [
    "ffmpeg", "-y", "-i", raw_composite_wav,
    "-af", "loudnorm=I=-14:LRA=7:tp=-1.0",
    "-ar", "48000", "-c:a", "pcm_s16le", out_14lufs
]
subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
print(f"✓ Master soundtrack normalized to -14 LUFS saved at: {out_14lufs}")
