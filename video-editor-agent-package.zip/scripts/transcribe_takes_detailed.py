import whisper
import json
import scipy.io.wavfile as wavfile
import numpy as np

model = whisper.load_model("base")
raw_wav = r"f:\Antigravity\video editor\work\reel_whatsapp\audio_boosted.wav"
sr, data = wavfile.read(raw_wav)

# Let's inspect the 5 key sections:
sections = [
    ("Take 1", 41.0, 53.5),
    ("Take 2", 79.0, 85.5),
    ("Take 3", 141.0, 148.0),
    ("Take 4", 155.0, 159.0),
    ("Take 5", 165.5, 172.0)
]

for name, t0, t1 in sections:
    s0 = int(t0 * sr)
    s1 = int(t1 * sr)
    chunk = data[s0:s1]
    temp_wav = f"work/reel_whatsapp/temp_{name.replace(' ', '_')}.wav"
    wavfile.write(temp_wav, sr, chunk)
    res = model.transcribe(temp_wav, word_timestamps=True)
    print(f"\n=================== {name} ({t0}s - {t1}s) ===================")
    print("Full text:", res["text"])
    for seg in res["segments"]:
        for w in seg.get("words", []):
            print(f"  {t0 + w['start']:6.2f} - {t0 + w['end']:6.2f} : {w['word']}")
