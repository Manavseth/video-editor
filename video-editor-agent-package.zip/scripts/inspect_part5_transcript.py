import json

with open(r"f:\Antigravity\video editor\work\audiogram_part5\transcription.json", encoding="utf-8") as f:
    d = json.load(f)

print(f"Total duration: {d['duration']}s")
for i, s in enumerate(d["segments"]):
    w_list = [f"{w['word']} ({w['start']}-{w['end']})" for w in s.get("words", [])]
    print(f"Seg {i:02d} [{s['start']:05.2f} - {s['end']:05.2f}]: {s['text']}")
    print("   Words: " + ", ".join(w_list))
