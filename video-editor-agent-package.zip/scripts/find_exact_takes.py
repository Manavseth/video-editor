import numpy as np
import scipy.io.wavfile as wavfile
import json
import sys
from faster_whisper import WhisperModel

sys.stdout.reconfigure(encoding='utf-8')

wav_path = r"f:\Antigravity\video editor\work\rough_cut_classifier\audio.wav"
sr, data = wavfile.read(wav_path)
data = data.astype(np.float32) / 32768.0

print(f"Sample rate: {sr}, Length: {len(data)/sr:.2f}s")

# Compute RMS envelope with 20ms hops and 50ms window
hop = int(0.02 * sr)
win = int(0.05 * sr)
n_frames = (len(data) - win) // hop
rms = np.zeros(n_frames, dtype=np.float32)
for i in range(n_frames):
    chunk = data[i*hop : i*hop + win]
    rms[i] = np.sqrt(np.mean(chunk**2))

# Find noise floor (10th percentile of RMS)
noise_floor = np.percentile(rms, 15)
thresh = noise_floor * 3.5  # speech threshold
print(f"Noise floor RMS: {noise_floor:.5f}, Speech threshold: {thresh:.5f}")

# Find speech regions (bursts)
is_speech = rms > thresh
min_speech_frames = int(0.2 / 0.02)  # 200ms
min_silence_frames = int(0.5 / 0.02)  # 500ms gap to split

bursts = []
in_burst = False
start_f = 0
silence_f = 0

for i, sp in enumerate(is_speech):
    if sp:
        if not in_burst:
            in_burst = True
            start_f = i
        silence_f = 0
    else:
        if in_burst:
            silence_f += 1
            if silence_f >= min_silence_frames:
                end_f = i - silence_f
                if (end_f - start_f) >= min_speech_frames:
                    bursts.append((start_f * 0.02, end_f * 0.02))
                in_burst = False
if in_burst:
    bursts.append((start_f * 0.02, len(is_speech) * 0.02))

print(f"\nFound {len(bursts)} speech bursts across the recording:")
for idx, (t0, t1) in enumerate(bursts):
    print(f"Burst {idx+1:02d}: {t0:6.2f}s -> {t1:6.2f}s (dur: {t1-t0:5.2f}s)")

# Now transcribe each burst individually with faster_whisper to get 100% accurate, drift-free text
print("\nLoading model for burst transcription...")
model = WhisperModel("small", device="cpu", compute_type="int8")

burst_results = []
for idx, (t0, t1) in enumerate(bursts):
    pad_t0 = max(0.0, t0 - 0.1)
    pad_t1 = min(len(data)/sr, t1 + 0.1)
    s0 = int(pad_t0 * sr)
    s1 = int(pad_t1 * sr)
    seg_audio = (data[s0:s1] * 32767.0).astype(np.int16)
    
    tmp_path = f"f:/Antigravity/video editor/work/rough_cut_classifier/tmp_burst_{idx}.wav"
    wavfile.write(tmp_path, sr, seg_audio)
    
    segs, _ = model.transcribe(tmp_path, language="hi", beam_size=3)
    text = " ".join(s.text.strip() for s in segs)
    print(f"[{pad_t0:6.2f}s -> {pad_t1:6.2f}s] Burst {idx+1:02d}: {text}")
    burst_results.append({
        "id": idx + 1,
        "start": round(pad_t0, 3),
        "end": round(pad_t1, 3),
        "text": text
    })

with open(r"f:\Antigravity\video editor\work\rough_cut_classifier\bursts.json", "w", encoding="utf-8") as f:
    json.dump(burst_results, f, indent=2, ensure_ascii=False)
