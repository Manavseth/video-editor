import os
import math
from PIL import Image, ImageDraw, ImageFont

art_dir = r"C:\Users\Lenovo\.gemini\antigravity\brain\41ef0fe8-618e-4426-a591-9b8597667e48"
out_img_path = os.path.join(art_dir, "clinic_style_sample.jpg")

W, H = 1080, 1920
img = Image.new("RGB", (W, H), (10, 15, 29)) # Deep midnight slate
draw = ImageDraw.Draw(img, "RGBA")

# 1. Radial Spotlight Glow in center
for r in range(600, 0, -15):
    alpha = int(35 * (1.0 - (r / 600.0)) ** 1.8)
    draw.ellipse([W//2 - r, H//2 - 120 - r, W//2 + r, H//2 - 120 + r], fill=(255, 200, 100, alpha))

# Secondary warm inner halo
for r in range(260, 0, -10):
    alpha = int(45 * (1.0 - (r / 260.0)) ** 1.5)
    draw.ellipse([W//2 - r, H//2 - 120 - r, W//2 + r, H//2 - 120 + r], fill=(255, 225, 140, alpha))

# 2. Ambient glowing dust particles
import random
random.seed(42)
for _ in range(35):
    px = random.randint(100, W - 100)
    py = random.randint(200, H - 350)
    pr = random.randint(2, 5)
    pa = random.randint(60, 180)
    draw.ellipse([px-pr, py-pr, px+pr, py+pr], fill=(255, 220, 130, pa))

# 3. Stylized Anatomical Ear & Cochlea (Vector silhouette & paper-cut layers)
# Outer ear canal silhouette (stylized dark cream / dusky rose)
center_x = W // 2
center_y = H // 2 - 120

# Draw concentric golden sound wave arcs emanating from left into the ear
for wave_r in [180, 240, 300, 360]:
    draw.arc([center_x - 380 - wave_r, center_y - wave_r, center_x - 380 + wave_r, center_y + wave_r], 
             start=-35, end=35, fill=(255, 200, 80, 160), width=3)

# Eardrum / Tympanic Membrane (Glowing golden membrane)
draw.line([center_x - 140, center_y - 90, center_x - 120, center_y + 90], fill=(255, 215, 0, 220), width=6)
draw.text((center_x - 190, center_y - 120), "TYMPANIC MEMBRANE", fill=(200, 220, 255, 200))

# Ossicles chain (Malleus, Incus, Stapes) stylized geometric bones
draw.polygon([(center_x - 120, center_y), (center_x - 70, center_y - 50), (center_x - 50, center_y - 30)], fill=(225, 215, 200, 255), outline=(255, 235, 180, 255))
draw.polygon([(center_x - 50, center_y - 30), (center_x, center_y - 40), (center_x - 10, center_y + 10)], fill=(205, 195, 180, 255), outline=(255, 235, 180, 255))
draw.polygon([(center_x - 10, center_y + 10), (center_x + 40, center_y + 5), (center_x + 40, center_y + 25)], fill=(235, 225, 210, 255), outline=(255, 235, 180, 255))

# Cochlea spiral (Golden geometric nautilus shell)
spiral_pts = []
for a in range(0, 720, 5):
    rad = math.radians(a)
    r = 25 + 0.22 * a
    sx = center_x + 90 + r * math.cos(rad)
    sy = center_y + 15 + r * math.sin(rad)
    spiral_pts.append((sx, sy))

for i in range(len(spiral_pts) - 1):
    draw.line([spiral_pts[i], spiral_pts[i+1]], fill=(255, 205, 60, 240), width=5)

# Glowing neural action potential lines into auditory nerve
for n in range(5):
    ny = center_y - 20 + n * 18
    draw.line([center_x + 220, ny, center_x + 380, ny - 30], fill=(100, 220, 255, 200), width=3)
    # Synaptic dots
    draw.ellipse([center_x + 380 - 4, ny - 34, center_x + 380 + 4, ny - 26], fill=(180, 245, 255, 255))

# 4. Blueprint Technical Dimensions & Calipers (Faith vs Fact style)
# Caliper horizontal line
draw.line([center_x - 140, center_y + 180, center_x + 250, center_y + 180], fill=(255, 200, 70, 180), width=2)
draw.line([center_x - 140, center_y + 170, center_x - 140, center_y + 190], fill=(255, 200, 70, 220), width=3)
draw.line([center_x + 250, center_y + 170, center_x + 250, center_y + 190], fill=(255, 200, 70, 220), width=3)
draw.text((center_x - 20, center_y + 195), "32 MILLIMETERS (COCHLEAR DUCT)", fill=(255, 215, 100, 220))

# Decibel spectrum badge
draw.rectangle([center_x - 220, center_y - 320, center_x + 220, center_y - 260], fill=(15, 25, 45, 220), outline=(255, 200, 80, 200), width=2)
draw.text((center_x - 170, center_y - 300), "FREQUENCY RESONANCE: 20Hz - 20,000Hz", fill=(255, 230, 140, 255))

# 5. Authoritative Classical Serif Subtitles (Faith vs Fact Style)
sub_y = 1530
# "THE HUMAN COCHLEA PROCESSES OVER"
# "20,000 FREQUENCIES IN PARALLEL."
draw.rectangle([center_x - 450, sub_y - 20, center_x + 450, sub_y + 80], fill=(0, 0, 0, 140))

# We write the text centered:
# Line 1:
draw.text((center_x - 330, sub_y - 10), "THE HUMAN COCHLEA PROCESSES OVER", fill=(255, 255, 255, 255))
# Line 2:
draw.text((center_x - 390, sub_y + 35), "20,000 SOUND FREQUENCIES", fill=(255, 205, 55, 255))
draw.text((center_x + 100, sub_y + 35), "SIMULTANEOUSLY.", fill=(255, 255, 255, 255))

# Save image
img.save(out_img_path, quality=90)
print(f"Generated clinic style sample image: {out_img_path}")
