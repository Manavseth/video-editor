import subprocess
import os
import numpy as np
import scipy.io.wavfile as wavfile

work_dir = r"f:\Antigravity\video editor\work\reel_whatsapp"
raw_audio = os.path.join(work_dir, "audio_boosted.wav")
clean_audio = os.path.join(work_dir, "audio_denoised_clean.wav")

# Denoising filter chain:
# 1. highpass=f=80 (removes low-end sub-bass rumbles / mic thumps)
# 2. afftdn=nf=-28:tn=1 (adaptive FFT denoiser with noise floor -28dB, track noise enabled)
# 3. acompressor=threshold=-20dB:ratio=2.5:attack=15:release=120 (evens out dynamics)
# 4. volume=2dB (healthy vocal level)
cmd_denoise = [
    "ffmpeg", "-y",
    "-i", raw_audio,
    "-af", "highpass=f=80,afftdn=nf=-28:tn=1,acompressor=threshold=-20dB:ratio=2.5:attack=15:release=120,volume=2dB",
    "-ar", "48000",
    "-ac", "2",
    clean_audio
]
subprocess.run(cmd_denoise, check=True)
print("Denoised audio created successfully.")

# Measure silent section vs speech section
sr, data = wavfile.read(clean_audio)
data = data.astype(np.float32) / 32768.0
# Noise section: 10s to 13s (silence in raw)
noise_sec = data[int(10*sr):int(13*sr)]
noise_rms = 20 * np.log10(np.sqrt(np.mean(noise_sec**2)) + 1e-9)

# Speech section: 41.5s to 43.5s
speech_sec = data[int(41.5*sr):int(43.5*sr)]
speech_rms = 20 * np.log10(np.sqrt(np.mean(speech_sec**2)) + 1e-9)

print(f"Noise Floor RMS: {noise_rms:.1f} dB")
print(f"Speech Level RMS: {speech_rms:.1f} dB")
print(f"Estimated SNR: {speech_rms - noise_rms:.1f} dB")
