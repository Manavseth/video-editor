import puppeteer from 'puppeteer-core';
import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';

const edgePath = 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const OUT_DIR = path.resolve('scratch');
fs.mkdirSync(OUT_DIR, { recursive: true });

// Read the rendered subtitle plates as data URLs or file paths
const SUB_DIR = path.resolve('scratch/subtitles');

const htmlContent = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    width: 1080px;
    height: 1920px;
    overflow: hidden;
    background: #F5F2EA;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  }
  canvas {
    position: absolute;
    top: 0; left: 0;
    width: 1080px;
    height: 1920px;
  }
</style>
</head>
<body>
  <canvas id="c" width="1080" height="1920"></canvas>
  <script>
    const canvas = document.getElementById('c');
    const ctx = canvas.getContext('2d');

    const C = {
      paper: '#F5F2EA',
      card: '#FBFAF7',
      ink: '#20252B',
      gray: '#8B9298',
      grayLight: '#D2D7DC',
      teal: '#2D8C85',
      ambient: '#A6ADB0',
      gold: '#C9A65E'
    };

    function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }
    function lerp(a, b, t) { return a + (b - a) * clamp(t, 0, 1); }
    function ease(t) {
      const x = clamp(t, 0, 1);
      return x * x * (3 - 2 * x);
    }
    function between(t, a, b) { return ease((t - a) / (b - a)); }

    function drawCard(x, y, w, h, r = 22) {
      ctx.save();
      ctx.shadowColor = 'rgba(32, 37, 43, 0.08)';
      ctx.shadowBlur = 18;
      ctx.shadowOffsetY = 8;
      ctx.fillStyle = C.card;
      ctx.strokeStyle = C.ink;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.roundRect(x, y, w, h, r);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

    function drawSpeechWave(x, y, w, color = C.ink, lw = 4) {
      ctx.save();
      ctx.strokeStyle = color;
      ctx.lineWidth = lw;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + w * 0.2, y);
      ctx.lineTo(x + w * 0.28, y - 18);
      ctx.lineTo(x + w * 0.42, y + 24);
      ctx.lineTo(x + w * 0.56, y - 26);
      ctx.lineTo(x + w * 0.70, y + 18);
      ctx.lineTo(x + w, y);
      ctx.stroke();
      ctx.restore();
    }

    function drawAmbientLines(x, y, w) {
      ctx.save();
      ctx.strokeStyle = C.ambient;
      ctx.lineWidth = 3;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(x, y - 25);
      ctx.lineTo(x + w * 0.3, y - 25);
      ctx.lineTo(x + w * 0.45, y - 35);
      ctx.lineTo(x + w * 0.6, y - 18);
      ctx.lineTo(x + w, y - 25);

      ctx.moveTo(x + 20, y + 35);
      ctx.lineTo(x + w * 0.35, y + 35);
      ctx.lineTo(x + w * 0.5, y + 22);
      ctx.lineTo(x + w * 0.65, y + 42);
      ctx.lineTo(x + w - 10, y + 35);
      ctx.stroke();
      ctx.restore();
    }

    // Subtitle images cache
    const subImages = {};
    for (let i = 1; i <= 15; i++) {
      const img = new Image();
      img.src = 'sub_' + String(i).padStart(2, '0') + '.png';
      subImages[i] = img;
    }

    function drawSubtitle(id) {
      const img = subImages[id];
      if (img && img.complete) {
        ctx.drawImage(img, 0, 0, 1080, 1920);
      }
    }

    window.renderFrame = function(t) {
      ctx.fillStyle = C.paper;
      ctx.fillRect(0, 0, 1080, 1920);

      // BLOCK 1: MG-01, MG-02, MG-03 (6.500 to 17.667s)
      if (t >= 6.500 && t < 17.667) {
        if (t < 10.500) {
          // MG-01: Phone to Classifier Morph
          const p = between(t, 6.7, 7.8);
          ctx.fillStyle = C.gray;
          ctx.font = '700 28px -apple-system, sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('01 / ACOUSTIC MECHANISM', 540, 320);

          ctx.fillStyle = C.ink;
          ctx.font = '800 52px -apple-system, sans-serif';
          ctx.fillText('Environmental Classifier', 540, 390);

          ctx.fillStyle = C.gray;
          ctx.font = '500 28px -apple-system, sans-serif';
          ctx.fillText('Sound scenes automatically guide device processing', 540, 445);

          // Card morph
          const cardW = lerp(320, 780, p);
          const cardH = lerp(480, 320, p);
          const cardX = 540 - cardW / 2;
          const cardY = lerp(600, 680, p);
          drawCard(cardX, cardY, cardW, cardH);

          if (p < 0.4) {
            // Phone outline view
            ctx.fillStyle = C.gray;
            ctx.beginPath();
            ctx.roundRect(540 - 15, cardY + 120, 30, 240, 15);
            ctx.fill();
            const thumbY = lerp(cardY + 280, cardY + 160, between(t, 6.5, 6.9));
            ctx.fillStyle = C.teal;
            ctx.beginPath();
            ctx.arc(540, thumbY, 18, 0, Math.PI * 2);
            ctx.fill();
          } else {
            // Process Card View
            const cAlpha = between(t, 7.2, 8.0);
            ctx.save();
            ctx.globalAlpha = cAlpha;
            ctx.fillStyle = C.ink;
            ctx.font = '700 24px -apple-system, sans-serif';
            ctx.textAlign = 'left';
            ctx.fillText('environmental classifier', cardX + 40, cardY + 55);

            // Inputs
            [120, 165, 210].forEach(dy => {
              ctx.fillStyle = C.gray;
              ctx.beginPath();
              ctx.arc(cardX + 65, cardY + dy, 10, 0, Math.PI * 2);
              ctx.fill();
              ctx.strokeStyle = C.gray;
              ctx.lineWidth = 3;
              ctx.beginPath();
              ctx.moveTo(cardX + 85, cardY + dy);
              ctx.lineTo(cardX + 220, cardY + 165);
              ctx.stroke();
            });

            // Center Module
            ctx.fillStyle = C.teal;
            ctx.beginPath();
            ctx.roundRect(cardX + 280, cardY + 115, 200, 100, 18);
            ctx.fill();
            ctx.fillStyle = C.card;
            ctx.font = '700 30px -apple-system, sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText('scene', cardX + 380, cardY + 175);

            // Outputs
            ctx.strokeStyle = C.gray;
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(cardX + 480, cardY + 145);
            ctx.lineTo(cardX + 680, cardY + 130);
            ctx.moveTo(cardX + 480, cardY + 185);
            ctx.lineTo(cardX + 680, cardY + 200);
            ctx.stroke();

            // Output boxes
            ctx.fillStyle = C.card;
            ctx.strokeStyle = C.ink;
            ctx.lineWidth = 2.5;
            ctx.beginPath();
            ctx.roundRect(cardX + 680, cardY + 116, 50, 28, 8);
            ctx.roundRect(cardX + 680, cardY + 186, 50, 28, 8);
            ctx.fill();
            ctx.stroke();

            // Active Marker
            const markerX = lerp(cardX + 480, cardX + 680, between(t, 8.2, 9.6));
            ctx.fillStyle = C.teal;
            ctx.beginPath();
            ctx.arc(markerX, cardY + 145, 10, 0, Math.PI * 2);
            ctx.fill();

            ctx.restore();
          }

          if (t >= 7.0 && t <= 10.5) drawSubtitle(3);
        } else if (t < 13.900) {
          // MG-02: Acoustic Input to Context
          ctx.fillStyle = C.gray;
          ctx.font = '700 28px -apple-system, sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('01 / ACOUSTIC MECHANISM', 540, 320);
          ctx.fillStyle = C.ink;
          ctx.font = '800 52px -apple-system, sans-serif';
          ctx.fillText('Environment Context', 540, 390);

          drawCard(150, 680, 780, 320);
          ctx.fillStyle = C.ink;
          ctx.font = '700 24px -apple-system, sans-serif';
          ctx.textAlign = 'left';
          ctx.fillText('environmental classifier', 190, 735);

          // Inflow of sound
          const inProgress = between(t, 11.0, 12.0);
          drawSpeechWave(lerp(80, 170, inProgress), 820, 160, C.teal, 3.5);

          // Center Module
          ctx.fillStyle = C.teal;
          ctx.beginPath();
          ctx.roundRect(430, 795, 200, 100, 18);
          ctx.fill();
          ctx.fillStyle = C.card;
          ctx.font = '700 30px -apple-system, sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('scene', 530, 855);

          // Context Tag Resolving
          const tagP = between(t, 12.0, 13.2);
          ctx.save();
          ctx.globalAlpha = tagP;
          drawCard(425, 1100, 230, 72, 20);
          ctx.fillStyle = C.teal;
          ctx.beginPath();
          ctx.arc(460, 1136, 9, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = C.ink;
          ctx.font = '700 24px -apple-system, sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('context', 555, 1144);
          ctx.restore();

          if (t >= 11.0 && t <= 13.45) drawSubtitle(4);
        } else {
          // MG-03: Quiet vs Busy Comparison
          ctx.fillStyle = C.gray;
          ctx.font = '700 28px -apple-system, sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('02 / SOUND SCENES', 540, 320);
          ctx.fillStyle = C.ink;
          ctx.font = '800 52px -apple-system, sans-serif';
          ctx.fillText('Quiet vs. Busy Listening', 540, 390);

          const slide = between(t, 13.9, 14.5);
          const leftX = lerp(40, 90, slide);
          const rightX = lerp(620, 570, slide);

          // Quiet Card
          drawCard(leftX, 640, 420, 360);
          ctx.fillStyle = C.ink;
          ctx.font = '700 24px -apple-system, sans-serif';
          ctx.textAlign = 'left';
          ctx.fillText('quiet conversation', leftX + 35, 695);
          drawSpeechWave(leftX + 35, 800, 240, C.teal, 4);

          // Busy Card
          drawCard(rightX, 640, 420, 360);
          ctx.fillStyle = C.ink;
          ctx.font = '700 24px -apple-system, sans-serif';
          ctx.textAlign = 'left';
          ctx.fillText('busy restaurant', rightX + 35, 695);
          drawSpeechWave(rightX + 35, 800, 240, C.ink, 4);
          drawAmbientLines(rightX + 35, 800, 240);

          // Router Center
          drawCard(450, 1070, 180, 76, 20);
          ctx.fillStyle = C.teal;
          ctx.beginPath();
          ctx.arc(490, 1108, 12, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = C.ink;
          ctx.font = '700 22px -apple-system, sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('classify', 565, 1116);

          if (t >= 13.9 && t <= 17.25) drawSubtitle(5);
        }
      }

      // BLOCK 2: MG-04, MG-05 (26.100 to 33.300s)
      else if (t >= 26.100 && t < 33.300) {
        ctx.fillStyle = C.gray;
        ctx.font = '700 28px -apple-system, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('03 / EVERYDAY USE', 540, 320);
        ctx.fillStyle = C.ink;
        ctx.font = '800 52px -apple-system, sans-serif';
        ctx.fillText('Daily Route Navigation', 540, 390);

        // Route Line
        const routeY = 820;
        ctx.strokeStyle = C.ink;
        ctx.lineWidth = 4;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(160, routeY);
        ctx.lineTo(920, routeY);
        ctx.stroke();

        // 3 Stops
        const stops = [240, 540, 840];
        const labels = ['Home', 'Transit', 'Office'];
        stops.forEach((sx, i) => {
          ctx.fillStyle = C.card;
          ctx.strokeStyle = C.ink;
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.arc(sx, routeY, 14, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();

          ctx.fillStyle = C.gray;
          ctx.font = '700 20px -apple-system, sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText(labels[i], sx, routeY + 44);
        });

        // Route Traveling Marker
        const markerP = between(t, 26.3, 32.5);
        const markerX = lerp(stops[0], stops[2], markerP);
        ctx.fillStyle = C.teal;
        ctx.beginPath();
        ctx.arc(markerX, routeY, 16, 0, Math.PI * 2);
        ctx.fill();

        if (t >= 29.75) {
          // MG-05: Manual Selector Card Docking
          const dockP = between(t, 29.75, 30.5);
          const selX = lerp(860, 710, dockP);
          drawCard(selX, 920, 240, 260, 20);

          ctx.fillStyle = C.ink;
          ctx.font = '700 20px -apple-system, sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('manual control', selX + 120, 960);

          [1000, 1050, 1100].forEach((ry, idx) => {
            const isSel = idx === 1;
            ctx.fillStyle = isSel ? C.teal : C.grayLight;
            ctx.beginPath();
            ctx.roundRect(selX + 30, ry, 180, 32, 8);
            ctx.fill();
          });

          // Tag: may reduce manual changes
          ctx.fillStyle = C.gray;
          ctx.font = '600 22px -apple-system, sans-serif';
          ctx.fillText('may reduce manual changes', 540, 1280);
        }

        if (t >= 26.3 && t < 29.5) drawSubtitle(8);
        else if (t >= 29.75 && t <= 32.9) drawSubtitle(9);
      }

      // BLOCK 3: MG-06, MG-07, MG-08 (38.800 to 47.467s)
      else if (t >= 38.800 && t < 47.467) {
        ctx.fillStyle = C.gray;
        ctx.font = '700 28px -apple-system, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('04 / LISTENING BENEFIT', 540, 320);
        ctx.fillStyle = C.ink;
        ctx.font = '800 52px -apple-system, sans-serif';
        ctx.fillText('Conversation Support', 540, 390);

        if (t < 44.500) {
          // MG-06 / MG-07: Acoustic pattern to settings
          drawCard(180, 680, 720, 340);
          ctx.fillStyle = C.ink;
          ctx.font = '700 24px -apple-system, sans-serif';
          ctx.textAlign = 'left';
          ctx.fillText('acoustic scene context', 220, 735);

          drawSpeechWave(220, 820, 220, C.teal, 4);
          drawAmbientLines(220, 820, 220);

          // Classifier Core
          ctx.fillStyle = C.teal;
          ctx.beginPath();
          ctx.roundRect(500, 770, 180, 90, 16);
          ctx.fill();
          ctx.fillStyle = C.card;
          ctx.font = '700 26px -apple-system, sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('classifier', 590, 825);

          // Settings indicator
          drawCard(360, 1100, 360, 90, 20);
          ctx.fillStyle = C.ink;
          ctx.font = '700 22px -apple-system, sans-serif';
          ctx.fillText('settings adapted to scene', 540, 1152);

          if (t >= 39.2 && t < 43.8) drawSubtitle(12);
          else if (t >= 44.2) drawSubtitle(13);
        } else {
          // MG-08: Conversation support with ambience retained
          drawCard(180, 680, 720, 380);
          ctx.fillStyle = C.ink;
          ctx.font = '700 24px -apple-system, sans-serif';
          ctx.textAlign = 'left';
          ctx.fillText('conversation in background noise', 220, 735);

          // Modest speech enhancement with ambience remaining
          drawSpeechWave(220, 840, 340, C.teal, 4.5);
          drawAmbientLines(220, 840, 340);

          // Notice badge
          ctx.fillStyle = C.teal;
          ctx.font = '700 24px -apple-system, sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('speech clarity supported • ambience retained', 540, 980);

          if (t >= 44.2 && t <= 47.3) drawSubtitle(13);
        }
      }
    };
  </script>
</body>
</html>`;

const htmlPath = path.join(OUT_DIR, 'motion_engine.html');
fs.writeFileSync(htmlPath, htmlContent);

// Copy subtitle images to scratch folder so HTML can load them directly
for (let i = 1; i <= 15; i++) {
  const name = `sub_${String(i).padStart(2, '0')}.png`;
  const src = path.join(SUB_DIR, name);
  const dst = path.join(OUT_DIR, name);
  if (fs.existsSync(src)) fs.copyFileSync(src, dst);
}

async function renderBlock(page, startSec, endSec, outMp4) {
  const fps = 30;
  const startF = Math.round(startSec * fps);
  const endF = Math.round(endSec * fps);
  const totalF = endF - startF;

  console.log(`\nRendering motion block: ${startSec}s to ${endSec}s (${totalF} frames @ 30fps) -> ${outMp4}...`);

  const ff = spawn('ffmpeg', [
    '-y',
    '-loglevel', 'error',
    '-f', 'image2pipe',
    '-framerate', '30',
    '-c:v', 'png',
    '-i', '-',
    '-c:v', 'libx264',
    '-crf', '17',
    '-preset', 'fast',
    '-pix_fmt', 'yuv420p',
    outMp4
  ], { stdio: ['pipe', 'inherit', 'inherit'] });

  for (let f = 0; f < totalF; f++) {
    const curSec = (startF + f) / fps;
    const dataUrl = await page.evaluate(sec => {
      window.renderFrame(sec);
      return document.getElementById('c').toDataURL('image/png');
    }, curSec);

    const buf = Buffer.from(dataUrl.split(',')[1], 'base64');
    if (!ff.stdin.write(buf)) {
      await new Promise(r => ff.stdin.once('drain', r));
    }
    if (f % 60 === 0 || f === totalF - 1) {
      process.stdout.write(`  Frame ${f}/${totalF} (${((f / totalF) * 100).toFixed(0)}%)\r`);
    }
  }

  ff.stdin.end();
  await new Promise(r => ff.on('close', r));
  console.log(`\n✓ Motion block complete: ${outMp4}`);
}

async function main() {
  console.log('Launching browser to render 3 motion design blocks...');
  const browser = await puppeteer.launch({
    executablePath: edgePath,
    headless: true,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-web-security',
      '--allow-file-access-from-files'
    ]
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1080, height: 1920, deviceScaleFactor: 1 });
  await page.goto('file:///' + htmlPath.replace(/\\/g, '/'), { waitUntil: 'load' });

  // 1. Motion Block 1: 6.500 to 17.667s (11.167s = 335 frames)
  await renderBlock(page, 6.500, 17.667, path.join(OUT_DIR, 'motion_01.mp4'));

  // 2. Motion Block 2: 26.100 to 33.300s (7.200s = 216 frames)
  await renderBlock(page, 26.100, 33.300, path.join(OUT_DIR, 'motion_02.mp4'));

  // 3. Motion Block 3: 38.800 to 47.467s (8.667s = 260 frames)
  await renderBlock(page, 38.800, 47.467, path.join(OUT_DIR, 'motion_03.mp4'));

  await browser.close();
  console.log('✓ All 3 motion design blocks rendered successfully!');
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
