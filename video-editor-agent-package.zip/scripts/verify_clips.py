import os
import subprocess
import json

clip_dir = r"f:\Antigravity\video editor\out\individual_clips"
files = sorted([f for f in os.listdir(clip_dir) if f.endswith(".mp4")])

print(f"Verifying {len(files)} clips:")
for f in files:
    p = os.path.join(clip_dir, f)
    cmd = [
        "ffprobe", "-v", "error",
        "-show_entries", "stream=width,height,r_frame_rate,duration,codec_name",
        "-of", "json", p
    ]
    res = subprocess.run(cmd, stdout=subprocess.PIPE, text=True)
    d = json.loads(res.stdout)
    v_stream = next(s for s in d["streams"] if s.get("width"))
    a_stream = next((s for s in d["streams"] if s.get("codec_name") == "aac"), None)
    w = v_stream["width"]
    h = v_stream["height"]
    fps = v_stream["r_frame_rate"]
    dur = float(v_stream.get("duration", 0))
    has_audio = "YES (AAC)" if a_stream else "NO"
    print(f"• {f:30s} | {w}x{h} @ {fps} | Dur: {dur:4.2f}s | Audio: {has_audio}")
