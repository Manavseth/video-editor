import sys
import io
import json
from faster_whisper import WhisperModel

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

model = WhisperModel('base', device='cpu', compute_type='int8')
clips = [
    ('clip1', 'E:/Courses/clip1.mp4'),
    ('clip2', 'E:/Courses/clip2.mp4'),
    ('clip3', 'E:/Courses/clip3.mp4'),
    ('clip4', 'E:/Courses/clip4.mp4')
]

results = {}
for name, c in clips:
    segments, info = model.transcribe(c, word_timestamps=True)
    seg_list = []
    for s in segments:
        seg_list.append({
            'start': s.start,
            'end': s.end,
            'text': s.text,
            'words': [{'word': w.word, 'start': w.start, 'end': w.end} for w in s.words]
        })
    results[name] = {
        'path': c,
        'language': info.language,
        'probability': info.language_probability,
        'segments': seg_list
    }
    print(f"Done {name}")

with open('scratch/transcription_results.json', 'w', encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False, indent=2)

print("Saved to scratch/transcription_results.json")
