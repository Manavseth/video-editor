import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open(r"f:\Antigravity\video editor\work\rough_cut_classifier\transcription.json", encoding="utf-8") as f:
    data = json.load(f)

print(f"Total duration: {data['duration']:.2f}s")
print(f"Total segments: {len(data['segments'])}")
print(f"Total words: {len(data['words'])}")
print("\n=== SEGMENTS ===")
for s in data["segments"]:
    print(f"[{s['start']:6.2f}s -> {s['end']:6.2f}s] (dur: {s['end']-s['start']:5.2f}s): {s['text']}")

print("\n=== WORDS TIMELINE CLUSTERS ===")
# Group words separated by > 1.5s silence
clusters = []
curr = []
for w in data["words"]:
    if not curr:
        curr.append(w)
    else:
        gap = w["start"] - curr[-1]["end"]
        if gap > 1.2:
            clusters.append(curr)
            curr = [w]
        else:
            curr.append(w)
if curr:
    clusters.append(curr)

for idx, cl in enumerate(clusters):
    t0 = cl[0]["start"]
    t1 = cl[-1]["end"]
    txt = "".join(w["word"] for w in cl)
    print(f"Cluster {idx+1:02d} [{t0:6.2f}s -> {t1:6.2f}s] ({t1-t0:4.1f}s, {len(cl)} words): {txt}")
