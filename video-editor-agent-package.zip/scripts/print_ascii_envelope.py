import numpy as np
import scipy.io.wavfile as wavfile
import sys

sys.stdout.reconfigure(encoding='utf-8')

wav_path = r"f:\Antigravity\video editor\work\rough_cut_classifier\audio.wav"
sr, data = wavfile.read(wav_path)
data = data.astype(np.float32) / 32768.0

print("=== ONSET ENVELOPE (99.8s - 101.2s) ===")
for t in np.arange(99.8, 101.2, 0.05):
    s = int(t * sr)
    chunk = data[s:s + int(0.05 * sr)]
    rms = np.sqrt(np.mean(chunk**2))
    bars = "#" * int(min(50, rms * 1500))
    print(f"{t:6.2f}s | RMS: {rms:7.4f} | {bars}")

print("\n=== RELEASE ENVELOPE (154.2s - 154.86s) ===")
for t in np.arange(154.2, 154.85, 0.05):
    s = int(t * sr)
    chunk = data[s:s + int(0.05 * sr)]
    rms = np.sqrt(np.mean(chunk**2))
    bars = "#" * int(min(50, rms * 1500))
    print(f"{t:6.2f}s | RMS: {rms:7.4f} | {bars}")
