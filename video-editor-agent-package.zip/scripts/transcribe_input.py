import json
import time
from faster_whisper import WhisperModel

print("Loading Whisper model...")
model = WhisperModel("small", device="cpu", compute_type="int8")

audio_file = r"f:\Antigravity\video editor\work\rough_cut_classifier\audio.wav"
print(f"Transcribing {audio_file}...")
t0 = time.time()
segments, info = model.transcribe(audio_file, word_timestamps=True, vad_filter=True)

print(f"Detected language: {info.language} with probability {info.language_probability:.2f}")

all_segments = []
all_words = []

for seg in segments:
    seg_dict = {
        "id": seg.id,
        "start": round(seg.start, 3),
        "end": round(seg.end, 3),
        "text": seg.text.strip(),
        "words": []
    }
    if seg.words:
        for w in seg.words:
            w_dict = {
                "word": w.word,
                "start": round(w.start, 3),
                "end": round(w.end, 3),
                "probability": round(w.probability, 3)
            }
            seg_dict["words"].append(w_dict)
            all_words.append(w_dict)
    all_segments.append(seg_dict)

out_data = {
    "language": info.language,
    "duration": info.duration,
    "segments": all_segments,
    "words": all_words
}

out_path = r"f:\Antigravity\video editor\work\rough_cut_classifier\transcription.json"
with open(out_path, "w", encoding="utf-8") as f:
    json.dump(out_data, f, indent=2, ensure_ascii=False)

print(f"Done in {time.time()-t0:.2f}s! Wrote {len(all_segments)} segments and {len(all_words)} words to {out_path}.")
