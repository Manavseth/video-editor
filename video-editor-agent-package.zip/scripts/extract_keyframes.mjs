import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';

const outDir = 'work/style-refs/so_thats_how/deep_analysis/frames';
fs.mkdirSync(outDir, { recursive: true });

const videos = [
  { id: 'ref_1', duration: 85.05 },
  { id: 'ref_2', duration: 158.10 },
  { id: 'ref_3', duration: 95.63 },
  { id: 'ref_4', duration: 100.73 },
  { id: 'ref_5', duration: 50.20 },
  { id: 'ref_6', duration: 51.37 },
  { id: 'ref_7', duration: 56.98 },
  { id: 'ref_8', duration: 56.52 }
];

for (const v of videos) {
  const file = `work/style-refs/so_thats_how/all_videos/${v.id}.mp4`;
  const timestamps = [
    (v.duration * 0.05).toFixed(1),
    (v.duration * 0.25).toFixed(1),
    (v.duration * 0.50).toFixed(1),
    (v.duration * 0.75).toFixed(1),
    (v.duration * 0.95).toFixed(1)
  ];
  timestamps.forEach((t, idx) => {
    const frameOut = path.join(outDir, `${v.id}_f${idx+1}_${t}s.jpg`);
    execSync(`ffmpeg -y -ss ${t} -i "${file}" -frames:v 1 -q:v 2 "${frameOut}" 2>NUL`);
  });
  console.log(`Extracted 5 keyframes for ${v.id}`);
}
