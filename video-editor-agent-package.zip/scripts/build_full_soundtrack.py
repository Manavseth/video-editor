import numpy as np
import scipy.io.wavfile as wavfile
import scipy.signal as signal
import subprocess
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

SR = 48000
DUR = 54.100
TOTAL_SAMPLES = int(SR * DUR)

# 1. Load voice
voice_path = 'scratch/audio_v2/master_voice_from_download.wav'
sr_v, voice_data = wavfile.read(voice_path)
if voice_data.ndim == 1:
    voice_data = np.column_stack([voice_data, voice_data])
if len(voice_data) > TOTAL_SAMPLES:
    voice_data = voice_data[:TOTAL_SAMPLES]
elif len(voice_data) < TOTAL_SAMPLES:
    pad = np.zeros((TOTAL_SAMPLES - len(voice_data), 2), dtype=voice_data.dtype)
    voice_data = np.vstack([voice_data, pad])

v_float = voice_data.astype(np.float32) / 32768.0

# 2. Generate Warm Human Instrumental Bed (84 BPM, Key of D Major / B Minor)
# Progression: Dmaj7 -> Bm7 -> Gmaj7 -> A7 (4 measures = ~11.4s, repeating)
t = np.linspace(0, DUR, TOTAL_SAMPLES, endpoint=False)

def gen_note(freq, duration_sec, sample_rate=48000):
    n_samples = int(duration_sec * sample_rate)
    tn = np.linspace(0, duration_sec, n_samples, endpoint=False)
    # Warm bell/felt harmonic blend
    tone = (
        1.00 * np.sin(2 * np.pi * freq * tn) +
        0.35 * np.sin(2 * np.pi * 2 * freq * tn) * np.exp(-tn * 2.0) +
        0.12 * np.sin(2 * np.pi * 3 * freq * tn) * np.exp(-tn * 4.0) +
        0.05 * np.sin(2 * np.pi * 4 * freq * tn) * np.exp(-tn * 7.0)
    )
    # Gentle attack (40ms) and exponential decay
    att = int(0.04 * sample_rate)
    tone[:att] *= np.linspace(0, 1, att)
    tone[att:] *= np.exp(-(tn[att:] - 0.04) * 0.8)
    return tone

# Warm analog pad bed (gentle sine chords through low-pass)
pad = np.zeros(TOTAL_SAMPLES, dtype=np.float32)

# Chords at 84 BPM (each chord = 2 bars = 5.714s, or 1 bar = 2.857s)
bar_len = (60.0 / 84.0) * 4 # 2.857s
chords = [
    [146.83, 220.00, 277.18, 369.99], # Dmaj7 (D3, A3, C#4, F#4)
    [123.47, 185.00, 220.00, 293.66], # Bm7 (B2, F#3, A3, D4)
    [98.00, 146.83, 196.00, 293.66],  # Gmaj7 (G2, D3, G3, D4)
    [110.00, 164.81, 220.00, 277.18]  # A7 (A2, E3, A3, C#4)
]

cur_t = 0.0
c_idx = 0
while cur_t < DUR:
    chord_freqs = chords[c_idx % len(chords)]
    chord_dur = min(bar_len * 2, DUR - cur_t)
    start_sample = int(cur_t * SR)
    for f in chord_freqs:
        chunk = gen_note(f, chord_dur)
        pad[start_sample:start_sample + len(chunk)] += chunk * 0.18
    cur_t += bar_len * 2
    c_idx += 1

# Low-pass filter the pad for deep warmth (< 800 Hz)
b_lp, a_lp = signal.butter(4, 750.0 / (SR / 2.0), btype='low')
pad_warm = signal.filtfilt(b_lp, a_lp, pad)

# Subtle gentle pulse / rhythmic texture (warm muted marimba note every beat)
pulse = np.zeros(TOTAL_SAMPLES, dtype=np.float32)
beat_len = 60.0 / 84.0 # 0.714s
bt = 0.0
while bt < DUR - 0.2:
    idx = int(bt * SR)
    # alternate root / 5th
    f_p = 146.83 if (int(bt / beat_len) % 2 == 0) else 220.00
    p_chunk = gen_note(f_p, 0.45)
    pulse[idx:idx + len(p_chunk)] += p_chunk * 0.08
    bt += beat_len

b_p, a_p = signal.butter(2, 600.0 / (SR / 2.0), btype='low')
pulse_warm = signal.filtfilt(b_p, a_p, pulse)

music_bed = (pad_warm * 0.7 + pulse_warm * 0.3)

# 3. Speech Envelope Follower for Dynamic Ducking
# Calculate speech RMS in 50ms windows
win_size = int(0.05 * SR)
speech_mono = 0.5 * (np.abs(v_float[:, 0]) + np.abs(v_float[:, 1]))
speech_env = np.convolve(speech_mono, np.ones(win_size) / win_size, mode='same')

# Ducking gain: when speech > threshold, duck by ~5.5 dB (gain = 0.45), else gain = 1.0
duck_gain = np.ones(TOTAL_SAMPLES, dtype=np.float32)
for i in range(TOTAL_SAMPLES):
    if speech_env[i] > 0.025:
        duck_gain[i] = 0.38
    else:
        duck_gain[i] = 0.95

# Smooth ducking gain (attack 250ms, release 500ms)
b_env, a_env = signal.butter(2, 3.0 / (SR / 2.0), btype='low')
duck_smooth = signal.filtfilt(b_env, a_env, duck_gain)

# Apply ducking to music bed
ducked_music = music_bed * duck_smooth

# Fade in at 00:00 (1.2s), fade out at 54.100s (1.5s)
fade_in = int(1.2 * SR)
ducked_music[:fade_in] *= np.linspace(0, 1, fade_in)
fade_out = int(1.5 * SR)
ducked_music[-fade_out:] *= np.linspace(1, 0, fade_out)

# 4. Synthesize the 4 Tactile SFX (quiet, subtle, organic)
sfx_track = np.zeros(TOTAL_SAMPLES, dtype=np.float32)

def add_tactile_click(time_sec, amp=0.18):
    idx = int(time_sec * SR)
    dur = 0.04
    n = int(dur * SR)
    tn = np.linspace(0, dur, n, endpoint=False)
    # Dual pitched pop with rapid decay
    pop = (np.sin(2 * np.pi * 880 * tn) * 0.6 + np.sin(2 * np.pi * 1760 * tn) * 0.4) * np.exp(-tn * 160)
    sfx_track[idx:idx + n] += amp * pop

def add_paper_swish(time_sec, amp=0.16):
    idx = int(time_sec * SR)
    dur = 0.18
    n = int(dur * SR)
    tn = np.linspace(0, dur, n, endpoint=False)
    # Filtered white noise with bell curve envelope
    noise = np.random.uniform(-1, 1, n)
    b_sw, a_sw = signal.butter(2, [1200 / (SR / 2), 4500 / (SR / 2)], btype='band')
    swish = signal.filtfilt(b_sw, a_sw, noise) * np.sin(np.pi * tn / dur) ** 2
    sfx_track[idx:idx + n] += amp * swish

def add_control_tick(time_sec, amp=0.16):
    idx = int(time_sec * SR)
    dur = 0.03
    n = int(dur * SR)
    tn = np.linspace(0, dur, n, endpoint=False)
    tick = np.sin(2 * np.pi * 1200 * tn) * np.exp(-tn * 200)
    sfx_track[idx:idx + n] += amp * tick

# Place cues exactly per storyboard Section 7:
add_tactile_click(9.200, amp=0.18)   # MG-01 gate resolution
add_paper_swish(13.900, amp=0.16)   # MG-03 comparison pair enter
add_control_tick(30.400, amp=0.16)  # MG-05 manual switch
add_tactile_click(41.400, amp=0.18)  # MG-06 context tag resolution

# 5. Master Mix (Voice foreground + Ducked warm music + Subtle tactile SFX)
mix_l = v_float[:, 0] + ducked_music * 0.28 + sfx_track
mix_r = v_float[:, 1] + ducked_music * 0.28 + sfx_track

# Clip protection
mix_l = np.clip(mix_l, -0.98, 0.98)
mix_r = np.clip(mix_r, -0.98, 0.98)

final_stereo = np.column_stack([mix_l, mix_r])
int16_out = (final_stereo * 32767.0).astype(np.int16)

raw_out = 'scratch/raw_full_soundtrack.wav'
master_out = 'scratch/master_soundtrack_14lufs.wav'
wavfile.write(raw_out, SR, int16_out)
print(f"[OK] Raw mixed soundtrack written: {raw_out}")

# Normalize with FFmpeg Loudnorm to exactly -14.0 LUFS EBU R128
print("Normalizing to exact -14.0 LUFS with EBU R128...")
cmd_norm = [
    'ffmpeg', '-y',
    '-i', raw_out,
    '-af', 'loudnorm=I=-14.0:LRA=7.0:tp=-1.0',
    '-ar', '48000',
    '-c:a', 'pcm_s16le',
    master_out
]
res = subprocess.run(cmd_norm, capture_output=True, text=True)
if res.returncode != 0:
    print("Error normalizing audio:", res.stderr)
    sys.exit(1)

print(f"[OK] Calibrated -14 LUFS soundtrack ready: {master_out}")
