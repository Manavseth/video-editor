import json

with open("work/reel_whatsapp/transcript_en.json", encoding="utf-8") as f:
    data_en = json.load(f)

print("=== English Transcript Segments ===")
for seg in data_en.get("segments", []):
    print(f"[{seg['start']:6.2f}s -> {seg['end']:6.2f}s] {seg['text']}")

with open("work/reel_whatsapp/hindi_transcript.json", encoding="utf-8") as f:
    data_hi = json.load(f)

print("\n=== Hindi Transcript Segments ===")
for seg in data_hi.get("segments", []):
    print(f"[{seg['start']:6.2f}s -> {seg['end']:6.2f}s] {seg['text']}")
