import os
import subprocess

clip_dir = r"f:\Antigravity\video editor\out\individual_clips"
work_dir = r"f:\Antigravity\video editor\work\reel_whatsapp"
bed_wav = r"f:\Antigravity\video editor\remotion_ci_reel\public\classifier_soundtrack.wav"
out_master = r"f:\Antigravity\video editor\out\ClassifierMasterReel_Hybrid_35s.mp4"

# 1. Create concat file list
concat_list_path = os.path.join(work_dir, "concat_clips.txt")
clips = [
    "clip_01_host_hook.mp4",
    "clip_02_code_chaos.mp4",
    "clip_03_host_concept.mp4",
    "clip_04_code_dsp_chip.mp4",
    "clip_05_code_modulation.mp4",
    "clip_06_host_settings.mp4",
    "clip_07_code_matrix.mp4",
    "clip_08_host_caveat.mp4",
    "clip_09_code_subtraction.mp4",
    "clip_10_host_context.mp4",
    "clip_11_host_punchline.mp4"
]

with open(concat_list_path, "w", encoding="utf-8") as f:
    for c in clips:
        p = os.path.join(clip_dir, c).replace("\\", "/")
        f.write(f"file '{p}'\n")

print("Concat list written.")

# 2. Concat video & dialogue track
concat_raw = os.path.join(work_dir, "raw_assembled.mp4")
cmd_concat = [
    "ffmpeg", "-y",
    "-f", "concat", "-safe", "0",
    "-i", concat_list_path,
    "-vf", "fps=30",
    "-c:v", "libx264", "-preset", "slow", "-crf", "18", "-pix_fmt", "yuv420p",
    "-c:a", "pcm_s16le", "-ar", "48000",
    concat_raw
]
subprocess.run(cmd_concat, check=True)
print("Raw assembled video created.")

# 3. Mix assembled audio with the cinematic bed & master to -14.0 LUFS
cmd_mix = [
    "ffmpeg", "-y",
    "-i", concat_raw,
    "-i", bed_wav,
    "-filter_complex",
    "[1:a]volume=0.25[bed];[0:a][bed]amix=inputs=2:duration=first:dropout_transition=2,loudnorm=I=-14.0:TP=-1.0:LRA=7.0[aout]",
    "-map", "0:v",
    "-map", "[aout]",
    "-c:v", "copy",
    "-r", "30",
    "-c:a", "aac", "-b:a", "256k", "-ar", "48000",
    "-movflags", "+faststart",
    out_master
]
subprocess.run(cmd_mix, check=True)
print(f"Final Master Reel created at: {out_master}")
