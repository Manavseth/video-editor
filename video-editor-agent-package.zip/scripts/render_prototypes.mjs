import puppeteer from 'puppeteer-core';
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

const edgePath = 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const OUT_DIR = path.resolve('scratch/prototypes');
fs.mkdirSync(OUT_DIR, { recursive: true });

// 1. Extract a clear frame from E:/Courses/clip1.mp4 at 2.0s
const hostFramePath = path.join(OUT_DIR, 'raw_host_clip1.png');
try {
  execSync(`ffmpeg -y -ss 2.0 -i "E:/Courses/clip1.mp4" -vframes 1 "${hostFramePath}"`, { stdio: 'ignore' });
  console.log('✓ Extracted raw host frame from clip1 at 2.0s');
} catch (e) {
  console.error('Error extracting host frame:', e);
}

// Convert extracted frame to base64 for embedding in prototype HTML
const hostBase64 = fs.existsSync(hostFramePath) ? fs.readFileSync(hostFramePath).toString('base64') : '';

// 2. Generate HTML containing the 3 prototypes:
// - Host Clip 1 with Subtitle Lane
// - MG-01 Phone to Classifier Morph
// - MG-03 Quiet vs Busy Comparison Cards
const htmlContent = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap');
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    width: 1080px;
    height: 1920px;
    overflow: hidden;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
  }
  .stage {
    width: 1080px;
    height: 1920px;
    position: relative;
    background: #F5F2EA;
  }
  .host-bg {
    position: absolute;
    inset: 0;
    width: 1080px;
    height: 1920px;
    object-fit: cover;
  }
  /* Subtitle Plate per storyboard: x: 72-930, y: 1460-1608 */
  .caption-container {
    position: absolute;
    left: 72px;
    top: 1460px;
    width: 858px;
    height: 148px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    background: rgba(251, 250, 247, 0.94);
    border: 2px solid #20252B;
    border-radius: 24px;
    box-shadow: 0 10px 30px rgba(32, 37, 43, 0.12);
    padding: 16px 28px;
    z-index: 100;
  }
  .caption-text {
    font-family: 'Inter', sans-serif;
    font-size: 42px;
    font-weight: 600;
    line-height: 1.35;
    color: #20252B;
  }
  .caption-highlight {
    color: #2D8C85;
    font-weight: 700;
  }

  /* Safe Area Guides (Optional visual audit) */
  .safe-guide {
    position: absolute;
    border: 1px dashed rgba(45, 140, 133, 0.4);
    pointer-events: none;
  }
</style>
</head>
<body>

<!-- PROTOTYPE 1: Host Clip 1 with Subtitle -->
<div id="proto-host" class="stage">
  <img src="data:image/png;base64,${hostBase64}" class="host-bg" />
  <div class="caption-container">
    <div class="caption-text">
      Phone ko <span class="caption-highlight">direct sunlight</span> se<br>apne room me le jao,
    </div>
  </div>
</div>

<!-- PROTOTYPE 2: MG-01 Phone to Classifier Morph -->
<div id="proto-mg01" class="stage" style="display:none; background: #F5F2EA;">
  <svg width="1080" height="1920" viewBox="0 0 1080 1920" style="position:absolute; inset:0;">
    <!-- Warm Paper Tone -->
    <rect width="1080" height="1920" fill="#F5F2EA"/>
    
    <!-- Title / Kicker Zone (y: 280) -->
    <text x="540" y="320" text-anchor="middle" font-family="Inter" font-size="28" font-weight="700" fill="#8B9298" letter-spacing="3">01 / ACOUSTIC MECHANISM</text>
    <text x="540" y="390" text-anchor="middle" font-family="Inter" font-size="52" font-weight="800" fill="#20252B">Environmental Classifier</text>
    <text x="540" y="445" text-anchor="middle" font-family="Inter" font-size="28" font-weight="500" fill="#8B9298">Sound scenes automatically guide device processing</text>

    <!-- Main Process Card A05 (x: 150, y: 680, w: 780, h: 320) -->
    <g transform="translate(150, 680)">
      <!-- Card Plate -->
      <rect x="0" y="0" width="780" height="320" rx="24" fill="#FBFAF7" stroke="#20252B" stroke-width="3"/>
      
      <!-- Card Label -->
      <text x="40" y="55" font-family="Inter" font-size="24" font-weight="700" fill="#20252B">environmental classifier</text>
      
      <!-- Input Dots (3 acoustic nodes) -->
      <circle cx="65" cy="120" r="10" fill="#8B9298"/>
      <circle cx="65" cy="165" r="10" fill="#8B9298"/>
      <circle cx="65" cy="210" r="10" fill="#8B9298"/>

      <text x="65" y="260" text-anchor="middle" font-family="Inter" font-size="16" font-weight="600" fill="#8B9298">inputs</text>

      <!-- Input Routes to Scene Module -->
      <path d="M 85 120 H 220 V 165 H 280" fill="none" stroke="#8B9298" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="M 85 165 H 280" fill="none" stroke="#8B9298" stroke-width="3" stroke-linecap="round"/>
      <path d="M 85 210 H 220 V 165 H 280" fill="none" stroke="#8B9298" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>

      <!-- Center Teal Module: scene -->
      <rect x="280" y="115" width="200" height="100" rx="18" fill="#2D8C85"/>
      <text x="380" y="174" text-anchor="middle" font-family="Inter" font-size="30" font-weight="700" fill="#FBFAF7">scene</text>
      <text x="380" y="250" text-anchor="middle" font-family="Inter" font-size="18" font-weight="600" fill="#2D8C85">acoustic classifier</text>

      <!-- Output Routes -->
      <path d="M 480 145 H 610 V 130 H 680" fill="none" stroke="#8B9298" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="M 480 185 H 610 V 200 H 680" fill="none" stroke="#8B9298" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
      
      <!-- Active Signal Marker -->
      <circle cx="560" cy="145" r="10" fill="#2D8C85"/>

      <!-- Output State Bars -->
      <rect x="680" y="116" width="50" height="28" rx="8" fill="#FBFAF7" stroke="#20252B" stroke-width="2.5"/>
      <rect x="680" y="186" width="50" height="28" rx="8" fill="#FBFAF7" stroke="#20252B" stroke-width="2.5"/>
      <text x="705" y="260" text-anchor="middle" font-family="Inter" font-size="16" font-weight="600" fill="#8B9298">settings</text>
    </g>

    <!-- Context Signal Connection A11 -->
    <path d="M 540 1000 V 1100" fill="none" stroke="#2D8C85" stroke-width="3" stroke-linecap="round" stroke-dasharray="8 8"/>
    <circle cx="540" cy="1100" r="8" fill="#2D8C85"/>

    <!-- Bottom Context Card A12 -->
    <g transform="translate(425, 1130)">
      <rect x="0" y="0" width="230" height="72" rx="20" fill="#FBFAF7" stroke="#20252B" stroke-width="2"/>
      <circle cx="36" cy="36" r="8" fill="#2D8C85"/>
      <text x="130" y="46" text-anchor="middle" font-family="Inter" font-size="24" font-weight="700" fill="#20252B">context</text>
    </g>

    <!-- Subtitle Lane on Warm Paper -->
    <g transform="translate(72, 1460)">
      <rect x="0" y="0" width="858" height="148" rx="24" fill="#FBFAF7" stroke="#20252B" stroke-width="2"/>
      <text x="429" y="70" text-anchor="middle" font-family="Inter" font-size="38" font-weight="600" fill="#20252B">Kuch hearing aids me <tspan fill="#2D8C85" font-weight="700">environmental classifier</tspan></text>
      <text x="429" y="115" text-anchor="middle" font-family="Inter" font-size="38" font-weight="600" fill="#20252B">bhi hota hai,</text>
    </g>
  </svg>
</div>

<!-- PROTOTYPE 3: MG-03 Quiet vs Busy Comparison Cards -->
<div id="proto-mg03" class="stage" style="display:none; background: #F5F2EA;">
  <svg width="1080" height="1920" viewBox="0 0 1080 1920" style="position:absolute; inset:0;">
    <rect width="1080" height="1920" fill="#F5F2EA"/>

    <!-- Kicker & Title -->
    <text x="540" y="320" text-anchor="middle" font-family="Inter" font-size="28" font-weight="700" fill="#8B9298" letter-spacing="3">02 / SOUND SCENES</text>
    <text x="540" y="390" text-anchor="middle" font-family="Inter" font-size="52" font-weight="800" fill="#20252B">Quiet vs. Busy Listening</text>
    <text x="540" y="445" text-anchor="middle" font-family="Inter" font-size="28" font-weight="500" fill="#8B9298">Distinct sound patterns create distinct context tags</text>

    <!-- Left Card: Quiet Conversation (x: 90, y: 640, w: 420, h: 360) -->
    <g transform="translate(90, 640)">
      <rect x="0" y="0" width="420" height="360" rx="22" fill="#FBFAF7" stroke="#20252B" stroke-width="2.5"/>
      <text x="35" y="55" font-family="Inter" font-size="24" font-weight="700" fill="#20252B">quiet conversation</text>
      <text x="35" y="90" font-family="Inter" font-size="18" font-weight="500" fill="#8B9298">Clean speech • low noise</text>
      
      <!-- Speech Line Waveforms -->
      <g transform="translate(35, 140)" stroke="#20252B" stroke-width="4" stroke-linecap="round" fill="none">
        <path d="M 0 30 h 40 l 8 -16 l 12 34 l 14 -42 l 12 28 h 60"/>
        <path d="M 10 80 h 30 l 10 -12 l 12 26 l 14 -32 l 12 20 h 50" stroke-width="3"/>
      </g>
      <circle cx="355" cy="270" r="10" fill="#2D8C85"/>
      <text x="35" y="278" font-family="Inter" font-size="20" font-weight="700" fill="#2D8C85">speech dominant</text>
    </g>

    <!-- Right Card: Busy Restaurant (x: 570, y: 640, w: 420, h: 360) -->
    <g transform="translate(570, 640)">
      <rect x="0" y="0" width="420" height="360" rx="22" fill="#FBFAF7" stroke="#20252B" stroke-width="2.5"/>
      <text x="35" y="55" font-family="Inter" font-size="24" font-weight="700" fill="#20252B">busy restaurant</text>
      <text x="35" y="90" font-family="Inter" font-size="18" font-weight="500" fill="#8B9298">Speech + ambient background</text>

      <!-- Speech Line Waveforms -->
      <g transform="translate(35, 140)" stroke="#20252B" stroke-width="4" stroke-linecap="round" fill="none">
        <path d="M 0 30 h 40 l 8 -16 l 12 34 l 14 -42 l 12 28 h 60"/>
        <path d="M 10 80 h 30 l 10 -12 l 12 26 l 14 -32 l 12 20 h 50" stroke-width="3"/>
      </g>
      <!-- Ambient Background Lines -->
      <g transform="translate(35, 140)" stroke="#A6ADB0" stroke-width="3" stroke-linecap="round" fill="none">
        <path d="M 25 5 h 35 l 8 -8 l 10 16 l 12 -20 l 10 14 h 40"/>
        <path d="M 15 110 h 40 l 8 -8 l 10 16 l 12 -22 l 10 14 h 45"/>
        <path d="M 190 20 h 30 l 8 -8 l 10 15 h 35"/>
      </g>
      <circle cx="355" cy="270" r="10" fill="#2D8C85"/>
      <text x="35" y="278" font-family="Inter" font-size="20" font-weight="700" fill="#8B9298">speech + ambience</text>
    </g>

    <!-- Connecting Router Node (Center) -->
    <g transform="translate(450, 1070)">
      <rect x="0" y="0" width="180" height="76" rx="20" fill="#FBFAF7" stroke="#20252B" stroke-width="2"/>
      <rect x="18" y="16" width="44" height="44" rx="12" fill="#2D8C85"/>
      <circle cx="40" cy="38" r="8" fill="#FBFAF7"/>
      <text x="115" y="48" text-anchor="middle" font-family="Inter" font-size="22" font-weight="700" fill="#20252B">classify</text>
    </g>
    <path d="M 300 1000 V 1040 H 450" fill="none" stroke="#20252B" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M 780 1000 V 1040 H 630" fill="none" stroke="#20252B" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M 540 1146 V 1200" fill="none" stroke="#2D8C85" stroke-width="3" stroke-linecap="round"/>
    <circle cx="540" cy="1200" r="8" fill="#2D8C85"/>

    <!-- Settled Context Output Tag A12 -->
    <g transform="translate(425, 1220)">
      <rect x="0" y="0" width="230" height="68" rx="20" fill="#FBFAF7" stroke="#20252B" stroke-width="2"/>
      <circle cx="36" cy="34" r="8" fill="#2D8C85"/>
      <text x="130" y="44" text-anchor="middle" font-family="Inter" font-size="22" font-weight="700" fill="#20252B">scene context</text>
    </g>

    <!-- Subtitle Lane -->
    <g transform="translate(72, 1460)">
      <rect x="0" y="0" width="858" height="148" rx="24" fill="#FBFAF7" stroke="#20252B" stroke-width="2"/>
      <text x="429" y="70" text-anchor="middle" font-family="Inter" font-size="38" font-weight="600" fill="#20252B">jaise ek <tspan fill="#2D8C85" font-weight="700">quiet conversation</tspan></text>
      <text x="429" y="115" text-anchor="middle" font-family="Inter" font-size="38" font-weight="600" fill="#20252B">ya ek <tspan fill="#2D8C85" font-weight="700">busy restaurant</tspan>.</text>
    </g>
  </svg>
</div>

</body>
</html>`;

const htmlFilePath = path.join(OUT_DIR, 'prototypes.html');
fs.writeFileSync(htmlFilePath, htmlContent);

async function render() {
  console.log('Launching browser to render 1080x1920 prototypes...');
  const browser = await puppeteer.launch({
    executablePath: edgePath,
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1080, height: 1920, deviceScaleFactor: 1 });
  await page.goto('file:///' + htmlFilePath.replace(/\\/g, '/'), { waitUntil: 'networkidle0' });

  // 1. Render Host Clip 1 with Subtitle
  await page.evaluate(() => {
    document.getElementById('proto-host').style.display = 'block';
    document.getElementById('proto-mg01').style.display = 'none';
    document.getElementById('proto-mg03').style.display = 'none';
  });
  const hostOut = path.join(OUT_DIR, 'prototype_01_host_clip1.jpg');
  await page.screenshot({ path: hostOut, type: 'jpeg', quality: 95 });
  console.log('✓ Rendered Prototype 1 (Host Frame + Subtitle Lane):', hostOut);

  // 2. Render MG-01 Phone to Classifier Morph
  await page.evaluate(() => {
    document.getElementById('proto-host').style.display = 'none';
    document.getElementById('proto-mg01').style.display = 'block';
    document.getElementById('proto-mg03').style.display = 'none';
  });
  const mg01Out = path.join(OUT_DIR, 'prototype_02_mg01_process.jpg');
  await page.screenshot({ path: mg01Out, type: 'jpeg', quality: 95 });
  console.log('✓ Rendered Prototype 2 (MG-01 Process Morph Card):', mg01Out);

  // 3. Render MG-03 Quiet vs Busy Comparison
  await page.evaluate(() => {
    document.getElementById('proto-host').style.display = 'none';
    document.getElementById('proto-mg01').style.display = 'none';
    document.getElementById('proto-mg03').style.display = 'block';
  });
  const mg03Out = path.join(OUT_DIR, 'prototype_03_mg03_comparison.jpg');
  await page.screenshot({ path: mg03Out, type: 'jpeg', quality: 95 });
  console.log('✓ Rendered Prototype 3 (MG-03 Quiet vs Busy Cards):', mg03Out);

  await browser.close();

  // 4. Create a 3-Up Composite Contact Sheet (width: 1920px)
  const contactSheet = path.join(OUT_DIR, 'prototype_contact_sheet_3up.jpg');
  try {
    const filter = 'xstack=inputs=3:layout=0_0|w0_0|w0+w1_0,scale=1920:-1';
    execSync(`ffmpeg -y -i "${hostOut}" -i "${mg01Out}" -i "${mg03Out}" -filter_complex "${filter}" -q:v 3 "${contactSheet}"`, { stdio: 'ignore' });
    console.log('✓ Rendered 3-Up Master Visual Contact Sheet:', contactSheet);
  } catch (err) {
    console.error('Error creating contact sheet:', err);
  }
}

render().catch(err => {
  console.error('Render error:', err);
  process.exit(1);
});
