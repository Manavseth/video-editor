import subprocess, json
from faster_whisper import WhisperModel

ffmpeg_bin = r"C:\Users\Lenovo\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"
subprocess.run([ffmpeg_bin, "-y", "-ss", "21.0", "-i", r"f:\Antigravity\video editor\work\audiogram_part5\raw_audio.wav", "-c", "copy", r"f:\Antigravity\video editor\work\audiogram_part5\part2.wav"], check=True)

model = WhisperModel('medium', device='cpu', compute_type='int8')
segs, info = model.transcribe(r"f:\Antigravity\video editor\work\audiogram_part5\part2.wav", word_timestamps=True, language='hi')

for s in segs:
    print(f"[{s.start:.2f} - {s.end:.2f}] {s.text}")
    for w in s.words or []:
        print(f"  {(21.0 + w.start):05.2f} - {(21.0 + w.end):05.2f}: {w.word}")
