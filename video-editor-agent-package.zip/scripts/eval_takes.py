import numpy as np
import scipy.io.wavfile as wavfile
import subprocess
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

wav_path = r"f:\Antigravity\video editor\work\rough_cut_classifier\audio.wav"
sr, data = wavfile.read(wav_path)
data = data.astype(np.float32) / 32768.0

candidates = [
    # BEAT 1 (Hook & Classifier)
    {"beat": "Beat 1 (Hook)", "take": "Take 1", "t0": 0.08, "t1": 16.82, "notes": "dhoop se room me..."},
    {"beat": "Beat 1 (Hook)", "take": "Take 2", "t0": 48.00, "t1": 64.40, "notes": "bha- stumble at start"},
    {"beat": "Beat 1 (Hook)", "take": "Take 3", "t0": 100.80, "t1": 118.00, "notes": "direct sunlight se... right?"},
    
    # BEAT 2 (Settings / Blend)
    {"beat": "Beat 2 (Settings)", "take": "Take 1", "t0": 17.40, "t1": 24.30, "notes": "phir device apne model aur fitting..."},
    {"beat": "Beat 2 (Settings)", "take": "Take 2", "t0": 65.30, "t1": 73.60, "notes": "phir device apne model..."},
    {"beat": "Beat 2 (Settings)", "take": "Take 3", "t0": 118.00, "t1": 126.50, "notes": "phir device apne model... settings ko automatically change..."},
    
    # BEAT 3 (Day-to-day life)
    {"beat": "Beat 3 (Day-to-day)", "take": "Take 1", "t0": 24.80, "t1": 31.40, "notes": "day-to-day patient ko..."},
    {"beat": "Beat 3 (Day-to-day)", "take": "Take 2", "t0": 74.40, "t1": 80.60, "notes": "day to day life me, patient ko har jagah ruk kar..."},
    {"beat": "Beat 3 (Day-to-day)", "take": "Take 3", "t0": 126.50, "t1": 133.50, "notes": "day to day life me patient ko har jagah ruk kar apna program switch..."},
    
    # BEAT 4 (Caveat - Mind reader)
    {"beat": "Beat 4 (Caveat)", "take": "Take 3", "t0": 133.50, "t1": 139.20, "notes": "yeh koi mind reader nahi hai..."},
    
    # BEAT 5 (Context & Punchline)
    {"beat": "Beat 5 (Punchline)", "take": "Take 3", "t0": 139.20, "t1": 154.60, "notes": "bas yeh room ya environment ka context..."}
]

print(f"{'BEAT':<20} | {'TAKE':<8} | {'START':<6} | {'END':<6} | {'DUR':<5} | {'RMS (dB)':<8} | {'PEAK (dB)':<9} | NOTES")
print("-" * 95)

for c in candidates:
    s0 = int(c["t0"] * sr)
    s1 = int(c["t1"] * sr)
    chunk = data[s0:s1]
    rms = np.sqrt(np.mean(chunk**2))
    rms_db = 20 * np.log10(rms + 1e-9)
    peak = np.max(np.abs(chunk))
    peak_db = 20 * np.log10(peak + 1e-9)
    dur = c["t1"] - c["t0"]
    print(f"{c['beat']:<20} | {c['take']:<8} | {c['t0']:6.2f} | {c['t1']:6.2f} | {dur:5.2f} | {rms_db:8.1f} | {peak_db:9.1f} | {c['notes']}")
