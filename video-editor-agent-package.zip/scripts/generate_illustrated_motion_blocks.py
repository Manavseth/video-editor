import os
import sys
import math
import subprocess
from PIL import Image, ImageDraw, ImageFont

sys.stdout.reconfigure(encoding='utf-8')

W, H, FPS = 1080, 1920, 30

PAPER = "#F5F2EA"
CARD = "#FBFAF7"
INK = "#20252B"
GRAY = "#8B9298"
LIGHT = "#B5B7B2"
RULE = "#D6D3C8"
TEAL = "#2D8C85"
PALE = "#E7F2EF"
OCHRE = "#C9A65E"
GOLD = "#E6D5A5"

FONT_REG = r"C:\Windows\Fonts\segoeui.ttf"
FONT_BOLD = r"C:\Windows\Fonts\segoeuib.ttf"
FONT_SBOLD = r"C:\Windows\Fonts\seguisb.ttf"

CACHE = {}

def font(size, weight="reg"):
    key = (size, weight)
    if key not in CACHE:
        if weight == "bold":
            p = FONT_BOLD
        elif weight == "sbold":
            p = FONT_SBOLD
        else:
            p = FONT_REG
        CACHE[key] = ImageFont.truetype(p, size)
    return CACHE[key]

def txt(d, xy, val, size=32, fill=INK, weight="reg", anchor=None):
    d.text(xy, str(val), font=font(size, weight), fill=fill, anchor=anchor)

def rr(d, box, r=22, fill=CARD, outline=INK, width=3):
    d.rounded_rectangle(box, radius=r, fill=fill, outline=outline, width=width)

def clamp(v, a=0.0, b=1.0):
    return max(a, min(b, float(v)))

def ease(t):
    t = clamp(t)
    return t * t * (3.0 - 2.0 * t)

def ease_out(t):
    t = clamp(t)
    return 1.0 - (1.0 - t) * (1.0 - t)

def lerp(a, b, t):
    return a + (b - a) * clamp(t)

# A16: Generic conversation figure
def draw_figure(d, cx, cy, scale=1.0, color=INK):
    r = int(24 * scale)
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=color)
    bw = int(76 * scale)
    top = cy + int(28 * scale)
    bot = cy + int(122 * scale)
    d.rounded_rectangle((cx - bw // 2, top, cx + bw // 2, bot), radius=int(26 * scale), fill=color)

# A18: Speech-bubble
def draw_bubble(d, x, y, w=128, h=72, accent=True, muted=False):
    border = LIGHT if muted else INK
    fill = CARD
    d.rounded_rectangle((x, y, x + w, y + h), radius=16, fill=fill, outline=border, width=3)
    d.polygon([(x + 24, y + h - 2), (x + 44, y + h - 2), (x + 32, y + h + 12)], fill=fill)
    d.line((x + 24, y + h - 2, x + 32, y + h + 12, x + 44, y + h - 2), fill=border, width=3)
    lens = [int(w * 0.35), int(w * 0.45), int(w * 0.28)]
    for i, ln in enumerate(lens):
        col = TEAL if (accent and i == 0 and not muted) else (LIGHT if muted else GRAY)
        yy = y + int(h * 0.35) + i * 14
        d.line((x + 20, yy, x + 20 + ln, yy), fill=col, width=4)

# A17: Cafe table/chair set
def draw_table(d, x, y, w, color=INK, light=False):
    c = LIGHT if light else color
    d.line((x, y, x + w, y), fill=c, width=5)
    d.line((x + 14, y, x + 14, y + 54), fill=c, width=4)
    d.line((x + w - 14, y, x + w - 14, y + 54), fill=c, width=4)
    # Chairs
    d.line((x + 8, y - 36, x + 8, y - 2), fill=c, width=4)
    d.line((x + 38, y - 36, x + 38, y - 2), fill=c, width=4)
    d.line((x + 8, y - 36, x + 38, y - 36), fill=c, width=4)
    d.line((x + w - 38, y - 36, x + w - 38, y - 2), fill=c, width=4)
    d.line((x + w - 8, y - 36, x + w - 8, y - 2), fill=c, width=4)
    d.line((x + w - 38, y - 36, x + w - 8, y - 36), fill=c, width=4)

# A19: Manual pointer hand
def draw_pointer(d, x, y, scale=1.0):
    pts = [
        (x, y),
        (x + int(8 * scale), y + int(42 * scale)),
        (x + int(18 * scale), y + int(32 * scale)),
        (x + int(28 * scale), y + int(54 * scale)),
        (x + int(36 * scale), y + int(50 * scale)),
        (x + int(26 * scale), y + int(28 * scale)),
        (x + int(38 * scale), y + int(28 * scale))
    ]
    d.polygon(pts, fill=CARD)
    d.line(pts + [pts[0]], fill=INK, width=max(2, int(3 * scale)))
    d.ellipse((x - 4, y - 4, x + 8, y + 8), fill=TEAL)

def draw_header(d, eyebrow, title, badge=None):
    txt(d, (540, 310), eyebrow, size=26, fill=GRAY, weight="bold", anchor="mm")
    txt(d, (540, 365), title, size=48, fill=INK, weight="bold", anchor="mm")
    if badge:
        # Top-left or top qualifier
        bx, by = 110, 420
        rr(d, (bx, by, bx + 280, by + 46), r=12, fill=PALE, outline=TEAL, width=2)
        txt(d, (bx + 140, by + 23), badge, size=20, fill=TEAL, weight="bold", anchor="mm")

# Preload subtitle plates
SUB_CACHE = {}
for i in range(1, 16):
    sp = f"scratch/subtitles/sub_{i:02d}.png"
    if os.path.exists(sp):
        SUB_CACHE[i] = Image.open(sp).convert("RGBA")

def overlay_sub(im, sub_id):
    if sub_id in SUB_CACHE:
        im.paste(SUB_CACHE[sub_id], (0, 0), SUB_CACHE[sub_id])

# -------------------------------------------------------------
# BLOCK 1: MG-01, MG-02, MG-03 (6.500s to 17.667s)
# -------------------------------------------------------------
def render_block1(t):
    im = Image.new("RGBA", (W, H), PAPER)
    d = ImageDraw.Draw(im)

    if t < 10.500:
        # MG-01 (6.500 - 10.500s): Phone to classifier sorting gate
        draw_header(d, "01 / ACOUSTIC MECHANISM", "Environmental Classifier", "SOME HEARING AIDS")
        
        # Phone morphing into Gate
        p_morph = ease((t - 6.5) / 0.8)
        card_w = int(lerp(260, 860, p_morph))
        card_h = int(lerp(460, 500, p_morph))
        card_x = 540 - card_w // 2
        card_y = int(lerp(580, 560, p_morph))
        rr(d, (card_x, card_y, card_x + card_w, card_y + card_h), r=24, fill=CARD, outline=INK, width=3)

        if p_morph < 0.6:
            # Phone A03 view
            pw, ph = 220, 380
            px, py = 540 - pw // 2, card_y + 40
            rr(d, (px, py, px + pw, py + ph), r=22, fill=PAPER, outline=INK, width=3)
            # Speaker slot & home dot
            d.line((px + 80, py + 22, px + 140, py + 22), fill=INK, width=4)
            d.ellipse((px + 104, py + ph - 28, px + 116, py + ph - 16), fill=GRAY)
            # Brightness slider track
            bx = px + 110
            d.line((bx, py + 70, bx, py + ph - 60), fill=RULE, width=12)
            # Slider thumb moves down
            thumb_y = lerp(py + 90, py + ph - 90, ease((t - 6.5) / 0.7))
            d.ellipse((bx - 16, thumb_y - 16, bx + 16, thumb_y + 16), fill=TEAL)
            # Retracting sun field A04
            sun_p = 1.0 - ease((t - 6.5) / 0.6)
            if sun_p > 0.05:
                sx, sy = 240, 520
                d.ellipse((sx - 24, sy - 24, sx + 24, sy + 24), fill=OCHRE)
                for a in range(8):
                    ang = a * (math.pi / 4)
                    d.line((sx + math.cos(ang) * 28, sy + math.sin(ang) * 28,
                            sx + math.cos(ang) * 44, sy + math.sin(ang) * 44), fill=OCHRE, width=3)
        else:
            # Sorting Gate Card A05 view
            alpha = ease((t - 7.3) / 0.5)
            # Label
            txt(d, (card_x + 40, card_y + 45), "environmental classifier", size=24, fill=INK, weight="bold")
            
            # Left Inlet Zone (x: card_x + 50, y: card_y + 120, w: 200, h: 260)
            rr(d, (card_x + 50, card_y + 120, card_x + 250, card_y + 380), r=16, fill=PAPER, outline=RULE, width=2)
            txt(d, (card_x + 150, card_y + 150), "INLET", size=20, fill=GRAY, weight="bold", anchor="mm")
            
            # Center Chamber: SCENE gate (x: card_x + 310, y: card_y + 130, w: 240, h: 240)
            gate_open = not (8.15 <= t <= 8.85)
            gate_col = TEAL if gate_open else INK
            rr(d, (card_x + 310, card_y + 130, card_x + 550, card_y + 370), r=20, fill=gate_col, outline=INK, width=3)
            txt(d, (card_x + 430, card_y + 240), "SCENE", size=36, fill=CARD, weight="bold", anchor="mm")
            txt(d, (card_x + 430, card_y + 285), "classifier", size=20, fill=PALE if gate_open else LIGHT, weight="reg", anchor="mm")

            # Right Shelves (x: card_x + 610)
            rr(d, (card_x + 610, card_y + 150, card_x + 810, card_y + 230), r=12, fill=CARD, outline=RULE, width=2)
            rr(d, (card_x + 610, card_y + 270, card_x + 810, card_y + 350), r=12, fill=CARD, outline=RULE, width=2)

            # Mini-scene token travels through
            token_p = ease((t - 7.55) / 1.7) # 7.55 to 9.25s
            token_x = lerp(card_x + 150, card_x + 710, token_p)
            token_y = card_y + 190
            
            if token_p < 0.45 or token_p > 0.65:
                # Token visible outside chamber
                rr(d, (token_x - 45, token_y - 30, token_x + 45, token_y + 30), r=10, fill=PALE, outline=TEAL, width=2)
                if token_p > 0.65:
                    txt(d, (token_x, token_y), "SOUND SCENE", size=15, fill=TEAL, weight="bold", anchor="mm")
                else:
                    draw_figure(d, token_x - 14, token_y - 2, scale=0.28, color=INK)
                    draw_figure(d, token_x + 14, token_y - 2, scale=0.28, color=INK)

            # Output route extends
            if t > 9.2:
                route_p = ease((t - 9.2) / 0.6)
                d.line((card_x + 810, card_y + 190, card_x + 810 + int(70 * route_p), card_y + 190), fill=TEAL, width=4)

        if 7.000 <= t <= 10.500:
            overlay_sub(im, 3)

    elif t < 13.900:
        # MG-02 (10.500 - 13.900s): Acoustic context classification
        draw_header(d, "01 / ACOUSTIC MECHANISM", "Environment Context", "ACOUSTIC SCENE ANALYSIS")

        # Left: Compact A05 gate (x: 80, y: 480, w: 340, h: 460)
        rr(d, (80, 480, 420, 940), r=22, fill=CARD, outline=INK, width=3)
        txt(d, (110, 520), "classifier gate", size=22, fill=INK, weight="bold")
        rr(d, (130, 580, 370, 780), r=18, fill=TEAL, outline=INK, width=3)
        txt(d, (250, 670), "SCENE", size=32, fill=CARD, weight="bold", anchor="mm")
        txt(d, (250, 715), "acoustic only", size=18, fill=PALE, weight="reg", anchor="mm")
        # Acoustic input signal entering gate
        sig_p = ease((t - 10.5) / 1.0)
        d.line((40, 680, lerp(40, 130, sig_p), 680), fill=TEAL, width=5)
        d.ellipse((lerp(40, 130, sig_p) - 8, 672, lerp(40, 130, sig_p) + 8, 688), fill=TEAL)

        # Right: Two scene thumbnails (x: 470, y: 480, w: 530, h: 460)
        slide_p = ease((t - 10.8) / 0.6)
        rx = int(lerp(540, 470, slide_p))
        rr(d, (rx, 480, rx + 530, 940), r=22, fill=CARD, outline=INK, width=3)
        txt(d, (rx + 30, 520), "SOUND SCENES", size=22, fill=INK, weight="bold")

        # Top Thumbnail: Quiet
        rr(d, (rx + 30, 555, rx + 500, 725), r=14, fill=PAPER, outline=RULE, width=2)
        txt(d, (rx + 50, 580), "QUIET CONVERSATION", size=18, fill=INK, weight="bold")
        draw_figure(d, rx + 160, 650, scale=0.45, color=INK)
        draw_figure(d, rx + 240, 650, scale=0.45, color=INK)
        d.line((rx + 130, 680, rx + 270, 680), fill=INK, width=3)
        draw_bubble(d, rx + 120, 600, 60, 36, accent=True)

        # Bottom Thumbnail: Busy
        rr(d, (rx + 30, 745, rx + 500, 915), r=14, fill=PAPER, outline=RULE, width=2)
        txt(d, (rx + 50, 770), "BUSY RESTAURANT", size=18, fill=INK, weight="bold")
        draw_figure(d, rx + 160, 840, scale=0.45, color=INK)
        draw_figure(d, rx + 240, 840, scale=0.45, color=INK)
        d.line((rx + 130, 870, rx + 270, 870), fill=INK, width=3)
        draw_bubble(d, rx + 120, 790, 60, 36, accent=True)
        # Background diner silhouettes in busy thumbnail
        draw_figure(d, rx + 360, 835, scale=0.32, color=LIGHT)
        draw_figure(d, rx + 430, 835, scale=0.32, color=LIGHT)
        draw_bubble(d, rx + 370, 795, 45, 28, accent=False, muted=True)

        # Selector marker from gate to quiet scene
        sel_p = ease((t - 11.6) / 0.8)
        d.line((370, 680, lerp(370, rx + 30, sel_p), 640), fill=TEAL, width=4)

        # Card: PERSON'S INTENT remains outside with no connecting path
        rr(d, (80, 970, 500, 1060), r=16, fill=PAPER, outline=LIGHT, width=2)
        txt(d, (110, 1000), "PERSON'S INTENT", size=20, fill=GRAY, weight="bold")
        txt(d, (110, 1030), "Not detectable by acoustics alone", size=16, fill=LIGHT, weight="reg")
        d.line((500, 1015, 540, 1015), fill=LIGHT, width=2)
        d.line((530, 1005, 550, 1025), fill="#D9534F", width=3)
        d.line((530, 1025, 550, 1005), fill="#D9534F", width=3)

        if 11.000 <= t <= 13.450:
            overlay_sub(im, 4)

    else:
        # MG-03 (13.900 - 17.667s): Quiet vs Busy acoustic comparison cards
        draw_header(d, "02 / SOUND SCENES", "Quiet vs. Busy Listening")

        slide_in = ease((t - 13.9) / 0.45)
        dx = int(50 * (1.0 - slide_in))
        
        # Left: Quiet card (x: 60, y: 440, w: 460, h: 760)
        qx = 60 - dx
        rr(d, (qx, 440, qx + 460, 1200), r=24, fill=CARD, outline=INK, width=3)
        d.line((qx, 515, qx + 460, 515), fill=RULE, width=2)
        txt(d, (qx + 30, 475), "QUIET CONVERSATION", size=24, fill=INK, weight="bold")

        # Right: Busy card (x: 560, y: 440, w: 460, h: 760)
        bx = 560 + dx
        rr(d, (bx, 440, bx + 460, 1200), r=24, fill=CARD, outline=INK, width=3)
        d.line((bx, 515, bx + 460, 515), fill=RULE, width=2)
        txt(d, (bx + 30, 475), "BUSY RESTAURANT", size=24, fill=INK, weight="bold")

        # Busy card: Background diners appear sequentially
        busy_reveal = ease((t - 14.8) / 1.5)
        if busy_reveal > 0.05:
            draw_table(d, bx + 70, 780, 320, color=LIGHT, light=True)
            crowd = [
                (bx + 110, 680, 0.52, 0.05),
                (bx + 230, 640, 0.48, 0.35),
                (bx + 350, 680, 0.52, 0.65)
            ]
            for cx, cy, sc, delay in crowd:
                cp = ease((busy_reveal - delay) / 0.3)
                if cp > 0.0:
                    draw_figure(d, cx, cy + int(15 * (1 - cp)), scale=sc, color=LIGHT)
                    if cp > 0.4:
                        draw_bubble(d, cx - 25, cy - 75, w=70, h=40, accent=False, muted=True)

        # Foreground Pair: Identical across both cards!
        turn_t = (t * 0.8) % 1.0
        for card_base_x in (qx, bx):
            fg_y = 860
            lx, rx = card_base_x + 160, card_base_x + 300
            draw_figure(d, lx, fg_y, scale=0.85, color=INK)
            draw_figure(d, rx, fg_y, scale=0.85, color=INK)
            draw_table(d, card_base_x + 95, 960, 270, color=INK)
            draw_bubble(d, card_base_x + 50, 680, 120, 68, accent=True)
            draw_bubble(d, card_base_x + 290, 680, 120, 68, accent=True)
            # Active speaker turn marker
            tok_x = lerp(card_base_x + 155, card_base_x + 305, turn_t)
            d.ellipse((tok_x - 7, 728, tok_x + 7, 742), fill=TEAL)

        # Teal focus bracket under both cards
        if t > 16.2:
            bp = ease((t - 16.2) / 0.6)
            x1, x2 = 180, 180 + int(720 * bp)
            d.line((180, 1225, 180, 1245), fill=TEAL, width=5)
            d.line((180, 1245, x2, 1245), fill=TEAL, width=5)
            if bp > 0.95:
                d.line((900, 1225, 900, 1245), fill=TEAL, width=5)
            txt(d, (540, 1285), "SAME CONVERSATION • SURROUNDING ACTIVITY VARIES", size=22, fill=TEAL, weight="bold", anchor="mm")

        if 13.900 <= t <= 17.250:
            overlay_sub(im, 5)

    return im.convert("RGB")

# -------------------------------------------------------------
# BLOCK 2: MG-04, MG-05 (26.100s to 33.300s)
# -------------------------------------------------------------
def draw_mini_scene(d, x, y, w, h, label, busy=False):
    rr(d, (x, y, x + w, y + h), r=16, fill=CARD, outline=RULE, width=2)
    txt(d, (x + 18, y + 26), label, size=20, fill=INK, weight="bold")
    cy = y + 110
    if busy:
        draw_figure(d, x + 40, cy - 10, scale=0.34, color=LIGHT)
        draw_figure(d, x + w - 40, cy - 10, scale=0.34, color=LIGHT)
        draw_bubble(d, x + w - 50, cy - 45, 38, 24, accent=False, muted=True)
    draw_figure(d, x + int(w * 0.36), cy + 20, scale=0.46, color=INK)
    draw_figure(d, x + int(w * 0.66), cy + 20, scale=0.46, color=INK)
    d.line((x + 30, y + h - 28, x + w - 30, y + h - 28), fill=INK, width=3)
    draw_bubble(d, x + 15, y + 54, 46, 28, accent=True)
    draw_bubble(d, x + w - 55, y + 54, 46, 28, accent=True)

def render_block2(t):
    im = Image.new("RGBA", (W, H), PAPER)
    d = ImageDraw.Draw(im)

    if t < 29.767:
        # MG-04 (26.100 - 29.767s): 3-stop daily route navigation
        draw_header(d, "03 / EVERYDAY USE", "Daily Route Navigation")

        # 3 Mini-scenes at stops (x: 70, 430, 790, y: 480, w: 220, h: 250)
        draw_mini_scene(d, 70, 480, 220, 250, "QUIET", busy=False)
        draw_mini_scene(d, 430, 480, 220, 250, "BUSY", busy=True)
        draw_mini_scene(d, 790, 480, 220, 250, "QUIET", busy=False)

        # Route track line
        route_y = 800
        d.line((180, route_y, 900, route_y), fill=RULE, width=8)
        d.line((180, route_y, 900, route_y), fill="#E2DFD5", width=3)

        # 3 Stop nodes
        stops = [180, 540, 900]
        stop_names = ["STOP 1", "STOP 2", "STOP 3"]
        for idx, sx in enumerate(stops):
            d.ellipse((sx - 18, route_y - 18, sx + 18, route_y + 18), fill=CARD, outline=INK, width=4)
            txt(d, (sx, route_y + 40), stop_names[idx], size=20, fill=GRAY, weight="bold", anchor="mm")

        # Route marker traveling
        u = clamp((t - 26.1) / 3.2)
        if u < 0.42:
            mx = lerp(180, 540, ease(u / 0.42))
        elif u < 0.58:
            mx = 540 # Pauses on ruk kar
        elif u < 0.90:
            mx = lerp(540, 900, ease((u - 0.58) / 0.32))
        else:
            mx = 900
        d.ellipse((mx - 14, route_y - 14, mx + 14, route_y + 14), fill=TEAL)

        # Selector card A10 (x: 580, y: 920, w: 420, h: 320)
        x0, y0 = 580, 920
        rr(d, (x0, y0, x0 + 420, y0 + 320), r=22, fill=CARD, outline=INK, width=3)
        txt(d, (x0 + 36, y0 + 26), "PROGRAM SELECTOR", size=24, fill=INK, weight="bold")
        
        # 3 Rows
        active_row = 1 if (26.9 <= t <= 28.3) else 0
        rows = []
        for i in range(3):
            ry = y0 + 75 + i * 70
            is_act = (i == active_row)
            f_col = PALE if is_act else CARD
            b_col = TEAL if is_act else RULE
            rr(d, (x0 + 30, ry, x0 + 390, ry + 56), r=12, fill=f_col, outline=b_col, width=3 if is_act else 2)
            d.ellipse((x0 + 52, ry + 18, x0 + 72, ry + 38), fill=TEAL if is_act else LIGHT)
            txt(d, (x0 + 90, ry + 15), f"SETTING {i+1}", size=22, fill=INK, weight="bold")
            rows.append(ry)

        # Pointer hand taps
        if 26.8 <= t <= 27.5:
            draw_pointer(d, x0 + 340, rows[1] + 10, scale=0.85)
            d.ellipse((x0 + 355, rows[1] + 25, x0 + 385, rows[1] + 55), outline=TEAL, width=3)
        elif 28.1 <= t <= 28.8:
            draw_pointer(d, x0 + 340, rows[0] + 10, scale=0.85)
            d.ellipse((x0 + 355, rows[0] + 25, x0 + 385, rows[0] + 55), outline=TEAL, width=3)

        txt(d, (90, 1340), "SCENE CHANGE  →  MANUAL SWITCHING REQUIRED", size=24, fill=INK, weight="bold")

        if 26.300 <= t <= 29.300:
            overlay_sub(im, 8)

    else:
        # MG-05 (29.767 - 33.300s): Side-by-side Manual vs Scene-Based comparison
        draw_header(d, "03 / EVERYDAY USE", "Who Changes The Setting?")

        left_box = (60, 420, 520, 1260)
        right_box = (560, 420, 1020, 1260)
        rr(d, left_box, r=24, fill=CARD, outline=INK, width=3)
        rr(d, right_box, r=24, fill=CARD, outline=INK, width=3)

        txt(d, (95, 450), "MANUAL", size=32, fill=INK, weight="bold")
        txt(d, (595, 450), "SCENE-BASED", size=32, fill=INK, weight="bold")
        rr(d, (800, 442, 990, 482), r=10, fill=PALE, outline=TEAL, width=2)
        txt(d, (895, 462), "DEVICE-DEPENDENT", size=16, fill=TEAL, weight="bold", anchor="mm")

        local = t - 29.767
        busy = (0.6 <= local < 1.9)
        scene_name = "BUSY RESTAURANT" if busy else "QUIET CONVERSATION"

        # Both lanes have the same mini-scene
        draw_mini_scene(d, 95, 510, 390, 230, scene_name, busy=busy)
        draw_mini_scene(d, 595, 510, 390, 230, scene_name, busy=busy)

        # Manual Lane: Tap action
        txt(d, (105, 770), "MANUAL TAPPING", size=20, fill=GRAY, weight="bold")
        d.line((290, 750, 290, 840), fill=RULE, width=4)
        d.polygon([(280, 835), (300, 835), (290, 850)], fill=RULE)

        # Assisted Lane: Classifier gate
        rr(d, (620, 765, 960, 895), r=16, fill=PALE, outline=TEAL, width=2)
        txt(d, (790, 805), "SCENE CLASSIFIER", size=22, fill=INK, weight="bold", anchor="mm")
        txt(d, (790, 845), "BUSY DETECTED" if busy else "QUIET DETECTED", size=18, fill=TEAL, weight="bold", anchor="mm")
        # Route to selector
        d.line((790, 895, 790, 930), fill=TEAL, width=4)

        # Both lanes have selectors
        active_idx = 1 if busy else 0
        for x0 in (95, 595):
            rr(d, (x0, 930, x0 + 390, 1220), r=18, fill=CARD, outline=RULE, width=2)
            txt(d, (x0 + 25, 960), "SETTINGS", size=20, fill=INK, weight="bold")
            for i in range(3):
                ry = 990 + i * 68
                is_act = (i == active_idx)
                f_col = PALE if is_act else CARD
                b_col = TEAL if is_act else RULE
                rr(d, (x0 + 20, ry, x0 + 370, ry + 54), r=10, fill=f_col, outline=b_col, width=3 if is_act else 2)
                d.ellipse((x0 + 40, ry + 17, x0 + 60, ry + 37), fill=TEAL if is_act else LIGHT)
                txt(d, (x0 + 75, ry + 14), f"SETTING {i+1}", size=20, fill=INK, weight="bold")

        # Pointer hand in Manual lane ONLY
        if busy and (0.6 <= local <= 1.5):
            draw_pointer(d, 435, 1070, scale=0.8)
            d.ellipse((445, 1085, 475, 1115), outline=TEAL, width=3)
        elif not busy and (1.9 <= local <= 2.7):
            draw_pointer(d, 435, 1000, scale=0.8)
            d.ellipse((445, 1015, 475, 1045), outline=TEAL, width=3)

        # Bottom Qualifier Badge
        if local > 2.2:
            qp = ease((local - 2.2) / 0.4)
            rr(d, (90, 1285, 990, 1355), r=16, fill=PALE, outline=TEAL, width=2)
            txt(d, (540, 1320), "MAY REDUCE MANUAL SWITCHING", size=26, fill=TEAL, weight="bold", anchor="mm")

        if 29.750 <= t <= 32.900:
            overlay_sub(im, 9)

    return im.convert("RGB")

# -------------------------------------------------------------
# BLOCK 3: MG-06, MG-07, MG-08 (38.800s to 47.467s)
# -------------------------------------------------------------
def render_block3(t):
    im = Image.new("RGBA", (W, H), PAPER)
    d = ImageDraw.Draw(im)

    if t < 41.700:
        # MG-06 (38.800 - 41.700s): Classifier labels the listening scene
        draw_header(d, "04 / LISTENING BENEFIT", "Scene Classification")

        # Left: Busy Restaurant Vignette (x: 70, y: 480, w: 340, h: 480)
        rr(d, (70, 480, 410, 960), r=22, fill=CARD, outline=INK, width=3)
        txt(d, (95, 515), "ACOUSTIC INPUT", size=20, fill=GRAY, weight="bold")
        # Inside vignette: foreground pair + background diners
        draw_table(d, 110, 780, 240, color=LIGHT, light=True)
        draw_figure(d, 150, 700, scale=0.42, color=LIGHT)
        draw_figure(d, 310, 700, scale=0.42, color=LIGHT)
        draw_bubble(d, 260, 640, 50, 30, accent=False, muted=True)
        # Foreground
        draw_figure(d, 170, 830, scale=0.62, color=INK)
        draw_figure(d, 270, 830, scale=0.62, color=INK)
        draw_table(d, 135, 890, 190, color=INK)
        draw_bubble(d, 100, 760, 80, 48, accent=True)

        # Center: Open A05 Classifier Gate (x: 440, y: 530, w: 220, h: 360)
        gate_closed = (39.85 <= t <= 40.45)
        rr(d, (440, 530, 660, 890), r=20, fill=INK if gate_closed else TEAL, outline=INK, width=3)
        txt(d, (550, 680), "SCENE", size=32, fill=CARD, weight="bold", anchor="mm")
        txt(d, (550, 725), "classifier", size=18, fill=PALE if not gate_closed else LIGHT, weight="reg", anchor="mm")

        # Right: Output Result Tag (x: 690, y: 580, w: 320, h: 260)
        rr(d, (690, 580, 1010, 840), r=20, fill=CARD, outline=RULE, width=2)
        txt(d, (720, 620), "CLASSIFICATION RESULT", size=18, fill=GRAY, weight="bold")
        
        # Moving Scene token
        p_tok = ease((t - 39.2) / 1.5)
        if p_tok < 0.4:
            tx = lerp(270, 550, p_tok / 0.4)
            rr(d, (tx - 35, 680 - 22, tx + 35, 680 + 22), r=8, fill=PALE, outline=TEAL, width=2)
            draw_figure(d, tx - 10, 678, scale=0.22, color=INK)
            draw_figure(d, tx + 10, 678, scale=0.22, color=INK)
        elif p_tok > 0.6:
            tx = lerp(550, 850, (p_tok - 0.6) / 0.4)
            rr(d, (tx - 110, 710 - 32, tx + 110, 710 + 32), r=12, fill=PALE, outline=TEAL, width=2)
            d.ellipse((tx - 90, 702, tx - 74, 718), fill=TEAL)
            txt(d, (tx + 10, 710), "BUSY CONVERSATION", size=18, fill=INK, weight="bold", anchor="mm")

        # Connecting path back to vignette
        if t > 40.8:
            d.line((850, 742, 850, 920, 410, 920), fill=TEAL, width=4)

        if 39.200 <= t <= 41.700:
            overlay_sub(im, 12)

    elif t < 44.500:
        # MG-07 (41.700 - 44.500s): Model/Fitting and Change vs Blend demonstration
        draw_header(d, "04 / LISTENING BENEFIT", "Device-Dependent Settings")

        # Top: Context Tag (x: 350, y: 440, w: 380, h: 56)
        rr(d, (350, 440, 730, 496), r=14, fill=PALE, outline=TEAL, width=2)
        d.ellipse((375, 458, 395, 478), fill=TEAL)
        txt(d, (550, 468), "BUSY CONVERSATION", size=22, fill=INK, weight="bold", anchor="mm")

        # Middle: A07 Model/Fitting Card (x: 140, y: 530, w: 800, h: 250)
        rr(d, (140, 530, 940, 780), r=22, fill=CARD, outline=INK, width=3)
        txt(d, (175, 565), "DEVICE CONFIGURATION", size=20, fill=GRAY, weight="bold")
        
        # Knobs move gently
        shift1 = int(22 * math.sin(clamp((t - 41.7) / 1.0) * math.pi))
        shift2 = int(-18 * math.sin(clamp((t - 42.0) / 1.0) * math.pi))
        
        # Model row
        txt(d, (175, 625), "MODEL", size=22, fill=INK, weight="bold")
        d.line((340, 625, 780, 625), fill=RULE, width=8)
        d.ellipse((560 + shift1 - 16, 609, 560 + shift1 + 16, 641), fill=TEAL)

        # Fitting row
        txt(d, (175, 715), "FITTING", size=22, fill=INK, weight="bold")
        d.line((340, 715, 780, 715), fill=RULE, width=8)
        d.ellipse((480 + shift2 - 16, 699, 480 + shift2 + 16, 731), fill=TEAL)

        # Connecting arrows to A08
        d.line((540, 780, 540, 830), fill=RULE, width=4)
        d.polygon([(530, 825), (550, 825), (540, 840)], fill=RULE)

        # Bottom: A08 Change vs Blend Card (x: 140, y: 840, w: 800, h: 390)
        rr(d, (140, 840, 940, 1230), r=22, fill=CARD, outline=INK, width=3)
        txt(d, (175, 875), "RESPONSE METAPHOR", size=20, fill=GRAY, weight="bold")
        rr(d, (720, 860, 910, 896), r=10, fill=PALE, outline=TEAL, width=2)
        txt(d, (815, 878), "DEVICE-DEPENDENT", size=16, fill=TEAL, weight="bold", anchor="mm")

        # Row 1: CHANGE (Single tile moves from slot 1 to slot 2)
        txt(d, (175, 955), "CHANGE", size=24, fill=INK, weight="bold")
        rr(d, (360, 925, 520, 985), r=12, fill=PAPER, outline=RULE, width=2)
        rr(d, (560, 925, 720, 985), r=12, fill=PAPER, outline=RULE, width=2)
        txt(d, (440, 955), "SLOT 1", size=18, fill=LIGHT, weight="bold", anchor="mm")
        txt(d, (640, 955), "SLOT 2", size=18, fill=LIGHT, weight="bold", anchor="mm")
        
        ch_p = ease((t - 42.6) / 0.8)
        tile_x = lerp(440, 640, ch_p)
        rr(d, (tile_x - 70, 930, tile_x + 70, 980), r=10, fill=TEAL)
        txt(d, (tile_x, 955), "SETTING", size=18, fill=CARD, weight="bold", anchor="mm")

        # Row 2: BLEND (Two tiles slide together into shared output slot!)
        txt(d, (175, 1095), "BLEND", size=24, fill=INK, weight="bold")
        rr(d, (360, 1065, 520, 1125), r=12, fill=PAPER, outline=RULE, width=2)
        rr(d, (560, 1065, 720, 1125), r=12, fill=PAPER, outline=RULE, width=2)
        rr(d, (760, 1065, 910, 1125), r=12, fill=PAPER, outline=TEAL, width=2)

        bl_p = ease((t - 42.6) / 0.8)
        # Tile A (Teal) slides from slot 1 into shared slot
        ta_x = lerp(440, 810, bl_p)
        rr(d, (ta_x - 30, 1073, ta_x + 30, 1117), r=8, fill=TEAL)
        # Tile B (Gray) slides from slot 2 into shared slot
        tb_x = lerp(640, 860, bl_p)
        rr(d, (tb_x - 30, 1073, tb_x + 30, 1117), r=8, fill=GRAY)

        if t < 43.8:
            overlay_sub(im, 12)
        else:
            overlay_sub(im, 13)

    else:
        # MG-08 (44.500 - 47.467s): Conversation Support Payoff
        draw_header(d, "04 / LISTENING BENEFIT", "Conversation Support")

        # Full-width Card A13 (x: 80, y: 440, w: 920, h: 780)
        rr(d, (80, 440, 1000, 1220), r=24, fill=CARD, outline=INK, width=3)
        txt(d, (120, 480), "CONVERSATION WITH SURROUNDING VOICES", size=22, fill=GRAY, weight="bold")

        # Background Diners (remain present and drift subtly, NOT silenced)
        drift = int(6 * math.sin((t - 44.5) * 2.5))
        draw_table(d, 160 + drift, 680, 440, color=LIGHT, light=True)
        draw_figure(d, 220 + drift, 600, scale=0.52, color=LIGHT)
        draw_figure(d, 380 + drift, 570, scale=0.48, color=LIGHT)
        draw_figure(d, 540 + drift, 600, scale=0.52, color=LIGHT)
        draw_bubble(d, 250 + drift, 530, 70, 42, accent=False, muted=True)
        draw_bubble(d, 430 + drift, 510, 70, 42, accent=False, muted=True)

        # Foreground Pair: Emphasized with teal focus & connected bubbles
        fg_scale = lerp(1.0, 1.04, ease((t - 45.0) / 0.8))
        lx, rx = 340, 680
        fy = 870
        draw_figure(d, lx, fy, scale=0.88 * fg_scale, color=INK)
        draw_figure(d, rx, fy, scale=0.88 * fg_scale, color=INK)
        draw_table(d, 260, 980, 480, color=INK)
        
        # Speech bubbles with teal path connecting them
        draw_bubble(d, 200, 690, 160, 85, accent=True)
        draw_bubble(d, 640, 690, 160, 85, accent=True)

        if t > 45.1:
            p_beam = ease((t - 45.1) / 0.7)
            d.line((360, 730, 360 + int(280 * p_beam), 730), fill=TEAL, width=6)
            d.ellipse((352, 722, 368, 738), fill=TEAL)
            if p_beam > 0.95:
                d.ellipse((632, 722, 648, 738), fill=TEAL)

        # Bottom Badge
        if t > 46.2:
            rr(d, (180, 1120, 900, 1180), r=16, fill=PALE, outline=TEAL, width=2)
            txt(d, (540, 1150), "CAN SUPPORT CONVERSATION • AMBIENCE RETAINED", size=22, fill=TEAL, weight="bold", anchor="mm")

        if 44.200 <= t <= 47.467:
            overlay_sub(im, 13)

    return im.convert("RGB")

# -------------------------------------------------------------
# Frame rendering function for pipe
# -------------------------------------------------------------
def render_block_to_mp4(block_id, start_sec, end_sec, out_mp4):
    fps = 30
    total_frames = int(round((end_sec - start_sec) * fps))
    print(f"\n[Motion Block {block_id}] Rendering {start_sec:.3f}s to {end_sec:.3f}s ({total_frames} frames) -> {out_mp4}")
    
    cmd = [
        "ffmpeg", "-y",
        "-loglevel", "error",
        "-f", "rawvideo",
        "-pix_fmt", "rgb24",
        "-s", f"{W}x{H}",
        "-r", str(fps),
        "-i", "-",
        "-c:v", "libx264",
        "-crf", "17",
        "-preset", "fast",
        "-pix_fmt", "yuv420p",
        out_mp4
    ]
    
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    
    for f in range(total_frames):
        cur_t = start_sec + f / fps
        if block_id == 1:
            frame_img = render_block1(cur_t)
        elif block_id == 2:
            frame_img = render_block2(cur_t)
        else:
            frame_img = render_block3(cur_t)
            
        raw_bytes = frame_img.tobytes()
        proc.stdin.write(raw_bytes)
        
        if f % 45 == 0 or f == total_frames - 1:
            pct = int((f + 1) / total_frames * 100)
            sys.stdout.write(f"\r  Frame {f+1}/{total_frames} ({pct}%)")
            sys.stdout.flush()
            
    proc.stdin.close()
    proc.wait()
    print(f"\n[OK] Motion Block {block_id} complete!")

def main():
    os.makedirs("scratch", exist_ok=True)
    
    # 1. Block 1: 6.500 to 17.667s (335 frames)
    render_block_to_mp4(1, 6.500, 17.667, "scratch/motion_01.mp4")
    
    # 2. Block 2: 26.100 to 33.300s (216 frames)
    render_block_to_mp4(2, 26.100, 33.300, "scratch/motion_02.mp4")
    
    # 3. Block 3: 38.800 to 47.467s (260 frames)
    render_block_to_mp4(3, 38.800, 47.467, "scratch/motion_03.mp4")
    
    print("\n[OK] ALL 3 MOTION DESIGN BLOCKS GENERATED SUCCESSFULLY!")

if __name__ == "__main__":
    main()
