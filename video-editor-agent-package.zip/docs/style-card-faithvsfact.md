# Style Card: Faith vs Fact (@faithvsfact)
**References Analyzed:** 
- `De0qGBoPGTv` — *How heavy was the mountain Hanuman ji carried?*
- `DezcRntviFa` — *Mahadev once killed Yamaraj*
- `DeumrQFz8jK` — *Ravana was half God and...*
- `Det5cUCPRXU` — *Arjun once almost killed Yudhishthir*
- `DernY5evLN5` — *Shri Hanuman never used Gada?*
- `Deor6Ehvm4U` — *Maa Durga vs Shumbha & Nishumbha*

**Channel Reference:** [https://www.instagram.com/faithvsfact/](https://www.instagram.com/faithvsfact/)  
**Analyzed Date:** 2026-10-25  
**Core Format:** 100% Procedural Vector Motion Graphics Explainer (Zero talking head, zero live-action camera footage, zero photorealistic AI slop)  
**Target Specification:** 9:16 Vertical (1080x1920) @ 30 FPS • Mastered to −14.0 LUFS EBU R128  

---

## 1. Pacing & Temporal Cadence (Measured Data)

| Metric | Measured Value Across References | Interpretation & Psychological Function |
|---|---|---|
| **Max Scene Duration (HARD RULE)** | **STRICT CEILING: ≤ 4.0 SECONDS** | **Permanent Rule:** No scene may ever run longer than 4.0 seconds (≤ 120 frames at 30 FPS). Typical target: 2.5s – 3.5s per shot. Long multi-stage concepts must be sliced into distinct progressive cuts. |
| **Cuts per Minute** | **15.0 to 22.0 cuts/min** | High visual momentum. Scene changes occur every 2.5s – 3.5s to maintain cognitive engagement and prevent visual stagnation. |
| **Average Shot Length (ASL)** | **2.8s to 3.5s (Strict Maximum: 4.0s)** | Each cut delivers one atomic visual fact or state change before hard-cutting to the next analytical layer. |
| **Motion Continuity** | **100% continuous micro-motion** | There is never a static frozen frame. Even during a 3-second shot, the camera slowly creeps (zoom-in 1.0x to 1.08x), background dust particles drift, character limbs subtly sway or breathe, and glowing halos pulse gently. |
| **Camera Dynamics** | Slow linear or eased zoom-in (creep), vertical pedestal pan tracking tall structures, and hard match-cuts on action beats. | Draws the eye into the center of interest while maintaining viewer trance state. |

---

## 2. Visual Aesthetic & Art Style Bible

### A. The "Paper-Cut Shadow Box" Vector Aesthetic
- **Character & Object Construction:** Flat, geometric 2D vector shapes with layered depth. Characters have segmented limbs (head, torso, upper arm, forearm, hand) resembling a refined digital puppet / paper-cut automaton.
- **Stylized Anatomy:** Clean minimalist facial features (sharp almond eyes, clean geometric brows, solid hair contours). No photorealistic skin pores or uncanny valley faces.
- **Lighting & Depth:** Soft drop shadows (`rgba(0, 0, 0, 0.45)`) between overlapping vector layers create clear physical separation.

### B. Backgrounds & Atmospheric Lighting
- **Dark, Atmospheric Canvas:** Deep, cinematic, saturated dark palettes:
  - Midnight Obsidian / Navy: `#0A0F1D` → `#141C2B`
  - Deep Sacred Crimson / Wine: `#200808` → `#3D1010`
  - Muted Royal Charcoal / Brown: `#191512` → `#2B231D`
  - Clinical Deep Slate (For hearing/speech): `#0D141F` → `#182232`
- **Radial Volumetric Spotlight (Signature Trait):** Every scene features a warm, glowing radial gradient spotlight behind the central hero actor or diagram (`radial-gradient(circle at 50% 45%, rgba(255, 215, 120, 0.22) 0%, transparent 70%)`).
- **Ambient Particle Field:** 15–25 ambient glowing dust motes or golden embers floating upward with subtle horizontal sine-wave drift.

### C. The "Fact" Technical & Blueprint Overlays (Signature Trait)
- **Glowing Blueprint Geometry:** Golden or crisp white technical lines (`stroke-width: 2px`, glowing drop shadow) illustrating volume, height, distance, or acoustic waves.
  - Wireframe 3D primitives (cones, cylinders, spheres, grids).
  - Dimension calipers with arrowheads and measurement tags (`3 KILOMETERS WIDE`, `1 KILOMETER TALL`).
- **Comparative Scientific Diagrams:** Balance scales, comparison meters, cross-sectional cutaways, trajectory arcs.
- **Ancient Scrolls & Manuscript Cards:** Floating parchment cards with etched runes or Sanskrit verses, highlighted with glowing light as they are cited.

---

## 3. Typography & Subtitle System

| Property | Measured Specification |
|---|---|
| **Font Family** | Classical, authoritative, serif / semi-serif with small-caps styling (e.g., **Cinzel**, **Marcellus**, **Trajan Pro**, or **Cormorant Garamond**) |
| **Casing** | **STRICTLY UPPERCASE** (or Small-Caps with larger first initials) |
| **Size** | **40px to 46px** on 1080x1920 (~2.1% to 2.4% of frame height) |
| **Letter Spacing** | `tracking-wider` / `letter-spacing: 0.08em` to `0.12em` |
| **Positioning** | Lower third (`y ≈ 1520px` to `1560px` from top), perfectly centered horizontally (`x = 540px`). Stays safely inside Instagram's UI dead-zones. |
| **Coloring** | **Base Text:** Crisp Pure White (`#FFFFFF`) or Soft Cream (`#F7F3E9`)<br>**Highlight Keywords:** Radiant Gold / Amber (`#FFC83B`, `#F5AF19`, `#FFD700`) |
| **Stroke & Shadow** | Subtle dark backdrop blur or 3px soft black halo (`text-shadow: 0 2px 10px rgba(0,0,0,0.85), 0 0 4px rgba(0,0,0,0.9)`) for 100% legibility on any background. |
| **Batching & Timing** | **2 to 5 words per batch**. Appears smoothly in exact lockstep with spoken syllable audio. Key quantitative or dramatic words turn gold. |

---

## 4. Color Palette Breakdown

```
Canvas / Deep Background:     #0A0F1D  (Midnight Navy)
                              #1F0A0A  (Dusky Crimson)
                              #0D1912  (Muted Forest)
Radial Ambient Glow:          rgba(255, 200, 100, 0.20)
Hero Primary Accent / Gold:   #FFC83B  (Bright Amber Gold)
Secondary Sacred Gold:        #D4AF37  (Classic Metallic Gold)
Technical Blueprint Line:     #64B5F6  (Luminous Cyan / Acoustic Blue)
Base Subtitle White:          #FFFFFF  (Pure White)
Highlight Keyword Gold:       #FFD24D  (Punchy Gold)
Shadow & Vignette:            #000000  (Deep Vignette at corners)
```

---

## 5. Sound & Audio Architecture

- **Integrated Loudness:** Strictly mastered to **−14.0 LUFS** ($\pm 0.5$ LUFS) with True Peak **−1.0 dBTP** (EBU R128).
- **Voiceover Character:** Deep, articulate, calm, authoritative storytelling delivery (~130–145 words per minute). Unrushed, clinical yet captivating cadence.
- **Atmospheric Music Bed:** Ambient cinematic synth pad / acoustic drone with subtle sub-bass presence, ducked at **−20 dB to −24 dB** beneath voiceover.
- **Sound Effects (SFX) Grammar:**
  - **Sub Impact / Boom:** On hook opener and major topic reveals (low-pass filtered deep hit).
  - **Cinematic Air Whoosh:** On scene hard-cuts and camera zooms.
  - **Crisp Mechanical / Caliper Click:** When blueprint lines, measurements, or numbers snap into frame.
  - **Ethereal Resonant Chime:** When glowing halos or anatomical structures illuminate.
  - **Organic Room Drone:** Subtle continuous background tone ensuring zero dead air.

---

## 6. Adaptation for Hearing & Speech Clinic

How this visual language translates directly to your Audiology & Speech Pathology practice:

| Faith vs Fact Element | Hearing & Speech Clinic Equivalent | Code Component |
|---|---|---|
| **Mythological Hero / Character** | Stylized Doctor / Patient / Child with hearing aid / Cochlear implant user | Segmented SVG puppet rig with subtle breathing and blinking |
| **Sacred Temple / Mountain** | High-precision stylized anatomical cross-section of the **Ear** (Cochlea, Ossicles, Eardrum) or **Vocal Tract** (Larynx, Vocal folds) | Layered vector SVG with glowing cross-sectional highlight paths |
| **Golden 3D Wireframe Cone / Calipers** | **Acoustic Sound Waves & Decibel Scales** (Oscillating sine waves, dB meters, frequency spectrum 250Hz–8000Hz) | Procedural Canvas / SVG wave renderer with animated amplitude |
| **Sanskrit Manuscript / Scroll Card** | **Diagnostic Audiogram Card / Clinical Case File** (Clean parchment/slate card with hearing thresholds, speech clarity scores) | SVG/CSS Bento card with glowing borders and animated plot points |
| **Balance Scale Comparison** | **Hearing Aid vs Normal Hearing vs Cochlear Implant** side-by-side technical comparison | Dual-register animated layout with balanced physics |
| **Gold Halos & Synaptic Threads** | **Neural Action Potentials** (Electric impulses traveling along the 8th cranial nerve to the auditory cortex) | Animated glowing dash-paths (`stroke-dashoffset`) |

---

## 7. Remotion Code Implementation Stack

1. **Framework:** Remotion (React 19 + TypeScript) rendering at 1080x1920 @ 30 FPS.
2. **Animation Engine:** Remotion `interpolate()` with `spring()` physics (damped harmonic oscillation: mass 0.5, damping 12, stiffness 100).
3. **Graphics Layer:** 100% vector SVG components (infinite DPI scaling, zero pixelation) combined with HTML5 Canvas for real-time acoustic waveform simulation.
4. **Audio & Subtitle Sync:** Automated word timestamping aligned with author-provided voiceover.
5. **Mastering Pipeline:** Remotion render → ffmpeg two-pass `loudnorm` filter targeting integrated −14.0 LUFS.
