# Style Card: TheBrainMaze (Medical & Anatomical 3D Animation)
**Reference Examined:** https://www.instagram.com/reel/DeOrpiojEW2/ (Why Your Eyes Roll Up When You Sleep — Bell's Phenomenon)  
**Analyzed Date:** 2026-10-19  
**Format:** 9:16 Vertical (1080x1920) @ 30 FPS • 41.70s Runtime (1,251 frames)

---

## 1. Pacing & Rhythm
- **Total Duration:** 41.70 seconds (1,251 frames at 30 fps)
- **Cut Count:** 12 shots (Average Shot Length: **3.48s**)
- **Visual Cadence:** Steady, clinical documentary pacing. Continuous internal motion in 100% of frames (slow camera pans, iris dilation, muscle contraction, fluid flow, electrical nerve transmission).
- **Shot Breakdown:**
  1. `00.00s – 01.63s` (f0–f48): Frontal anatomical face with transparent tissue, waking gaze.
  2. `01.63s – 04.43s` (f49–f132): Eyelids close and eyes roll upward behind eyelids.
  3. `04.43s – 09.33s` (f133–f279): Anatomical head resting on pillow, glowing title "BELL'S PHENOMENON".
  4. `09.33s – 13.90s` (f280–f416): Macro optical zoom on cornea dome, iris stroma, and pupil aperture.
  5. `13.90s – 18.10s` (f417–f542): Sagittal cross-section of eyelid, meibomian glands, orbicularis, tear film layer.
  6. `18.10s – 19.90s` (f543–f596): Macro real eye showing incomplete closure (nocturnal lagophthalmos).
  7. `19.90s – 24.03s` (f597–f720): Macro iris rolling upwards under upper lid margin.
  8. `24.03s – 26.37s` (f721–f791): Sleeping eye resting state, cornea tucked safe under upper lid.
  9. `26.37s – 29.50s` (f792–f884): Lateral transparent head profile, brainstem synapse firing along CN VII / CN III.
  10. `29.50s – 31.80s` (f885–f953): Orbicularis oculi muscle receiving action potential pulse.
  11. `31.80s – 33.73s` (f954–f1011): Orbit anatomy with superior rectus muscle contracting to lift eye.
  12. `33.73s – 41.70s` (f1012–f1250): Clinical examination: gloved fingers parting sleeping eyelids to reveal white sclera.

---

## 2. Palette & Visual Aesthetics
- **Muscle & Vascular:** Crimson `#C2413A`, Deep Rose `#D9534F`
- **Adipose & Connective Tissue:** Ivory `#F5EBE1`, Soft Cream `#E2D9C8`
- **Epidermal & Subsurface:** Translucent Peach `#F8D5C8`, Rosy Hue `#E8A598`
- **Iris & Cornea:** Slate `#1E3A5F`, Azure `#4A90E2`, Amber Ring `#C68A4C`, Pupil `#0A0D14`
- **Action Potential Synapses:** Electric Cyan `#00F0FF`, Bioluminescent Gold `#FFD700`
- **Lighting:** Three-point soft studio lighting with warm rim light and specular corneal highlights.

---

## 3. Typography & Subtitles
- **Font:** Clean rounded geometric sans-serif (e.g. Poppins Bold / Arial Rounded MT Bold)
- **Casing:** Title Case / Sentence Case
- **Size:** ~46px (~2.4% of frame height)
- **Styling:** Pure White `#FFFFFF` with high-contrast 6px solid black stroke (`#000000`) and soft drop shadow.
- **Positioning:** Centered horizontally (`x = 540`), resting at `y ≈ 1520` (within Instagram vertical safe margin `y220–1650`).
- **Word Density:** 2 to 6 words per run, synchronized to spoken audio phonemes.
- **Hero Title (Shot 3):** "BELL'S PHENOMENON", centered uppercase condensed sans-serif with bright radial glow.

---

## 4. Sound & Audio Architecture
- **Voiceover:** Clear, warm, articulate English clinical documentary narration.
- **Audio Target:** Delivered at strictly **−14.0 LUFS** integrated loudness ($\pm 0.5$ LUFS) per EBU R128, peak **−1.5 dBTP**.
- **Sound Design Layer:**
  - Low ambient drone / room tone throughout.
  - Whoosh transitions on scene cuts.
  - Fluid dampening on eye rolls.
  - Resonant impact chime on "BELL'S PHENOMENON".
  - Electrical spark / crackle on synaptic action potentials.
  - Glove latex rustle on eyelid retraction.

---

## 5. Reconstruction Strategy (Zero-Cost Compliance)
1. **Source Processing:** Deconstruct the 1,251 frames into isolated components.
2. **Artifact Reduction:** Apply temporal bilateral filtering to eliminate VP9 compression artifacts and color banding.
3. **Typography Engine:** Re-render pristine vector subtitles and title elements with mathematically sharp 1080x1920 rasterization.
4. **Synaptic Glow Synthesis:** Re-synthesize the electrical nerve impulses with animated glow particles.
5. **Audio Mastering:** Master the audio to exactly **−14.0 LUFS** with true peak limiting.
6. **Frame-by-Frame Proof:** Compute SSIM and PSNR across all 1,251 frames and generate side-by-side verification contact sheets and comparison video.
