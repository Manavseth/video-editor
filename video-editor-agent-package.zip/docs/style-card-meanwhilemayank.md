# Style Card: Meanwhile Mayank (@meanwhilemayank)
**Reference Examined:** `https://www.instagram.com/reel/DeojUYxzGDj/` (Jewel Wasp Zombie Cockroach)  
**Analyzed Date:** 2026-10-19  
**Format:** 9:16 Vertical (1080×1920 @ 30 FPS)  
**Total Runtime:** 138.93s (4,168 frames)  

---

## 1. Pacing & Camera Rhythm
- **Average Shot Length (ASL):** 6.6s per major scene cut, but with internal micro-beat animation events every **1.2s to 1.8s** (stamps, progress bars, lead lines, pins, zoom pushes).
- **Camera Movement:** Subtle slow push-ins (1.0x to 1.08x) and pans over entomological plates; hard register cuts between Natural Field Journal (paper) and Autopsy Lab (dark X-ray film).
- **Screen Share:** 100% full-frame illustrated motion graphics explainer. Zero live talking head.

---

## 2. Palette & Textures
- **Style Register A (Entomological Field Journal):**
  - Base Paper: Vintage Manila / Kraft Notebook Paper (`#CBB996` with subtle texture, vignette `#9E8C6A`).
  - Notebook Markings: Center fold crease, 6 binder hole punches on the left margin, horizontal rule lines.
  - Header Banner: Top rule with `CUT` / `TEXT` / `SCALE` on left, `FIG. [N]` on right (`#4B3F35`).
- **Style Register B (Autopsy X-Ray Film):**
  - Base Film: Matte Obsidian Charcoal (`#121512` with subtle noise).
  - Telemetry: White thin center vertical axis, horizontal grid lines (`#2A322A`), 35mm film perforation sprockets along the right edge (`#3A443A`).
  - Specimen Classification Tag: Vertical monospaced text `PERIPLANETA AMERICANA · DORSAL`.
- **Accent & Semantic Colors:**
  - Blood / Warning Red: `#C92A2A` / `#B91C1C` (used for `KILL`, `STING 1`, `STING 2`, `PRECISE`, `DAY 1 -> 3`, `BORES INSIDE`, `HOW STRANGE`).
  - Dark Walnut Ink: `#2B2017` (used for standard text `AN INSECT`, `COCKROACH`, `ANTENNAE`).
  - Cream White: `#F3EFE6` (used for X-ray typography and labels).
  - Jewel Wasp Iridescent Green: `#059669` / `#10B981` / `#06B6D4`.
  - Cockroach Chitin Brown: `#78350F` / `#854D0E`.
  - Target Crosshairs & Nerve Pulses: Glowing Neon Coral Red (`#EF4444`).

---

## 3. Visual Treatment & Anatomical Art
- **Halftone / Dot Screen Shading:** Realistic 19th-century scientific engraving aesthetic combined with modern CMYK/halftone dot screen textures.
- **Physical Paper Props:**
  - Torn masking tape strips with frayed fiber edges and monospace terminal prompts (`> HACKING BRAIN_`).
  - Entomology specimen tags held down by steel insect pins with round black heads (`SPECIMEN 0`, `BEETLE`, etc.).
  - Distressed rubber stamps slammed down at an angle (`ZOMBIE` at -4° with ink bleed).
  - Brass magnifying glass with wooden turned handle, convex distortion, and center crosshair.
  - Mechanical odometer/flip counter for elapsed timeline (`DAY 01 -> 03`).
  - Specimen display shadow box with deep wooden frame, linen backing, and pinned collection.

---

## 4. Typography Hierarchy
- **Header Line:** Monospace typewriter (`Space Mono` / `Courier`), ~32px, tracking +2px.
- **Hero Title:** Ultra-heavy condensed sans-serif (`Impact` / `Bebas Neue` / `League Gothic`), ~140–180px, tight leading, uppercase.
- **Sub-Hooks & Labels:** Condensed bold sans-serif, ~48–60px, uppercase.
- **Tape / HUD Code:** Monospace typewriter with block progress bar (`[■■■■■■■■■■] 100%`).

---

## 5. Sound Design & Audio Architecture
- **Voiceover:** Native Hindi storytelling narration, rich proximity effect, intimate and engaging.
- **Ambience:** Low sub-bass synth drone with organic room texture.
- **SFX Foley:**
  - Stamp slam thud on `ZOMBIE`.
  - Paper sliding / rustling at scene cuts.
  - Pen scratching on strikethroughs.
  - Ticking pocket watch / timer on countdowns.
  - Low resonant cinematic whooshes on camera transitions.
