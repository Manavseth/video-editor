import os
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

pdf_path = r"f:\Antigravity\video editor\docs\dm\80db-volume-guide.pdf"
os.makedirs(os.path.dirname(pdf_path), exist_ok=True)

doc = SimpleDocTemplate(pdf_path, pagesize=letter, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
styles = getSampleStyleSheet()

title_style = ParagraphStyle(
    'TitleStyle',
    parent=styles['Heading1'],
    fontName='Helvetica-Bold',
    fontSize=22,
    textColor=colors.HexColor('#00FF9D'),
    spaceAfter=10
)

subtitle_style = ParagraphStyle(
    'SubTitleStyle',
    parent=styles['Normal'],
    fontName='Helvetica-Bold',
    fontSize=13,
    textColor=colors.HexColor('#00E5FF'),
    spaceAfter=15
)

body_style = ParagraphStyle(
    'BodyStyle',
    parent=styles['Normal'],
    fontName='Helvetica',
    fontSize=11,
    textColor=colors.HexColor('#222222'),
    leading=15,
    spaceAfter=10
)

elements = []
elements.append(Paragraph("AUDIOLOGY CLINICAL REFERENCE GUIDE", subtitle_style))
elements.append(Paragraph("The 3 dB Exchange Rate: Ear Safety Protocol", title_style))
elements.append(Paragraph("How daily earphone volume silently damages high-frequency stereocilia hair cells in the cochlea, resulting in permanent tinnitus and sensorineural hearing loss.", body_style))
elements.append(Spacer(1, 15))

elements.append(Paragraph("<b>1. The Exposure Doubling Rule (NIOSH Standard)</b>", body_style))

data = [
    ["Volume Level", "Max Permissible Time / Day", "Auditory Risk Assessment"],
    ["85 dB", "8 Hours", "Safe clinical baseline"],
    ["88 dB (+3 dB)", "4 Hours", "Safe window cut by 50%"],
    ["91 dB (+6 dB)", "2 Hours", "Safe window cut by 75%"],
    ["100+ dB (Full Volume)", "< 15 Minutes", "Immediate acoustic trauma risk"]
]

table = Table(data, colWidths=[130, 180, 210])
table.setStyle(TableStyle([
    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1c1926')),
    ('TEXTCOLOR', (0, 0), (-1, 0), colors.HexColor('#00FF9D')),
    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
    ('FONTSIZE', (0, 0), (-1, 0), 10),
    ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
    ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#F8F9FA')),
    ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#D0D7DE')),
    ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
    ('FONTSIZE', (0, 1), (-1, -1), 9),
    ('TEXTCOLOR', (0, 4), (-1, 4), colors.HexColor('#D32F2F')),
]))
elements.append(table)
elements.append(Spacer(1, 20))

elements.append(Paragraph("<b>2. Key Preventative Directives</b>", body_style))
elements.append(Paragraph("• <b>Lock Phone Volume to 70%:</b> Enable 'Reduce Loud Sounds' (iOS) or 'Media Volume Limit' (Android).", body_style))
elements.append(Paragraph("• <b>The 60/60 Protocol:</b> Never exceed 60% max volume; take a 10-minute quiet break every 60 minutes.", body_style))
elements.append(Paragraph("• <b>Recognizing Tinnitus:</b> Persistent ringing, buzzing, or clicking after headphone removal indicates acute hair-cell exhaustion.", body_style))

doc.build(elements)
print(f"PDF built successfully at {pdf_path}")
