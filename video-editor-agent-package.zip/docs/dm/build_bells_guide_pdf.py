import os, shutil
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

pdf_path = r"f:\Antigravity\video editor\docs\dm\bells-phenomenon-guide.pdf"
artifact_dir = r"C:\Users\Lenovo\.gemini\antigravity\brain\17de5f2b-0f0a-46af-b833-f4de8bfb1454"
artifact_pdf = os.path.join(artifact_dir, "bells-phenomenon-guide.pdf")
os.makedirs(os.path.dirname(pdf_path), exist_ok=True)
os.makedirs(artifact_dir, exist_ok=True)

doc = SimpleDocTemplate(pdf_path, pagesize=letter, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
styles = getSampleStyleSheet()

title_style = ParagraphStyle(
    'TitleStyle',
    parent=styles['Heading1'],
    fontName='Helvetica-Bold',
    fontSize=20,
    textColor=colors.HexColor('#1E3A5F'),
    spaceAfter=8
)

subtitle_style = ParagraphStyle(
    'SubTitleStyle',
    parent=styles['Normal'],
    fontName='Helvetica-Bold',
    fontSize=12,
    textColor=colors.HexColor('#008080'),
    spaceAfter=12
)

body_style = ParagraphStyle(
    'BodyStyle',
    parent=styles['Normal'],
    fontName='Helvetica',
    fontSize=10,
    textColor=colors.HexColor('#1F2937'),
    leading=14,
    spaceAfter=8
)

elements = []
elements.append(Paragraph("NEURO-OPHTHALMOLOGY CLINICAL REFERENCE SHEET", subtitle_style))
elements.append(Paragraph("Bell's Phenomenon: The Nocturnal Eye Defense Reflex", title_style))
elements.append(Paragraph("Why your eyes automatically roll upward behind your closed eyelids during sleep, how the pontine brainstem circuit coordinates Cranial Nerves VII and III, and its critical role in preventing corneal drying.", body_style))
elements.append(Spacer(1, 10))

elements.append(Paragraph("<b>1. Neural Reflex Arc Architecture</b>", body_style))

data = [
    ["Anatomical Node", "Cranial Nerve / Nucleus", "Effector Structure", "Physiological Function"],
    ["Eyelid Afferent", "CN VII (Facial)", "Orbicularis Oculi Muscle", "Initiates voluntary or reflex palpebral closure"],
    ["Pontine Interneuron", "Paramedian Reticular Formation", "Brainstem Synaptic Relay", "Synchronizes CN VII firing with CN III subnuclei"],
    ["Ocular Efferent", "CN III (Oculomotor)", "Superior Rectus & Inf. Oblique", "Contracts to elevate globes superiorly and laterally"],
    ["Corneal Protection", "Superior Conjunctival Fornix", "Corneal Epithelial Shield", "Tucks central cornea away from palpebral fissure gap"]
]

table = Table(data, colWidths=[100, 130, 140, 160])
table.setStyle(TableStyle([
    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0F172A')),
    ('TEXTCOLOR', (0, 0), (-1, 0), colors.HexColor('#FFFFFF')),
    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
    ('FONTSIZE', (0, 0), (-1, 0), 8.5),
    ('BOTTOMPADDING', (0, 0), (-1, 0), 6),
    ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#F8FAFC')),
    ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#CBD5E1')),
    ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
    ('FONTSIZE', (0, 1), (-1, -1), 8),
    ('TEXTCOLOR', (0, 1), (-1, 1), colors.HexColor('#1E3A5F')),
    ('TEXTCOLOR', (0, 2), (-1, 2), colors.HexColor('#008080')),
]))
elements.append(table)
elements.append(Spacer(1, 14))

elements.append(Paragraph("<b>2. Key Clinical & Biological Insights</b>", body_style))
elements.append(Paragraph("• <b>Evolutionary Defense Against Nocturnal Lagophthalmos:</b> In roughly 5%–10% of the population, the eyelids do not achieve an airtight seal during sleep. Without Bell's phenomenon, environmental air circulation would evaporate the tear film directly over the optical center of the cornea, causing painful exposure keratitis and epithelial ulceration.", body_style))
elements.append(Paragraph("• <b>Population Prevalence:</b> Clinical trials show Bell's phenomenon is active in approximately 88%–92% of healthy human subjects. In the remaining 10%, the eyes either stay neutral or occasionally demonstrate an inverse Bell's phenomenon (downward rotation).", body_style))
elements.append(Paragraph("• <b>The Bell's Palsy Diagnostic Clue:</b> When a patient suffers from peripheral facial nerve palsy (Bell's palsy), the orbicularis oculi is paralyzed and cannot close the eyelid. When asked to close their eyes, the patient's eyelid remains open while the eye visibly rolls upward, making the phenomenon dramatically visible to the naked eye.", body_style))

doc.build(elements)
print(f"PDF built successfully at {pdf_path}")
shutil.copyfile(pdf_path, artifact_pdf)
print(f"Copied to artifact directory: {artifact_pdf}")
