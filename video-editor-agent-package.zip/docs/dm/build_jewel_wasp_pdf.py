import os, shutil
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

pdf_path = r"f:\Antigravity\video editor\docs\dm\jewel-wasp-guide.pdf"
artifact_pdf = r"C:\Users\Lenovo\.gemini\antigravity\brain\758b3156-3a07-48eb-a4e2-046693a1acf9\jewel-wasp-guide.pdf"
os.makedirs(os.path.dirname(pdf_path), exist_ok=True)

doc = SimpleDocTemplate(pdf_path, pagesize=letter, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
styles = getSampleStyleSheet()

title_style = ParagraphStyle(
    'TitleStyle',
    parent=styles['Heading1'],
    fontName='Helvetica-Bold',
    fontSize=20,
    textColor=colors.HexColor('#C32418'),
    spaceAfter=8
)

subtitle_style = ParagraphStyle(
    'SubTitleStyle',
    parent=styles['Normal'],
    fontName='Helvetica-Bold',
    fontSize=12,
    textColor=colors.HexColor('#168065'),
    spaceAfter=12
)

body_style = ParagraphStyle(
    'BodyStyle',
    parent=styles['Normal'],
    fontName='Helvetica',
    fontSize=10,
    textColor=colors.HexColor('#221C16'),
    leading=14,
    spaceAfter=8
)

elements = []
elements.append(Paragraph("ENTOMOLOGY & NEUROBIOLOGY FIELD REFERENCE", subtitle_style))
elements.append(Paragraph("The Jewel Wasp (Ampulex compressa): Precision Neurosurgeon", title_style))
elements.append(Paragraph("How a 22 mm parasitic wasp executes precision micro-neurosurgery to turn a cockroach twice its size into an obedient zombie host.", body_style))
elements.append(Spacer(1, 10))

elements.append(Paragraph("<b>1. The Two-Sting Surgical Protocol</b>", body_style))

data = [
    ["Phase", "Target Anatomy", "Neurochemical Action", "Observed Behavior"],
    ["Sting 1", "Thoracic Ganglion", "GABA + Central Motor Block", "Front legs paralyzed for 2-3 mins"],
    ["Sting 2", "Subesophageal Ganglion", "Dopamine / Octopamine Blocker", "Ablates spontaneous escape reflex"],
    ["Leash Walk", "Antennal Stumps", "Mechanoreceptive Guidance", "Roach walks into burrow like a pet"],
    ["Egg Implant", "Mid-Coxa Leg Base", "Cemented single 2mm egg", "Barricaded with pebbles for 40 days"]
]

table = Table(data, colWidths=[70, 130, 160, 170])
table.setStyle(TableStyle([
    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1A1C19')),
    ('TEXTCOLOR', (0, 0), (-1, 0), colors.HexColor('#FFFFFF')),
    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
    ('FONTSIZE', (0, 0), (-1, 0), 9),
    ('BOTTOMPADDING', (0, 0), (-1, 0), 6),
    ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#F5EFE6')),
    ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#D2BE9B')),
    ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
    ('FONTSIZE', (0, 1), (-1, -1), 8.5),
    ('TEXTCOLOR', (0, 1), (-1, 1), colors.HexColor('#C32418')),
    ('TEXTCOLOR', (0, 2), (-1, 2), colors.HexColor('#168065')),
]))
elements.append(table)
elements.append(Spacer(1, 14))

elements.append(Paragraph("<b>2. Key Biochemical Mechanisms</b>", body_style))
elements.append(Paragraph("• <b>Octopamine Blockade:</b> Octopamine is the insect equivalent of norepinephrine. When blocked, the cockroach can still run, jump, or groom if stimulated, but its internal motivation / initiation drive is completely eradicated.", body_style))
elements.append(Paragraph("• <b>Radioactive Tracking Studies:</b> Modern radioisotope labeling proved the wasp stinger carries sensory receptors that physically 'probe' through brain tissue until detecting the exact neural coordinates of the subesophageal ganglion.", body_style))
elements.append(Paragraph("• <b>Non-Vital Organ Consumption:</b> The hatched larva intentionally avoids eating the cockroach's central nervous system or heart during the initial 8 days, keeping the host alive and fresh so the meat does not rot.", body_style))

doc.build(elements)
print(f"PDF built successfully at {pdf_path}")
shutil.copyfile(pdf_path, artifact_pdf)
print(f"Copied to artifact directory: {artifact_pdf}")
