# Instagram Reel Caption: The Jewel Wasp (Ampulex compressa)

This isn’t a sci-fi movie. This happens in real life every single day. 

A tiny 22 mm emerald jewel wasp does literal micro-neurosurgery on an American cockroach twice its size, turning it into an obedient zombie pet.

Here is the exact biological surgery breakdown:

1. STING 1 (Thorax): Delivers a fast-acting GABA neurotoxin straight to the thoracic ganglion, completely paralyzing the cockroach’s front legs for 3 minutes so it cannot fight back.
2. STING 2 (The Brain): The wasp uses mechanosensory receptors on its stinger to locate the exact subesophageal ganglion in the head, injecting a venom cocktail that blocks Octopamine (the neurotransmitter responsible for spontaneous escape movement).
3. THE LEASH WALK: Once the escape reflex is dead, the wasp chews down both antennae like a dog leash and leads the 2x larger cockroach walking straight into a dark underground burrow.
4. THE INCUBATOR: A single 2mm egg is glued to the host’s leg, the burrow is sealed with pebbles, and the hatched larva consumes the living cockroach from the inside out—specifically saving vital organs for last so the meat never rots.

Nature’s precision is terrifyingly beautiful.

Comment "WASP" below and I’ll send you the full 1-page Field Reference PDF with the surgical neurochemical breakdown straight to your DMs! 📩

---
#biology #naturefacts #jewelwasp #entomology #sciencefacts #motiongraphics #wildlife #parasitology
