# Asset Plan: Antigravity 60s Capabilities Showreel
**Format:** 9:16 Vertical (1080x1920) @ 30 FPS  
**Target Duration:** Exactly 60.00s (1,800 frames)  
**Cost Budget:** **$0.00 / ₹0.00** (Strict zero-cost constraint satisfied via local programmatic code, procedural canvas, Three.js, and neural Edge TTS)

---

## 1. Executive Summary & Concept
A high-velocity, broadcast-grade 60-second capability showreel demonstrating the complete range of motion design and video editing craftsmanship engineered directly in code. Every style mentioned is demonstrated with authentic visuals, live telemetry, and precision sound design.

---

## 2. Style-by-Style Visual & Script Breakdown (10 Acts)

| Act | Time Range | Frames (30fps) | Style Name & House Engine | Voiceover Script | Continuous Motion & Visual Elements | SFX Design Cues |
|---|---|---|---|---|---|---|
| **0** | `00.00 – 05.00s` | `0 – 150` | **Cold Open / Manifesto** | *"Most editors assemble clips. We engineer visual perception at the pixel level. Ten undisputed styles. Zero dollars spent. Watch."* | Glitch kinetic typography, reactive FFT audio spectrum bloom, cyan laser scan-line sweep, telemetry HUD readout. | Sub-bass impact, glitch stutter, laser sweep. |
| **1** | `05.00 – 11.00s` | `150 – 330` | **Apple Keynote Mixed-Media** (`apple-motion-edit`) | *"Style One: Apple Keynote commercial motion. Frosted Bento grids, dark obsidian studio, 4K product cutouts, and continuous spring physics."* | Obsidian background (`#060709`), frosted glass Bento card with specular sheen, 3D titanium hardware cutout, live animated digital caliper measuring `4.2 mm`, live rolling counter `₹8,00,000`. | Air whoosh, mechanical caliper click, digital readout chime. |
| **2** | `11.00 – 17.00s` | `330 – 510` | **2D Procedural JavaScript** (`2d-javascript-edit`) | *"Style Two: Two-D Procedural JavaScript. Zero timeline software. Every single frame drawn in math on HTML5 canvas with sub-50-millisecond cognitive fluency."* | Off-white paper ground (`#F4F1EA`), live sine wave oscillator, needle sweeping past `85 dB` safety dial into danger zone, 5px top progress bar, floating borderless subtitles. | Sine wave frequency sweep, gauge tick-tick-snap, paper slide. |
| **3** | `17.00 – 23.00s` | `510 – 690` | **Anatomy Mechanical Rig** (`anatomy-style-edit`, `anatomy`) | *"Style Three: Anatomy Mechanical Rigs. Crafted physical instruments, four-tone directional shading, dial gauges, and live laboratory telemetry."* | Blueprint plate (`#0D1117`), 3D exploded view separating casing, battery, and AI chip along isometric z-axis, 4-tone directional shading, `FIG 1.0` precision labels, blinking status LEDs. | Servo whir, pneumatic unlatch, sonar ping. |
| **4** | `23.00 – 29.00s` | `690 – 870` | **Signature 60-40 Split** (`split-screen`) | *"Style Four: The Signature sixty-forty split. Upper demo screen, lower camera card, dedicated caption lane, and hard-cut register grammar."* | 60-40 split-screen layout, upper screen card with live audio FFT oscilloscope, high-contrast yellow caption lane (`STAMPS NOT PILLS`), face card below with headroom safety, hard register cuts. | UI tab switch, snap impact, camera shutter. |
| **5** | `29.00 – 35.00s` | `870 – 1050` | **Tactile Paper Drawer & Whiteout** (`paper-drawer-edit`, `whiteout-edit`) | *"Style Five: Paper Drawer and Whiteout. Seventy-two-pixel tactile grid paper, sliding mechanical drawers, sticker physics, and bold editorial takeovers."* | Blueprint grid paper world with seam at y820, drawer sliding down in 10 frames, stickers dropping with shadows, flash takeover to pure Paper Whiteout canvas with kinetic typography. | Crisp paper slide, sticker slap, rapid typewriter tick. |
| **6** | `35.00 – 41.00s` | `1050 – 1230` | **Fast Creator Essay** (`broll-style-edit`) | *"Style Six: The Fast Creator Essay. One cut per second, two-tone building captions, and color registers flipping from black-and-white into vivid cinema."* | 1080x1080 square floating card on matte black, rapid 0.9s visual cuts, B&W archival grade blooming to vivid 4K color, two-tone accumulating captions. | Film projector click, whoosh transition, cinematic bass hit. |
| **7** | `41.00 – 47.00s` | `1230 – 1410` | **Layered Head & Depth** (`layered-head-edit`) | *"Style Seven: Layered Head spatial depth. Typography running behind the subject, floating interface chips beside hands, and kinetic punch-ins."* | Multi-plane depth separation, giant bold typography (`UNSTOPPABLE`) sliding behind subject, floating holographic UI chips, scoreboard HUD, jump-cut punch-ins. | Holographic UI hum, spatial whoosh, deep mechanical thud. |
| **8** | `47.00 – 53.00s` | `1410 – 1590` | **Forensic Reverse-Engineering** (`style-reverse-engineer`) | *"Style Eight: Empirical reverse-engineering. Contact sheet extraction, cut-frequency analysis, and pixel-for-pixel style cloning from raw reference links."* | 30-frame forensic contact sheet matrix, live analytics (`ASL: 1.14s`, `Cuts/min: 52.6`, `SSIM: 0.842`), side-by-side synchronization comparison slider. | Scanner beam frequency sweep, data chirps, confirmation ding. |
| **9** | `53.00 – 60.00s` | `1590 – 1800` | **Audio Engine & Outro** (`caption-align`, `sfx-design`, `render-ops`) | *"Sub-frame forced alignment. Peak-offset sound design. Broadcast mastered at minus 14 LUFS. Built entirely in code. Zero dollars. Unchallenged."* | Audio spectrum waterfall, live LUFS radar gauge locking at `-14.0 LUFS`, rapid 4-frame strobe recap of all styles, final lockup: `ANTIGRAVITY // THE UNDISPUTED VIDEO ENGINE // $0 BUDGET`. | Sub-bass rumble riser, sub drop boom, high-voltage snap, lock click. |

---

## 3. Audio & Engineering Specs
- **Integrated Loudness Target:** Strictly **−14.0 LUFS** ($\pm 0.5$ LUFS) with **−1.5 dBTP** true peak.
- **Voiceover Voice:** `en-US-ChristopherNeural` (broadcast documentary timbre, crisp transient clarity).
- **SFX Architecture:** Custom synthetic sub-bass drops, risers, mechanical clicks, and UI whooshes, peak-offset aligned to the exact video frame.
- **Visual Dimension:** 1080x1920 (9:16 vertical, Instagram / TikTok / Shorts native).
- **Render Stack:** Node.js + Edge Puppeteer + HTML5 Canvas + Three.js + OpenCV + FFmpeg rawvideo pipe.
