# Style Card: Figuring Out (True Crime / Noir Comic Reel)
**Reference Examined:** https://www.instagram.com/reel/DehTZOfM4hE/  
**Subject:** Barbara Butcher (Retired NYC Chief Death Investigator) interviewed by Raj Shamani  
**Analyzed Date:** 2026-10-19  

## 1. Pacing & Rhythm
- **Duration:** 173.58 seconds (2m 53.58s)
- **Total Measured Scene Cuts:** 75 cuts
- **Pacing:** 25.92 cuts/minute
- **Average Shot Length (ASL):** 2.31 seconds (ranges from 0.50s micro-cuts on impacts/dialogue turns to 7.58s for dramatic story reveals)
- **Visual Composition:** 
  - **72% Narrative Noir Artwork** (Full-screen dramatic 2D graphic novel illustration with blue/amber rim lighting, camera slow push/drift) + Picture-in-Picture (PIP) speaker in lower-right corner.
  - **28% Direct Studio Camera Cuts** (Medium close-up of Raj Shamani or Barbara Butcher with Rode Procaster/SM7B mic, black studio backdrop).

## 2. Palette & Lighting Semiotics
- **Background Black / Deep Charcoal:** `#050306` to `#0d0f14`
- **Cool Detective Blue Rim:** `#1e2952` to `#3b5998` (used for nighttime ambiance, cold suspense)
- **Warm Danger / Amber Accent:** `#764131` to `#c2410c` (used for street lamps, cigarette/table lamps, blood motifs)
- **Illustration Style:** High-contrast graphic novel noir, digital ink hatch, textured grain, cinematic key light.

## 3. Subtitles & Typography
- **Font Family:** Classical Serif (EB Garamond / Cormorant Garamond / Georgia)
- **Size:** 2.8% to 4.7% of frame height (~54px to ~90px on 1080x1920)
- **Case:** Title Case / Sentence Case (e.g. *"And One Day They Were Coming Into"*, *"And He Went Insane"*)
- **Word Density:** 2–5 words per display burst
- **Color & Weight:** 
  - Current/Active word: Bold Solid White (`#FFFFFF`) with soft ambient white blur/glow.
  - Context/Past words: Dimmed Silver/Gray (`#9CA3AF`, ~60% opacity).
- **Position:** Vertical Y ~ 63%–68% from top, horizontally centered or left-aligned within safe margin.
- **Disclaimer Footer:** 
  - Text: *"Visuals are AI-generated for illustration purposes only and do not depict real footage."*
  - Position: Y = 96% (bottom margin), font size ~16px, opacity ~65%, centered.

## 4. Picture-in-Picture (PIP) Face Overlay
- **Dimensions:** ~28% frame width, ~22% frame height, aspect ~4:5
- **Placement:** Bottom-right corner (X: ~68%, Y: ~72%)
- **Corner Radius:** 16px to 24px rounded rectangle
- **Border / Shadow:** Subtle dark drop shadow separating speaker window from illustration background.

## 5. Audio & Sound Dynamics
- **Integrated Loudness:** -14.19 LUFS (precisely adhering to the -14 LUFS short-form standard)
- **Loudness Range (LRA):** 2.60 LU (tight dynamic control, broadcast speech compression)
- **True Peak:** +0.68 dBTP
- **Audio Mix:** 
  - Primary dialogue centered, crisp high-presence, dry studio acoustic.
  - Background score: Low cello drone, dark cinematic sub-bass pulses, subtle string tremolo during tension beats, silent pauses on punchlines.
