# Style Card: so.thats.how ("How It Actually Works")
**References Examined:** 
- `ref_01.mp4`: Tesla Flying Car / Cold Gas Thrusters & Suction (`DelLPeEogle`)
- `ref_02.mp4`: Washing Machine Internal Mechanism (`DekjZVLKQCr`)
**Analyzed Date:** 2026-10-17  
**Format:** 9:16 Vertical (1080×1920)

---

## 1. Pacing & Camera Rhythm
- **Average Shot Length (ASL):** 2.2s to 3.5s per visual angle / transition.
- **Camera Movement:** Continuous, cinematic slow orbital drifts, macro push-ins into internal components, and isometric top-down transitions. Zero abrupt jump cuts; cuts are camera position shifts or cutaway dissections.
- **Screen Share:** **100% full-frame 3D cutaway / schematic explainer**. Zero human talking head.

---

## 2. Palette & Studio Environment
- **Studio Background:** Deep slate black `#08090C` to `#0F1117` with subtle radial vignette.
- **Lighting:** Moody dark-studio lighting with rim lights, volumetric spotlight cones, and illuminated ground plane.
- **Accent Colors:**
  - **Hook Tag / Brand Accent:** Yellow `#EAB308` / `#FACC15` (e.g. `HOW IT ACTUALLY WORKS` and watermark `So. Thats. How`).
  - **Technical HUD Lines & Cool Glow:** Electric Blue `#38BDF8` / `#2563EB` and Cyan `#06B6D4`.
  - **Energy / Pressure / Heat Callouts:** Neon Red/Orange `#EF4444` / `#F97316`.
  - **Ground Grid:** Faint isometric perspective grid lines (`#1E293B` or `#334155`).

---

## 3. Visual Treatment & Anatomical Cutaways
- **X-Ray & Shell Transparency:** Outer product shell fades to semi-transparent frosted glass/plastic, revealing the internal mechanics in motion.
- **HUD Blueprint Overlays:**
  - Thin cyan/white leader lines with small circular target anchors pointing to components.
  - Micro-labels in small uppercase monospaced type (e.g. `1 SUCTION`, `CONCRETE COUNTERWEIGHT`, `DOOR LOCK`, `FANS`).
- **Dynamic Physics & Particles:**
  - Particle streams showing invisible forces (air pressure dots, sound waves, water droplet simulations).
  - Directional force vectors (solid arrows showing force or air movement).
- **Physical Real-World Analogies:** Cut to a simple everyday object that illustrates the mechanism (e.g. comparing car suction to a phone suction mount).

---

## 4. Typography & On-Screen Text
- **Hook Title Card (0–3s):**
  - Category Badge: `HOW IT ACTUALLY WORKS` (Yellow, uppercase, tracked, ~24px).
  - Main Headline: Heavy bold sans-serif (`Tesla's Flying Car.`, `Washing machine.`, `Soap.`, ~80–90px, white).
  - Sub-Hook: Sentence case, medium weight, curiosity punchline (`It doesn't wash by spinning.`, ~36px, `#94A3B8`).
- **Subtitles / Captions (Throughout):**
  - Font: Clean Monospace or Neo-Grotesk (e.g., `JetBrains Mono` or `Roboto Mono`).
  - Density: 2–4 words per run, lower-middle third (`cy ≈ 0.72`).
  - Active Word Highlight: Solid rounded pill background (`#2563EB` blue or `#DC2626` red) with crisp white text.

---

## 5. Sound Design & Audio
- **Audio Texture:** Deep, atmospheric synth drone bed beneath VO.
- **Sound Accents (SFX):**
  - Low sub-bass hits on title reveals and major section transitions.
  - Crisp mechanical clicks / high-tech UI chirps when HUD labels and leader lines snap on.
  - Realistic foley: Motor hums, whooshes on camera rotations, water splashes, electrical buzzes.
