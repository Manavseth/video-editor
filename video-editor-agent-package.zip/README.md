# AI Video Editor Agent

An autonomous, code-driven AI Video Editor agent workspace. Builds, cuts, styles, and renders studio-quality short-form (9:16) and long-form (16:9) video explainers using code, CLI tools, and deterministic pipelines rather than manual NLE software.

---

## Architecture Overview

This repository is structured as a full agent workspace compatible with Antigravity, Claude Code, and OpenAI Codex:

- **Agent Personas & Directives:**
  - `VIDEO_EDITOR_AGENT.md`: Core agent manifesto, 10-stage production pipeline, and toolkit quick-reference.
  - `AGENTS.md` / `GEMINI.md`: Strict behavioral protocols, anti-revision traps, and production rules.
- **Skills Library (`.agents/skills/`):**
  - **Styles & Formats:** `hearing-clinic-reels`, `apple-motion-edit`, `2d-javascript-edit`, `visual-explainer-engine`, `anatomy-style-edit`, `split-screen`, `whiteout-edit`, `paper-drawer-edit`, `card-list-edit`, `layered-head-edit`, `broll-style-edit`, `longform-edit`, `vlog-edit`.
  - **Craft & Audio Pipelines:** `caption-align`, `cut-audit`, `sfx-design`, `shortform-cutaway`, `shortform-finish`, `take-geometry`, `render-ops`, `reel-review`.
  - **Asset Creation & Capture:** `design-asset`, `screen-capture`, `broll-select`, `genvideo`, `omni-restyle`, `mg-kit`, `prompt-motion`.
- **Engines & Tools:**
  - `video-hub/`: Local hub for videos written as code, live preview server, and review loop.
  - `remotion_ci_reel/`: Programmatic React/Remotion video rendering project.
  - `scripts/`: Audio splicing, Whisper alignment checks, and loudness normalization utilities.
  - `core/` & `tools/`: Core orchestration components.

---

## Getting Started

Read [SETUP.md](SETUP.md) for full environment prerequisites:
1. **FFmpeg**: Required for audio extraction, loudness measurement (-14 LUFS), and video encoding.
2. **Node 22+**: For HyperFrames and Remotion video engines.
3. **Python 3.11+ Virtual Environment**: For WhisperX forced alignment, DeepFilterNet, and audio processing.

---

## Documentation

- [SETUP.md](SETUP.md): Setup instructions for agents, environments, and API keys.
- [SKILLS_README.md](SKILLS_README.md): Detailed inventory and registry of all agent skills.
- [VIDEO_EDITOR_AGENT.md](VIDEO_EDITOR_AGENT.md): Detailed 10-stage editing pipeline specification.
