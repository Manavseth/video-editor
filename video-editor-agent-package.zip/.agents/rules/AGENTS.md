# Video edits — agent instructions

## Start every edit with the `hearing-clinic-reels` skill
Always use `hearing-clinic-reels` for clinic Reels and video projects unless specifically asked to use another skill. It enforces the pipeline and quality protocols below.

## Formats — pick ONE per job
split-screen · paper-drawer-edit · whiteout-edit · caption-edit · layered-head-edit · broll-style-edit ·
card-list-edit · vlog-edit · longform-edit · style-reverse-engineer (when matching an external creator) · anatomy-style-edit · 2d-javascript-edit (2D javascript) · apple-motion-edit (Apple Keynote Motion Design) · visual-explainer-engine (Deep Biological/Physical Explainer) · hearing-clinic-reels (Hearing Clinic & Audiology Reels)

## The pipeline (every edit, in this order)
| # | Stage | Skill |
|---|---|---|
| -1| Reference analysis (if matching a creator): measure, rule of 2, style card | `style-reverse-engineer` |
| 0 | Asset plan first: classify every visual, fact-check every claim, get my yes | `asset-plan` |
| 1 | Rough cut: WhisperX words, envelope-exact edges | `shortform-cutaway` |
| 2 | Cut audit: the transcript is not evidence | `cut-audit` |
| 3 | Take geometry: measure the face before placing anything | `take-geometry` |
| 4 | Capture + assets | `screen-capture` · `broll-select` · `design-asset` · `genvideo` · `omni-restyle` |
| 5 | Style | the format skill + `mg-kit` + `shortform-finish` |
| 6 | Captions | `caption-align` |
| 7 | Sound | `sfx-design` |
| 8 | Render + deliver (−14 LUFS measured on the encoded file) | `render-ops` |
| 9 | Review gate, never skipped: a different model reviews | `reel-review` |

## Hard rules
- Never touch original footage; always work on copies.
- If a tool or approach fails twice, stop, change approach, and state the pivot plainly.
- Never put text or graphics on my face, in any frame.
- Registers hard-cut. No opacity crossfades between them.
- **Zero-Fade Protocol (Hard Cuts Only):** Never apply any fade (neither audio fade nor visual crossfade/fade-to-black) at the end of a shot or at the conclusion of the video. Master audio terminates naturally on the final word release; all shot transitions and endings are hard cuts.
- Nothing animates across a cut.
- Screen recordings must be real and must move. Mocked recordings are banned (mocked terminals are fine).
- Real numbers only. Fact-check every claim against the live source.
- Cost-gate every generation: show the plan (model, prompts, durations), wait for a yes.
- Sound effects only, unless I ask for music.
- When I correct something, update the skill that should have prevented it.
- **Hearing Clinic Reels talking-head integration:** Pair host footage with procedural code-drawn scenes as alternating full-frame registers (no floating PiP boxes); continuous master voice under cutaways with preserved lip-sync; strict ≤4.0s shot cap for all shots; never put text, paper texture, or sound lines on the clinician's eyes, face, or hearing aid.
- **Visual Storyboards Default:** Whenever asked to create a storyboard or a scene of a storyboard, ALWAYS produce VISUAL scenes (interactive visual UI, rendered SVG/Canvas artboards, graphical frames), NEVER purely written/textual descriptions that duplicate markdown files.
- **Audio Splice Zero-Repetition Mandate:** Any hybrid master audio assembled from multiple takes must pass `scripts/audit_composite_audio.py` with 0 critical violations before video rendering begins. Splicing must occur at unambiguous word-level boundaries verified by Whisper forced-alignment, NOT phrase-level estimates.
- **Incomplete / Flawed Take Visual Prohibition:** Any clip where speech cuts off mid-sentence, contains verbal restarts, or has delivery stumbles (like Clip 4) is STRICTLY PROHIBITED from being placed on screen as video. Promote the scene immediately to 100% pure code-driven motion graphics.
- **Setting & Wardrobe Continuity Rule:** Never mix professional studio footage (collared shirt, sweater, studio microphone) with casual home/bedroom footage in the same video. Any casual home/bed footage is designated `SCRATCH / AUDIO_ONLY` by default.
- **Explainer Anatomical & Histological Depth Standard:** Medical, physiological, or biological explainers must never use single-line nerves or cartoon blob organs. Cranial Nerve VIII must be a multi-fiber fascicle (epineurium sheath, parallel myelinated axons, Nodes of Ranvier, saltatory pulses), and the brain must feature anatomical lobes, sulci, cerebellar folia, and tonotopic Primary Auditory Cortex (A1).
- **Clean Audio Tail Law & Zero Audio Fade:** The audio timeline must terminate strictly on the natural phonetic release of the final script word. Do not apply any artificial audio fade-out filter (`afade`) at the end of the shot or audio. Trailing conversational mutters, outtakes (e.g. "remove that part"), or sighs are prohibited from surviving into the master mix, but spoken words must never be faded out.
- **Audio-Only / Title-Slate Source Rule:** If a source video has no human subject (plain black background, static title card or slate, text showing reel name/topic throughout), treat it strictly as an audio file. Export reference clips strictly in audio formats (`clip1.wav`/`clip1.mp3`, `clip2.wav`/`clip2.mp3`), NEVER as video files (`.mp4`, `.mkv`). Only export video format reference clips when a real talking-head video is present in the source footage.
- **Permanent Visual Storytelling & Quality Control Protocol:** Across all procedural code scenes, visual explainers, and clinic reels:
  1. **Concept-to-Visual Port:** Every important spoken concept must have a corresponding visual representation in that scene (no concept survives solely in captions or voice).
  2. **Self-Explanatory Visuals:** Visuals must communicate their intended meaning without depending entirely on audio or captions (must pass the silent blind-viewer test).
  3. **Instant Asset Recognisability:** Assets must be immediately recognisable at phone scale with zero ambiguity (when code drawing cannot achieve first-glance recognition, use a user-approved real asset, such as the 🧠 emoji for the brain).
  4. **Explanatory Animation:** Animations must explain concepts (demonstrating cause, flow, repetition, or state change) rather than merely adding movement.
  5. **Mobile Text Readability:** Important text must remain comfortably readable on mobile screens (punchline/result pills ≥ 22 px; grow the container rather than shrinking font).
  6. **Refine Over Redesign:** Existing scenes should be refined rather than unnecessarily redesigned when the composition is already working.
  7. **Intentional Proportions & Axis Alignment:** Visual proportions, alignment, spacing, and positioning must be carefully balanced so every composition looks deliberate and polished. Enclosed assets must maintain balanced ~25–35% breathing margins without clipping or protruding past enclosing circles/containers; transit notches, connector lines, and traveling chips must share the exact same transit axis.
  8. **Moving Video Takes (Sequence Rigging Mandate):** Video clips must play as actual moving footage rather than accidentally appearing as static frames. In Remotion, always wrap `<OffthreadVideo>` inside an explicit `<Sequence from={...} durationInFrames={...}>` so the local frame resets to 0 and the video actively plays at full frame rate.
  9. **Professional Typography & Cohesive Identity:** Typography must maintain a professional, consistent visual identity throughout the video. Use unified Bento glass badges with high-contrast text, clear uppercase sub-labels, and safe margins clear of the face. Never use arbitrary pixel-offset sticker pills.
  10. **Clinical Accuracy for Audiology & Medical Data:** Terminology, anatomical illustrations, and audiological graphs must be technically accurate. Audiograms must feature canonical symbols (e.g. `<` for unmasked right bone conduction at ≤ 20 dB, `O` for unmasked right air conduction), continuous connecting lines, clear dB HL scales, and accurate caliper delta readouts for the Air-Bone Gap (≥ 15 dB indicating conductive impairment). Anatomical sites (outer/middle ear vs cochlea/auditory nerve) must reflect true physiological mechanisms.
  11. **Strict Minimalistic Consistency & Elimination of Unnecessary Animation:** Avoid unnecessary, exaggerated, decorative, or stylistically inconsistent animations (no pseudo-3D cartoon organs, looping token dots, or marching chevrons). Every visual element and animation must directly serve a conceptual purpose and strictly adhere to the calm, flat Minimalistic house style (paper `#F5F2EA`, ink `#20252B`, hairline cards, and teal accent).
  12. **Text Container Bounding Box Guarantee:** All text must remain comfortably contained within designated bounding boxes and pills with balanced margins (≥ 25–35 px padding). Never allow text strings to overflow or clip past container borders; clamp font sizes and widen containers appropriately.
  13. **Primary Master Audio Precedence & Automatic Clip Muting:** Whenever audio from a specific source file is designated as the primary audio track, all individual video takes placed on the timeline must be automatically and completely muted (`muted={true}` in code and `-an` audio-stripped on video clip files). No secondary camera audio, background hiss, or clip dialogue may ever bleed, overlap, or interfere with the primary master voice.
  14. **Direct One-Click File Accessibility Guarantee:** Whenever presenting, delivering, or referencing any file, audio take, reference clip, video render, storyboard, or folder to the creator, ALWAYS format every item as an immediate, clickable markdown link using the `file:///` URI scheme with forward slashes (e.g. `[clip1.wav](file:///C:/Users/Lenovo/Desktop/reels/audiogram_part4_reference_clips/clip1.wav)`, `[Open Directory](file:///C:/Users/Lenovo/Desktop/reels/audiogram_part4_reference_clips)`). Never output bare text paths. The creator must always be able to click and access/play every delivered file right there and then.

---

## Anti-Revision & Precision Execution Rules (The Traps Protocol)
Enforce these guards across every shot, cut, audio pass, and render to eliminate avoidable revisions:

### 1. Sound & Speech Intelligibility
- **The Pause-Hit Rule:** Never place an illustrative SFX hit directly on top of the spoken keyword it illustrates. Land the hit in the natural breath or pause immediately after the word.
- **Bed Ducking:** Background beds, drones, or risers under technical explanations, facts, and hooks must duck strictly to `0.10–0.15` volume.
- **Transient Cutoff (`until` cues):** Short UI sounds or alert beeps must feature an explicit cutoff/`until` cue at the next shot cut; decay tails must never bleed across cuts into the next sentence.
- **Stem Normalization Awareness:** Stem-level loudness normalization shifts the whole stem; reducing one loud transient raises background noise. Balance relative levels before mastering.
- **Fricative-Tail Distinction:** In cut/sync audits, do not confuse harmless vocal decay tails ("s", "t", "ch") with actual speech masking collisions.

### 2. Framing, Hierarchy & Safe Margins
- **Focal Luminance Isolation:** Props, cards, mockups, and UI backgrounds must sit at least one shade darker than the primary subject/face. Nothing bright competes with the face.
- **Contrast Guarantee:** Dark graphic elements on dark/navy sets disappear; require bright outlines, light fills, or rim lighting.
- **Auto-Clamp Long Titles:** Any text hook or title over ~20 characters must auto-clamp font size (e.g., 88–100px) to guarantee safety from Instagram UI chevrons and buttons.
- **Zoom Counter-Scaling:** Reticles, callout rings, stamps, and pointers must counter-scale with camera zoom (`scale(1 / zoom)`) to avoid ballooning at punch-ins.
- **Substantial Foreground Framing:** Over-the-shoulder framing elements must occupy ~1/3 of the frame (dark and blurred `blur16`); tiny slivers read as accidental render bugs.

### 3. Cut Discipline & Continuity
- **Never Cut to an Empty Frame:** Baseline containers, sets, or backgrounds must be visible at frame `0` (e.g. trigger pops at `t + 3`, never empty `t - 1`). No delayed pop-ins that leave dead frames.
- **Insert Directionality:** In close-up cutaways (hands, screens, props), entering elements must come from the screen edge matching the subject's position in preceding shots.
- **Diegetic State Continuity:** Visual elements implying progression (calendar crosses, step counters, progress bars, clocks) must explicitly lock their state to the script beat (`crossed={0}` on beat 1).

### 4. Motion Graphics & Remotion Rigging
- **Pure Functional Clock (`t`):** Never use `Math.random()`, unseeded noise, or React state in animation frames. Derive all coordinates and motion from shot clock `t` using seeded noise `rnd(seed, i)` for frame-exact scrubbing.
- **Screen-Bounded Filter Units:** Global SVG/CSS filters across scenes must specify `filterUnits="userSpaceOnUse"` over the full canvas (`0 0 1080 1920`) to prevent off-canvas vector clipping.
- **Preserve True Black:** Do not apply black-lifting color matrix grades to letterboxes or outer viewport containers; keep `#000000` borders outside graded groups.
- **Unique SVG IDs:** Scope all procedural gradient, mask, and clip-path IDs (e.g. `id="sh4_grad"`) to prevent cross-shot bleeding.

### 5. Pre-Flight Render Operations
- **Stills-First Verification:** Always render and review 3 still frames (Hook, Mid-peak action, End CTA) in ~2s before launching a full 2+ minute video render.
- **Asset Pre-Flight Gate:** Run pre-flight scripts (`plan.py`) to assert all referenced audio clips, B-roll files, and fonts exist on disk before rendering.
- **Offline Local Typography:** Bundle font files locally (`.woff2` / `.ttf`) in workspace config; never fetch Google Fonts live at render time.

### 6. Multi-Take Hybrid Alignment & Anti-Repetition Quality Protocol (The Zero-Mistake Standards)
- **Word-Level Boundary Splicing:** Splicing two takes together requires finding exact phonetic boundaries with forced alignment. If Take A ends with phrase X and Take B also begins with phrase X, Take A must be cut before phrase X or Take B must start after phrase X. Never crossfade two takes that share identical spoken words.
- **The Whisper N-Gram Pre-Flight Gate:** Run `python scripts/audit_composite_audio.py <audio_or_video> --end-word <final_word>` before every render. The script asserts:
  $$\text{Word}_i == \text{Word}_{i+1} \text{ within } \Delta t < 2.5\text{s} \implies \text{CRITICAL BUILD ABORT}$$
  Any detected duplicate consecutive words, stutter loops, or trailing conversational mutters abort the build immediately.
- **Visual Footage Quality Gate:**
  - Audit every talking-head clip against the Wardrobe & Setting Matrix:
    - `STUDIO_A_ROLL`: Professional lighting, backdrop, formal wardrobe, studio microphone -> Approved for on-screen host registers.
    - `CASUAL_OR_BED_SCRATCH`: Casual loungewear, bed, informal handheld angle -> Classified as `SCRATCH / AUDIO_ONLY`. Never draw on canvas.
    - `INCOMPLETE_OR_FUMBLED_TAKE`: Clip cuts off before phrase completion or contains false starts -> Classified as `DISCARD_VIDEO`. Promote scene to 100% Motion Graphics & Motion Design.
- **Medical & Scientific Asset Fidelity Standards:**
  - When illustrating biological systems:
    - **Nerves (Cranial / Peripheral):** Multi-fiber fascicles with epineurium sheaths, parallel axon bundles, Schwann cell myelin sheaths, Nodes of Ranvier, and saltatory action potentials. Never draw a single stick line.
    - **Brain / Cerebrum:** True lateral or coronal anatomical profiles with defined lobes (frontal, parietal, occipital, temporal), deep sulci (Sylvian fissure, central sulcus), cerebellar folia, brainstem, and tonotopic cortical activation. Never draw generic cartoon blobs.
    - **Receptors / Cells:** Histologically grounded cutaways (e.g., Organ of Corti hair cells with stepped V-shaped stereocilia bundles, tip links, and basilar membrane).
- **Phonetic Tail Truncation & Zero-Fade Mandate:**
  - Master audio must end naturally on the phonetic release of the final script word without applying any fade-out filter (`afade`). Never apply an audio or video fade at the end of the shot. Never leave trailing audio unmuted where conversational instructions ("remove that part"), sighs, or microphone rustle could be audible, but never truncate or fade out speech.

---

## Mandatory 5-Step Reel Production Protocol (Raw Analysis → Clips → Re-recording Gate → Final Edit)
Apply this exact 5-step sequence to every Instagram Reel / short-form project:

### Step 1: Analyze My Complete Talking-Head Video / Source Take
- Review the complete raw take, even though takes may be unpolished or rough.
- Analyze delivery, dialogue, expressions, clarity, and overall flow.
- **Audio-Only / Slate Source Check:** If the source has no human subject (plain black screen, static title card or slate, text with reel name/topic throughout), treat it strictly as an audio file.
- Identify the strongest sections that work best for the final Instagram Reel:
  - **Short-Video Rule (<50s):** If the input take is shorter than 50 seconds, select strictly **TWO clips** (never 3 or 4), and ensure each clip is **≤ 6.0 seconds (hard cap, never exceeding 6.00s)** in duration. Position them at balanced, spaced intervals within the video body (avoiding the very beginning or end, which are reserved for code-drawn visual hooks and concluding curiosity/branding cards).
  - **Clickable File Access Rule (Universal Mandatory):** Whenever referencing, listing, or delivering ANY files (audio clips, videos, manifests, storyboards, reports), NEVER output plain-text file paths. ALWAYS provide direct, clickable Markdown file links using the `file:///` URI scheme with forward slashes (e.g. `[clip1.wav](file:///C:/path/to/clip1.wav)`) so the user can immediately click to open, play, inspect, or copy the file directly from the interface.
  - **Longer Video (>50s):** Select 3–4 sections capped at purposeful beat lengths.

### Step 2: Select and Share the Exact Clips
- Export the selected sections from the original file as separate files in chronological order:
  - **For Audio-Only / Title-Slate Sources:** Export strictly in **audio format** (`clip1.wav`/`clip1.mp3`, `clip2.wav`/`clip2.mp3`), NEVER as video.
  - **For Real Talking-Head Sources:** Export in **video format** (`clip1.mp4`, `clip2.mp4` for <50s takes; `clip1.mp4`–`clip4.mp4` for longer takes).
- Share these exact clips with the creator along with their exact timestamps from the original video as reference guides for professional re-recordings.

### Step 3: Creator Re-recording Gate (STRICT STOP GATE)
- **DO NOT edit or build the complete Reel before the creator provides the professional recordings.**
- Wait for the creator to record professional versions of the selected clips using the same dialogue, message, and context (`clip1.mp4`, `clip2.mp4`).

### Step 4: Create the Instagram Reel
- Once the professional recordings are delivered, use them to build the complete Reel.
- Combine the clips in sequence and enhance with:
  - Motion design and motion graphics.
  - Dynamic transitions and visual effects where appropriate.
  - Animated text, captions, and key-message highlights.
  - Background music and sound effects where needed.
  - Appropriate pacing, cuts, and visual storytelling (design supports the message without distracting).

### Step 5: Deliver the Complete Package
Deliver:
1. Complete, final Instagram Reel ready to publish (at −14 LUFS).
2. The 3–4 reference clips selected from the original video (`clip1.mp4` – `clip4.mp4`).
3. The final professional clips used in the Reel, saved separately.
4. The editable project file / source engine.
