---
name: visual-explainer-engine
description: "The Deep Visual Explainer (Medical, Biological, Physical & Engineering Explainer) format: An autonomous system to turn a voiceover script and context into a broadcast-ready, code-driven animated video ($0.00 cost, 1080x1920 9:16 vertical, -14.0 LUFS EBU R128). Built on the Canonical 8-Beat Narrative Arc (Everyday Hook -> Quantitative Scope -> Structural Protagonist -> Environmental Threat -> Biomechanical Defense -> Control Circuit -> Physical Actuator -> Empirical Proof) with deep obsidian studio aesthetics, zone-budgeted layouts, damped harmonic spring physics, and continuous organic micro-motion."
---

# VISUAL EXPLAINER ENGINE — Deep Biological, Physical & Technical Motion Design

> **THE ESSENCE:** An autonomous production system that turns any educational, medical, physical, or technical script into a **finished, broadcast-ready MP4** at **$0.00 cost** (zero paid generative tokens, zero frame-sampling). Every single frame is drawn procedurally via HTML5 Canvas 2D math, rendered frame-by-frame through headless Chromium/Edge into FFmpeg `image2pipe`, and mastered to **−14.0 LUFS** EBU R128 audio.

---

## 1 · The Canonical 8-Beat Narrative Arc (How the Story Progresses)

Every high-engagement visual explainer follows this universal 8-beat progression:

| Beat | Narrative & Dramatic Function | Visual Scene Type & Camera Staging | Motion Design Grammar |
|---|---|---|---|
| **1. The Everyday Hook** | Ground viewer in an immediate relatable observation or mystery ("Why do eyes roll up when you sleep?"). | **Macro Recognizable Actor**: Human face, eyes, heart, or phone. Organic entrance. | Gentle cosine eyelid closure (+38.5° upward roll), slow breathing drift. |
| **2. Quantitative Scope** | Establish universal scale, prevalence, or statistical significance ("Happens in 90% of people"). | **Demographic / Metric Ring**: 100 biological micro-nodes in concentric circle. | Kinetic counter increment ($0\% \to 90\%$), illuminated node sequencing, glowing gold typography. |
| **3. Structural Protagonist** | Introduce and isolate the delicate asset/organ that requires defense or study ("The cornea: clear front surface"). | **Technical Optical Cross-Section**: Sagittal or coronal slice, $0.54\text{ mm}$ dimension callout. | Refraction light path, avascular highlight, specular light sweep, leader-line callout. |
| **4. Environmental Threat** | Introduce the physics failure mode or environmental threat ("Tears drop, eyelids don't seal completely"). | **Micro-Gap / Hazard Vectors**: Nocturnal lagophthalmos cross-section with $\sim 2.0\text{ mm}$ gap. | Aerodynamic desiccating air streamlines, red pulsing danger aura, evaporative particles. |
| **5. Biomechanical Defense** | Reveal the elegant natural mechanism that neutralizes the threat ("Rolling up tucks cornea under upper lid"). | **Kinematic Transformation & Safe Harbor**: Seamless continuation of Beat 4. | Upward elevation (+38°) tucking cornea into moist fornix pocket; tough sclera buffer shields gap. |
| **6. The Control Circuit** | Demystify the central intelligence / reflex arc driving the motion ("Brainstem circuit links lid and eye nerves"). | **Cranial Silhouette & Synaptic Arc**: Lateral skull profile, illuminated brainstem core (Pons). | Dual divergent pathways (CN VII in gold, CN III in cyan) with traveling white-hot action-potential packets. |
| **7. The Physical Actuator** | Expose the motor hardware executing the movement ("...to the nerve that lifts the eyes"). | **Orbital Muscle Engine**: Coronal orbit with extraocular muscles strictly on lateral sides. | Striated red fascicles, kinetic contraction waves bunching the muscle belly, silvery tendon insertions. |
| **8. The Empirical Proof** | Provide direct real-world verification or clinical test proof ("Often only the whites of eyes are visible"). | **Clinical Diagnostic Reticle**: Clean bedside examination with gentle lid retraction indicators. | Reticle focus, 100% glistening white sclera exposed, iris hidden above, diagnostic status badge. |

---

## 2 · Motion Design Grammar & Aesthetic Standards

### 1. The Obsidian Studio Atmosphere
- **Base Canvas**: Deep obsidian `#06080d` with a subtle radial gradient centered at the visual stage (`#0c1424` at center $\to$ transparent at $r = 820\text{px}$).
- **Ambient Bokeh Motes**: Exactly 45 pre-seeded deterministic floating particles drifting slowly vertically and horizontally (`speedY = 0.12 - 0.40`, `alpha = 0.06 - 0.18`), ensuring the frame never looks sterile or frozen.
- **Specular Glow Passes**: High-intensity highlights use `ctx.shadowColor` and `ctx.shadowBlur` (always immediately followed by `ctx.shadowBlur = 0` to preserve crisp rendering).

### 2. Standard 9:16 Zone Budgeting (1080 × 1920)
```
┌────────────────────────────────────────────────────────────────────────┐
│ y = 0..6       : 5px Continuous Global Progress Bar (Neon Emerald)     │
│ y = 50..85     : Category Breadcrumb HUD (Cyan) & Chapter Tag (Muted)  │
│ y = 135..220   : Hero Bold Headline & Color-Coded Subtitle             │
│                                                                        │
│ y = 380..1380  : HERO VISUAL STAGE (Center 60% Negative Space)         │
│                  - Center Anchor: (x = 540, y = 880)                   │
│                  - Hero Anatomical Actor / Dynamic Model               │
│                  - Streamlines / Action-Potential Waves / Muscle Belly │
│                                                                        │
│ y = 1420..1540 : Obsidian Frosted Glass Telemetry HUD Card            │
│                  - Live Breathing LED Status Indicator                 │
│                  - Monospace Badge & 2-Line Technical Description      │
│                                                                        │
│ y = 1620..1680 : Floating Borderless Dual-Tone Subtitles               │
│                  - Centered White Typography + Cyan/Amber Keyword Glow │
│                                                                        │
│ y = 1750..1920 : Instagram / TikTok Platform Safe Margin (Zero UI)    │
└────────────────────────────────────────────────────────────────────────┘
```

### 3. Strict Semantic Color Palette
- **Cyan (`#00f0ff`)**: Hero delicate asset, cornea, optical window, CN III pathway, keyword highlight.
- **Radiant Gold / Amber (`#fbbf24`)**: Neural reflex core, CN VII pathway, demographic percentage, electrical impulse.
- **Warning Coral (`#ff4466`)**: Desiccation risk, nocturnal lagophthalmos gap, shear stress, threat vectors.
- **Emerald (`#10b981`)**: Optimal tolerance, safe harbor, progress bar, clinical confirmation badge.
- **Pearlescent White (`#f1f5f9` / `#ffffff`)**: Sclera, action-potential spark packets, bone structures, primary headlines.
- **Obsidian Glass (`rgba(8, 14, 24, 0.85)`)**: Telemetry cards with `rgba(56, 189, 248, 0.28)` specular borders.

### 4. Anatomical & Histological Fidelity Standards (Zero-Juvenile Graphics)
Whenever depicting human or animal physiological systems:
- **Nerves & Axon Pathways:** NEVER draw a single stick line. Nerves must be multi-fiber fascicle cables with epineurium sheaths, parallel axon bundles, Schwann cell myelin sheaths, Nodes of Ranvier, and saltatory action potential sparks.
- **Brain & Central Nervous System:** NEVER draw cartoonish two-lobed outlines or simplified blobs. Brain models must be true lateral or coronal anatomical profiles with defined lobes (frontal, parietal, occipital, temporal), deep sulci (Sylvian fissure, central sulcus), cerebellar folia, brainstem (pons, medulla), and active cortical localization maps (e.g. Primary Auditory Cortex A1).
- **Sensory Receptors & Cells:** Depict real histological structure (e.g. cuticular plate, stepped stereocilia bundles with tip-links, basilar membrane anchoring). Avoid generic geometric blocks.
- **Audio Verification Gate:** Every visual explainer must pass `python scripts/audit_composite_audio.py <audio_or_video> --end-word <final_word>` with 0 errors before rendering.

---

## 3 · Camera Transitions & Morphological Continuity

1. **The Morphological Persistence Rule**:
   Never jump-cut between related anatomical views. If Scene 4 introduces the nocturnal lagophthalmos sagittal cross-section, Scene 5 **must** maintain the identical cross-section geometry and smoothly rotate the globe upward into the fornix.
2. **The Neural Hand-off**:
   When transitioning from control circuits (Scene 6) to physical actuators (Scene 7), an action potential packet exiting the brainstem terminal hands off directly into the synaptic endplate of the muscle.
3. **Sub-Stepped Harmonic Physics**:
   All movements use damped harmonic spring physics (`springVal(t, t0, dur, stiffness = 220, damping = 24)`). Linear robotic transitions are strictly forbidden.

---

## 4 · Engine Tooling & CLI Reference

The reusable engine lives in `core/visual_explainer_engine/`:

| File | Purpose |
|---|---|
| `canvas_toolkit.js` | Reusable Canvas 2D motion design library (math, zone renderers, vector actors). |
| `story_architect.js` | Analyzes scripts and maps narrative beats into the 8-phase canonical storyboard. |
| `scene_compiler.js` | Compiles a `storyboard.json` into a production-ready `scene.js`. |
| `render_runner.mjs` | Headless Chromium harness + FFmpeg image2pipe streaming + −14.0 LUFS audio master. |
| `cli.mjs` | Command-line interface for autonomous execution. |

### CLI Usage Commands
```bash
# 1. Generate 8-Beat Storyboard from Script
node core/visual_explainer_engine/cli.mjs storyboard --topic "Bell's Phenomenon" --script "script.txt" --duration 41.7 --out storyboard.json

# 2. Compile Storyboard to Canvas Engine
node core/visual_explainer_engine/cli.mjs compile --storyboard storyboard.json --out work/scene.js

# 3. Headless Render & Master Delivery
node core/visual_explainer_engine/cli.mjs render --workdir work/explainer_render --audio audio_master.wav --frames 1251 --out out/
```

---

## 5 · Review Gate & Quality Standards

### MANDATORY RULE: Always Create a Visual Storyboard
**Every asset plan and storyboard MUST include a Visual Storyboard (a 4×2 contact sheet + high-res per-scene stills) before moving to final render.**
Text descriptions alone are not evidence of visual composition. The creator must be able to visually inspect:
1. Composition, framing, and zone budgeting.
2. Anatomical accuracy and histological detail.
3. Typography hierarchy, telemetry HUD cards, and floating subtitle legibility.
4. Color semiotics and contrast.

Before delivering any video created with this system:
1. **$0.00 Cost Verification**: Prove 100% of frames are procedurally drawn with JavaScript. Zero third-party generative tokens.
2. **Audio Loudness**: Verify integrated loudness is strictly **−14.0 LUFS** ($\pm 0.5\text{ LUFS}$) with maximum true peak **−1.5 dBTP**.
3. **Contact Sheet Extraction**: Generate a 4×2 contact sheet (`master_scenes_contact_sheet.jpg`) showing all 8 beats and inspect for:
   - Zero text collisions.
   - 100% text inside the safe zone ($y \le 1720$).
   - Legible, dual-tone floating subtitles.
   - Smooth anatomical and camera continuity between beats.
