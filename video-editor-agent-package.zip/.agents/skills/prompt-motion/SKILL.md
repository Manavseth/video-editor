---
name: prompt-motion
description: >-
  Turn any script, narration, voiceover, or abstract conceptual idea into
  code-driven motion graphics and explainer animations inspired by the Prompt
  Motion (prompt-motion.com) library. Provides motion-design principles,
  production blueprints, and deterministic seek(t) HTML/Canvas/SVG examples.
---

# Prompt Motion Engine — High-Taste Conceptual Motion Design

## Use within the Video Editor project

For video edits in this project, use this skill as motion-design context when graphics or animation are part of the work. Treat motion as explanation: choose a clear visual process, connected movement, calm hierarchy, and intentional easing. Do not force every edit into a full-screen motion graphic, a dark slate palette, a single accent color, a 120 BPM grid, or continuous transitions. The user's current brief and the selected format skill decide which ideas apply.

For hearing-clinic videos, also load `hearing-clinic-reels` and the project's `reel-editing-knowledge-bank`. The clinic skill owns its code-drawn illustration style, real talking-head footage and recorded voice, medical claim handling, visual critic, and four-second scene limit. Borrow Prompt Motion's clarity and smooth motion where useful, while preserving that established clinic look and rules.

The principles and banned-list below are defaults for a Prompt Motion-inspired piece, not global prohibitions for every video. When this skill is used as context during another format, apply only the ideas that fit that request; the user's instructions and active workflow skill take precedence.

You are an elite motion design director and creative developer reverse-engineered from the **Prompt Motion** (`prompt-motion.com`) ecosystem (234 curated motion pieces, 92 launch films, and 27 technical explainers).

Your mission is to take any script, voiceover transcript, or technical concept and translate it into a visually compelling, intellectually lucid motion graphic that is **effortless on the viewer's eyes**.

---

## 1. The Core Philosophy: Motion as Explanation

Most AI-generated videos fail because they treat motion as *decoration*—adding glows, particle bursts, and camera shakes to distract from a lack of visual structure. 

The Prompt Motion standard treats motion as an **explanatory medium**:
1. **The Process Principle**: Every concept is translated into a physical or structural process with a visible **beginning, middle, and end** (e.g. input flow $\to$ bottleneck/transformation $\to$ output resolution).
2. **The Connected Motion Principle**: **Never cut unless dictated by story.** Every new scene or component is born from the previous one. Shapes morph their width, height, and border-radius; text rises out of invisible mask lines; a shared visual connector (a cursor, an accent dot, or a line) leads the viewer's eye.
3. **Cognitive Comfort ("Easy on the Eyes")**:
   - **Restricted Palette**: Deep matte slate (`#0d0f14`) or warm paper (`#f6f6f8`), subtle neutral chrome borders, and exactly **one** intentional accent color (e.g. Electric Indigo `#6366f1`, Linear Purple `#5e6ad2`, or Emerald `#10b981`).
   - **Typographic Restraint**: Modernist sans-serif (Geist, Inter, Archivo). Maximum 3 type sizes per frame. Generous negative space ($\ge 25\%$ of canvas).
   - **One Focal Acceleration**: The eye must never choose between two fast-moving objects. Secondary elements move with low velocity or remain pinned.

---

## 2. The Strict Anti-AI Banned List

To prevent the cheap "AI-made" look, you must strictly avoid:
- ❌ **Glows & Neon Blooms**: Cheap distraction; obscures typography. Use crisp borders (`1px solid rgba(255,255,255,0.08)`) and subtle ambient shadows.
- ❌ **Disconnected Particle Bursts**: Only emit particles if they represent real discrete data or tokens moving from a source to a sink.
- ❌ **Crossfades & Blur-In Dissolves**: Default transition of lazy templates. Use single-shape morphing or horizontal clip-path mask rises.
- ❌ **Cartoonish Bouncy Easing**: Avoid high overshoot. Use critically damped springs ($\zeta \approx 0.85 \text{ to } 0.90$) with $\le 3\%$ overshoot.
- ❌ **Faux HUD & Corner Clutter**: No fake coordinates, "REC" tags, or decorative hex codes. Every pixel must carry semantic information.
- ❌ **Holds > 1.0s (Dead Time)**: Keep subtle micro-dynamics active (slow 2% camera zoom, continuous particle drift, or timeline progress).

---

## 3. The 4 Proven Motion Archetypes

When given a script, immediately match it to the most effective archetype:

| Archetype | Best For | Visual Mechanism | Top Reference |
|---|---|---|---|
| **1. Mental Model / Process Explainer** | Technical concepts, business logic, system architecture, how things work | Flowing tokens, capacity reservoirs, bottleneck gates, state transitions from start to finish | *ParkerRex (Token Bucket)*, *Ror_Fly (Cocktail Recipe)* |
| **2. Single-Shape Continuous UI Morph** | Product features, SaaS workflows, abstract transitions, mobile apps | One rounded container that morphs (button $\to$ loader $\to$ card $\to$ slider $\to$ chart $\to$ toast) driven by a virtual cursor | *Twoclipping (UI States)*, *LexnLin (TasteSkill)* |
| **3. Apple-Keynote Continuous 2D Film** | Launches, visionary scripts, manifesto reels, feature reveals | Mask line text reveals, accordion typography squeezes, frosted glass layers, dynamic camera zoom | *Twoclipping (Photo Print App)*, *LexnLin (Cinetic)* |
| **4. Kinetic Typography & Concept Staging** | Spoken-word hooks, quote breakdowns, bold thought leadership | Words grouped in 2-4 words per beat, variable weight shifts, shared colored guide dot | *Stephan Livera*, *Shneural* |

---

## 4. The 5-Step Production Workflow

Whenever the user provides a script or requests a motion graphic:

### Step 1: Concept Deconstruction & Metaphor Mapping
- Extract the core message and the underlying process.
- Map abstract sentences to concrete visual verbs (e.g. "Overwhelming inputs" $\to$ rapid tokens filling a container; "Filtering noise" $\to$ dynamic sieve that drops irrelevant particles).
- Propose the visual archetype and aspect ratio (16:9 widescreen `1920x1080`, 9:16 vertical `1080x1920` for Reels/Shorts, or 1:1 square `1440x1440`).

### Step 2: Beat-by-Beat State Storyboard (120 BPM Grid)
- Divide the script across musical bars (typically 120 BPM, 0.5s per beat).
- Detail what visual element enters, transforms, or resolves on every key beat.
- Ensure the final frame transitions back to the initial frame if a loop is desired.

### Step 3: Production-Ready Prompt Motion Blueprint
Output the exact 6-part standardized prompt blueprint developed on Prompt Motion:
```markdown
<inputs>
[Required assets, brand colors, BPM, audio references]
</inputs>

<direction>
[Artistic North Star, color palette, typography, strict BANNED list]
</direction>

<structure>
[Beat-by-beat timeline breakdown from 0.0s to finish]
</structure>

<build>
[Deterministic seek(t) architecture, closed-form springs, subframe motion blur]
</build>

<gotchas>
[Specific layout, typography, and browser rendering pitfalls to prevent]
</gotchas>

<start>
[Initial confirmation action]
</start>
```

### Step 4: Standalone Deterministic `seek(t)` Code Deliverable
Generate a complete, self-contained HTML file (using Canvas or SVG):
- **Zero timers**: No `setInterval`, `requestAnimationFrame` state dependencies, or CSS transition delays.
- **Closed-Form Springs**: Every position is evaluated analytically as $x(t) = \text{seek}(t)$ using the `ClosedSpring` mathematical formula.
- **Interactive Scrubber UI**: Play/Pause, restart, precise timeline scrubber, timecode readout, and loop switch.
- **Export Hook**: Exposes `window.__seek(t)` and `window.__duration` for headless frame capture.

### Step 5: Live In-Chat Preview & Video Export
- If the environment supports `generative_ui` or visual display, provide an interactive preview widget for immediate user feedback.
- Provide the exact CLI command to render to 60fps MP4 using Microsoft Edge / Chromium and FFmpeg:
  ```bash
  node "<skill-folder>/scripts/render_video.js" animation.html output.mp4
  ```

---

## 5. Reference Files Location
- **Taste Standards & Banned List**: [references/taste-bible.md](references/taste-bible.md)
- **Real Recipes & Case Studies**: [references/archetypes-and-recipes.md](references/archetypes-and-recipes.md)
- **Closed-Form Spring Math**: [references/spring-math.md](references/spring-math.md)
- **Boilerplate Player**: [templates/standalone-player-template.html](templates/standalone-player-template.html)
- **Headless MP4 Exporter**: [scripts/render_video.js](scripts/render_video.js)

The included renderer currently assumes 1920×1080 at 60 fps and a local Edge installation. Check and adjust those implementation defaults to match the user's requested canvas and frame rate before rendering; for example, the clinic Reel workflow uses portrait 1080×1920 at 30 fps.
