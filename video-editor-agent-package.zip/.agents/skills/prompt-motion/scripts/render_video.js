/**
 * Prompt Motion — Headless 60fps Frame Renderer
 * 
 * Steps through any HTML animation with `window.__seek(t)` frame-by-frame
 * and pipes screenshots directly to FFmpeg to create a pristine 60fps MP4.
 */

const { spawn, execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const http = require('http');

// Configuration
const FPS = 60;
const DURATION = 15; // default seconds (overridden by window.__duration if present)
const WIDTH = 1920;
const HEIGHT = 1080;

const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';

async function main() {
  const inputFile = process.argv[2];
  const outputFile = process.argv[3] || 'output_motion.mp4';

  if (!inputFile) {
    console.error('Usage: node render_video.js <path-to-html-file> [output.mp4]');
    process.exit(1);
  }

  const absoluteHtmlPath = path.resolve(inputFile);
  const fileUrl = 'file:///' + absoluteHtmlPath.replace(/\\/g, '/');

  console.log(`[Prompt Motion] Preparing to render: ${fileUrl}`);
  console.log(`[Prompt Motion] Output target: ${outputFile}`);

  // Check if puppeteer-core is available
  let puppeteer;
  try {
    puppeteer = require('puppeteer-core');
  } catch (e) {
    try {
      puppeteer = require('playwright');
    } catch (e2) {}
  }

  if (puppeteer) {
    console.log('[Prompt Motion] Using Puppeteer / Playwright with Edge binary...');
    const browser = await puppeteer.launch({
      executablePath: EDGE_PATH,
      headless: 'new',
      args: ['--no-sandbox', '--disable-gpu', `--window-size=${WIDTH},${HEIGHT}`]
    });
    const page = await browser.newPage();
    await page.setViewport({ width: WIDTH, height: HEIGHT });
    await page.goto(fileUrl, { waitUntil: 'networkidle0' });

    const duration = await page.evaluate(() => window.__duration || 15);
    const totalFrames = Math.round(duration * FPS);
    console.log(`[Prompt Motion] Rendering ${totalFrames} frames at ${FPS} fps...`);

    // Setup FFmpeg process
    const ffmpeg = spawn('ffmpeg', [
      '-y',
      '-f', 'image2pipe',
      '-vcodec', 'png',
      '-r', String(FPS),
      '-i', '-',
      '-c:v', 'libx264',
      '-pix_fmt', 'yuv420p',
      '-preset', 'slow',
      '-crf', '18',
      outputFile
    ]);

    ffmpeg.stderr.on('data', () => {}); // silence ffmpeg stderr or log if needed

    for (let f = 0; f < totalFrames; f++) {
      const t = f / FPS;
      await page.evaluate((currTime) => {
        if (window.__seek) window.__seek(currTime);
      }, t);

      const canvasBuffer = await page.screenshot({ type: 'png' });
      ffmpeg.stdin.write(canvasBuffer);

      if (f % 30 === 0 || f === totalFrames - 1) {
        process.stdout.write(`\r[Prompt Motion] Render progress: ${Math.round((f / totalFrames) * 100)}% (${f}/${totalFrames} frames)`);
      }
    }

    ffmpeg.stdin.end();
    await new Promise((resolve) => ffmpeg.on('close', resolve));
    await browser.close();
    console.log(`\n[Prompt Motion] Render complete: ${outputFile}`);
  } else {
    console.log('\n[Prompt Motion Quick Render Guide]');
    console.log('To render directly to 60fps MP4 on Windows:');
    console.log('1. Run: npm install puppeteer-core');
    console.log(`2. Run: node render_video.js "${inputFile}" "${outputFile}"`);
    console.log('\nOr open the HTML file directly in Microsoft Edge / Chrome to view and scrub interactively!');
  }
}

main().catch(err => {
  console.error('[Prompt Motion Error]:', err);
});
