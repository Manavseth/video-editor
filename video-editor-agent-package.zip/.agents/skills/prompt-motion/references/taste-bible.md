# Taste Bible — The Anti-AI Motion Design Standard

*Derived from the analysis of 234 motion graphics pieces, 92 launch films, 27 explainers, and creator post-mortems on prompt-motion.com.*

---

## 1. Why AI Motion Graphics Look "AI-Made"

When AI models (like Claude, GPT-4, or video generators) are asked to create motion graphics without strict guardrails, they default to superficial decoration rather than structural communication. In the Prompt Motion database, top creators (such as `@twoclipping`, `@LexnLin`, `@ParkerRex`, `@notdwd`, `@Ror_Fly`) explicitly ban these giveaways.

### The Banned List & Why Each Item Destroys Credibility

| Banned Element | Why AI Defaults to It | Why It Reads as "AI-Made" | The Professional Replacement |
|---|---|---|---|
| **Glows, neon halos, bloom** | Easy way to add brightness and fake depth | Blurs edges, feels like a 2010 sci-fi template, obscures content | Crisp monochromatic borders (`border: 1px solid rgba(255,255,255,0.08)`), subtle ambient occlusion shadows |
| **Random particle bursts & shockwaves** | Fills empty space when nothing else is happening | Disconnected from logic; bursts appear from nowhere and lead nowhere | **Connected Motion**: Every particle or accent must originate from an interaction (e.g. cursor click, slider threshold) and travel to a logical destination |
| **Crossfades & blur-in dissolves** | Default transition when the author didn't design one | Destroys rhythm; looks like PowerPoint slides; leaves a cognitive gap | **Morphing & Mask Rises**: The same geometric container morphs its bounds and border-radius, or text rises out of an invisible clip-path mask |
| **Bouncy / cartoonish easing** | Overly aggressive spring overshoots | Feels gimmicky, unstable, and childlike | **Critically Damped Springs**: Springs with damping ratio $\zeta \ge 0.85$ (tiny overshoot at most $\le 3\%$) or smooth cubic-bezier step responses |
| **Corner HUD text & faux data** | Faux technical clutter ("REC", coordinates, hex numbers) | Pure noise that conveys zero value; classic sci-fi trope | Generous negative space, focal clarity; only display information the viewer needs to read |
| **Dead time / Holds > 1.0s** | Lack of structural pacing | Kills momentum, bores the viewer, causes drop-off | Micro-dynamics: slow camera creep (2% zoom), subtle coordinate parallax, or continuous beat-synced progression |
| **Cheesy rainbow gradients** | Vibrant filler | Clashes with modern product design aesthetics | Strict monochromatic base (warm charcoal `#0e0f12` or paper `#f5f5f7`) + **single intentional accent color** |

---

## 2. The 3 Core Pillars of High-Taste Motion

### Pillar 1: The Single Connected Object Principle
> *"Never cut. Every scene is made out of the previous one."*

Instead of cutting between disparate slides:
1. One primary geometric container (a rounded pill, a card, an orb, or a window) lives on screen.
2. When the concept shifts, that container **morphs**: its width, height, corner radius, and background tint smoothly interpolate to form the next container.
3. Content inside cross-morphs using mask wipes (`overflow: hidden` with `clip-path`) rather than crossfading opacities.
4. If a secondary element enters, it is born from an existing element (e.g., an icon expands into a modal, a button contracts into a loader).

### Pillar 2: Easy on the Eyes (Cognitive Comfort)
Viewers consume short-form video in rapid, noisy environments. A motion graphic must be visually striking yet effortless to comprehend:
- **Restricted Palette**:
  - Background: Deep matte slate (`#0a0b0e`), warm off-black (`#111216`), or editorial warm paper (`#f7f7f9`).
  - Neutral UI Chrome: 4 calibrated levels of white/black opacity (8%, 15%, 40%, 90%).
  - Single Accent: One purposeful brand color (e.g. Linear purple `#5e6ad2`, Claude amber `#d97706`, Emerald `#10b981`, or Electric Indigo `#6366f1`).
- **Typographic Discipline**:
  - Font choice: Clean geometric or humanist grotesque (Geist, Inter, SF Pro, Archivo).
  - Maximum 2 font families, maximum 3 font sizes per scene.
  - Generous padding: At least 24% of the frame is breathing room (negative space).
- **Focal Tracking**:
  - Only **ONE** element moves with high acceleration at any given millisecond. Secondary elements either move with low velocity or remain locked. The eye should never be forced to choose between two competing motions.

### Pillar 3: Beat-Synced Momentum
- Professional motion graphics feel "musical" even on mute.
- Set an explicit tempo (typically **118 to 124 BPM**, where 1 beat = 0.5s at 120 BPM).
- Major concept transformations occur on the downbeat (Beat 1, 5, 9, etc.).
- Accent interactions (clicks, toggles, slider releases) occur on quarter or eighth beats.
