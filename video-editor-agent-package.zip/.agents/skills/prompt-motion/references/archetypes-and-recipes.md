# Archetypes & Real Recipes from Prompt Motion

This reference catalogs the proven visual archetypes, timelines, and prompt architectures reverse-engineered from the top-performing entries in the Prompt Motion gallery.

---

## Archetype 1: The Mental Model & Process Explainer
*Reference cases: Negroni Recipe (@Ror_Fly, 1,028 likes), Token Bucket Rate Limiter (@ParkerRex), Recursion Explained in Genres (@emollick).*

### Core Mechanism
Take an abstract or sequential concept and give it a **physical process with a visible beginning, middle, and end**.

### Visual Blueprint
1. **The Canvas**: Dark slate (`#0d0f14`) or warm blueprint. Monospace labels for variables, sans-serif for explanation.
2. **The Reservoir / Core State**: A central geometric container representing system capacity, memory, state, or an empty receptacle.
3. **The Flow Rate**: Visual tokens, fluid, or signals entering from the left at a measured velocity.
4. **The Bottleneck / Transformation Rule**: Visual gate or filter that changes token state (e.g., color shift from grey to emerald when approved, or drops into an overflow drain when throttled).
5. **The Output Sink**: Completed tasks or formatted results flowing out smoothly.

### Prompt Template Structure
```markdown
Adopt the role of an expert technical motion designer.
Explain [CONCEPT/SCRIPT THEME] as a continuous 30-second procedural animation rendered in plain HTML5 Canvas.
No external libraries. Every frame must be a pure function of time inside seek(t).

Visual Direction:
- Clean technical blueprint aesthetic: matte dark slate background (#0d0e14), crisp monochromatic outlines, one electric emerald accent (#10b981).
- Show the complete physical mechanism from input to transformation to output.
- Banned: Glows, neon halos, particle explosions, random numbers, faux HUD labels, cartoon bouncy easing.
- Pacing: 60fps, 3 distinct phases (Phase 1: Normal steady-state flow, Phase 2: Spike / Stress test showing the bottleneck, Phase 3: Resolution / Outcome).
```

---

## Archetype 2: Single-Shape Continuous UI Morph
*Reference cases: Shape morphing through UI states (@twoclipping, 1440x1440), TasteSkill dashboard showcase (@LexnLin).*

### Core Mechanism
**Never cut.** Every scene and component is the *exact same geometric element* morphing its width, height, corner radius, and background color while its internal content swaps via mask wipes. A virtual cursor drives all actions.

### 7-Bar Beat Structure (120 BPM, 28 Beats Total)
- **Bar 1 (0.0s - 2.0s)**: Primary Action Button (`w: 180, h: 48, r: 24`). Cursor clicks. Button squashes by 6% and springs into a circular loader (`w: 48, h: 48, r: 24`).
- **Bar 2 (2.0s - 4.0s)**: Loader completes, morphs into a checkmark, then expands horizontally into a dynamic pill / island (`w: 320, h: 44, r: 22`).
- **Bar 3 (4.0s - 6.0s)**: The pill opens downward into a compact media player or status card (`w: 380, h: 120, r: 20`). Cursor scrubs a progress slider.
- **Bar 4 (6.0s - 8.0s)**: Cursor pulls slider past maximum; container stretches elasticaly and morphs into a segmented control / tabs.
- **Bar 5 (8.0s - 10.0s)**: Active tab knob expands into a full Bento metrics card with a self-drawing SVG sparkline chart and hover tooltip.
- **Bar 6 (10.0s - 12.0s)**: Card collapses smoothly into a `⌘K` command bar; cursor types 12 characters; `Enter` keystroke trigger.
- **Bar 7 (12.0s - 14.0s)**: Command bar contracts into a brief floating toast, which shrinks back into the original primary button. Perfect seamless loop.

---

## Archetype 3: The Apple-Keynote Continuous 2D Film
*Reference cases: Photo print app launch film (@twoclipping), Cinetic launch film (@LexnLin).*

### Core Mechanism
Editorial sophistication. Warm off-white canvas, stark contrast typography, iOS-grade frosted glass (`backdrop-filter: blur`), mask line reveals.

### Key Rules
- **Mask Rises**: Text never simply fades in. Every headline rises up from behind an invisible horizontal baseline mask line (`clip-path: inset(0 0 0 0)` to `clip-path: inset(0 0 100% 0)`).
- **Accordion Squeeze**: Words squeeze into their own punctuation marks, which expand into icons or photo frames.
- **Camera Zoom & Follow**: The camera zooms in screen-studio style so that whichever card or detail is currently active fills 80% of the frame, with the virtual cursor scaling proportionally.

---

## Archetype 4: Kinetic Typography & Conceptual Showreel
*Reference cases: Claude motion designer showreel (@stephanlivera, @himanshutwtxs, @shneural).*

### Core Mechanism
High-impact typographic rhythm that translates dense spoken ideas into striking visual statements.

### Key Rules
- **One Idea, One Word Group**: Do not place paragraphs on screen. Present 2 to 4 words per beat.
- **Variable Font Interpolation**: Weight transitions (e.g. Archivo weight 300 to 900, width 100 to 125) animated smoothly over 0.25 seconds on key emphasis words.
- **Shared Connector**: An orange dot, an accent cursor, or a geometric line guides the viewer's eye across text positions so the gaze never wanders.
