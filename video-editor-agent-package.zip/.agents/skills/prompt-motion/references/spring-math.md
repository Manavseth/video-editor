# Closed-Form Spring Physics for Deterministic seek(t) Renders

## Why Stateful Simulation Fails in Video Rendering

In typical UI animation libraries (Framer Motion, React Spring), physics are computed frame-by-frame using numerical integration (Euler or Verlet):
```javascript
// Stateful (BAD for deterministic offline rendering)
velocity += acceleration * dt;
position += velocity * dt;
```
This fails for video production because:
1. Jumping to an arbitrary time `t` (scrubbing, seeking) requires simulating every preceding frame.
2. Variable framerates or subframe supersampling cause timing drift.
3. Rendering cannot be parallelized across worker threads or headless tabs.

---

## The Closed-Form Analytical Solution

For any spring starting at time $t_0$ from initial position $x_0$ toward target $x_1$ with mass $m = 1$, spring stiffness $k$, and damping coefficient $c$:

1. **Natural Angular Frequency**:
   $$\omega_0 = \sqrt{k}$$

2. **Damping Ratio**:
   $$\zeta = \frac{c}{2 \sqrt{k}}$$

We categorize three regimes:

### 1. Underdamped ($\zeta < 1$) — Tiny, Pleasing Overshoot
This is the standard motion graphics spring (recommended $\zeta \approx 0.82 \text{ to } 0.88$ for Dribbble-level snappiness without cartoonish bounce):

$$\omega_d = \omega_0 \sqrt{1 - \zeta^2}$$
$$\Delta t = \max(0, t - t_0)$$
$$\text{decay} = e^{-\zeta \omega_0 \Delta t}$$

When initial velocity $v_0 = 0$:
$$x(t) = x_1 - (x_1 - x_0) \cdot \text{decay} \cdot \left( \cos(\omega_d \Delta t) + \frac{\zeta \omega_0}{\omega_d} \sin(\omega_d \Delta t) \right)$$

### 2. Critically Damped ($\zeta = 1$) — Zero Overshoot, Maximum Smoothness
Ideal for camera zooms, modal expansions, and text reveals where overshoot causes awkward clipping:

$$\Delta t = \max(0, t - t_0)$$
$$\text{decay} = e^{-\omega_0 \Delta t}$$
$$x(t) = x_1 - (x_1 - x_0) \cdot \text{decay} \cdot (1 + \omega_0 \Delta t)$$

---

## JavaScript Implementation for `seek(t)`

```javascript
class ClosedSpring {
  constructor({ stiffness = 180, damping = 24, mass = 1 } = {}) {
    this.k = stiffness;
    this.c = damping;
    this.m = mass;
    this.omega0 = Math.sqrt(this.k / this.m);
    this.zeta = this.c / (2 * Math.sqrt(this.k * this.m));
    if (this.zeta < 1) {
      this.omegaD = this.omega0 * Math.sqrt(1 - this.zeta * this.zeta);
    }
  }

  // Returns value at time t for a step transition occurring at t0
  evaluate(t, t0, from, to) {
    if (t <= t0) return from;
    const dt = t - t0;
    const delta = to - from;

    if (this.zeta < 1) {
      // Underdamped
      const decay = Math.exp(-this.zeta * this.omega0 * dt);
      const coeff = (this.zeta * this.omega0) / this.omegaD;
      const response = 1 - decay * (Math.cos(this.omegaD * dt) + coeff * Math.sin(this.omegaD * dt));
      return from + delta * response;
    } else {
      // Critically damped or overdamped
      const decay = Math.exp(-this.omega0 * dt);
      const response = 1 - decay * (1 + this.omega0 * dt);
      return from + delta * response;
    }
  }
}
```

### Multi-Target Chained Transitions (Sum of Springs)
When a single value (e.g., container width or position) changes targets multiple times across a timeline:
$$\text{Width}(t) = W_0 + \sum_{i=1}^{N} \text{Step}_i(t)$$
Where each step is computed independently with `ClosedSpring.evaluate(t, t_i, 0, \Delta W_i)`.
Because the solution is linear, multiple spring impulses sum together perfectly, maintaining analytical determinism at any $t$.

---

## Dual-Edge Morphing (Liquid Stretching)

To give shapes an organic, fluid quality without expensive physics meshes:
- The **Leading Edge** (the side moving in the direction of motion) rides a faster spring ($k = 240, \zeta = 0.8$).
- The **Trailing Edge** rides a slower spring ($k = 150, \zeta = 0.9$).
- Result: As the object expands or moves, it automatically elongates during flight and compresses snugly into its final resting state.
