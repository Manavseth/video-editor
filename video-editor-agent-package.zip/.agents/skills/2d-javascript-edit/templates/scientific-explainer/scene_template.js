// =========================================================================================
// 2D JAVASCRIPT SCIENTIFIC EXPLAINER TEMPLATE
// Reusable Production Engine inspired by @physicsofeveryday
// Standard: 1080x1920 (9:16) • 30 FPS • Pure Canvas 2D • 60% Negative Space
// =========================================================================================

const canvas = document.getElementById('c');
const ctx = canvas.getContext('2d');
const W = 1080, H = 1920;
const FPS = 30;

// Set by caller / project
let DURATION = 30.0;
let TOTAL_FRAMES = Math.round(DURATION * FPS);
window.READY = true;

// 1. Semantic Color Tokens
const C_BG_DARK    = "#060a08"; // Deep obsidian base
const C_BG_RADIAL  = "#0b1510"; // Center radial vignette glow
const C_TEXT_WHITE = "#ffffff";
const C_TEXT_MUTED = "#7a8f83";
const C_TEXT_DIM   = "#44554b";
const C_GREEN      = "#00ff88"; // Safe / optimal / truth
const C_GREEN_GLOW = "rgba(0, 255, 136, 0.35)";
const C_RED        = "#ff4455"; // Hazard / danger / error
const C_RED_GLOW   = "rgba(255, 68, 85, 0.4)";
const C_AMBER      = "#ffbb00"; // Caution / intermediate delta
const C_AMBER_GLOW = "rgba(255, 187, 0, 0.3)";
const C_CYAN       = "#00e5ff"; // Interactive / telemetry highlight

// 2. Mathematical Helpers
function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
function lerp(a, b, t) { return a + (b - a) * t; }
function easeOutCubic(t) { return 1 - Math.pow(1 - clamp(t, 0, 1), 3); }

// Sub-stepped Damped Harmonic Spring
function springVal(t, t0, dur, stiffness = 220, damping = 24) {
  if (t < t0) return 0;
  const dt = t - t0;
  if (dt >= dur) return 1;
  const omega = Math.sqrt(stiffness);
  const zeta = damping / (2 * omega);
  const omegaD = omega * Math.sqrt(Math.max(0, 1 - zeta * zeta));
  const envelope = Math.exp(-zeta * omega * dt);
  const osc = Math.cos(omegaD * dt) + (zeta / Math.sqrt(Math.max(0.0001, 1 - zeta * zeta))) * Math.sin(omegaD * dt);
  return clamp(1 - envelope * osc, 0, 1.25);
}

// 3. Pre-seeded Ambient Bokeh Particles
const PARTICLES = [];
for (let i = 0; i < 40; i++) {
  PARTICLES.push({
    x: (i * 12345.67) % W,
    y: (i * 98765.43) % H,
    r: 3 + ((i * 37) % 14),
    speedY: 0.15 + ((i * 11) % 0.35),
    speedX: (((i % 2 === 0) ? 1 : -1) * (0.05 + ((i * 7) % 0.15))),
    alpha: 0.08 + ((i * 19) % 0.16),
    shape: (i % 3 === 0) ? 'square' : 'circle'
  });
}

// -----------------------------------------------------------------------------------------
// REUSABLE VECTOR PRIMITIVES
// -----------------------------------------------------------------------------------------

// 4. Global Top Duration Progress Bar (y = 0)
function drawGlobalProgressBar(t, totalDuration) {
  const p = clamp(t / totalDuration, 0, 1);
  const barH = 5;
  ctx.save();
  ctx.fillStyle = "rgba(255, 255, 255, 0.08)";
  ctx.fillRect(0, 0, W, barH);
  ctx.fillStyle = C_GREEN;
  ctx.shadowColor = C_GREEN;
  ctx.shadowBlur = 8;
  ctx.fillRect(0, 0, W * p, barH);
  ctx.shadowBlur = 0;
  ctx.fillStyle = C_TEXT_WHITE;
  ctx.fillRect(W * p - 3, 0, 6, barH);
  ctx.restore();
}

// 5. Minimal Top Chapter HUD (y = 80)
function drawTopHUD(tag, label) {
  ctx.save();
  ctx.font = "18px 'SF Mono', monospace";
  ctx.textAlign = "left";
  ctx.fillStyle = C_TEXT_MUTED;
  ctx.fillText(tag, 80, 85);
  ctx.textAlign = "right";
  ctx.fillStyle = C_TEXT_DIM;
  ctx.fillText(label, W - 80, 85);
  ctx.strokeStyle = "#141f18";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(80, 105);
  ctx.lineTo(W - 80, 105);
  ctx.stroke();
  ctx.restore();
}

// 6. Floating In-Line Semantic Subtitles (Borderless Monospace)
function drawFloatingSubtitles(t, subtitlesList, subY = 1640) {
  const sub = subtitlesList.find(s => t >= s.start && t < s.end);
  if (!sub) return;

  ctx.save();
  const fontSize = sub.text.length > 50 ? 30 : 34;
  ctx.font = `500 ${fontSize}px 'SF Mono', monospace`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  const words = sub.text.split(" ");
  const hlWords = (sub.highlight || "").toLowerCase().split(" ");

  let totalWidth = 0;
  const wordWidths = words.map(w => {
    const wClean = w.replace(/[.,!]/g, "").toLowerCase();
    const isHL = hlWords.includes(wClean);
    ctx.font = isHL ? `bold ${fontSize}px 'SF Mono', monospace` : `500 ${fontSize}px 'SF Mono', monospace`;
    const metrics = ctx.measureText(w + " ");
    totalWidth += metrics.width;
    return { word: w, width: metrics.width, isHL };
  });

  let curX = W / 2 - totalWidth / 2;
  wordWidths.forEach(ww => {
    if (ww.isHL) {
      ctx.font = `bold ${fontSize}px 'SF Mono', monospace`;
      ctx.fillStyle = ww.word.match(/deadly|wrong|danger|alert|loss/i) ? C_RED : C_GREEN;
      ctx.shadowColor = ctx.fillStyle;
      ctx.shadowBlur = 14;
      ctx.fillText(ww.word, curX + ww.width / 2, subY);
      ctx.shadowBlur = 0;
    } else {
      ctx.font = `500 ${fontSize}px 'SF Mono', monospace`;
      ctx.fillStyle = C_TEXT_WHITE;
      ctx.fillText(ww.word, curX + ww.width / 2, subY);
    }
    curX += ww.width;
  });
  ctx.restore();
}

// 7. Reusable Radial Gauge / Meter (2D Speedometer)
function drawRadialGauge(cx, cy, r, val, minVal, maxVal, unit = "dBA", label = "METRIC", isAlert = false) {
  ctx.save();
  ctx.translate(cx, cy);

  const startAng = Math.PI * 0.8;
  const endAng = Math.PI * 2.2;
  const totalAng = endAng - startAng;
  const pct = clamp((val - minVal) / (maxVal - minVal), 0, 1);
  const curAng = startAng + totalAng * pct;
  const gaugeColor = isAlert ? C_RED : C_GREEN;

  // Track arc
  ctx.strokeStyle = "#16231b";
  ctx.lineWidth = 24;
  ctx.beginPath();
  ctx.arc(0, 0, r, startAng, endAng);
  ctx.stroke();

  // Active sweep arc
  ctx.strokeStyle = gaugeColor;
  ctx.shadowColor = gaugeColor;
  ctx.shadowBlur = 18;
  ctx.beginPath();
  ctx.arc(0, 0, r, startAng, curAng);
  ctx.stroke();
  ctx.shadowBlur = 0;

  // Needle
  ctx.save();
  ctx.rotate(curAng);
  ctx.fillStyle = C_TEXT_WHITE;
  ctx.beginPath();
  ctx.moveTo(-6, 20);
  ctx.lineTo(6, 20);
  ctx.lineTo(2, -r + 10);
  ctx.lineTo(-2, -r + 10);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // Center pivot knob
  ctx.fillStyle = gaugeColor;
  ctx.beginPath();
  ctx.arc(0, 0, 18, 0, Math.PI * 2);
  ctx.fill();

  // Central readouts
  ctx.font = "bold 60px 'SF Mono', monospace";
  ctx.textAlign = "center";
  ctx.fillStyle = gaugeColor;
  ctx.fillText(`${val} ${unit}`, 0, 60);

  ctx.font = "20px 'SF Mono', monospace";
  ctx.fillStyle = C_TEXT_MUTED;
  ctx.fillText(label, 0, 105);

  ctx.restore();
}

// 8. Reusable Horizontal Metric Battery / Time Budget Bar
function drawMetricBattery(cx, cy, w, h, pct, label = "BUDGET", readoutStr = "100%") {
  ctx.save();
  ctx.translate(cx, cy);

  const r = h / 2;
  const isAlert = pct < 0.15;
  const fillColor = isAlert ? C_RED : (pct < 0.5 ? C_AMBER : C_GREEN);

  // Label above
  ctx.font = "18px 'SF Mono', monospace";
  ctx.textAlign = "left";
  ctx.fillStyle = C_TEXT_MUTED;
  ctx.fillText(label, -w/2, -h/2 - 18);

  ctx.textAlign = "right";
  ctx.font = "bold 24px 'SF Mono', monospace";
  ctx.fillStyle = fillColor;
  ctx.fillText(readoutStr, w/2, -h/2 - 18);

  // Battery outer frame
  ctx.fillStyle = "#101813";
  ctx.beginPath();
  ctx.roundRect(-w/2, -h/2, w, h, r);
  ctx.fill();
  ctx.lineWidth = 2.5;
  ctx.strokeStyle = isAlert ? C_RED : "#213026";
  ctx.stroke();

  // Battery fill
  const fillW = Math.max(r * 2, w * clamp(pct, 0, 1));
  ctx.save();
  ctx.beginPath();
  ctx.roundRect(-w/2, -h/2, w, h, r);
  ctx.clip();
  ctx.fillStyle = fillColor;
  ctx.shadowColor = fillColor;
  ctx.shadowBlur = isAlert ? 22 : 12;
  ctx.fillRect(-w/2, -h/2, fillW, h);
  ctx.shadowBlur = 0;
  ctx.fillStyle = "rgba(255, 255, 255, 0.2)";
  ctx.fillRect(-w/2, -h/2, fillW, h * 0.35);
  ctx.restore();

  ctx.restore();
}

// -----------------------------------------------------------------------------------------
// RENDER HOOK
// -----------------------------------------------------------------------------------------

function renderFrame(frameIndex) {
  const t = frameIndex / FPS;

  // Clear background with radial vignette
  ctx.fillStyle = C_BG_DARK;
  ctx.fillRect(0, 0, W, H);
  const radial = ctx.createRadialGradient(W/2, H/2 - 100, 100, W/2, H/2 - 100, 950);
  radial.addColorStop(0, C_BG_RADIAL);
  radial.addColorStop(1, C_BG_DARK);
  ctx.fillStyle = radial;
  ctx.fillRect(0, 0, W, H);

  // Ambient particles
  ctx.save();
  PARTICLES.forEach(p => {
    const curY = (p.y - t * 40 * p.speedY) % H;
    const finalY = curY < 0 ? curY + H : curY;
    const curX = (p.x + Math.sin(t * 0.5 + p.r) * 15) % W;
    ctx.fillStyle = C_GREEN;
    ctx.globalAlpha = p.alpha;
    ctx.beginPath();
    if (p.shape === 'circle') ctx.arc(curX, finalY, p.r, 0, Math.PI * 2);
    else ctx.rect(curX - p.r, finalY - p.r, p.r * 2, p.r * 2);
    ctx.fill();
  });
  ctx.restore();

  // Top global progress bar
  drawGlobalProgressBar(t, DURATION);

  // [Insert narrative act choreography here using primitives above]
}

window.grabFrame = function(frameIndex) {
  renderFrame(frameIndex);
  return canvas.toDataURL('image/png');
};
