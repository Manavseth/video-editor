// =========================================================================================
// 2D JAVASCRIPT RENDER RUNNER (Chrome/Edge Puppeteer -> FFmpeg Stream)
// Outputs pristine MP4 with broadcast loudness (-14.0 LUFS EBU R128)
// =========================================================================================

import http from 'http';
import fs from 'fs';
import path from 'path';
import { spawn, execSync } from 'child_process';
import puppeteer from 'puppeteer-core';

const W = 1080, H = 1920, FPS = 30;
const PORT = 4998;

export async function render2DJavaScript({
  htmlPath,
  audioPath,
  outputMp4Path,
  durationSec,
  previewKeyframes = []
}) {
  const totalFrames = Math.round(durationSec * FPS);
  const workDir = path.dirname(outputMp4Path);
  fs.mkdirSync(workDir, { recursive: true });

  const server = http.createServer((req, res) => {
    let reqPath = decodeURIComponent(req.url.split('?')[0]);
    let filePath = path.resolve('.' + reqPath);
    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
      if (filePath.endsWith('.js') || filePath.endsWith('.mjs')) res.setHeader('Content-Type', 'application/javascript');
      else if (filePath.endsWith('.html')) res.setHeader('Content-Type', 'text/html');
      else if (filePath.endsWith('.png')) res.setHeader('Content-Type', 'image/png');
      res.end(fs.readFileSync(filePath));
    } else {
      res.statusCode = 404; res.end('Not found');
    }
  });

  server.listen(PORT, async () => {
    const exePaths = [
      'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
      'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
      process.env.LOCALAPPDATA + '/Google/Chrome/Application/chrome.exe',
      'C:/Program Files/Google/Chrome/Application/chrome.exe'
    ];
    const exe = exePaths.find(p => fs.existsSync(p));
    if (!exe) throw new Error('No compatible Chrome or Edge browser found.');

    const browser = await puppeteer.launch({
      executablePath: exe,
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--use-gl=angle', '--enable-webgl']
    });

    const page = await browser.newPage();
    await page.setViewport({ width: W, height: H, deviceScaleFactor: 1 });
    await page.goto(`http://localhost:${PORT}/${htmlPath.replace(/\\/g, '/')}`);
    await page.waitForFunction('window.READY === true', { timeout: 30000 });

    // Capture stills
    for (const kf of previewKeyframes) {
      const dataUrl = await page.evaluate(f => window.grabFrame(f), kf.frame);
      const buf = Buffer.from(dataUrl.split(',')[1], 'base64');
      fs.writeFileSync(kf.outputPath, buf);
    }

    // Stream frames to FFmpeg
    const rawVideo = path.join(workDir, 'temp_visuals.mp4');
    const ff = spawn('ffmpeg', [
      '-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(FPS),
      '-c:v', 'png', '-i', '-', '-c:v', 'libx264', '-crf', '17', '-preset', 'fast',
      '-pix_fmt', 'yuv420p', rawVideo
    ], { stdio: ['pipe', 'inherit', 'inherit'] });

    for (let f = 0; f < totalFrames; f++) {
      const dataUrl = await page.evaluate(fIdx => window.grabFrame(fIdx), f);
      const buf = Buffer.from(dataUrl.split(',')[1], 'base64');
      if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
    }
    ff.stdin.end();
    await new Promise(r => ff.on('close', r));

    await browser.close();
    server.close();

    // Mux with audio and normalise to -14.0 LUFS
    const muxCmd = `ffmpeg -y -i "${rawVideo}" -i "${audioPath}" -c:v copy -af "loudnorm=I=-14.0:TP=-1.5:LRA=7.0" -c:a aac -b:a 256k -shortest "${outputMp4Path}"`;
    execSync(muxCmd, { stdio: 'inherit' });
    fs.unlinkSync(rawVideo);
    console.log('Render complete:', outputMp4Path);
  });
}
