---
name: 2d-javascript-edit
description: "The '2D javascript' (Motion Studio & Scientific Explainer) format: Make a finished, studio-quality animated video (MP4 with a picture-synced soundtrack) from references and a rough idea. Every frame is drawn in procedural JavaScript on an HTML5 canvas. Covers two primary expressions: (1) The Scientific & Physics Explainer (@physicsofeveryday style: instant <50ms cognitive fluency, persistent visual actors, 60% negative space, 5px top progress bar, floating borderless monospace subtitles, and real-world semiotics) and (2) The Artisanal Motion Studio (risograph, pencil sketch, watercolor, stipple, ASCII, X-ray). Use whenever someone asks for '2D javascript', '2d-javascript-edit', 'motion-studio', or wants procedural code animation."
---

# 2D JAVASCRIPT EDIT — procedural code-drawn animation format

> **THE ESSENCE:** You deliver a **finished, broadcast-ready MP4** where every frame is procedurally drawn in JavaScript on an HTML5 Canvas, rendered frame-by-frame through the local Chrome/Edge browser via Puppeteer, encoded with FFmpeg, and mastered to **−14.0 LUFS** EBU R128 audio. 
> 
> Two distinct craft expressions live here:
> 1. **The Scientific & Physics Explainer (The `@physicsofeveryday` Standard)**: The gold standard for science, technical, audiology, mathematics, and cognitive explainers. Characterized by **instant cognitive fluency (<50ms)**, **persistent visual protagonists**, **60% generous negative space**, a **5px continuous top progress bar**, and **floating borderless monospace subtitles** with in-line semantic highlights.
> 2. **The Artisanal Motion Studio**: The painterly, hand-drawn aesthetic (risograph halftone, watercolor washes, pencil sketch boil, stipple, ASCII, and X-ray).

---

## 1 · The Golden Rules (Learned the Hard Way)

1. **The First-Glance Fluency Rule (<50ms Decodability)**:
   * *The Rule*: Every object, model, or actor must be instantly recognized in a single glance without reading text. A phone is a phone; an ear is an ear; a car is a car; a hazard is a traffic cone; a velocity meter is a speedometer.
   * *The Failure*: Building an "invented machine" (e.g. an intricate 3D isometric laboratory apparatus with brass calipers, sliding drawers, and heavy telemetry). If the viewer has to spend 1.5 seconds decoding *what the machine is*, the motion design has failed.
2. **Unbroken Visual Protagonist Continuity**:
   * *The Rule*: Anchor the entire narrative to **1 or 2 persistent visual characters** that evolve across scenes (e.g., the Green Car vs. Red Car in `@physicsofeveryday`; the Smartphone Volume Slider vs. Ear Time Battery in our audiology master).
   * *The Failure*: "Metaphor whiplash"—swapping the visual universe every 4 seconds (ear canal → balance beam → gauge → alarm box → cochlea → drawer).
3. **60% Generous Negative Space**:
   * *The Rule*: Leave at least 60% of the screen dark, open, and breathing. The hero model commands center stage on a deep obsidian vignette (`#060a08` base, `#0b1510` radial core) with soft ambient bokeh motes drifting in the background.
   * *The Failure*: Cockpit clutter—filling every corner with persistent 16-band waterfall FFTs, audiograms, gauges, and footer HUDs simultaneously.
4. **The 5px Top Global Progress Bar**:
   * *The Rule*: Always draw a 5px hairline progress bar running across the very top edge ($y = 0$). It steadily fills from $0\%$ to $100\%$ across the runtime in neon green (`#00ff88`), giving viewers an instinctive anchor of video pacing.
5. **Floating Borderless Monospace Subtitles**:
   * *The Rule*: Subtitles float naturally in the lower third ($y \approx 1620-1640$) in clean monospace (`SF Mono`, `Roboto Mono`, or `Space Mono`). Active semantic keywords are highlighted in-line with glowing semantic color.
   * *The Failure*: Putting subtitles inside a heavy, dark rounded container pill with borders and blinking indicator dots that collide with long sentences.
6. **Strict 3-Tone Semantic Color Hierarchy**:
   * **Neon Green (`#00ff88` / `#22c55e`)**: Truth, safe threshold, optimal efficiency, baseline ($85\text{ dBA}$, $100\text{ km/h}$).
   * **Neon Coral/Red (`#ff4455` / `#ef4444`)**: Hazard, danger, acoustic overload, cognitive error ($105\text{ dBA}$, `[x WRONG]`, $120\text{ km/h}$).
   * **Warm Amber/Yellow (`#ffbb00`)**: Caution, intermediate stepped deltas, $-4\text{h} / -2\text{h}$ drops.
7. **Sub-Stepped Damped Harmonic Spring Physics**:
   * *The Rule*: Nothing moves with linear robotic pacing or harsh jump-resets. All pops, slider movements, and meter sweeps follow a damped harmonic oscillator (`stiffness = 220`, `damping = 24`) for organic physical weight.
8. **Broadcast Loudness Master**:
   * *The Rule*: Audio must be delivered at strictly **−14.0 LUFS** integrated loudness ($\pm 0.5\text{ LUFS}$) with a maximum true peak of **−1.5 dBTP** and sound effects pre-shifted to their waveform peaks.

---

## 2 · Format Specification: Scientific & Physics Explainer

### Standard Aspect Ratio & Canvas
- **Vertical 9:16**: $1080 \times 1920$ @ 30 FPS.
- **Duration**: Paced to speech (typically 30–60s). Every beat adds or transforms state every $\le 1.5 - 2.0\text{s}$.

### Information Architecture (9:16 Vertical Zone Budget)
```
┌─────────────────────────────────────────────────────────────┐
│ y = 0..5      : 5px Neon Green Continuous Global Progress Bar│
│ y = 70..110   : Minimalist Top Chapter Tag HUD (y=80)       │
│ y = 260..340  : Hero Topic Statement & Clean Monospace Title │
│                                                             │
│ y = 480..1200 : HERO VISUAL STAGE (Center 60% Negative Space)│
│                 - Persistent Protagonist (Phone / Car / Dial)│
│                 - Interactive Waveform / Speedometer / Curve │
│                                                             │
│ y = 1240..1320: Metric Battery / Safe Time Budget Bar       │
│ y = 1380..1460: Dynamic Callout Badge (Pill / Stepped Delta) │
│ y = 1600..1680: Floating Borderless Monospace Subtitles     │
│ y = 1750..1920: Safe Margins / Bottom Platform Clearance     │
└─────────────────────────────────────────────────────────────┘
```

---

## 3 · Core Code Primitives & Math Engine

Every Scientific 2D JavaScript project should draw from the pre-tested primitives located in:
`templates/scientific-explainer/scene_template.js`

### 1. Damped Harmonic Spring
```javascript
function springVal(t, t0, dur, stiffness = 220, damping = 24) {
  if (t < t0) return 0;
  const dt = t - t0;
  if (dt >= dur) return 1;
  const omega = Math.sqrt(stiffness);
  const zeta = damping / (2 * omega);
  const omegaD = omega * Math.sqrt(Math.max(0, 1 - zeta * zeta));
  const envelope = Math.exp(-zeta * omega * dt);
  const osc = Math.cos(omegaD * dt) + (zeta / Math.sqrt(Math.max(0.0001, 1 - zeta * zeta))) * Math.sin(omegaD * dt);
  return Math.max(0, Math.min(1.25, 1 - envelope * osc));
}
```

### 2. Floating Semantic Subtitles
```javascript
function drawFloatingSubtitles(t, subtitlesList, subY = 1640) {
  const sub = subtitlesList.find(s => t >= s.start && t < s.end);
  if (!sub) return;

  ctx.save();
  const fontSize = sub.text.length > 50 ? 30 : 34;
  ctx.font = `500 ${fontSize}px 'SF Mono', monospace`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  const words = sub.text.split(" ");
  const hlWords = (sub.highlight || "").toLowerCase().split(" ");

  let totalWidth = 0;
  const wordWidths = words.map(w => {
    const wClean = w.replace(/[.,!]/g, "").toLowerCase();
    const isHL = hlWords.includes(wClean);
    ctx.font = isHL ? `bold ${fontSize}px 'SF Mono', monospace` : `500 ${fontSize}px 'SF Mono', monospace`;
    const metrics = ctx.measureText(w + " ");
    totalWidth += metrics.width;
    return { word: w, width: metrics.width, isHL };
  });

  let curX = W / 2 - totalWidth / 2;
  wordWidths.forEach(ww => {
    if (ww.isHL) {
      ctx.font = `bold ${fontSize}px 'SF Mono', monospace`;
      ctx.fillStyle = ww.word.match(/deadly|wrong|danger|alert|loss|hazard/i) ? C_RED : C_GREEN;
      ctx.shadowColor = ctx.fillStyle;
      ctx.shadowBlur = 14;
      ctx.fillText(ww.word, curX + ww.width / 2, subY);
      ctx.shadowBlur = 0;
    } else {
      ctx.font = `500 ${fontSize}px 'SF Mono', monospace`;
      ctx.fillStyle = C_TEXT_WHITE;
      ctx.fillText(ww.word, curX + ww.width / 2, subY);
    }
    curX += ww.width;
  });
  ctx.restore();
}
```

### 3. Top Continuous Progress Bar
```javascript
function drawGlobalProgressBar(t, totalDuration) {
  const p = Math.max(0, Math.min(1, t / totalDuration));
  ctx.save();
  ctx.fillStyle = "rgba(255, 255, 255, 0.08)";
  ctx.fillRect(0, 0, W, 5);
  ctx.fillStyle = C_GREEN;
  ctx.shadowColor = C_GREEN;
  ctx.shadowBlur = 8;
  ctx.fillRect(0, 0, W * p, 5);
  ctx.shadowBlur = 0;
  ctx.fillStyle = C_TEXT_WHITE;
  ctx.fillRect(W * p - 3, 0, 6, 5);
  ctx.restore();
}
```

---

## 4 · Rendering & Master Delivery Pipeline

1. **Host HTML**: Pure self-contained `<canvas id="c" width="1080" height="1920">` running `scene.js`.
2. **Headless Execution**: `render_template.mjs` spins up local Microsoft Edge / Google Chrome via `puppeteer-core`. It sets `window.READY = true`, executes `window.grabFrame(frameIndex)`, and pipes base64 buffers directly into FFmpeg's `image2pipe` stdin.
3. **Muxing & Audio Loudness**:
   ```bash
   ffmpeg -y -i visuals_raw.mp4 -i audio_master.wav -c:v copy -af "loudnorm=I=-14.0:TP=-1.5:LRA=7.0" -c:a aac -b:a 256k -shortest final_master.mp4
   ```
4. **Verification Gate**:
   - Extract verification keyframes at act boundaries.
   - Run `ffmpeg -i final_master.mp4 -af ebur128 -f null -` to prove integrated loudness is strictly **−14.0 LUFS**.

---

## 5 · Reusable Assets & Templates Reference
- **HTML Boilerplate**: `templates/scientific-explainer/template.html`
- **Core Scene Engine**: `templates/scientific-explainer/scene_template.js`
- **Automated Render Runner**: `templates/scientific-explainer/render_template.mjs`
- **Reference Landmark**: `work/delivery_two_options/option_a_v4/Option_A_V4_Physics_Explainer.mp4` (Rated 8.5/10 by creator).
