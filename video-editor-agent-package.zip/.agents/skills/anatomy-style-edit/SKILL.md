---
name: anatomy-style-edit
description: "The crafted, physical mechanical instrument format for technical explainer motion graphics (9:16 vertical reels or 16:9). Adapts the aesthetic of the anatomy skill into strictly NON-INTERACTIVE video motion graphics. Two modes: (1) Hybrid Talking Head (talking head ≤40% runtime/area, Anatomy MG ≥60%) and (2) 100% Pure Motion Graphics (audio-only or total visual takeover). Enforces continuous motion every ≤2s, 4-tone directional shading, harmonic damped spring physics, precision instrument framing (Fig n.0, live readouts, status LEDs), and zero interactive UI clutter."
---

# ANATOMY STYLE EDIT — the physical instrument motion graphics grammar

> **THE ESSENCE:** Translate the crafted, ultra-detailed isometric laboratory-rig aesthetic from the `anatomy` skill into **strictly non-interactive motion graphics** for video. Every abstract concept becomes a tangible, physical machine on a workbench: heavy flanged bases, guide rails with laser-etched tick marks, knurled adjustment knobs, precision dial gauges with sweeping needles, and hyper-realistic coilover springs. 

---

## 1. The Core Philosophy

### "The Object IS the Explanation"
Reviewers reject abstract floating boxes, generic circles, and template tech icons. Instead, map every abstract concept to a functional physical machine or laboratory rig:

| Abstract Concept | Physical Instrument (Anatomy Object) |
|---|---|
| **Price / Weight Parity** | Dual-pan comparison balance on coilover suspension with dial readout |
| **Acoustic Gain / Decibels** | Brass acoustic horn on micrometer rails + calibrated dial indicator |
| **Silicon Miniaturization** | Exploded chip carrier sliding apart along isometric guide pillars |
| **Signal Processing / Filtering** | Dual-channel oscilloscope test bench with rotary stepped dials |
| **Biological Ear Canal Trap** | Medical ear-canal cross-section clamped in an acrylic inspection jig |
| **Bundled Professional Services** | Multi-tier calibration rig with micrometric probe and audit scale |

### The Non-Interactive Video Contract
1. **Zero UI Artifacts:** Strip out all browser DOM listeners, hover states, click handles, slider knobs, and interactive cursor hints.
2. **Timeline-Driven Motion:** Every motion parameter (needle angle, spring deflection, carriage position, LED intensity) is driven **parametrically along the video timeline ($t$)** synchronized to Whisper audio timestamps.
3. **Continuous Micro-Motion (≤2s Rule):** The screen must **never sit static for longer than 2 seconds**. Even in resting holds, instruments exhibit realistic micro-motion (subtle needle jitter, spring relaxation, scanning laser sweeps, or status LED breathing).
4. **Object Recognizability & Context Guard (Zero Naked Primitives):** Never render generic geometric primitives (smooth ovals, plain spheres, isolated floating wireframe tubes) as stand-ins for real objects. 
   - A medical or consumer object must include its **signature tactile landmarks** (e.g. a hearing aid MUST show its curved behind-the-ear body or ergonomic custom shell, silicone mushroom dome tip, receiver wire, microphone grille, and faceplate).
   - Internal biological anatomy (like an ear canal or blood vessel) must NEVER float as a bare abstract wireframe mesh or net; it must be visually anchored within a semi-transparent **human silhouette or outer anatomical context** so viewers instantly recognize the scale and body part.


---

## 2. The Two Production Modes

### Mode A: Hybrid Talking-Head Explainer (≤40% Face / ≥60% Anatomy MG)
Use when camera footage of the creator is provided.

- **Screen Time & Area Ratio:**
  - Talking head video owns **$\le 40\%$** of total screen time (or $\le 40\%$ vertical split area).
  - Anatomy motion graphics own **$\ge 60\%$** of total screen time (or $\ge 60\%$ vertical split area).
- **Layout Variations:**
  1. **Fixed 60-40 Split (1080×1920):**
     - **Top Card (60%):** $y0 - y1152$ — Full Anatomy mechanical instrument card with live readouts.
     - **Bottom Card (40%):** $y1152 - y1920$ — Full-bleed talking head.
     - **Seam ($y1152$):** Thin 1px technical divider with centered caption pill.
  2. **Mechanical Drawer Variant:**
     - Face sits in a bottom drawer ($y1080 - y1920$).
     - When the mechanical rig needs the full frame, the face drawer slides down out of frame (10-frame cubic ease) revealing the complete 1080×1920 laboratory rig.
     - The face slides back up when the creator speaks directly to camera.
- **Hard Rules:**
  - **Alpha Face Guard:** Never place technical labels, dial needles, or graphics over the face in any frame.
  - **Hard Cuts / Mechanical Slides Only:** Zero opacity crossfades between camera and graphics.

---

### Mode B: 100% Pure Motion Graphics Explainer
Use when the project is audio-only (e.g. podcast clip, voiceover recording) or when the creator asks for a full visual takeover.

- **Geometry:** Full 1080×1920 vertical canvas (or 1920×1080 16:9).
- **Stage Progression:**
  - The entire duration is structured into distinct mechanical acts (3–8 acts).
  - Acts transition via hard cuts or physical camera pans/trucks across the laboratory bench.
  - Exploded views: assemblies slide apart along isometric axes ($\pm \vec{u}_{\text{iso}}$) on staggered keyframes to reveal internal sub-assemblies.

---

## 3. Visual Aesthetics & Craft Rules

### A. Isometric Camera & Framing
- **Azimuth:** $45^\circ$ ($35^\circ - 60^\circ$ for elongated subjects).
- **Elevation:** $30^\circ$ ($44^\circ$ when looking inside recessed chambers).
- **Coordinate System:** $x$ and $y$ on the bench floor, $z$ pointing straight up.
- **Screen Mapping:**
  $$X = X_0 + (x \sin A - y \cos A) \cdot k$$
  $$Y = Y_0 + \big((x \cos A + y \sin A) \sin E - z \cos E\big) \cdot k$$
  where $A = 45^\circ$, $E = 30^\circ$, and $k$ is the uniform scale factor.

### B. 4-Tone Directional Shading System
Every solid object must have true physical volume, painted in strict depth order (bottom-to-top, back-to-front):
- **Top Planes:** Always the lightest tone (`--anatomy-top: #1c1c1c` in dark mode).
- **Side Faces:** Shaded across 4 distinct tones based on surface normal orientation against the virtual key light:
  - Shade 0 (darkest): `--anatomy-shade-0: #0f0f0f`
  - Shade 1: `--anatomy-shade-1: #121212`
  - Shade 2: `--anatomy-shade-2: #151515`
  - Shade 3 (brightest side): `--anatomy-shade-3: #181818`
- **Edges & Creases:**
  - Outer silhouettes: 0.6px contour strokes (`--anatomy-lo: #3e3e3e` or `mid: #6a6a6a`).
  - Internal creases & bevels: Faint knife-edge lines (`--anatomy-faint: #2a2a2a`).
  - Active focal point: Single illuminated accent (`--anatomy-lit: #ffffff` or saturated cyan/amber).
- **Ground Drop Halos:** Every resting base plate has a soft Gaussian radial drop halo (`filter: blur(9px)`, opacity 0.9) cast onto the benchtop.

### C. Mechanical Parts Vocabulary
Every instrument must be constructed from recognizable engineering hardware:
1. **Heavy Base Plate:** Rounded rectangular slab (`{w, d, r}`) with 4 cylindrical flanged feet and corner dot screws (`r=0.45` circles inside concentric rings).
2. **Guide Rails & Tick Rulers:** Linear bars with laser-etched metric ticks (minor every unit, major every 5th unit with numbers).
3. **Precision Dial Gauges:** Circular lathe-turned bezel, stepped degree ticks, central pivot pin, and an anti-aliased swept needle.
4. **Knurled Adjustment Screws:** Cylindrical thumbscrews with vertical diamond or slotted knurling lines (`lineSvg` with tone `lo`).
5. **Hyper-Realistic Coilover Springs:**
   - Real helical coils with true 3D depth.
   - Back coil segments rendered behind central damper shaft; front coil segments rendered on top with specular highlight line.
   - Dynamic compression/extension varying the helical pitch $\Delta z(t)$.

---

## 4. Physics & Animation Mathematics

All animations must follow physical laws rather than linear interpolation (`linear` is banned).

### 1. Harmonic Damped Spring Oscillation
When a scale drops, an arm impacts, or a weight is added:
$$y(t) = y_{\text{target}} + A \cdot e^{-\zeta \omega_n t} \cos\left(\omega_d t - \phi\right)$$
- $\zeta \approx 0.18 - 0.25$ (underdamped mechanical oscillation).
- $\omega_n \approx 12 - 18\text{ rad/s}$ (fast, crisp mechanical response).
- Settles cleanly within $0.8 - 1.2$ seconds without perpetual buzzing.

### 2. Dial Gauge Needle Sweep
When readings change, needles rotate with angular inertia:
$$\theta(t) = \theta_0 + (\theta_{\text{target}} - \theta_0) \cdot \left[1 - e^{-\lambda t} \cos(\omega t)\right]$$
Needles overshoot their target by $3\% - 8\%$ before settling with a tiny damped quiver.

### 3. Continuous Micro-Movement Formula
During long holds where a machine is idling:
$$\delta_{\text{jitter}}(t) = 0.4 \sin(3.1 t) + 0.2 \cos(7.3 t)\quad [\text{px or degrees}]$$
Keeps the gauge alive and verified under the $\le 2\text{s}$ continuous motion rule.

### 4. Euler Axle Rotation Integrity
When animating rotating wheels, gears, drums, or rotors:
- **Never rotate along an unaligned parent axis** on a mesh that already contains a static orientation transform (e.g. creating a cylinder with `rotation.x = Math.PI / 2` to face Z, and then animating `parent.rotation.x`, causing the wheel to tumble sideways/end-over-end and appear morphed/flipping).
- **Isolate the spin axis:** Wrap the wheel cylinder inside an isolated axle group, and rotate strictly on the cylinder's native cylindrical axis (`rotation.y` or dedicated rolling pivot) aligned with the direction of travel ($v = \omega r$).
- Verify rolling orientation visually: wheels must roll smoothly forward across the floor, never wobble or flip cartwheel-style.

---

## 5. Technical Card Framing

Every Anatomy visual lives within an industrial instrument frame:
```
+-------------------------------------------------------------+
| [FIG 1.0 // SPEC]                      [DUAL-BALANCE RIG]   |
|                                                             |
|                                                             |
|                    ( ISOMETRIC RIG )                        |
|                                                             |
|                                                             |
| [SYS: ONLINE · CALIBRATED]             [READOUT: 80.2 dB]   |
+-------------------------------------------------------------+
```
- **Top-Left:** Section index (`FIG 1.0`, `FIG 2.0`, etc.) in monospaced uppercase.
- **Top-Right:** Machine / Subsystem Title (`ACOUSTIC IMPEDANCE`, `SILICON DIE PRESS`).
- **Bottom-Left:** Live instrument status (`SYS: ACTIVE`, `HOLD: 125 dB SPL`).
- **Bottom-Right:** Dynamic numeric telemetry (`data-readout`) ticking with monospace tabular digits.

---

## 6. Sound Design & Audio Mix

Sound design brings the physical machine to life:
1. **Peak-Aligned SFX Scheduling:** Trigger sound effects at `event_time - peak_offset` so mechanical impacts hit exactly on the contact frame.
2. **Approved SFX Vocabulary:**
   - Scale drop / weight impact: Deep metallic clank + subtle low sub-thump (`sfx/clank_heavy.wav`).
   - Dial needle sweep: Fine mechanical click / ratchet flutter (`sfx/ratchet_fine.wav`).
   - Drawer slide / cutaway: Pneumatic air hiss + smooth rail slide (`sfx/pneumatic_whoosh.wav`).
   - On-chip AI / digital sweep: Low-frequency sine sweep + high-frequency data chime (`sfx/data_sweep.wav`).
3. **Loudness Standards:** Master audio normalized to **$-14.0$ LUFS** EBU R128 on the final encoded MP4. SFX mixed at $-18$ to $-22$ dBFS under voiceover.

---

## 7. Quality Checklist Before Delivery

- [ ] **Mode Verified:** Either Hybrid (Face $\le 40\%$, Anatomy $\ge 60\%$) or 100% Pure Anatomy MG.
- [ ] **Non-Interactive Verified:** Zero web UI buttons, zero click hints, zero draggable handles.
- [ ] **Continuous Motion:** Verified noticeable movement on screen every $\le 2$ seconds.
- [ ] **Shading Correctness:** 4-tone directional side shading + light top face + ground drop halos.
- [ ] **Depth Order Proved:** No intersecting pipes, no see-through wireframes, background coils behind damper shaft.
- [ ] **Face Safety (Mode A):** Alpha face guard proves zero graphics or text collide with creator's face.
- [ ] **Hard Cuts:** Zero opacity crossfades between registers or takes.
- [ ] **Master Loudness:** Measured exactly at $-14.0 \pm 0.5$ LUFS on the final encoded video file.
