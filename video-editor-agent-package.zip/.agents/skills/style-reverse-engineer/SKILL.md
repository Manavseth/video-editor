---
name: style-reverse-engineer
description: "Reverse-engineer the editing style of any external creator from 1-3 reference video links using first-principles measurement. Downloads reference clips with yt-dlp, generates contact sheets with ffmpeg, transcribes with Whisper, and measures cuts/min (ASL), face-to-broll ratio, hex color palettes, typography, subtitle specs (height %, styling), SFX/music triggers, and hook pacing. Applies the 'Rule of 2' to filter out one-offs and outputs an approved Style Card (docs/style-card-<creator>.md) before editing."
---

# STYLE REVERSE-ENGINEER — first principles style extraction

> **THE GOLDEN RULE:** Never copy by vibes. Measure. If you cannot point to an exact number (cuts/min,
> font size as % of frame height, exact hex values, or millisecond SFX offsets), you are guessing,
> not reverse-engineering.

Use this skill whenever:
- The user provides 1–3 reference videos or links (YouTube, Instagram, TikTok) and says:
  *"Make it look like this creator"*, *"Copy this editing style"*, or *"Edit in the style of [Creator]"*.
- You need to produce a clean, verifiable **Style Card** (`docs/style-card-<creator>.md`) before
  cutting or styling footage.

---

## The 5-Step Reverse-Engineering Pipeline

```
1. INGEST         yt-dlp download ──► contact sheet (every 2s) ──► audio extraction & Whisper
2. MEASURE        cuts/min · face vs b-roll % · palette hex · subtitle geometry · sound dynamics
3. FIND THE WHY   derive the functional psychological purpose behind each pattern
4. RULE OF 2      only patterns appearing in ≥2 distinct videos become part of the style card
5. STYLE CARD     synthesize into docs/style-card-<name>.md and get the creator's YES
```

---

## Step 1 — Ingest & Fact-Gathering

Never analyze low-res previews or memory. Grab the clean source files:

```bash
WORK="work/style-refs/<creator>"
mkdir -p "$WORK"

# 1. Download highest quality video (up to 1080p)
yt-dlp -f "bv*[height<=1080]+ba/b[height<=1080]" -o "$WORK/ref_%(id)s.%(ext)s" "<URL>"

# 2. Generate a 2-second interval contact sheet (grid of 5x5 or sequential frames)
mkdir -p "$WORK/frames"
ffmpeg -y -i "$WORK/ref_01.mp4" -vf "fps=0.5,scale=540:960" "$WORK/frames/f_%04d.jpg"

# 3. Extract audio and transcribe with word timestamps
ffmpeg -y -i "$WORK/ref_01.mp4" -vn -ac 1 -ar 16000 "$WORK/ref_01.wav"
whisper "$WORK/ref_01.wav" --model small --word_timestamps True --output_dir "$WORK" --output_format json
```

---

## Step 2 — Measure, Don't Guess

Measure these 6 objective dimensions across the reference frames:

| Dimension | Metric / Measurement Method | Example Measured Value |
|---|---|---|
| **1. Pacing & Cuts** | Total cuts divided by duration in minutes = **cuts/min**. Average Shot Length (ASL) in seconds. | 42 cuts in 50s = **50.4 cuts/min** (ASL = 1.19s). |
| **2. Screen Share** | Count frames with talking head vs. B-roll / screen capture / full-canvas graphics. | **35% talking head**, 45% screen recording, 20% motion graphics cards. |
| **3. Typography & Subtitles** | - Font classification (sans, serif, monospaced, rounded).<br>- Size as **% of frame height** (target ~4%).<br>- Casing (UPPERCASE vs lowercase).<br>- Word batching (1–3 words vs full sentence).<br>- Animation (pop, wipe, fade, static highlight). | Montserrat Black, UPPERCASE, size = 4.2% frame height (80px on 1080x1920), 2-3 words/run, yellow active word pop. |
| **4. Color Palette** | Sample exact hex values from solid backgrounds, cards, and accent highlights using an eyedropper / ffmpeg pixel sampler. | Background: `#0F172A`<br>Card: `#1E293B`<br>Accent: `#FACC15`<br>Text: `#FFFFFF` |
| **5. Sound & Music** | - Music ducking level under speech (dB).<br>- When does music drop out (jokes, tension, CTA)?<br>- Which visual transitions get SFX (whoosh on slide, click on pop, riser on hook)? | Music sits at **-22 dB** under speech; hard cut to silence on joke punchlines; crisp click on list pops. |
| **6. Hook Anatomy (First 30s)** | What visual or audio event happens every 2–3 seconds in the first 30s to retain attention? | 0.0s zoom-out hook + sound boom<br>1.2s bold headline card<br>2.8s fast cut to b-roll punchline. |

---

## Step 3 — Find the "WHY"

For every visual pattern you observe, articulate its psychological or narrative function:
- *Bad analysis:* "He uses yellow subtitles and zooms in a lot."
- *First-principles analysis:*
  - *"Yellow highlight tracks the spoken semantic verb so the eye is pulled forward before the word is finished."*
  - *"Same-take jump cuts alternate 1.0x and 1.12x punch framing to disguise take resets without motion blur."*
  - *"Music drops out completely for 1.2s at second 14 to force attention onto the core thesis statement."*

---

## Step 4 — The "Rule of 2" (Filter Out One-Offs)

A stylistic habit is only valid if it appears in **at least 2 distinct videos** from the creator.
- If a sound effect or font appears once, mark it as an *experiment / one-off*.
- If a 2-tone subtitle or 1.15x punch cut repeats in both video A and video B, mark it as *house DNA*.

---

## Step 5 — The Style Card Output

Write the distilled findings into `docs/style-card-<creator>.md`. Present it to the user before cutting.

### Standard Style Card Template:
```markdown
# Style Card: [Creator Name]
**References Examined:** [URL 1], [URL 2]  
**Analyzed Date:** [YYYY-MM-DD]

## 1. Pacing & Rhythm
- Cuts per minute: [X] cuts/min (ASL: [Y]s)
- Headroom & framing: [e.g. Chest up, face centered at cx=0.50, cy=0.38]
- Head vs. Media ratio: [X]% talking head / [Y]% media

## 2. Palette & Geometry
- Canvas / Background: #HEX
- Card / Panel Fill: #HEX
- Primary Accent: #HEX
- Safe zone padding: Top [X]px, Bottom [Y]px, Sides [Z]px

## 3. Typography & Subtitles
- Subtitle style: [Select from 7 styles e.g. Style 6: Classic Viral or Custom]
- Font: [Family] [Weight]
- Case: [UPPERCASE / Sentence / lowercase]
- Height: [X]% of frame height ([Y]px at 1080x1920)
- Word density: Max [N] words per run
- Highlight rule: [Single semantic keyword in Accent Color]

## 4. Motion & Transitions
- Register cuts: [Hard cut / slide-in / paper drawer]
- Animations across cuts: NONE (Hard cuts only)
- Motion easing: [e.g. expo.out / power3.out]

## 5. Sound Design
- Music bed: [Ducked at -X dB / SFX only]
- Sound accents: [Whoosh on register slide, pop on tag, risers on hook]
- Silence points: [Cut music on punchlines]
```

Stop and ask: *"Here is the measured Style Card for [Creator]. Does this match the look and feel you want to replicate before I start the edit?"*
