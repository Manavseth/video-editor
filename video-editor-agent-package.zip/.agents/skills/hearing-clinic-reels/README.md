# Minimalistic — the clinic's code-drawn Reel style (skill package)

The named house style **Minimalistic** — a flat, code-drawn, voice-synced diagram
explainer — plus the skill that governs it and everything needed to build in it.

Vertical 9:16 · 1080 × 1920 · 30 fps · palette-tokened canvas drawing · captions
locked to the creator's real voice · no shot over 4.0 s.

## Contents

```
minimalistic-video-style/
├─ README.md                        ← you are here
├─ skills/                          ← install ALL THREE, as siblings
│  ├─ hearing-clinic-reels/         THE skill: style law, standing brief, workflow,
│  │                                QA runner + visual-critique rubric incl. the
│  │                                permanent visual-communication gate (9 principles)
│  ├─ reel-editing-knowledge-bank/  REQUIRED dependency (referenced as ../…)
│  └─ prompt-motion/                required design reference for code animation
├─ style-ground-truth/              the as-built sources the style law points at
│  ├─ environmental_classifier_piece_template.html   master template (as-built v3)
│  ├─ chl_piece.html                episode-01 as-built: helper library, caption plate,
│  │                                connector/stamp/pill engine — copy these helpers
│  ├─ chl_render.mjs                deterministic frame renderer (napi-canvas + ffmpeg pipe)
│  ├─ environmental_classifier_reel_style_system.md style system write-up
│  └─ style_test_chl/               episode-01 proof render + 15 QA stills
└─ example-episode/                 worked example: latest episode (Rev 3 clinical pass)
   ├─ storyboard.md                 fully self-contained director board — demonstrates
   │                                the gate, clinical-chart conventions, asset bible
   └─ shots.json                    17-shot machine manifest (schema v1)
```

## Install

1. Copy the three folders inside `skills/` into your skills root **keeping them
   siblings** — `hearing-clinic-reels` references
   `../reel-editing-knowledge-bank/references/source-knowledge-bank.md` and
   `../prompt-motion/SKILL.md` by relative path.
2. Load `hearing-clinic-reels/SKILL.md` as the entry point; it pulls the others in.
3. Requirements: Node ≥ 18 (a `@napi-rs/canvas` equivalent, or the browser canvas
   inside the piece HTML), and ffmpeg for the mux
   (`-fps_mode vfr`, not the deprecated `-vsync`).
4. The style-ground-truth files are referenced by name in SKILL.md
   (`environmental_classifier_piece_template.html` = "the master template",
   `chl_piece.html` = "the as-built ground truth"). Keep them reachable; if your
   install moves them, update those two names in the skill text.

## The laws that make this style work

- **Palette tokens only.** paper `#F5F2EA` · ink `#20252B` · teal `#2D8C85` (the one
  accent) · gray/light/rule neutrals · `denyRed` `#D04B46` reserved for ✕ denial
  strokes and pain bursts. No gradients, no shadows, no unexplained blobs.
  (One sanctioned exception: a user-approved real asset such as the platform 🧠 emoji.)
- **4.0-second cap.** Every scene/shot ≤ 4.0 s; purposeful 2–4 s beats, one focal
  action each; hard cuts; every scene re-introduces its objects settled on frame one.
- **Voice is master.** Captions verbatim from the creator's own recording / SRT —
  never rewritten, never TTS. Animations key to exact spoken-word timestamps, kept
  in ONE word-beat table so re-sync touches a table, not scene code.
- **Visual-communication gate (permanent).** Before finalising any scene:
  *"If someone sees this visual without hearing the audio or reading the captions,
  will they be able to understand what it represents?"* — assumed viewer has zero
  context. The nine permanent principles (spoken-concept→visual port; visuals
  self-sufficient; assets immediately recognisable, real assets when code drawing
  can't; animations explain; mobile-readable text; refine don't redesign; canonical
  clinical/anatomical drawing over random shapes; consistency of repeats; chart
  conventions outrank decoration) live in the skill and its critique rubric.
- **Deterministic rendering.** `render(f)` is a pure function of the frame number;
  same f → same pixels. QA = fixed key-frame still set inspected by a human-like
  dumb-watch review + a scripted deterministic checker, both run after every render.
- **Escalation.** When a scene is approved by the creator, refine it in place —
  scope, palette, characters, and helpers persist across episodes.
