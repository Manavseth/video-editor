# Visual critique and automatic repair loop

Use this after every render and after every visual code change. Inspect every contact-sheet page and every shot sample, not just a few representative scenes. The aim is a coherent, clear, intentional-looking video. The checklist is a review lens, not an exhaustive list of all possible visual defects.

## Review every shot for

1. **Human and animal drawing:** facial features are present, paired where expected, placed plausibly, and consistent with the character's view angle; expressions read as intended; ears, hands, limbs, and joints do not merge, disappear, duplicate, or detach. Hair, clothing, and body silhouettes look deliberate and coherent with the character. Do not require a particular hairstyle unless the creator asked for it.
2. **Object construction:** every device, prop, icon, vehicle, and diagram reads as the thing intended; scale and orientation make sense; parts connect; nothing floats, duplicates, clips, or changes shape unexpectedly. Avoid accidental dots, blobs, rings, and decorative shapes that suggest an unexplained accessory or medical signal.
3. **Meaning and emotional tone:** the image clearly illustrates the line being spoken; metaphorical marks are understandable and don't imply a clinical measurement. Show listening difficulty with dignity. No magical cure, guaranteed outcome, mockery, panic, or patronizing portrayal.
4. **Composition and layering:** faces, hands, hearing devices, and important props stay visible. Captions and titles do not cross faces, collide with objects, compete with action, run off-screen, or enter phone interface zones. Check text at full-resolution phone scale, not only as a contact-sheet thumbnail.
5. **Visual hierarchy and legibility:** each frame has a clear focal point; color contrast, caption breaks, line weight, spacing, and typography remain readable; the scene is not cluttered or accidentally empty. No image contains cropped/garbled labels, tiny unintentional text, or pseudo-product UI that could be mistaken for a real branded interface.
6. **Continuity and motion:** a character's identity, clothing, proportions, device placement, palette, and drawing style remain consistent across cuts. Motion is smooth and motivated. Motion graphics travel through the environment or attach to a meaningful object; they do not accidentally cover a face. Check that a scene's entrance and exit frames do not reveal a leftover, partial, or one-frame element.
7. **Reference discipline:** the result uses broad visual qualities only. It does not reproduce a reference creator's likeness, exact staging, script, symbols, or distinctive scene composition.

For creator footage, also confirm the face remains natural and undistorted, the crop feels intentional, the eyes and mouth stay unobstructed, and visible speech matches the supplied recording. Preserve the original voice and identity; place code-drawn graphics beside or around the host rather than across facial features.

## Concept gating — cover every spoken idea, visually

After every render, run a **dumb-watch pass**: mute the audio and hide the captions, then list the important concepts spoken in the Reel in order. Every listed concept must have at least one visible, meaning-bearing element on screen during (or just before) the moment it is spoken. If a concept survives only inside the caption text or the voice, the picture is not finished.

Frame every scene with the **blind-viewer question**, the creator-authored gate this pass exists to enforce:

> **"If someone sees this visual without hearing the audio or reading the captions, will they be able to understand what it represents?"**

Assume the viewer has absolutely no context — they can only see the picture on screen. The visual itself must communicate the intended concept as clearly as possible. A scene whose meaning needs the caption or the narration attached is unfinished; the fix is usually the asset itself (a recognisable object, a properly drawn chart, a real approved asset), not more on-screen text.

Apply these permanent principles (creator-authored quality-control law; valid for every future project, not corrections tied to one video):

1. **Concept-to-visual port (the sound-extra test).** Abstract nouns the script depends on — sound, noise, echo, pain, pressure, clarity — need a drawn agent, not just figures or speech boxes. When the topic is literally *sound*, a sound motif (radiating wave arcs, a travelling sound chip, vibrating marks) must appear the first time it is spoken. Waves that travel with the moving element, or change state with it (dim in, turn teal as the chip moves out), also *explain* flow direction — draw that state change rather than a static decoration.
2. **Sensation visuals.** Internal sensations (heavy/muffled, blocked, echo, pain) get a visible proxy: waves that weaken between source and head, a pressure ring around the head, repetitions of the same bubble fading along a loop (echo), a pulsing red cluster at the affected spot (pain). Keep the proxy inside the existing composition — add supporting elements, do not replace the scene.
3. **Recognition test.** Every prop or icon must be identifiable at first glance at phone scale. Ambiguous prototypes (a circle on a stick) fail: use the canonical recognisable form with enough defining attributes (for example a cotton bud: double puffy cotton heads on a narrow white shaft, plus an ear context if the message is about inserting it). If a first-glance viewer might say "microphone", "lollipop", or "maze", redraw it. When a code-drawn approximation cannot reach first-glance recognition, stop polishing the abstraction and switch to a user-approved **real asset** (a proper illustration or the matching platform emoji drawn via canvas fillText). The brain is the standing precedent: the abstract ellipse-with-folds failed this test, and the 🧠 emoji was the approved replacement — applied at every appearance, not just the first.
4. **Animation explains, not decorates.** Each animation must demonstrate cause, flow, repetition, or state. An echo is shown as *repetition* (ghost copies fading back along the path), a block as *interruption* (a stamp or a fade), pressure as *pulsing*. Pure motion on an inert object is a defect, not a style.
5. **Minimum readable text.** Result pills, tag pills, and label bars are content, not texture: keep punchline text comfortable at phone scale (target ≥ 22 px at 1080-wide canvas for result/tag pills; grow the pill with the text instead of shrinking the text). Never let a long word cross the pill border.
6. **Refine over redesign.** When a scene's composition already works, add or tune the smallest possible set of elements (a motif, a pulse, a bolder text size). Do not restructure, re-stage, or replace a working scene to chase polish. Only redesign when the composition itself communicates the wrong idea.
7. **Visual proportions, alignment, spacing, and intentional polish.** Every composition must look balanced and deliberate. An illustration enclosed in a circular halo or container must have balanced padding (target ~25–35% breathing margin); the enclosed asset must NEVER awkwardly touch, clip, or protrude past its boundary ring. Traveling chips, entrance notches, and connecting lines must share the exact same transit axis (e.g. gate notches align vertically with the chip flight path so items enter directly through the gate, rather than missing it).
8. **Clinical and anatomical accuracy — no random-geometry approximations.** An anatomical or clinical object (brain, ear, cochlea, hearing aid, audiogram) must be drawn in its canonical, recognisable form with its defining attributes. NEVER approximate it with arbitrary geometric shapes: an ellipse plus a few curves does not become a brain, and a scatter of marks does not become an audiogram. If code drawing cannot make the object immediately recognisable, use the creator-approved real asset instead (principle 3). Scientific and clinical illustrations must stay visually and conceptually accurate — the viewer's understanding outranks the illustration's convenience.
9. **Consistency of repeated concepts.** The same spoken concept uses the same asset, proportions, and behavior at every appearance; a revisit changes only its state (meter fill, pulse rate, plotted data), never its identity. A recurring card must remain unmistakably itself at every scale and in every scene it returns to.
10. **Clinical data obeys real chart conventions.** When the visual represents clinical data (the audiogram is the standing example), plotting correctness outranks decoration: use the discipline's actual axis conventions (dB HL inverted — 0 dB at the top, louder downward), plot the data at the standard positions (six frequencies 250/500/1K/2K/4K/8K), keep ONE symbol type per curve exactly as clinical practice does (O = one curve; never mix O and X decoratively), connect one curve's points with ONE continuous line, and label the axes/ticks so the chart alone reads as the chart. Data, axis labels, and decorations move independently and only data moves with the data. If numeric labels fall below readable size at a reduced card scale, suppress the numbers but keep the full convention (grid, pills, plot, symbols) intact.

Where the fix is unclear, ask the creator one narrow question about the intended sensation or metaphor before drawing.

## Classify findings

- **BLOCKER:** malformed or misleading imagery, a visible collision/occlusion, a hard timing/spec violation, unreadable essential text, or a visual that undermines the message or dignity of the subject. Must be fixed and re-reviewed.
- **FIX:** an obvious awkward, confusing, inconsistent, or unintended detail that materially weakens the scene. Fix before delivery.
- **NIT:** a small optional polish whose correction is preference-dependent and does not impede understanding. Apply it when the fix is clear and low-risk; otherwise list it for the creator.

For each finding, report the shot ID, timestamp/frame, evidence, why it is a problem, and a concrete source-code change. Do not invent findings to fill a quota. Say **clear** when a full pass finds no actionable issues.

## Repair loop

1. Read the deterministic QA report and contact-sheet index. Confirm every scene and cut is represented.
2. Visually inspect all samples. On a suspected defect, open its original-size frame and inspect adjacent moments or the cut boundary.
3. Translate the finding into a source-level repair: adjust geometry, drawing order, scale, easing, palette, caption position, label wording, or timing as appropriate. Keep the user's script, factual meaning, and code-drawn requirement intact.
4. Render the changed shot or complete Reel, whichever is needed to expose the fix. For timeline-wide changes, render the full video.
5. Run the deterministic checker again, regenerate all samples, and repeat the full visual inspection. Do not accept a repair based only on the changed frame; check its scene and adjacent cuts for regressions.
6. Continue while clear, actionable defects remain. Ask one narrow question only when a remaining choice depends on the creator's taste, missing facts, or clinical intent, and show the exact frame and proposed alternatives.

## Known regression examples

These examples are useful checks, not the limit of the critique:

- a drawn person with one eye, a duplicated eye, or facial features that read as misaligned;
- concentric sound marks sitting on hair or forehead, where they read as Wi-Fi or an unexplained medical signal;
- detached circles or shapes on hair that read as ornaments;
- a hearing aid that sits on the cheek or reads as an unrelated earpiece;
- a sound wave crossing the eyes or mouth;
- caption bars crossing faces or the phone-safe reading area;
- a spoken concept whose visual agent is absent (or only implied by the caption) at the moment it is said;
- a prop or icon that cannot be named confidently at first glance at phone scale;
- an illustration or icon disproportionately large or small compared to its enclosing container or halo, causing awkward contact, clipping, or protrusion past the circle (e.g., the brain emoji protruding past its surrounding breathing ring);
- an entrance gate or receiving notch misaligned with the transit axis of incoming connector lines or traveling chips (e.g., chips flying at y=772 while the notch sits at y=694);
- an anatomical or clinical object drawn as an arbitrary shape-collection (ellipse + folds for a brain) that a first-glance viewer cannot name — the abstract brain that had to be replaced by the approved 🧠 emoji asset (Rev 3, audiogram episode);
- a clinical chart that scatters mixed symbol types (O and X together) or unconnected arbitrary marks, instead of one symbol type per curve plotted at the standard positions and joined by one continuous line — an "audiogram" that reads as decoration, not data (Rev 3);
- a clinical chart missing its axis conventions and labels (audiogram: inverted dB scale 0 top → louder bottom, six frequency ticks), so it could be any grid;
- a group slide of plotted data that moves labels, axes, or decorations together with the data, instead of only the symbols + connecting line;
- two recurring cards shown together whose identities are not readable on sight (the S13 two-up that had to become "recognisable audiogram + 🧠 brain", self-explanatory without audio);
- punchline or result text smaller than comfortable phone reading size;
- essential numeric labels shrunk below ~16 px rendered at 1080-wide instead of being suppressed at small card scales (keep the chart convention, drop the tiny numbers);
- any scene longer than four seconds.

The Minimalistic style does **not** impose a universal hairstyle. Review hair as part of the overall silhouette, identity, and drawing quality for that character.
