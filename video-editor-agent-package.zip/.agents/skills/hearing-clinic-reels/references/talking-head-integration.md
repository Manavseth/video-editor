# Integrating the creator's talking head

Use this mode when the creator supplies their own on-camera footage or a separate recording of their voice. The goal is for viewers to recognize and trust the clinician while the code-drawn scenes make the explanation easier to picture.

## Choose the recording mode

- **On-camera master (preferred when the creator records the script to camera):** keep the camera audio synchronized during host shots; when animation replaces the picture, continue that same original voice track underneath it.
- **Separate voiceover master:** use the supplied recording as the continuous narration. Use on-camera clips only where speech is synchronized, or where the creator is visibly listening or gesturing without mismatched mouth movement.
- **Both recordings:** select the cleanest take for each spoken line, make edits at phrase boundaries, and preserve consistent room tone and level. Do not stack duplicate speech tracks.

The face moments establish a personal connection; animated cutaways carry the explanation. A useful starting arc is an on-camera hook, animation for the feature or listening situation, a return to camera for the practical caveat or next step, then a personal close. Rearrange this when the script calls for a different emotional flow.

## Recommended visual rhythm

Use full-frame host footage and full-frame code-drawn scenes as two complementary registers. Avoid a permanent small face box unless the creator asks for a split-screen format; it shrinks the face and competes with the illustrated scene.

- Open with the creator on camera for the personal hook or question.
- Cut to code-drawn scenes when the narration describes a listening situation, device feature, sound path, or abstract process.
- Bring the creator back for interpretation, a realistic caveat, or a direct-to-viewer next step.
- End with the creator for the practical close or clinic identity once supplied.
- As a starting point, keep the creator visible for roughly one-third to one-half of the Reel, with at least an opening, a middle return, and a closing presence. Adjust this to the story; it is not a fixed quota.
- Keep the audio continuous across visual cutaways when the spoken passage flows naturally. Cut at sentence or phrase boundaries when the meaning changes. Avoid cuts that make a word, breath, or facial expression look accidental.
- The permanent four-second cap applies to live-camera shots too. A host may return more than once; use purposeful cutaways or a new camera moment rather than leaving one visual scene unchanged for a long monologue.

## Simple 45-second example

This illustrates the pattern, not a required template:

| Time | Picture | Voice |
| --- | --- | --- |
| 0–3 s | Creator, eye contact, short empathetic hook | Creator speaks on camera |
| 3–6 s | Code-drawn quiet conversation | Same voice continues |
| 6–9 s | Creator names the concept | Creator on camera |
| 9–12 s | Code-drawn classifier and listening-scene icons | Same voice continues |
| 12–15 s | Animated quiet conversation | Same voice continues |
| 15–18 s | Animated group conversation with competing sound paths | Same voice continues |
| 18–21 s | Code-drawn music/car examples | Same voice continues |
| 21–24 s | Creator explains that devices and fittings differ | Creator on camera |
| 24–28 s | Code-drawn feature adjustment with a clear, restrained motion | Same voice continues |
| 28–32 s | Family scene showing that group listening may remain hard | Same voice continues |
| 32–36 s | Creator gives a practical, qualified next step | Creator on camera |
| 36–40 s | Code-drawn note-taking or listening-setting recap | Same voice continues |
| 40–45 s | Creator closing; optional name, role, clinic and CTA | Creator on camera |

All scene lengths in this example are 2–4 seconds. A real script may call for fewer or more returns; preserve the cap and let the story determine the alternation.

## Recording checklist

Ask for the original camera file, not a screen recording or a social-media download. If available, record vertical 9:16 at 1080p or higher and 30 fps. Keep the camera near eye level, use soft light on the face, choose a quiet room, and use a lavalier or close microphone to reduce room echo. Keep the background simple and the face large enough to read on a phone.

Frame the creator with some clean space beside or below them only if the planned graphics need it. Do not place text over the eyes, mouth, or hearing device. Avoid excessive headroom, backlighting, beauty filters, digital face restyling, and unnecessary zooms. Keep the person's appearance natural and consistent across recordings.

If the creator is reading a full script on camera, preserve that take's synchronized voice track and place the code-drawn cutaways over the picture while the same audio continues. If the creator records separate voiceover, use that exact file as the master narration. Avoid recording duplicate takes with mismatched room tone unless there is a clear reason.

If a silent design review is needed, make a muted proof and label it as such. For the publishable version, align every caption to the supplied recording, not to estimated script timing. Never synthesize speech.

## Personal branding

Use the creator's face and voice as the primary identity. Once supplied, introduce name and professional role in a small, stable lower-third during a clear host moment; reserve the end for clinic name, logo, contact route, and a simple CTA. Keep these elements consistent across episodes, and avoid repeating a large logo over every illustrated scene.

Do not invent credentials, clinical titles, clinic claims, or contact details. Use the spelling, credentials, colors, logo, and CTA exactly as the creator supplies them. Until then, leave the brand lockup out rather than filling it with a placeholder.

## Picture and sound checks

- Match the code-drawn palette and texture to the live footage with lighting and restrained transition elements; don't put the illustration's texture over the creator's face.
- A recurring sound line can leave the illustrated world at a cut and appear beside the host, then lead into the next drawing. Keep it away from the eyes and mouth so it cannot look like a clinical signal.
- Keep captions in a consistent lane that does not cover faces or hands. Use short phrase groups and sufficient contrast.
- Check the actual recording for framing, focus, clipping, echo, and sync. If graphics are placed beside or behind a person in-camera, measure the source framing before layout; never guess the safe head area.
- Recheck every live/animated cut for a one-frame flash, frozen face, audio discontinuity, caption collision, abrupt crop, or mismatch between the spoken line and the picture.
