# Production workflow learned from the first clinic Reel

This procedure captures the successful decisions and correction loop from the first code-drawn Reel about environmental classifiers in hearing aids. Keep its durable rules; adapt story and scene design to the next script.

## 1. Intake and reference study

The creator defined the audience as long-term hearing-loss patients who struggle to follow conversation or feel left out, along with adult children concerned about a parent's well-being. The first Reel was requested at 40 seconds. The creator would record their own narration later, so the look-development cut had captions but no voice or text-to-speech. The visual artwork had to be created entirely in code. No clinic identity was available, so the video used no logo or clinic name.

Seven example Reels informed the broad treatment: full-frame vertical scenes, illustrated people, painterly light, a warm storybook palette, gentle movement, and short serif captions. The clinic's style bible deliberately excluded the references' scripts, characters, symbols, exact compositions, and subject matter. When reference playback did not expose audio, the style analysis did not infer a music or sound-effects treatment.

## 2. Script and factual guardrails

The topic was environmental classification in hearing aids. The draft was about 90 words and followed a quiet-chat-versus-family-dinner hook, a plain-language explanation of scene classification, everyday examples, qualified examples of automatic processing, a limitation, and a practical suggestion to discuss difficult settings with a hearing care professional.

The claims were checked against manufacturer documentation and research. The classifier was described as estimating a listening situation; device behavior was qualified because implementation and fitting vary. Benefits were phrased as possibilities, not guarantees. The script retained the caveat that difficult group conversations can remain hard. These were source-backed content decisions, not a license to make medical recommendations.

For future scripts, keep the user's own authored words unless asked to revise them. A script drafted from a topic still needs a fresh claim audit before drawing scenes.

## 3. Scene plan and code build

The 40-second cut used 13 scenes: twelve 3-second beats and one 4-second beat. The plan named each visual and its continuing motion. The actual project kept the canvas scene code in `piece.html`, the frame-by-frame FFmpeg renderer in `render.mjs`, captions in SRT, and the shot plan in `REVISION-ASSET-PLAN.md` / `shots.json`.

The timeline covered a family conversation, a device close-up, classifier examples, automatic feature adjustment, a still-difficult group conversation, and a professional follow-up. Every final visual was drawn on Canvas. Reuse this pattern where it helps, not necessarily these scenes.

## 4. Review and revision loop

The first visual review found issues that were visible only by inspecting the frames: character faces had incomplete eyes, the older listener's hair silhouette and floating marks read strangely, a child's unexplained hair shapes looked like ornaments, and sound rings sat on heads. Later inspection found captions crossing the face area and sound waves crossing the face in a close-up. Those were fixed in the code, not painted over in a raster export.

The close-up review then found that the hearing aid read as a square earpiece and a bright hair stroke looked like an accessory. The device was redrawn with a compact body, hook, and tip; the bright stroke was removed. The cut was rendered again and reviewed again. The final reviewer confirmed clear faces and captions, readable device placement, and scenes within the four-second limit.

The lesson is general: inspect the rendered composition at phone scale, inspect key details at full resolution, repair source code, then rerender. Do not stop after a successful render command. Do not limit critique to this historical list; use the broader rubric in [visual-critique.md](visual-critique.md).

## 5. Repeatable output set

For each new Reel, keep a project-local set such as:

- `piece.html` or equivalent editable code-native artwork;
- `render.mjs` or the existing project renderer;
- `shots.json` with contiguous cut times and one moving-element description per scene;
- the silent review MP4 and any separate caption SRT;
- the QA report, review index, sampled frames, and contact sheets.

When the user supplies their own recorded voice, create a voice-aligned caption pass and a final muxed version separately from the silent proof. Never synthesize a voice.

## 6. New hybrid mode: creator footage plus code-drawn scenes

The creator later clarified that future Reels should pair their own talking-head video and voice with the illustrated scenes, so viewers associate the clinic page with their face and branding. This supersedes the first Reel's code-only picture constraint for future hybrid work: the creator's own camera footage is now an approved visual source; the illustrative worlds, diagrams, graphics, and transitions remain code-drawn. Stock footage and generated voices remain excluded.

Keep the narration continuous over cutaways when it helps the explanation. Return to the creator for the hook, clinical interpretation, realistic limitation, and closing next step. Let the creator occupy roughly one-third to one-half of the duration as a flexible starting point. Keep each live or animated shot within the same four-second cap. See [talking-head-integration.md](talking-head-integration.md) for recording, branding, and transition guidance.

When the creator supplies a talking-head take, add it as a `creator-talking-head` shot source in `shots.json`; mark every illustrated beat `code-drawn`. The technical reviewer validates these source labels, while the visual pass verifies that the live framing, face, captions, and adjacent illustration cuts actually work. The user recording's own audio is authoritative. If speech is baked into the camera clip, preserve sync through picture cutaways; if voiceover is separate, use only the file the creator supplies. Align captions to the real delivered audio.
