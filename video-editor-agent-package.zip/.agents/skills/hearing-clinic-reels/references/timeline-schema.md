# Shot timeline manifest

The deterministic reviewer takes a JSON manifest that describes the intended scene cuts. The manifest is the source of truth for maximum shot duration and sample-frame planning.

## Fields

- `version`: currently `1`.
- `expectedVideo`: optional render expectations. Defaults are 1080 × 1920, 30 fps, and silent output.
  - `width`, `height`, `fps`: expected technical output.
  - `audio`: `silent` to require no audio stream, or `user-voice-or-silent` to allow the creator's recorded voice or a silent proof. Generated text-to-speech is never permitted by the skill.
- `shots`: ordered scene list. Each item needs a unique `id`, `start`, `end`, `visualSource`, a visual `description`, and a `motion` description.
  - `visualSource`: `code-drawn` for code-created illustration/graphics or `creator-talking-head` for the user's own camera footage. Do not use this field to authorize stock or generated footage.

Times are in seconds. Start at zero. Shots must be ordered, contiguous, non-overlapping, and end at the render duration. No shot may exceed the Minimalistic style's fixed **4.0-second maximum**. The script checks the structural timeline; the visual critique separately verifies that the described motion is visible and that cuts look clean.

## Example

```json
{
  "version": 1,
  "expectedVideo": {
    "width": 1080,
    "height": 1920,
    "fps": 30,
    "audio": "silent"
  },
  "shots": [
    {
      "id": "S01",
      "start": 0,
      "end": 3,
      "visualSource": "creator-talking-head",
      "description": "A parent follows a quiet one-to-one conversation",
      "motion": "The speaker gestures and the listener shifts gaze."
    },
    {
      "id": "S02",
      "start": 3,
      "end": 6,
      "visualSource": "code-drawn",
      "description": "A family dinner becomes harder to follow",
      "motion": "Two speakers take turns while separate sound lines travel laterally."
    }
  ]
}
```

The first production's full 13-shot manifest is `clinic-style-test/episode-01-environment-classifier/shots.json` in the workspace.
