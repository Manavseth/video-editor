# Audiogram Part 1 — Super-Detailed Director Storyboard (Minimalistic style)

**Status:** Handoff board for an external build agent. Timing is locked to the supplied SRT and must stay exactly there. The director produces **no render** — the build agent renders code-drawn picture only, then muxes the creator's part 1 voice once its file path is supplied (mux spec in §10.7; force-alignment rules in §8.4).
**Rev 3 (clinical-accuracy pass):** audiogram rebuilt to recognisable chart conventions — single symbol type (O only), exactly six symbols at six frequency positions, one continuous connecting line, labelled axes (dB scale + frequency ticks) so the chart alone reads as an audiogram; brain replaced by the user-approved 🧠 asset everywhere it appears; S13/S17 two-card and final card upgraded to be self-explanatory without audio.

**Companion manifest:** `shots.json` (17 code-drawn shots, contiguous, all ≤ 4.0 s, ending at 48.000 s, `audio: user-voice-or-silent`) lives next to this file and is the deterministic-reviewer source of truth for cut order.

## 1. Project lock

- **Format:** Instagram Reel, vertical 9:16, 1080 × 1920, 30 fps.
- **Runtime:** 47.95 s of narration + 0.05 s closing hold = **48.000 s = 1,440 frames** (NF=1440).
- **Narrative arc:** clinic test → the graph gets its name → symbols on the graph → what the graph costs the brain daily → the inverted dB axis → thresholds fall → normal speech needs more volume + clarity → the brain decodes by working hard → the clinic quote → the test diagnoses process state → part 2 teaser.
- **Picture register:** 100% code-drawn Minimalistic motion, with ONE user-approved exception: the brain emoji asset (§3 A04). No talking-head windows, no stock, no generated footage, no product screenshots, no brand marks.
- **Audio:** the creator's part 1 recording (path pending) is the master voice. **No TTS, ever.** No music bed and no SFX — the piece runs on voice over quiet paper.
- **Scene cadence:** 17 scenes, every one ≤ 4.0 s (4.0 s hard cap; beats run 1.9–4.0 s).
- **Source authority:** `audiogram part 1.srt` (21 cues, verbatim, timings untouched). Everything a builder needs is inside this document — palette hex, type, helper contracts, card geometry, frame-exact beats, caption code, QA lists. No other reference file is required.

## 2. Creative direction

### Viewer takeaway

An audiogram is the graph the audiologist hands you after a hearing test. Its symbols plot pitch and volume, its dB axis is inverted (0 dB at top, loud at bottom), and when threshold symbols fall down the chart, normal conversation costs more volume, more clarity — and more daily decoding effort from the brain. A person can hear and still not understand; the test shows whether the brain processes speech smoothly or guesses itself tired.

### Visual approach

Two recurring anchor objects carry the whole episode:

1. **A02 — The Graph Card.** First handed over as a recognizable BLANK audiogram form — axes, labelled ticks and grid already in place (S02), then the six-symbol threshold plot grows in (S03), the axis inversion is demonstrated (S06), the thresholds fall (S07–S08–S09), the test links to the brain (S13), and the card returns as the part-2 promise (S16–S17). Every visit keeps the full chart convention so the card alone says "audiogram"; only the state changes, never the base geometry (§10.5 gives the parametric spec).
2. **A04 — The Brain Card.** The effort anchor: introduced as the decoder of normal speech (S04), metered daily (S05), receiving the clarity chip (S10), linked from the test (S13), compared in smooth (S14) vs guessing (S15) states. Every visit shows the SAME recognizable brain asset — the platform 🧠 emoji, user-approved because the abstract ellipse version failed first-glance recognition. Only pulse rate, meter fill, and content chips change.

Every scene fits the situation → action → result trio: recognizable object on frame one, one visible cause-and-effect action, readable resolved hold. No scene survives on a label alone (concept gating; checklist in §10.6).

### Hard laws

- Palette tokens only (§4). `denyRed` is reserved for the ✕ in S12 — nothing else.
- Punchline pill text ≥ 22 px. Display stamps ≤ 1 per scene. Captions verbatim, teal highlight tokens only.
- One focal action at a time; hard cuts only; every scene re-introduces its objects settled on frame one (the S16→S17 teaser card is the single sanctioned exception — it is *already mid-motion* at the cut, driven by one shared function both scenes read).
- Motion always motivated: axis inversion is demonstrated, not recited; falling thresholds physically slide; effort is metered and repeated; guessing is a broken loop. Static poster frames are defects.

## 3. Reusable asset bible

Spoken nouns without an image here stay narration-only. No new visual nouns during build.

- **A01 — Clinic room card.** White rounded card (r28, ink border 3). Inside: floor line (light, lw4), an ink desk (top segment lw5 + two legs lw4), two generic figures drawn with the `figure()` helper: patient figure (ink) and audiologist figure (ink, slightly larger). One chip bubble for the audiologist's speech, one pale primary bubble for the patient. No faces, no gender, no décor.
- **A02 — The Graph Card (recurring).** White rounded card (r28, ink border 3) whose interior ALWAYS carries the recognizable clinical chart convention:
  - Vertical axis labelled top-down `0 · 20 · 40 · 60 · 80` (17 px gray 600, left label lane; 0 at TOP, 80 at bottom, no minus signs) with a horizontal grid hairline (rule, lw1.5) at each labelled level.
  - Horizontal axis with SIX frequency tick labels `250 · 500 · 1K · 2K · 4K · 8K` (17 px gray 600) under their ticks, a dotted vertical guide (rule, dash 2/6) rising from each tick, and one spaced `PITCH` caps label (17 gray) at the bottom-right of the tick row.
  - `0 dB` pale pill pinned OUTSIDE the plot at the top of the vertical axis; `LOUD ↓` pale pill pinned at the bottom mark — the inversion visible on first glance.
  - At compressed card scales (S13/S17 minis) 17 px numerics drop below mobile legibility → suppress ONLY the numeric tick labels at scales below ~0.55; grid lines, pills, plot and symbols remain (smallest rendered text ≥ 16 px, always).
  - States compose on this base: blank form (S02) → six-O plot (S03) → axis demo (S06) → falling plot (S07–S09) → compressed recognizable form (S13, S16–S17). The `AUDIOGRAM` display stamp is S02-only and never crosses a cut.
- **A03 — The O-symbol threshold plot.** EXACTLY SIX symbols — a single type, `O` (ink-outline circle r13, lw2.5 at full scale) — plotted at the six frequency ticks and connected through ONE continuous smooth line (teal, lw6, rounded joins) drawn through all six in frequency order. Plotted values in dB → relY = 0.06 + dB/80·0.82: 250→10 · 500→10 · 1K→15 · 2K→25 · 4K→40 · 8K→50 (plausible mild high-frequency slope). O and X are NEVER mixed, and ✕ is reserved for S12 only. No decorative scatter: the curve and its six points are the only marks on the chart.
- **A04 — The Brain Card (recurring).** White card (r24, ink border 3). Its interior centers the **brain emoji 🧠** drawn via canvas fillText (user-approved asset; the episode's ONLY multi-colour element — recognizability outranks palette monotony). Around it: the soft teal breathing ring (radius ≈ 132·(w/460), ±5 px, rate 1.0–2.8 by state; ±2 px deterministic jitter during the S15 break; +9 px arrival blip on gate entry). At the card bottom: the effort meter (pale rail 26 px + teal fill bar — fill amount is the ONLY expressiveness law: taller = more effort). On the card's left edge: the entry gate notch (pale, teal border, 22 × 48 full scale) with the teal arrival ring. No gears, no faces, and NEVER the former ellipse+blob abstraction.
- **A05 — Speech bubble chips.** Template bubble glyph family only: white `bubble()` (3 speech marks, tail down), pale `paleBubble()` (teal first dash), small `chipBubble()` (pale fill, teal + gray dash, gray tail), `mbubble()` (muted gray). One language, no new bubble styles.
- **A06 — Day tabs + effort meter.** Three plain rounded tabs in a row (white, rule border, r16), each holding a mini meter rail with a teal fill (35% → 55% → 75%). No calendar dates, no clock, no labels.
- **A07 — Axis-ruler chips.** `0 dB` pale pill (teal border, teal text 20 px) pinned to the top axis mark; `LOUD ↓` identical pill pinned at the bottom mark. Always present — together with the tick labels they are what make the blank chart legible as an audiogram.
- **A08 — Threshold line + reference.** A dashed light-gray reference line (lw2.5, dash 10/10) across the chart at the BASE plot level = the settle-state benchmark. A solid teal polyline (lw6) that draws through the six O marks and then slides down the chart as ONE grouped unit with the symbols (and the dB tick labels anchored to the axis — labels never move). Falling = one smooth downward slide, then settle.
- **A09 — Requirement pills.** Pale pills with teal border, **teal dot + INK bold text ≥ 22 px** (`ZYADA VOLUME`, `CLARITY`, `NORMAL BAAT-CHEET`). The generic template pill with teal text exists too (used for `SMOOTH` / `GUESS` in S14/S15) — keep the two variants distinct: A09 pills speak facts (ink text), status pills speak state (teal text).
- **A10 — Quote lockup.** Two large pills side by side: `SUN` (pale, teal border, teal dot — listening confirmed) and `SAMAJH` (pale, ink text) with the denyRed ✕ stamped across it (lw7, ±30 px arms). A thin light tail line + dot toward lower-left remembers the patient position of S11. Nothing else may compete in the card while it holds.
- **A11 — Guess loop.** Sentence chips travel the lane to the brain card's gate, break there, and fragment into 2–3 small `?` chips (r13 gray-outline circles holding a gray `?`) that bounce back halfway, fading. The loop repeats; the effort meter rises and pegs; the pulse ring jitters (±2 px, deterministic sine) instead of breathing smoothly. No sweat drops, no drooping figures.
- **A12 — Part-2 teaser hardware.** Display stamps `AGLI BAAR` and `EK GRAPH` (ink, mask-reveal, 44 px) plus the A02 card returning at final scale 1.04 in its fully recognizable audiogram state (chart + six-O plot + teal line), with three speech chips of growing size (tiny → mid → large, 2/3/4 wave arcs) popping on the plot's right half.

### Noun-to-asset map

Hearing test / clinic → A01; audiogram graph (chart convention) → A02; the six-symbol threshold plot → A03; brain/effort/decode (🧠 emoji) → A04; normal speech / speech processing → A05; roz (daily) → A06; 0 dB / loud → A07; thresholds → A08; volume+clarity need → A09; the patient quote → A10; guessing/tired → A11; part-2 promise → A12. No literal audiometer, headphone hardware, ear cross-section, or brand UI anywhere.

## 4. Engine constants (build agent must implement exactly)

### Palette (flat tokens; no gradients, no shadows, no blur)

```
paper      #F5F2EA   full background of every frame
ink        #20252B   display text, card borders, figures, axes, symbol marks
gray       #8B9298   kicker, sub-labels, fold lines, quiet wave arcs
light      #B5B7B2   muted bubbles, floor lines, dashed tails, fading ends
teal       #2D8C85   THE accent: threshold line, connectors, meter fills, rings,
                     gates, pill borders/leads, caption highlights
pale       #E7F2EF   pill/panel/meter fills, gate notch
white      #FFFDF8   card fills, caption plate fill
rule       #D6D3C8   rails, hairlines, grid dots, dashed reference line
denyRed    #D04B46   ONLY the ✕ over SAMAJH in S12
procInk    #1F242A   (available but unused in this episode)
warm       #F2F0E9   S04 left conversation panel fill
mutedFill  #EDECE7   mbubble default fill
```

`ochre` exists in the family but is **unused in this episode** (sun-disk token only). One sanctioned colour exception: the brain emoji (A04) renders in its own platform colours — user-approved for recognizability.

### Type

Font stack `'Segoe UI', sans-serif`. Default weight 600; display/heading/pill text 700.
Caption size 44. Heading kicker 24 (gray, letterspaced ~2 px/char) at y 317; heading title 54 (ink 700, centered) at y 380 — both STATIC members of each scene, never animated. Letterspaced caps are drawn char-by-char (deterministic; no letterSpacing property).

### Caption plate (the only overlay allowed over anything)

Fixed box x74 w856, r24, white fill, ink border 2.5; BOTTOM-anchored at bottom y 1606.
Top by row count (1/2/3 lines): 1502 / 1462 / 1451; row pitch 54 / 48; last-line baselines 1552 / 1582 / 1588. Words centered per line at plate center x501. Highlighted words: teal, weight 700; others ink 600. Plate enters ~cue start +0.15 s, leaves ~cue end −0.10 s (gone slightly EARLY when a cue end borders a cut).

### Easing / motion laws

- `easeOutCubic = 1-(1-t)^3` for every path/travel/draw/fill.
- `easePop` (~2% overshoot, ease-out-back s≈0.75) for chip/pill/stamp/tab landings only.
- Line draws 12–36 frames; card travels 40–80 px; pops land in ≤ 14 frames (stamps ≤ 14, ✕ ≤ 8, DECODE ≤ 8).
- Nothing crosses a cut except the S16→S17 teaser card (shared-function continuity, §7 S16/S17).
- `render(f)` must reset: transform, globalAlpha, composite op — then fill paper, draw scene, draw captions last.


## 5. Frame-accurate storyboard map

Frames start-inclusive / end-exclusive at 30 fps. 17 scenes, contiguous, terminating at frame 1440 (48.000 s). Cue times are locked; scene cuts may fall inside a caption cue without moving it.

| ID | Timecode s | Frames | Dur s | Picture | Cues |
|---|---|---|---:|---|---|
| S01 | 0.000–2.200 | 0–66 | 2.200 | Clinic test moment; hand-off chip travels | c1, start c2 |
| S02 | 2.200–5.740 | 66–172 | 3.533 | Graph card slides in, named `AUDIOGRAM` | rest c2, c3 |
| S03 | 5.740–9.200 | 172–276 | 3.467 | Six O markers stamp at the frequency ticks; one continuous curve draws | c4 |
| S04 | 9.200–12.350 | 276–370 | 3.133 | Normal conversation feeds the brain; meter to 35% | c5 |
| S05 | 12.350–14.980 | 370–449 | 2.633 | Roz: day tabs + rising effort meter | c6 |
| S06 | 14.980–18.200 | 449–546 | 3.233 | Inverted axis demo: 0 dB up, loud drops down | c7, c8 |
| S07 | 18.200–21.200 | 546–636 | 3.000 | Threshold line draws, then slides down | c9 |
| S08 | 21.200–24.350 | 636–730 | 3.133 | Normal-speech pill; dropline + louder-end arrow | c10 |
| S09 | 24.350–26.600 | 730–798 | 2.267 | Requirement pills: `ZYADA VOLUME`, `CLARITY` | c11 |
| S10 | 26.600–30.600 | 798–918 | 4.000 | Clarity chip travels into the brain; DECODE stamps | c12, c13 |
| S11 | 30.600–33.100 | 918–993 | 2.500 | Clinic moment: patient's bubble opens empty | c14 |
| S12 | 33.100–35.300 | 993–1059 | 2.200 | Quote lockup: `SUN` vs `SAMAJH ✕` | c15 |
| S13 | 35.300–37.200 | 1059–1116 | 1.900 | Graph + brain linked by a teal connector | c16 |
| S14 | 37.200–39.680 | 1116–1190 | 2.467 | Smooth state: sentence chips flow straight in | c17 |
| S15 | 39.680–43.100 | 1190–1293 | 3.433 | Guess state: chips fragment to `?`, meter pegs | c18 |
| S16 | 43.100–45.000 | 1293–1350 | 1.900 | `AGLI BAAR` stamp; graph card begins to rise | c19, start c20 |
| S17 | 45.000–48.000 | 1350–1440 | 3.000 | Card completes rise; `EK GRAPH`; growing chips; hold | rest c20, c21 |

Boundary array for any builder: `[0,66,172,276,370,449,546,636,730,798,918,993,1059,1116,1190,1293,1350,1440]`.

## 6. Word-beat table — the sync spine (W)

Every motion keyframe is keyed to an absolute frame in this ONE table so that a voice-file pass touches only the table, never scene code. **Exact** rows come straight from cue starts; rows marked **~** are proportional word estimates inside their cue (safe ±1–2 frames; to be verified against the real recording, tolerance ±6 frames / 0.2 s).

| Key | Frame | Spoken word / event | Source |
|---|---:|---|---|
| `graphStart` | 56 | c2 opens (1.880 s): hand-off chip begins | exact |
| `graphWord` | 99 | ~ 'graph' spoken in c2 | ~ |
| `audiogramWord` | 124 | ~ 'audiogram' in c3 (cue opens f114) | ~ |
| `pitchWord` | 190 | ~ 'pitch' in c4 | ~ |
| `volumeWord` | 206 | ~ 'volume' in c4 | ~ |
| `symbolsWord` | 226 | ~ 'symbols...' in c4 | ~ |
| `baatCheet` | 290 | c5 phrase head 'normal baat-cheet' | ~ |
| `roz` | 401 | ~ 'roz' in c6 | ~ |
| `gadha` | 428 | ~ 'gadha-mazdoori' in c6 | ~ |
| `zeroDb` | 450 | c7 opens: '0 dB' (f449.4) | exact |
| `loud` | 511 | ~ 'aur loud...' c8 (cue opens f501.6) | ~ |
| `neeche` | 533 | ~ '...neeche.' c8 | ~ |
| `girne` | 597 | ~ 'girne' in c9 (the fall trigger) | ~ |
| `matlab` | 648 | ~ 'to iska matlab...' c10 | ~ |
| `volume` | 746 | ~ 'zyada volume' c11 | ~ |
| `clarity` | 767 | ~ 'clarity' c11 | ~ |
| `dimaag` | 825 | ~ 'dimaag' c12 | ~ |
| `mehnat` | 861 | ~ 'mehnat' c13 | ~ |
| `decode` | 882 | ~ 'decode' c13 | ~ |
| `clinic` | 934 | ~ 'clinic' c14 | ~ |
| `bolte` | 978 | ~ 'bolte ho:' c14 | ~ |
| `sun` | 1005 | ~ 'sun' c15 | ~ |
| `samajh` | 1038 | ~ 'samajh' c15 | ~ |
| `samajhX` | 1050 | ~ the deny lands ('nahi') c15 | ~ |
| `brain` | 1100 | ~ 'brain' c16 | ~ |
| `smoothly` | 1134 | ~ 'smoothly' c17 | ~ |
| `guess` | 1227 | ~ 'guess' c18 | ~ |
| `thak` | 1251 | ~ 'thak' c18 (meter flash trigger) | ~ |
| `agliBaar` | 1305 | ~ 'Agli baar' c19 (cue opens f1293) | ~ |
| `teaserCard` | 1335 | c20 opens (44.500 s): card rise begins | exact |
| `ekGraph` | 1360 | ~ 'graph' c20 | ~ |
| `duniya` | 1400 | ~ 'duniya' c21 (cue opens f1392) | ~ |
| `kitni` | 1414 | ~ 'kitni' c21 | ~ |
| `loudEnd` | 1425 | ~ 'loud' c21 (largest chip pops) | ~ |

Exact cue-open frames for cross-checking: c1 0, c2 56.4, c3 114, c4 172.2, c5 276, c6 370.5, c7 449.4, c8 501.6, c9 546, c10 636, c11 730.5, c12 798, c13 849, c14 921, c15 993, c16 1059, c17 1116, c18 1190.4, c19 1293, c20 1335, c21 1392.


## 7. Scene directions — frame-exact

Local scene time `t = (f − sceneStart) / 30`. All runs are `[startFrame, endFrame)` semantics; durations in frames. Every scene opens with its heading lockup already on screen and draws captions last.

### S01 — Clinic test moment
**0.000–2.200 · frames 0–66 · 66 f**

- Cues: c1 0.000–1.700 (hl `hearing` `test`); c2 opens 1.880.
- **Compose (settled on frame 1):** heading `01 / AT THE CLINIC` / `The Hearing Test`. Clinic card A01 rect **(130, 470, 820, 660)**: card label mini `TEST ROOM` (spaced 17 gray, card-left inset 26/46); floor line light lw4 at y 1056 inset 30; ink desk top from (400, 906) to (682, 906) lw5, legs (414, 682 → y1056) lw4; patient figure (330, 772) s0.60; audiologist figure (742, 758) s0.66. Patient pale bubble `paleBubble(230, 560, 130, 78)` (filled, at rest). Audiologist speech chip `chipBubble(630, 668, 110, 54)`.
- **Action:** hold 0–56. At **W.graphStart 56** the chip travels left 60 px: `dx = −60·easeOutCubic((f−56)/10)` → completes at f66. Two teal wave arcs (r12, r21) ride just right of the chip edge while traveling.
- **Resolution:** a clinic room where a test happens; the hand-off completes exactly as 'graph' is said.
- **Cut (S01→S02):** hard cut. The travel **completes inside S01**; S02 re-frames the room smaller at the cut.

### S02 — The graph gets its name
**2.200–5.740 · frames 66–172 · 106 f**

- Cues: c2 1.880–3.700 (rest, hl `graph`); c3 3.800–5.550 (hl `audiogram`).
- **Compose:** heading `02 / THE GRAPH` / `This Is The Audiogram`. Compressed clinic room A01 at rect **(110, 452, 430, 520)** — same card function, internals proportional (patient figure s0.34 at (214, 691); audiologist s0.38 at (429, 690); parked chip `chipBubble(330, 586, 76, 40)`; pale bubble scaled ~0.6).
- **Graph card entrance:** A02 rect **(90, 480, 900, 600)**, in **blank-audiogram-form state**: vertical axis + dB labels `0·20·40·60·80` + grid hairlines, horizontal axis + SIX tick labels `250·500·1K·2K·4K·8K` + dotted guides + `PITCH` label, `0 dB` + `LOUD ↓` pills — but NO symbols and NO threshold line (the symbols arrive on their word in S03). Slides from x1120 → x90 over frames **99–119** (`W.graphWord`, 20 f, easeOutCubic). Before f99 it is fully off-canvas right. The chart convention alone makes the handed-over card instantly readable as an audiogram.
- **AUDIOGRAM stamp:** `stampText('AUDIOGRAM', 540, 1152, 40)` mask-reveal frames **124–138** (`W.audiogramWord`, 14 f) — left-to-right clip mask, ink 700.
- **Hold:** 138–172. Stamp does NOT cross the cut; S03 re-reveals the same card, stamp gone, axes replace it.

### S03 — Pitch × volume, symbols
**5.740–9.200 · frames 172–276 · 104 f**

- Cue: c4 5.740–8.850 (hl `pitch` `volume`; 3-line plate).
- **Compose:** heading `03 / READING IT` / `Pitch × Volume, Plotted`. Graph card A02 same rect (90, 480, 900, 600), settled from frame 1 — full chart convention from the blank-form state (axes, dB + frequency labels, grid, pills).
- **Action:** the plot grows on the named words. At **W.pitchWord 190** the six frequency positions shimmer once (their dotted vertical guides brighten rule → gray, 12 f, tallest first) — the axis where symbols will land. At **W.volumeWord 206** the `0 dB` / `LOUD ↓` pills give their one re-affirming pulse (scale 1→1.06→1, 12 f). At **W.symbolsWord 226** the SIX `O` symbols stamp onto the plot in frequency order (220, 226, 232, 238, 244, 250 — 8 f easePop each) and the continuous connecting line draws through all six right behind them — **232–262** (30 f draw along the polyline, teal lw6) — so by f262 the chart shows one clean connected threshold curve.
- **Hold:** 262–276. Six O's, one line: the audiogram promise of the narration, exactly as spoken.
- **Cut:** S04 re-frames away; state persists for every later graph visit.

### S04 — Normal speech costs the brain
**9.200–12.350 · frames 276–370 · 94 f**

- Cue: c5 9.200–12.300 (hl `baat-cheet`).
- **Compose:** heading `03 / THE BRAIN` / `Normal Speech Is Work`. Left conversation panel: warm rect **(110, 500, 360, 560)** r24, rule border; furniture line light lw4 at y 940 inset 24; white bubble `bubble(150, 610, 117, 79, accent)`; speech chip `chipBubble(330, 660, 90, 50)`. Right: brain card A04 rect **(600, 442, 390, 540)**, meter 0, ring calm (rate 1.0), gate notch on its left edge.
- **Action:** settle 276–290. At **W.baatCheet 290**: both bubbles pulse once (scale 1→1.05→1, 8 f each, staggered 8 f). **Connector** 316–352 (36 f): teal lw4, dotR7, points `[[486, 780], [560, 780], [600, 776]]`. On arrival **352–370**: gate ring pulses; effort meter fills 0 → 0.35 (easeOutCubic).
- **Resolution:** normal speech visibly routes through the brain and the brain visibly works — the first meter reading.
- **Cut (S04→S05):** graphic match — brain card identical geometry/position into S05.

### S05 — Roz: the daily meter
**12.350–14.980 · frames 370–449 · 79 f**

- Cue: c6 12.350–14.800 (hl `roz` `gadha-mazdoori`).
- **Compose:** heading `03 / THE BRAIN` / `Same Work, Every Day`. Brain card A04 at **(150, 442, 390, 540)**, meter already 0.35, ring calm.
- **Action:** hold 370–398. Three day tabs A06 pop at **W.roz 401** staggering 7 f apart (8 f easePop each; tab i pops at 401 + 7i): rects x 640 / 768 / 896, w106 h300 at y 560, r16, white fill, rule border, each containing a mini meter rail (74 × 18 at tab bottom inset 16) whose teal fill draws to 0.35 / 0.55 / 0.75 during 416–440 (easeOutCubic). The brain card's meter mirrors the rise 0.35 → 0.75 during **401–440** (`gadha` word inside).
- **Hold:** 440–449. The meter does not keep animating past the cut.

### S06 — The axis is upside down
**14.980–18.200 · frames 449–546 · 97 f**

- Cues: c7 14.980–16.700 (hl `0 dB`); c8 16.720–18.150 (hl `neeche`).
- **Compose:** heading `04 / THE AXIS` / `0 dB At The Top`. Graph card A02 same rect (90, 480, 900, 600) in **axis-demo state**: full chart convention (dB labels + grid, tick labels + dotted guides, the S03 six-O plot + connected line) with the horizontal tick labels and vertical guides faded one step (rule-light gray) so the VERTICAL value axis reads alone; `0 dB` + `LOUD ↓` pills pinned on their gridlines in the left label lane, as always. Plot for S06 is EMPTY of Os in this isolation state (§10.5 `axisIsolate`).
- **Action:** hold 449–462. `0 dB` top pill gets its twist cue: scale pulse 1.00 → 1.06 → 1.00 across **462–476**. Small quiet chip (2 gray wave arcs r8/15) pins just under the 0 dB gridline at plot center-x (594, 594) in **494–506**. At **W.loud 511** the heavier loud wave chip (pale rect 210 × 84 r18, teal border, holding an ink wave trio + a teal wave trio) drops through the plot center from y663 → y829 in **511–523** (12 f easeOutCubic) and settles — passing from the quiet top zone to the loud bottom zone of the SAME axis.
- **Resolution:** the inversion is demonstrated spatially — quiet lives at the top, loudness at the bottom. Every later beat depends on this.
- **Cut:** full chart state restores into S07 (graphic match).

### S07 — Thresholds fall
**18.200–21.200 · frames 546–636 · 90 f**

- Cue: c9 18.200–21.100 (hl `thresholds`).
- **Compose:** heading `05 / THRESHOLDS` / `Thresholds Fall`. Graph card same rect in the **full S03 state** — six O's plotted and connected by the teal line. The dashed rule benchmark line is ABSENT on frame 1.
- **Action:** at the cue open the benchmark draws **548–560** (12 f): a dashed light line (lw2.5, dash 10/10) at relYin 0.2138 (abs y ≈ 637 full-scale) — literally "where the thresholds used to sit". Hold 560–597. At **W.girne 597** the ENTIRE group — teal line + all six O's — slides DOWN by +25 dB (ΔrelYin 0.2563, ≈102 px full-scale: 10/10/15/25/40/50 → 35/35/40/50/65/75 dB) in **597–629** (32 f easeOutCubic), then settles. The dB labels, tick labels, grid and pills never move — only the plotted data falls, which is exactly how deterioration looks on a real audiogram.
- **Hold:** 629–636 — fallen curve clearly below the benchmark.
- **Cut:** fallen positions carry into S08 (graphic match).

### S08 — Normal speech needs more
**21.200–24.350 · frames 636–730 · 94 f**

- Cue: c10 21.200–24.300 (hl `samajhne`; 3-line plate).
- **Compose:** heading `05 / THRESHOLDS` / `Speech Needs More`. Graph card in fallen state (as S07 hold: curve + six O's at 35/35/40/50/65/75 dB). Requirement pill A09 `NORMAL BAAT-CHEET` (pale, teal border, teal dot, INK 700 text, size 22, h47) centered at **(540, 920)** — below the fallen curve, inside the gap it must shout across.
- **Action:** settle 636–648. At **W.matlab 648** a dashed light dropline draws from the fallen teal curve (at x540 ≈ the 1K tick, fallen y ≈ 738) down to the pill top (540, 912) — **648–664** (16 f): the gap the listener must cross, drawn. Requirement arrow draws **668–700** (32 f): teal lw4 from the pill bottom center (540, 975) straight DOWN to (540, 1028), ending in a filled teal arrowhead (12 px) at (540, 1042) — pointing at the LOUDER region (inverted axis law: down = louder, matching the chart labels). The pill nudges with it: translate y +12 and scale ×0.96 across the same 32 f.
- **Hold:** 700–730 — chip, dropline, arrow read as one statement.
- **Cut:** the pill does not travel; its meaning re-states as the A09 pills of S09.


### S09 — Volume + clarity, named
**24.350–26.600 · frames 730–798 · 68 f**

- Cue: c11 24.350–26.500 (hl `volume` `clarity`).
- **Compose:** heading `06 / WHAT HELPS` / `More Volume · Clarity`. Graph card compressed slightly left: rect **(70, 470, 600, 680)**, in the fallen-plot state (full chart convention + six-O plot + teal line + benchmark + fall applied) — the parametric card rescales its interior; at this scale (×0.67) the numeric tick labels STAY ON (≥ 0.55 threshold).
- **Action:** graph holds 730–746. A09 pill `ZYADA VOLUME` (pale/teal/teal-dot/ink 700, size 22, h47) pops at **W.volume 746** (12 f) at (742, 596). A09 pill `CLARITY` pops at **W.clarity 767** (12 f) at (742, 668).
- **Hold:** 779–798 — both pills + graph as one statement. Nothing invented beyond the words.
- **Cut:** pills do not travel; their meaning travels as a chip in S10.

### S10 — Clarity travels into the brain; decode
**26.600–30.600 · frames 798–918 · 120 f**

- Cues: c12 26.600–28.300 (hl `dimaag`); c13 28.300–30.200 (hl `decode` `mehnat`).
- **Compose:** heading `06 / WHAT HELPS` / `Clarity Enters The Brain`. Brain card A04 at canonical (600, 442, 390, 540) — meter already 0.75 (the cut re-frames it settled; no S05 spill), ring calm. Left: A09 pill `CLARITY` (size 22) resting at (200, 616) from frame 1. Clear connector lane across the middle.
- **Action:** settle 798–825. At **W.dimaag 825** a riding chip — pale rounded rect 132 × 64 r14, teal border, teal dot + `CLARITY` ink 700 text 20 — travels from (200, 616) to the brain gate (634, 800) in **825–855** (30 f, easeOutCubic). On arrival: gate ring pulse (14 f). At **W.mehnat 861** the ring doubles its breathing rate (rate 1.0 → 2.8) through 861–905, and the effort meter climbs 0.75 → 0.90 (855–895, easeOutCubic). At **W.decode 882** the `DECODE` display stamp (ink 700, 26 px) mask-reveals under the meter — `stampText('DECODE', 795, 966, 26)` in **882–894** (8 f mask).
- **Hold:** 894–918 — chip inside, meter high, word stamped. This is the logical bridge to the quote.

### S11 — The clinic moment
**30.600–33.100 · frames 918–993 · 75 f**

- Cue: c14 30.700–32.950 (hl `clinic`).
- **Compose:** heading `07 / THE QUOTE` / `Back At The Clinic`. Clinic room A01 rect **(110, 480, 860, 660)**, mirrored framing: patient figure LEFT foreground **(300, 860) s0.72** ink; audiologist figure right **(760, 846) s0.52**. Patient bubble is an **outline-only empty** pale bubble (paleBubble empty variant) at **(170, 640, 150, 88)** — invisible on frame 1, scales in.
- **Action:** room settles 918–934. At **W.clinic 934** the empty bubble scales in (0.75 → 1.0, bottom-left anchored, 16 f easeOutCubic) and HOLDS empty through 950–978. At **W.bolte 978** the speech marks fill in (teal first dash, then gray pair, 8 f per-dash ramp) — the person is about to speak.
- **Hold:** 986–993. Nothing else competes; the empty bubble created the pull for the quote.
- **Cut:** straight into the quote lockup — the fastest emotional cut of the episode.

### S12 — Sun vs Samajh
**33.100–35.300 · frames 993–1059 · 66 f**

- Cue: c15 33.100–35.100 (verbatim quote wrap on the plate; hl `samajh` `nahi`).
- **Compose:** heading `07 / THE QUOTE` / `Sun Yes, Samajh No`. Quote lockup A10 centered: big `SUN` pill (pale, teal border, teal dot, ink 700 text 34, h64) centered at (400, 742); big `SAMAJH` pill (pale, ink border, ink 700 text 34, h64) centered at (700, 742). Tail: light lw3 line from (330, 806) to (250, 866) with a light r6 dot at (244, 872) — graphic memory of the patient at lower-left.
- **Action:** `SUN` pops at **W.sun 1005** (12 f easePop). `SAMAJH` pops at **W.samajh 1038** (12 f). At **W.samajhX 1050** the denyRed ✕ (lw7, arms ±30 px) stamps across the SAMAJH pill center in **≤ 8 f** — the episode's ONLY denyRed usage.
- **Hold:** 1058–1059 (deliberately brief — verdict, then cut). The plate carries the full verbatim sentence; the card carries the two-glyph verdict.
- **Law:** the ✕ never appears again in S13–S17.

### S13 — The test says what the brain is doing
**35.300–37.200 · frames 1059–1116 · 57 f**

- Cue: c16 35.300–37.200 (hl `brain`).
- **Compose:** heading `08 / THE CHECK` / `Test → Brain`. Two-up, each card self-explanatory AT FIRST GLANCE: graph card A02 compressed to ~45% at **(90, 490, 430, 580)** in the full recognizable audiogram state (chart convention: grid hairlines + `0 dB`/`LOUD ↓` pills + six-O plot + connected teal line; numeric tick labels suppressed at this scale — 430/900 ≈ 0.48 < 0.55 — grid, pills and plot remain); brain card A04 at ~65% **(565, 470, 420, 560)** with the 🧠 emoji centered, meter 0.55, ring calm. Empty lane between. A viewer with no audio sees "hearing chart" + "brain" — nothing else is needed.
- **Action:** settle 1059–1071. Teal connector draws **1071–1100** (29 f): lw5, dotR7, `[[520, 780], [565, 778]]`. At **W.brain 1100**: gate ring pulses (14 f) + a small teal ring stamps around the connector's graph-side endpoint dot — the test speaks about the brain.
- **Hold:** 1109–1116. Pure setup beat for the two-state comparison.
- **Cut (S13→S14):** graphic match — anchors hold exact positions.

### S14 — Smooth state
**37.200–39.680 · frames 1116–1190 · 74 f**

- Cue: c17 37.200–39.650 (hl `smoothly`).
- **Compose:** identical anchors to S13. Sentence chips (A05, speech-mark glyphs — never words) queue three-deep at the graph end of the lane (x ≈ 500, y 772).
- **Action:** at **W.smoothly 1134** the chips begin flowing: each small pale chip (84 × 46, chipBubble glyph) moves the lane rightward at a steady **95 px/s linear** cadence, emission every 0.55 s, absorbed at the gate (shrink over the last 30 px, gentle alpha ramp), each absorption giving a small gate ring blip. Ring breathes calm (rate 1.1); meter holds **0.40**. Status pill `SMOOTH` (teal-text variant) pops at (740, 520) at **1144** (10 f).
- **Hold:** steady cadence IS the resolved state (endless-calibration precedent: the CHL echo loop). Even spacing, unbroken path, relaxed pulse.

### S15 — Guessing, and tiring
**39.680–43.100 · frames 1190–1293 · 103 f**

- Cue: c18 39.680–42.650 (hl `guess` `thak`).
- **Compose:** identical anchors to S14 (meter starts 0.40 — cut re-frames it; a chip waits in queue).
- **Action:** first chip enters at 1196, reaches the gate at **1212**, and breaks: it fragments into 3 `?` chips (r13 gray-outline circles, gray `?` 19 px) that scatter back dx −52/−78/−104, dy −8/+6/−14 (8 f easeOutCubic out, 4 f return, fade). The pulse ring jitters (±2 px, deterministic 3-frame spike), and the effort meter jumps 0.40 → 0.90 (12 f easeOutCubic) at the same beat. At **W.guess 1227** a `GUESS` status pill pops at (740, 520) — the same slot SMOOTH held (state swap across cut). Second chip enters 1238, breaks 1252 with the same fragment pattern. At **W.thak 1251** the meter's top segment flashes once (pale → teal → pale over 1251–1268) and the meter stays PEGGED at 0.90.
- **Hold:** 1268–1293 — broken-loop state: waiting chip, ? chips hovering (±2 px float), meter maxed, pulse jittering. Dignified contrast: no mockery.

### S16 — Agli baar
**43.100–45.000 · frames 1293–1350 · 57 f**

- Cues: c19 43.100–44.200 (hl `agli` `baar`); c20 opens 44.500.
- **Compose:** heading `09 / NEXT TIME` / `Coming Next`. Card zone otherwise clean. Display stamp `AGLI BAAR` (ink 700, 44 px) centered at (540, 700); rule arrow beneath it: ink lw4 from (470, 764) to (610, 764) ending in a filled ink arrowhead (16 px) pointing right at (626, 764).
- **Action:** stamp mask-reveals **1305–1319** (`W.agliBaar`, 14 f). Arrow draws **1320–1338** (18 f). At **W.teaserCard 1335** (c20 opens exactly) the A02 graph card begins rising: shared function `teaserState(f)`: for f < 1335 nothing; for f ≥ 1335, `p = easeOutCubic((f−1335)/60)` and **topY = 1218 − 750·p**. The card is drawn fully clipped to the card-zone rect **(0, 442, 1080, 776)**: card rect (72, topY, 936, 624), r28, in the **full recognizable audiogram state** (chart convention, six-O plot + teal line at BASE level, numeric tick labels ON — scale ≈ 1.04). At the cut f1350, topY ≈ 785 — the card's upper half is already in the zone, stamp still fully clear (its baseline 700 + arrow 764 sit above 785).
- **Transition (S16→S17):** graphic-match with **sanctioned cross-cut motion** — both scenes read the same `teaserState(f)`, so the card never jumps. This is the episode's only cross-cut element.

### S17 — Sirf ek graph
**45.000–48.000 · frames 1350–1440 · 90 f**

- Cues: c20 44.500–46.400 (hl `graph`); c21 46.400–47.950 (hl `loud`).
- **Compose:** heading `09 / NEXT TIME` / `Sirf Ek Graph`. Teaser card continues its rise from `teaserState(f)` — topY reaches 468 by **f1395**; card scale eases 1.00 → 1.04 across **1350–1372** about the card's own center (at the cut the scale is exactly 1.00 — continuity kept). The card reads as the SAME recognizable audiogram to the last frame: chart convention, six-O plot, teal line at base level, tick labels on.
- **Action:** `EK GRAPH` display stamp (ink 700, 44 px) mask-reveals **1360–1374** (`W.ekGraph`, 14 f) at (540, 1152) below the card. Three A05 speech chips pop in growing size on c21's words, ON the plot's lower-right emptiness (below the curve's right descent, clear of the six O's — verify no overlap in QA): chip1 (110 × 48, 2 wave arcs) at (790, 795) at **W.duniya 1400**; chip2 (150 × 56, 3 arcs) at (830, 895) at **W.kitni 1414**; chip3 (190 × 66, 4 arcs, largest) at (870, 1000) at **W.loudEnd 1425** (each 10 f easePop from 0.7).
- **Hold:** 1437–1440 — final settled hold; the last ~4 frames are deliberately still (no pops through the close). The last frame is a kept hold, not a fade.


## 8. Caption and voice specification

### 8.1 Wording law

The supplied Hinglish SRT is the single source of caption wording — all 21 cues exact, including punctuation (`!` in c15/c18/c21, `:` in c14/c19, and the c15 verbatim quote wrap `"…"`). No word is ever added, corrected, deleted, or duplicated. No TTS at any stage.

### 8.2 Cue table (timings locked; line splits + highlight tokens fixed)

| Cue | s | e | Lines | Highlight |
|---|---|---|---|---|
| 1 | 0.000 | 1.700 | `Jab aap clinic me` / `hearing test karate ho,` | hearing · test |
| 2 | 1.880 | 3.700 | `aur audiologist aapko` / `ek graph deta hai,` | graph |
| 3 | 3.800 | 5.550 | `jise hum audiogram` / `kehte hain.` | audiogram |
| 4 | 5.740 | 8.850 | `Is graph par jo alag-alag` / `pitch aur volume ke` / `symbols bane hote hain,` | pitch · volume |
| 5 | 9.200 | 12.300 | `ye batate hain ki normal` / `baat-cheet samajhne ke liye` | baat-cheet |
| 6 | 12.350 | 14.800 | `aapke dimaag ko roz kitni` / `gadha-mazdoori karni padti hai.` | roz · gadha-mazdoori |
| 7 | 14.980 | 16.700 | `0 dB sabse upar hota hai,` | 0 dB |
| 8 | 16.720 | 18.150 | `aur loud sounds neeche.` | neeche |
| 9 | 18.200 | 21.100 | `Jab ye thresholds neeche` / `girne lagte hain,` | thresholds |
| 10 | 21.200 | 24.300 | `to iska matlab hai aapko` / `normal baat-cheet samajhne` / `ke liye` | samajhne |
| 11 | 24.350 | 26.500 | `zyada volume aur` / `clarity chahiye.` | volume · clarity |
| 12 | 26.600 | 28.300 | `Woh clarity aapke` / `dimaag ko` | dimaag |
| 13 | 28.300 | 30.200 | `khud mehnat karke decode` / `karni padti hai,` | decode · mehnat |
| 14 | 30.700 | 32.950 | `isliye aap mere clinic me` / `aake bolte ho:` | clinic |
| 15 | 33.100 | 35.100 | `"Ki sun to raha hai,` / `par samajh nahi aa raha!"` | samajh · nahi |
| 16 | 35.300 | 37.200 | `Test saaf bata dete hain` / `ki brain` | brain |
| 17 | 37.200 | 39.650 | `speech ko smoothly` / `process kar raha hai,` | smoothly |
| 18 | 39.680 | 42.650 | `ya har sentence guess` / `karke thak raha hai!` | guess · thak |
| 19 | 43.100 | 44.200 | `Agli baar dikhaunga:` | agli · baar |
| 20 | 44.500 | 46.400 | `sirf ek graph se ye kaise` / `pata chalta hai` | graph |
| 21 | 46.400 | 47.950 | `ki duniya aapko kitni` / `loud lagti hai!` | loud |

### 8.3 Ready-to-code caption array (equals the table; embed verbatim)

```js
const SRT = [
  { s:0.000,  e:1.700,  lines:['Jab aap clinic me','hearing test karate ho,'],            hl:[['hearing'],['test']] },
  { s:1.880,  e:3.700,  lines:['aur audiologist aapko','ek graph deta hai,'],             hl:[['graph']] },
  { s:3.800,  e:5.550,  lines:['jise hum audiogram','kehte hain.'],                       hl:[['audiogram']] },
  { s:5.740,  e:8.850,  lines:['Is graph par jo alag-alag','pitch aur volume ke','symbols bane hote hain,'], hl:[['pitch'],['volume']] },
  { s:9.200,  e:12.300, lines:['ye batate hain ki normal','baat-cheet samajhne ke liye'], hl:[['baat-cheet']] },
  { s:12.350, e:14.800, lines:['aapke dimaag ko roz kitni','gadha-mazdoori karni padti hai.'], hl:[['roz'],['gadha-mazdoori']] },
  { s:14.980, e:16.700, lines:['0 dB sabse upar hota hai,'],                           hl:[['0','dB']] },
  { s:16.720, e:18.150, lines:['aur loud sounds neeche.'],                            hl:[['neeche']] },
  { s:18.200, e:21.100, lines:['Jab ye thresholds neeche','girne lagte hain,'],        hl:[['thresholds']] },
  { s:21.200, e:24.300, lines:['to iska matlab hai aapko','normal baat-cheet samajhne','ke liye'], hl:[['samajhne']] },
  { s:24.350, e:26.500, lines:['zyada volume aur','clarity chahiye.'],                 hl:[['volume'],['clarity']] },
  { s:26.600, e:28.300, lines:['Woh clarity aapke','dimaag ko'],                       hl:[['dimaag']] },
  { s:28.300, e:30.200, lines:['khud mehnat karke decode','karni padti hai,'],         hl:[['decode'],['mehnat']] },
  { s:30.700, e:32.950, lines:['isliye aap mere clinic me','aake bolte ho:'],          hl:[['clinic']] },
  { s:33.100, e:35.100, lines:['"Ki sun to raha hai,','par samajh nahi aa raha!"'],    hl:[['samajh'],['nahi']] },
  { s:35.300, e:37.200, lines:['Test saaf bata dete hain','ki brain'],                 hl:[['brain']] },
  { s:37.200, e:39.650, lines:['speech ko smoothly','process kar raha hai,'],          hl:[['smoothly']] },
  { s:39.680, e:42.650, lines:['ya har sentence guess','karke thak raha hai!'],        hl:[['guess'],['thak']] },
  { s:43.100, e:44.200, lines:['Agli baar dikhaunga:'],                               hl:[['agli'],['baar']] },
  { s:44.500, e:46.400, lines:['sirf ek graph se ye kaise','pata chalta hai'],         hl:[['graph']] },
  { s:46.400, e:47.950, lines:['ki duniya aapko kitni','loud lagti hai!'],             hl:[['loud']] }
];
```

Matching rule for highlights: normalize tokens by lowercasing and stripping `[.,!?"'()—-]` on BOTH cue words and highlight tokens (so `baat-cheet` matches hyphen-stripped cue words, and the quote wrap does not block `Ki`). A highlight token group matches a consecutive word run; matched words render teal 700, all others ink 600.

### 8.4 Voice-file sync rules (when the creator's part 1 file arrives)

1. Spot-check ≥ 6 cues against the waveform edges (first, middle, last, and any cue whose scene cut sits inside it). Tolerance ~0.2 s.
2. If any cue deviates more than 0.2 s: shift ONLY the affected cue s/e **and** the matching rows in the W word-beat table (§6); re-cut scene bounds at the affected gaps only. Never re-word captions; never re-time the whole SRT.
3. The creator's voice is the master. Never stretch, pitch, or fade speech to fit. Trim silence only.

## 9. Claim and visual-accuracy audit

| Script claim | Visual treatment / limit |
|---|---|
| Audiologist hands a graph called audiogram | A01/A02 show hand-off and naming only. No equipment branding, no audiometer anatomy. |
| Symbols for pitch and volume | A03 plots EXACTLY six `O` markers — one symbol type only, never mixed — at the six frequency positions of a real audiogram, connected by ONE continuous teal line through all six. Creator-approved chart conventions (dB labels, frequency ticks) are present for recognizability even though the Hz units are not spoken; no right/left-ear legend is invented (the chart shows one curve, informally one ear). |
| 0 dB at top, loud at bottom | Textbook HL-axis inversion, demonstrated spatially in S06, backed by the labelled dB scale (0 top…80 bottom). Suppression direction consistent in all later scenes (down = louder). |
| Thresholds fall | A08 — the whole six-O curve group slides down +25 dB in one move against a dashed benchmark (35/35/40/50/65/75 dB after the fall). No "hearing loss" label, no red anywhere — the fall is state, not catastrophe. |
| Normal speech then needs more volume+clarity | S08/S09 use only spoken words (`NORMAL BAAT-CHEET`, `ZYADA VOLUME`, `CLARITY`). No "speech banana" diagram, no measured curves. |
| Brain decodes with daily effort | S04/S05/S10 show the recognizable 🧠 brain with effort as meter heights and pulse rate. No gears, no pain marks, no abstract stand-in shapes. |
| "Sun to raha hai, par samajh nahi aa raha!" | Verbatim on the plate incl. quote wrap (c15); the card lockup uses two pills (`SUN` teal-led / `SAMAJH` ✕). The ✕ obeys the denyRed law. Dignity rule holds: no drooping figures, no mockery. |
| Test shows smooth processing vs guessing-tired | S14/S15 contrast cadence, meter, and pulse. No performance score, no percentage, no diagnosis claim beyond the narration. |
| Part-2 teaser | Promise-only visual (card + growing chips + two stamps). No unreleased claim invented. |

**Clinical note (Rev 3):** the dB HL axis convention (0 at top, louder downward), the six standard frequency positions (250/500/1K/2K/4K/8K), single-symbol-type plotting, and the one continuous threshold curve are standard audiogram practice and are now REQUIREMENTS for every graph visit (creator directive). Any patient-facing caption or claim outside this script must cite the clinic's own materials / ASHA public audiogram resources. The plotted values (10/10/15/25/40/50 → 35/35/40/50/65/75 dB) are plausible illustrative thresholds, not patient data.


## 10. Build handoff (for the build agent)

### 10.1 Suggested file layout

```
episode-02-audiogram-part-1/
  storyboard.md      this document (creative + technical source of truth)
  shots.json         17-shot manifest (schema v1; keep in sync if bounds shift)
  audiogram_piece.html   all code in ONE script block; canvas 1080x1920
  audiogram_render.mjs   deterministic frame renderer + mux
  qa/                QA stills (named qa_0000.png …)
  render/            silent video master → final mux with voice
```

### 10.2 Runner contract

All code lives in a single `<script>` block inside the piece HTML. The runner evaluates the script with `(window, document, performance, requestAnimationFrame)` and a canvas it owns; the script must expose `window.render(f)`, `window.FPS = 30`, `window.NF = 1440`, `window.bounds` (the §5 array). `render(f)` must be a pure function of f: reset transform/globalAlpha/composite, fill paper, floor-clamp f, draw scene by bounds dispatch, draw captions LAST. The runner pipes 1,440 PNG frames into ffmpeg:

```
ffmpeg -y -f image2pipe -framerate 30 -vcodec png -i - -frames:v 1440 -an
  -c:v libx264 -preset medium -crf 18 -pix_fmt yuv420p -r 30 -movflags +faststart master.mp4
```

### 10.3 Helper library (exact contracts)

```
rr(x, y, w, h, r, fill, stroke, lw)   rounded rect; r clamped to w/2,h/2
circ(x, y, r, fill, stroke, lw)       full circle; fill then stroke
seg(x1, y1, x2, y2, col, lw)          line, round caps
text(str, x, y, size, col, weight, align, baseline)  default align left, baseline alphabetic
spaced(str, x, y, size, col, tracking, align)  letterspaced caps char-by-char;
                                      align 'center' centers the tracked total
connector(pts, drawT, col, lw, dotR)  polyline revealed along cumulative length by
                                      drawT 0..1; when complete, teal dots radius
                                      dotR on BOTH endpoints (skip dots when dotR=0)
waveTrio(x, y, r0, grow, n, col, lw)  n concentric right-opening arcs at (x,y),
                                      radii r0 + k·grow, sweep −0.85..0.85 rad
figure(cx, cy, s, col)                head circle r24s at (cx,cy); torso roundRect
                                      (cx−39s, cy+30s, 78s, 94s, r28s) same fill
bubble(x, y, w, h, accent, muted, empty)   white bubble r18, border ink (or light
                                      when muted); tail down-left (28/h−2 → 36/h+14);
                                      3 speech dashes at (x+24, y+27+16i), lengths
                                      20/21/16, teal+gray when accent, light when
                                      muted; empty=true draws outline only
chipBubble(x, y, w, h)                pale chip r10 ink border lw2.5; teal dash
                                      (14→32 at y+16), gray dash (14→26 at y+29);
                                      small gray tail triangle
paleBubble(x, y, w, h, empty)         pale bubble r18 ink border; tail like bubble;
                                      dashes teal/gray/gray at y+28/44/60; empty skips dashes
mbubble(x, y, w, h, dir, fill)        muted fill, light border r16; tail down-left
                                      (dir<0) or down-right (dir>0)
pill(label, x, y, {size=22, h=47, anchor='left', dot=true})   pale pill r24 teal
                                      border; px-pad 28 left/right + 20 before text
                                      when dot; teal dot r6 at px+22; teal 700 label
pillInk(label, ...)                   identical geometry, INK 700 label (A09 variant)
labelBar(str, x, y, w, reveal)        pale bar r22 teal border h56, centered teal
                                      600 21px text; reveal<1 → progressive clip mask
stampText(str, cx, cy, size, p)       ink 700 caps centered; p 0..1 = left-to-right
                                      clip mask (pad 26 px), fade alpha until p=0.7
```

### 10.4 Geometry primitives

```
graphGeom(x, y, w, h) → {
  gx0 = x + 0.19w,  gx1 = x + w − 0.05w,   // horizontal axis span; left lane holds dB labels + pills
  gy0 = y + 0.12h,  gy1 = y + h − 0.22h,   // vertical plot span; bottom lane holds tick labels + PITCH
  plotH = gy1 − gy0, plotW = gx1 − gx0
}
oxMark(x, y, s)      the ONLY plot symbol type: ink circle OUTLINE r13s, lw2.5s
                     (r clamped ≥ 6s at mini scales; never an X, never mixed types)
brainEmoji(cx, cy, size)   draw '🧠' via canvas fillText, font size = size,
                           centered (textBaseline 'middle'); platform emoji font
                           renders the colours — this is the sanctioned asset
```

**Worked example — full-scale card (90, 480, 900, 600), the one S02–S11 use:**

```
plot rect      x 261..945,  y 552..948                          (plotW 684, plotH 396)
dB gridlines   0→y576, 20→y657, 40→y738, 60→y819, 80→y901      (rule lw1.5, full plot width)
dB labels      right-aligned x253, on each gridline, 17px gray 600
freq ticks     relX [0.12, 0.272, 0.424, 0.576, 0.728, 0.88]
               → x 343, 447, 551, 655, 759, 863
tick labels    centered under each tick, baseline y970, 17px gray 600
dotted guides  vertical rule dash 2/6 lw1.5 from y552 to y948 at each tick x
O plot (base)  (343,616) (447,616) (551,637) (655,677) (759,738) (863,779)
               = dB 10 / 10 / 15 / 25 / 40 / 50; relYin = 0.06 + dB/80·0.82
teal line      single polyline lw6 through the six O centers, rounded joins
fall +25 dB    Δy ≈ +102 px → fallen Os at y 718/718/738/779/840/880
benchmark      dashed light lw2.5 dash 10/10 at y637 (the base curve level)
axis pills     '0 dB' 20px h44 centered (213, 576) · 'LOUD ↓' centered (213, 900)
PITCH label    spaced 17 gray, right-aligned at x935, y996
```

All recurring cards are **parametric**: pass a rect, the interior scales from the rect's own proportions. Never hardcode full-scale pixel values inside a card that is reused at another size.

### 10.5 Recurring card specs (state bags)

**graphCard(x, y, w, h, S)** — white r28 card → chart convention (ALWAYS drawn): five horizontal grid hairlines at the dB positions + dB labels (suppressed below scale 0.55) + six dotted frequency guides + tick labels (suppressed below 0.55) + `PITCH` label + `0 dB` / `LOUD ↓` pills pinned on the 0/80 gridlines in the left lane → optional six-O plot: symbols flag ON stamps the six `oxMark`s (freq order, 8 f easePop each) and draws the ONE continuous teal polyline through them (rounded joins, lw6) → optional fall: ΔrelYin = 0.2563·fall moves Os + line TOGETHER (labels/grid/pills never move) → optional benchmark: dashed line at base curve level → optional S06 demo (below). Plot states compose as named in §3.

```
O plot  relX: [0.12, 0.272, 0.424, 0.576, 0.728, 0.88]           // six freq ticks
        dB:   [10,   10,    15,    25,    40,    50]             // base thresholds
        relYin(dB) = 0.06 + dB/80 · 0.82                         // plot-relative y
        fall: +25 dB → relYin shift ≈ +0.2563 (applied to Os + line)
```

State fields: `gr` 0..1 reserved axis-draw carryover (the chart is present from S02, so typically 1); `axisIsolate` bool (S06: tick row + guides faded one step, plot emptied of Os); `axisChips` 0..1 (pill pop scale); `plot` 0..1 (O stamp + line draw progress: per-O easePop stride 6 f, line draw trails 30 f behind); `fall` 0..1; `ref` 0..1 (benchmark); `demo = {pose, drop}` (S06: pinned quiet arcs y594; heavy chip drop y663→829 through plot center).

**brainCard(x, y, w, h, B)** — white r24 card → breathing teal ring: radius 132·(w/460) + 5·sin(2π·rate·t) + jitter (±2.2·sin(13t) when B.jitter) + 9·arrival, alpha 0.85 → the recognizable brain: `brainEmoji(cx, y+0.40h, 0.42h)` — NEVER an ellipse+fold abstraction → effort meter at y+h−74: pale rail (0.56w × 26, r13) + teal fill 0.56w·meter + optional top flash band (last 52 px repainted teal at B.flash 0..0.9 alpha) → left-edge gate notch (pale 22 × 48, teal border) + teal arrival ring 30+9·arrival when arriving.
State fields: `meter` 0..1 (0.35 default), `t` seconds, `rate` breathing rate, `jitter` bool, `arrival` 0..1, `flash` 0..1.

**clinicRoom(x, y, w, h, R)** — white r28 card → optional top-left `spaced` label → floor light lw4 at y+h−74 (inset 30) → ink desk: top seg (x+0.33w → +0.34w) at y+0.66h lw5, legs to floor → patient figure (x+0.24w, y+0.46h, s0.55) + audiologist figure (x+0.74w, y+0.44h, s0.58) — overrides via `R.pat` / `R.aud` → optional `R.patBubble {x, y, w, h, empty}` paleBubble → optional `R.audChip {x, y, w, h, dx, grey, alpha}` chip/mbubble at x+dx.

**teaserState(f)** (S16→S17 shared): f<1335 → hidden; else `p = easeOutCubic((f−1335)/60)`, `topY = 1218 − 750·p`. Card rect (72, topY, 936, 624) r28, in the full recognizable audiogram state (chart convention + six-O plot at base level + tick labels on), clipped to card zone (0, 442, 1080, 776). S17 adds scale 1.00 → 1.04 across 1350–1372 about the card center; the scale MUST read exactly 1.00 at f1350.

**A06 day tabs:** three white r16 rect(106 × 300) at x 640/768/896, y 560; mini meter rail 74 × 18 at tab bottom inset 16; fills 0.35/0.55/0.75.


### 10.6 QA — two mandatory passes before any delivery

**Pass A — deterministic still set.** Render and inspect these 20 frames; every changed state gets its frame:

```
[10, 56, 130, 240, 330, 420, 500, 590, 618, 690, 760, 850, 960, 1030, 1090, 1160, 1240, 1320, 1400, 1439]
```

Keyed checks: `56` hand-off chip mid-travel · `130` AUDIOGRAM stamp + labelled blank chart form landed · `240` six-O plot + continuous line landed · `330` connector mid-draw → meter filling · `420` day tabs + tallest bar · `500` loud wave chip settled low · `590` curve + benchmark readable pre-fall · `618` six-O curve mid-fall vs benchmark · `690` dropline + arrow mid-draw · `760` both A09 pills · `850` clarity chip mid-lane · `960` 🧠 brain + empty patient bubble + marks filled · `1030` SUN (no ✕ yet) · `1090` connector + endpoint dot pulse · `1160` chips streaming + SMOOTH pill · `1240` GUESS pill + second break + meter pegged · `1320` stamp + arrow + card edge not yet risen · `1400` recognizable audiogram card risen, EK GRAPH landed, chip1 popping · `1439` final hold.

**Pass B — full visual critique with concept gating.** The dumb-watch list (every claim must be answerable from the picture alone, first glance, no label-reading):

hearing-test ✓A01 · graph deta hai ✓A02 chip+card slide · audiogram ✓stamp · pitch/volume/symbols ✓A03+A07 · baat-cheet→dimaag ✓S04 panel→brain · roz/gadha-mazdoori ✓A06 · 0 dB upar ✓ · loud neeche ✓demo chip drop · thresholds neeche ✓A08 group slide · zyada volume/clarity ✓A09 · decode/mehnat ✓A04 meter+stamp · bolte ho ✓empty bubble fills · sun/samajh ✓A10 · brain (test link) ✓S13 connector · smoothly ✓S14 stream · guess/thak ✓A11 loop break+meter flash · agli baar ✓S16 stamp · ek graph/loud ✓S17 chips.

Plus the standing defect hunts: dead hold frames, unjustified pops, label-only storytelling, palette drift, ✕ misuse, any element outside the canvas, anything essential below y≈1240 outside the caption plate, caption drift vs SRT.

### 10.7 Mux (only when the voice file path arrives)

```
ffmpeg -y -i master.mp4 -i <voice-file> -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac
  -b:a 192k -t 48.0 -movflags +faststart audiogram_part1.mp4
```

Run the §8.4 sync verification BEFORE muxing. The silent master alone is the silent proof deliverable until then (`audio: user-voice-or-silent` in shots.json permits it).

### 10.8 Deliverable checklist

- [ ] Piece renders 1,440 frames deterministically (same f → same pixels)
- [ ] 17 scene bounds exactly the §5 array; no scene > 4.0 s
- [ ] Captions verbatim, plate fixed, teal highlights land on the §8.2 tokens
- [ ] Recurring anchors identical across every revisit (A02 six visits, A04 four)
- [ ] denyRed appears exactly once (S12 ✕)
- [ ] Cross-cut continuity proven at S16→S17 (no jump frame)
- [ ] QA Pass A stills + Pass B critique both clean
- [ ] `shots.json` still matches final scene bounds
- [ ] Voice mux verified with ffprobe (48.000 s, 1080×1920@30, h264 + AAC 48 kHz)

**Handoff state:** storyboard complete and frame-locked to the SRT. The build agent renders the silent proof now; the creator's part 1 voice file completes the Reel via §10.7. The director produces no render.

