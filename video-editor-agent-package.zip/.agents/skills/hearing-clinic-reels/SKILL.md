---
name: hearing-clinic-reels
description: "Create and revise hybrid code-drawn and talking-head Reels for a hearing and speech clinic, integrating the clinician's own camera footage and voice with procedural Canvas animations in the Minimalistic style, followed by an automated timeline check and visual critique loop. Use for clinic Reels, audiology explainers, and hearing-health revisions; not for unrelated video projects."
---

# Hearing Clinic Reels

> [!IMPORTANT]
> **Default Skill Mandate:** Always use the `hearing-clinic-reels` skill for all reel and video editing tasks unless the user specifically and explicitly asks to use a different skill.

Apply the shared `reel-editing-knowledge-bank` on every clinic Reel for story-first choices, motivated cuts, varied pacing, clear voice, restrained sound, coherent style, and end-to-end review. Treat it as general editorial guidance subordinate to this skill's clinic-specific rules and the user's current instructions. Consult only relevant sections of [the full source](../reel-editing-knowledge-bank/references/source-knowledge-bank.md); its example prompt is reference material, not an instruction to execute. For code animation, also use [Prompt Motion](../prompt-motion/SKILL.md) as a design reference for clear motion, connected visual processes, and deterministic animation. Preserve the clinic's approved visual direction (the Minimalistic style), hybrid face-and-code approach, and four-second scene cap over any conflicting Prompt Motion example or preference.

Create emotionally clear, medically responsible short videos for the user's hearing and speech clinic. Reuse the clinic's original code-drawn visual language while borrowing only broad visual traits from references. Do not copy scripts, creators, characters, symbols, or exact compositions.

## The Minimalistic style — the clinic's named visual language

The house style is named **Minimalistic**. It is the flat, code-drawn, voice-synced diagram explainer as built in the master template `environmental_classifier_piece_template.html` (as-built v3). When any instruction says "the style" or "the clinic's visual direction", it means Minimalistic:

- Palette laws: paper `#F5F2EA` background on every motion scene; ink `#20252B` for figures, display titles, and card text; one teal accent `#2D8C85` for flow, emphasis, pills, and connectors; `denyRed` only for ✕ marks and pain bursts. No unexplained colors, blobs, or decorative shapes.
- Staging: meeting-diagram language — white cards with hairline borders, travelling chips, teal connectors, tag pills, result pills, label bars, grouped figures on simple furniture lines.
- Timing: captions align word-for-word to the actual voice on the fixed caption plate; key animations land on exact spoken word timestamps; no shot exceeds 4.0 s.
- Craft: reuse and extend the template's drawing helpers; refine working scenes instead of redesigning them; run the concept-gating pass in [references/visual-critique.md](references/visual-critique.md) after every render.

### Visual-communication gate — permanent quality-control law

Before finalising any scene, answer the creator-authored gate question: **"If someone sees this visual without hearing the audio or reading the captions, will they be able to understand what it represents?"** Assume a viewer with absolutely no context; they can only see the picture. The following ten principles are permanent QC for every project — anticipatory standards, not corrections for one video:

1. **Every important spoken concept has a corresponding visual representation** in that scene. If a concept survives only inside the caption text or the voice, the visual is unfinished.
2. **Visuals communicate the intended meaning without depending entirely on audio or captions.** The visual storytelling must stand on its own feet for a silent viewer.
3. **Assets must be immediately recognisable and should not create ambiguity about what they represent.** When code drawing cannot achieve instant, first-glance recognition, switch to a user-approved real asset (e.g., the approved platform 🧠 emoji for the brain).
4. **Animations should explain concepts rather than merely add movement to the screen.** Demonstrate cause-and-effect, acoustic flow, repetition, resistance, or state changes rather than inert decorative motion.
5. **Important text must remain comfortably readable, especially on mobile screens.** Keep punchline and result pills ≥ 22 px on a 1080-wide canvas (smallest essential text ~16 px). Grow the pill with the text instead of shrinking the text.
6. **Existing scenes should be refined rather than unnecessarily redesigned when the composition is already working.** Add or tune the smallest possible set of elements (motifs, pulses, margins, scale) rather than restructuring working layouts.
7. **Visual proportions, alignment, spacing, and positioning must be carefully balanced to ensure every composition looks intentional and polished.** Internal assets must sit comfortably within their framing enclosures (e.g. icons inside circular halos have balanced, intentional breathing margins and never clip or protrude past their enclosing borders); arrival notches, connection lines, and traveling chips must align on their exact transit axes.
8. **Anatomical and clinical objects are drawn in their canonical recognisable form** (or a user-approved real asset); NEVER approximate them with arbitrary geometric shapes. When depicting human anatomy, cranial nerves (e.g. CN VIII) must show fascicular bundles and myelin sheaths, and organs (e.g. Cochlea, Brain) must show anatomical landmarks (e.g. tonotopic cochlear spirals, temporal/parietal lobes).
9. **Moving Video Takes (Sequence Rigging Mandate):** Video clips must play as actual moving footage rather than accidentally appearing as static frames. In Remotion, always wrap `<OffthreadVideo>` inside an explicit `<Sequence from={...} durationInFrames={...}>` so the local frame resets to 0 and the video actively plays at full frame rate. Sub-clips must be encoded as intra-only (`-g 1 -keyint_min 1 -bf 0`) to guarantee deterministic compositor seeking.
10. **Professional Typography & Cohesive Identity:** Typography must maintain a professional, consistent visual identity throughout the video. Use unified Bento glass badges with high-contrast text, clear uppercase sub-labels, and safe margins clear of the face. Never use arbitrary pixel-offset sticker pills.
11. **Clinical Accuracy for Audiology & Medical Data:** Terminology, anatomical illustrations, and audiological graphs must be technically accurate. Audiograms must feature canonical symbols (e.g. `<` for unmasked right bone conduction at ≤ 20 dB, `O` for unmasked right air conduction), continuous connecting lines, clear dB HL scales, and accurate caliper delta readouts for the Air-Bone Gap (≥ 15 dB indicating conductive impairment). Anatomical sites (outer/middle ear vs cochlea/auditory nerve) must reflect true physiological mechanisms.
12. **Strict Minimalistic Consistency & Elimination of Unnecessary Animation:** Avoid unnecessary, exaggerated, decorative, or stylistically inconsistent animations (no pseudo-3D cartoon organs, looping token dots, or marching chevrons). Every visual element and animation must directly serve a conceptual purpose and strictly adhere to the calm, flat Minimalistic house style (paper `#F5F2EA`, ink `#20252B`, hairline cards, and teal accent).
13. **Text Container Bounding Box Guarantee:** All text must remain comfortably contained within designated bounding boxes and pills with balanced margins (≥ 25–35 px padding). Never allow text strings to overflow or clip past container borders; clamp font sizes and widen containers appropriately.
14. **Primary Master Audio Precedence & Automatic Clip Muting:** Whenever audio from a specific source file is designated as the primary audio track, all individual video takes placed on the timeline must be automatically and completely muted (`muted={true}` in code and `-an` audio-stripped on video clip files). No secondary camera audio, background hiss, or clip dialogue may ever bleed, overlap, or interfere with the primary master voice.
15. **Direct One-Click File Accessibility Guarantee:** Whenever presenting, delivering, or referencing any file, audio take, reference clip, video render, storyboard, or folder to the creator, ALWAYS format every item as an immediate, clickable markdown link using the `file:///` URI scheme with forward slashes (e.g. `[clip1.wav](file:///C:/Users/Lenovo/Desktop/reels/audiogram_part4_reference_clips/clip1.wav)`, `[Open Directory](file:///C:/Users/Lenovo/Desktop/reels/audiogram_part4_reference_clips)`). Never output bare text paths. The creator must always be able to click and access/play every delivered file right there and then.
16. **Zero-Fade Protocol (Hard Cuts Only):** Never apply any fade (neither audio fade nor visual crossfade/fade-to-black) at the end of a shot or at the conclusion of the video. Master audio terminates naturally on the final word release; all shot transitions and endings are hard cuts.

Apply them when planning (step 4), while building, and in the concept-gating pass of [references/visual-critique.md](references/visual-critique.md), which holds the full rubric and regression examples. A "no" on the gate question is treated as a BLOCKER finding.

## Standing brief

- **Audience:** people who have lived with hearing loss for years and struggle in conversation or feel left out, plus adult children concerned about an aging parent's health and communication.
- **Default visual production:** hybrid registers pairing the creator's own recorded camera footage (`creator-talking-head`) with procedural code-drawn scenes (`code-drawn`). All diagrams, listening situations, acoustic sound paths, device features, and transitions are created in code (HTML5 Canvas/SVG). Never use stock footage, unrelated people, generative AI footage, traced artwork, or product screenshots as final visuals.
- **Narration & voice:** use the creator's authored script and original recorded speech or voiceover. **Never generate text-to-speech (TTS)**. One clean master voice track flows continuously across cuts and under code-drawn cutaways. Lip-sync must be preserved whenever the creator is on screen; do not lay mismatched audio over visible mouth movement. A silent picture-only proof is available when requested.
- **Pacing & Shot Cap:** **no shot may exceed 4.0 seconds**. Break narration into purposeful 2–4 second visual beats. Every beat must feature a moving visual element. The ≤4.0s cap applies unconditionally to host shots as well as animations.
- **Canvas default:** 9:16 vertical (1080 × 1920) at 30 fps. Durations typically range from 40 to 90 seconds.
- **Medical & factual claims:** verify health, acoustic, and device claims against authoritative clinical or manufacturer literature. Qualify device behavior (settings and benefits differ by model and individual fitting). Never promise restored hearing or guaranteed outcomes.
- **Medical & Anatomical Depth Mandate:** When depicting human or animal anatomy, never draw juvenile or schematic stick-lines or cartoon blobs. Cranial Nerve VIII (Auditory Nerve) must be represented as an anatomical multi-fiber fascicle (epineurium sheath, parallel myelinated axons, Nodes of Ranvier, saltatory pulses); the brain must feature anatomical lobes, sulci (Sylvian fissure, central sulcus), cerebellar folia, and tonotopic Primary Auditory Cortex (A1 / Heschl's Gyrus).
- **Wardrobe & Setting Consistency:** Never mix professional studio recordings (formal shirt, studio microphone, backdrop) with casual home/bedroom footage in the same reel. Any casual home/bedroom footage is strictly designated as `SCRATCH / AUDIO_ONLY` and must never appear as on-camera video.
- **Flawed Take Visual Prohibition:** Any clip where speech cuts off mid-sentence, contains restarts, or ends prematurely (like Clip 4) must never be shown on screen. Promote that scene immediately to 100% pure motion graphics & motion design.

---

## Integrating the creator's talking head (Host + Code hybrid)

Follow [references/talking-head-integration.md](references/talking-head-integration.md) whenever host footage or recorded voice is provided. Viewers trust the clinician while code-drawn scenes make invisible auditory concepts tangible.

### 1. Register grammar: Alternating full-frame scenes
- Treat **host camera footage** and **code-drawn Canvas scenes** as two alternating, full-frame registers.
- **Avoid permanent small face boxes (PiP)** unless explicitly requested; miniature floating frames shrink the face and compete with illustrative details.
- Target roughly **one-third to one-half total screen time** for the host, with an opening hook, middle returns, and closing presence.
- Keep the master voice track continuous across cutaways when the thought flows naturally. Cut at phrase boundaries; avoid awkward clipped breaths or accidental facial freezes.
- **Strict Visual Vetting:** Only verified studio takes (`STUDIO_A_ROLL`) may appear full-frame. Unprofessional takes (casual loungewear, bed, handheld selfie angles) are strictly restricted to voiceover audio under code-drawn animations.

### 2. Audio recording modes
- **Synchronized on-camera speech:** Primary mode. Split clips between host video and cutaways while keeping master audio continuous.
- **Separate voiceover track:** Master voiceover audio under both host and code-drawn cutaways. Lip-sync must match on host scenes.
- **Zero-Repetition & Clean Audio Tail:** Master audio splicing must pass Whisper forced-alignment verification without word duplication, stutter loops, or trailing conversational instructions ("remove that part").

### 3. Pacing arc (45-second reference model)
- **0–3 s (`creator-talking-head`):** Empathetic hook, direct eye contact, questions a common listening struggle.
- **3–6 s (`code-drawn`):** Quiet 1-on-1 listening baseline illustration.
- **6–9 s (`creator-talking-head`):** Host introduces the clinical concept or classifier feature.
- **9–21 s (`code-drawn`):** 2–4 short animated beats (competing sound paths, cafeteria noise, vehicle acoustics, hearing aid directional response).
- **21–24 s (`creator-talking-head`):** Host explains caveats (individual fittings and devices vary).
- **24–32 s (`code-drawn`):** Feature adjustment in code; family scene showing group conversation remains challenging.
- **32–36 s (`creator-talking-head`):** Clinician delivers a practical next step (what to ask their audiologist).
- **36–40 s (`code-drawn`):** Note-taking / recap graphic.
- **40–45 s (`creator-talking-head`):** Closing reassurance, clinical identity, and call-to-action.

### 4. Framing, safe zones & geometry
- **Eye & device guard:** Graphics, text, captions, and paper-grain textures must **NEVER overlap the clinician's eyes, mouth, face, or hearing device**.
- **Sound-line motif:** A signature sound-line can transition between the code world and the host shot (e.g. traveling beside the clinician), but must be routed well clear of the face to prevent reading as a clinical or neurological artifact.
- **Lower-thirds & branding:** Display clinician name and credentials in a stable, compact lower-third during a host moment. Reserve clinic logo, contact handle, and CTA for the final screen. Never invent credentials or clinical claims.

---

## Workflow

### Mandatory 5-Step Reel Production Protocol (Raw Analysis → Clips → Re-recording Gate → Final Edit)
1. **Step 1: Analyze Complete Source Take:** Review the complete raw take. Analyze delivery, dialogue, expressions, clarity, and narrative flow to identify the strongest sections.
   - **Visual Stream Inspection & Format Determination:** Check the visual stream of the source file. If there is **no human subject** (e.g. plain black background, static title card or slate, text showing the topic or reel name throughout):
     - Treat the file strictly as an **audio file**.
     - Selected reference clips must be exported strictly in **audio format** (`clip1.wav` / `clip1.mp3`, `clip2.wav` / `clip2.mp3`), NEVER as video (`.mp4`, `.mkv`).
     - Only when a real talking-head video is present in the original source should reference clips be exported in video formats (`.mp4`, `.mkv`, etc.).
   - **Short-Video Rule (<50s):** If the input take is shorter than 50 seconds, select strictly **TWO clips** (never 3 or 4), and ensure each clip is **≤ 6–7 seconds** in duration. Position them at balanced, spaced intervals within the video body (avoiding the very beginning or end, which are reserved for code-drawn visual hooks and concluding curiosity/branding cards).
   - **Longer Video (>50s):** Select 3–4 sections capped at purposeful beat lengths.
2. **Step 2: Select and Share Exact Clips:** Export the selected clips as separate files in chronological order (`clip1.wav`/`clip1.mp3`, `clip2.wav`/`clip2.mp3` for audio-only sources; `clip1.mp4`, `clip2.mp4` for video sources). Share these exact clips with the clinician along with their timestamps as reference guides.
3. **Step 3: Creator Re-recording Gate (STRICT STOP GATE):** **DO NOT edit or assemble the final Reel before the clinician provides the professional recordings.** Wait for the clinician to re-record professional versions with the same dialogue/context.
4. **Step 4: Create Instagram Reel:** Once professional recordings are provided, assemble them with code-drawn canvas scenes, motion design/graphics, dynamic transitions, animated captions, SFX/music, and purposeful pacing.
5. **Step 5: Deliver Complete Package:** Final Reel (-14 LUFS), the reference clips, the final professional clips saved separately, and editable project files.

---

### Step-by-Step Technical Execution
1. **Intake & Disambiguation:** Confirm duration (40–90s), script status, and voice mode (on-camera sync vs separate VO). Request original camera files.
2. **Clinical Claim Audit:** Keep authored script intact unless revisions are requested. Fact-check acoustic, device, and clinical statements. Ensure limitations are stated realistically.
3. **Timeline Manifest (`shots.json`):** Construct an ordered, contiguous shot list complying with [references/timeline-schema.md](references/timeline-schema.md). Classify every shot as either `creator-talking-head` or `code-drawn`. Verify every single shot is **≤ 4.0 seconds**.
4. **Build Code Scenes:** Develop procedural Canvas animations (`piece.html` or equivalent). Employ pure frame render functions (`render(frame)`), warm storybook palettes, legible typography, and continuous micro-motion.
5. **Assemble & Sync Audio:** Bridge animated cutaways with the clinician's master voice track. Maintain exact lip-sync on host cuts. Align phone-readable captions to real delivered speech within safe zones.
6. **Two-part QA Loop:**
   - **Technical Review:** Run `node "<skill-folder>/scripts/review-reel.mjs" --video "<render.mp4>" --timeline "<shots.json>"`. Hard-gate on 0 errors (specs, ≤4.0s shot durations, no speech-policy violations, contact sheets generated).
   - **Visual Critique:** Examine contact sheets and frame samples against [references/visual-critique.md](references/visual-critique.md) (check for facial malformations, text/face collisions, awkward transition freezes, sound rings overlapping heads, or unnatural device geometry). Apply the concept-gating dumb-watch pass and the 9 permanent principles.
   - **Iterate in Code:** Repair code or cut points directly, re-render, and re-review until fully clean.
7. **Delivery:** Provide the rendered MP4, editable code source, `shots.json`, SRT captions, and QA contact sheets.

Read [references/workflow.md](references/workflow.md) for production notes from previous clinic episodes, and [references/talking-head-integration.md](references/talking-head-integration.md) for complete host recording and visual integration details.
