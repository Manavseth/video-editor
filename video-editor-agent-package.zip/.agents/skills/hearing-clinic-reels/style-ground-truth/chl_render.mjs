// CHL style test: renders chl_piece.html (8 scenes, NF=945, 31.5 s) to a video
// master, then muxes the chl.mp4 voiceover audio underneath. 1080x1920 @ 30fps.
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const root = path.dirname(__filename);
const require = createRequire(import.meta.url);

import { createCanvas } from '@napi-rs/canvas';

const PIECE = 'chl_piece.html';
const FPS = 30, NF = 945, W = 1080, H = 1920;
const AUDIO = 'style_test_20s/chl_audio.wav';

const FF = 'ffmpeg';

function createRenderer() {
  const canvas = createCanvas(W, H);
  const fakeWin = {
    document: { getElementById: id => (id === 'cv' ? canvas : { addEventListener: () => {} }) },
    performance: { now: () => 0 },
    requestAnimationFrame: () => {},
  };
  const html = fs.readFileSync(path.join(root, PIECE), 'utf8');
  const scriptMatch = html.match(/<script>([\s\S]*?)<\/script>/);
  if (!scriptMatch) throw new Error('Script block not found in ' + PIECE);
  const fn = new Function('window', 'document', 'performance', 'requestAnimationFrame', scriptMatch[1]);
  fn(fakeWin, fakeWin.document, fakeWin.performance, fakeWin.requestAnimationFrame);
  if (typeof fakeWin.render !== 'function') throw new Error('window.render not exposed');
  return { canvas, render: fakeWin.render, NF: fakeWin.NF, bounds: fakeWin.bounds };
}

async function run(bin, args) {
  await new Promise((res, rej) => {
    const p = spawn(bin, args, { stdio: 'inherit' });
    p.on('error', rej);
    p.on('close', c => (c === 0 ? res() : rej(new Error(`${bin} exited ${c}`))));
  });
}

async function main() {
  const { canvas, render, NF: pieceNF, bounds } = createRenderer();
  if (pieceNF !== NF) throw new Error(`piece NF=${pieceNF}, runner expects ${NF}`);
  console.log(`CHL TEST: ${PIECE} — 1080x1920 @ ${FPS}fps, ${NF} frames, bounds=${bounds.join(',')}`);

  const outDir = path.join(root, 'style_test_chl');
  fs.mkdirSync(outDir, { recursive: true });
  const master = path.join(outDir, 'chl_video_master.mp4');

  const proc = spawn(FF, [
    '-y', '-hide_banner', '-loglevel', 'error',
    '-f', 'image2pipe', '-framerate', String(FPS), '-vcodec', 'png', '-i', '-',
    '-frames:v', String(NF), '-an', '-c:v', 'libx264', '-preset', 'medium',
    '-crf', '18', '-pix_fmt', 'yuv420p', '-r', String(FPS), '-movflags', '+faststart',
    master,
  ], { stdio: ['pipe', 'inherit', 'inherit'] });

  const writeFrame = buf => new Promise(resolve => {
    if (!proc.stdin.write(buf)) proc.stdin.once('drain', resolve);
    else process.nextTick(resolve);
  });

  const QA = new Set([45, 60, 150, 240, 330, 430, 460, 540, 570, 660, 700, 780, 810, 944]);
  const t0 = Date.now();
  for (let f = 0; f < NF; f++) {
    render(f);
    const buf = canvas.toBuffer('image/png');
    if (QA.has(f)) fs.writeFileSync(path.join(outDir, `qa_${String(f).padStart(4, '0')}.png`), buf);
    await writeFrame(buf);
    if (f % 130 === 0 || f === NF - 1) console.log(`frame ${f + 1}/${NF} at ${((Date.now() - t0) / 1000).toFixed(1)}s`);
  }
  proc.stdin.end();
  await new Promise((res, rej) => {
    proc.on('error', rej);
    proc.on('close', c => (c === 0 ? res() : rej(new Error(`ffmpeg exited ${c}`))));
  });
  console.log(`video master done: ${master}`);

  const finalOut = path.join(outDir, 'chl_style_test.mp4');
  console.log('--- muxing creator voiceover ---');
  await run(FF, [
    '-y', '-hide_banner', '-loglevel', 'error',
    '-i', master, '-i', path.join(root, AUDIO),
    '-map', '0:v:0', '-map', '1:a:0', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k',
    '-t', '31.5', '-movflags', '+faststart',
    finalOut,
  ]);
  console.log(`DONE: ${finalOut}`);
}

main().catch(e => { console.error(e); process.exit(1); });
