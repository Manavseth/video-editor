# Environmental Classifier — Reel Style System (content-agnostic)

**What this is.** The codified STYLE of `environmental_classifier_master_reel.mp4`, extracted so any future script can be poured into the same look. Every string you see in a final render — titles, labels, caption words, pill text, scene names — is **content** and lives in token/config slots. Everything described here — layout grammar, component interaction rules, representation choices, motion laws, palette/type contract — is **style** and never changes between reels.

**Authority rule.** Where the planning storyboard and the actual render differ, the render wins. All geometry below was pixel-verified against the master (qa color passes + visual crops); the as-built deltas are compiled in §9 and in the as-built storyboard §0.

**Kit files** (all in `environmental_classifier_reference_clips/`):

| File | Role |
|---|---|
| `environmental_classifier_piece_template.html` | fill-out template: window.render(f) contract, full as-built scene code |
| `environmental_classifier_master_shots.json` | shot-timeline manifest (schema v1: 12 shots, cut map 0…1622 frames) |
| `environmental_classifier_piece_render.mjs` | stills runner (`--frames=300,990,…` → `render_check/piece_frame_NNNN.png`) |
| `render.mjs` (workspace root) | production runner: napi-canvas → PNG → libx264 H.264 |
| `environmental_classifier_asbuilt_storyboard.md` | master reel description + §0 errata (content reference) |

---

## 1. Style philosophy (the five laws)

1. **Invisible devices get honest plumbing.** A hearing aid's impossible-to-see behavior is drawn as literal metaphors: inlet panels, classifier blocks, output slots, wells, knobs, routes. Never decoration — every drawn shape maps to one clause of the script.
2. **Flat ink-on-paper vector, zero photographic texture.** One background (`paper`), rounded-rect cards with 2–3 px ink borders, flat fills, no gradients, no shadows (the caption plate border is crisp too). Authority = precision, not realism.
3. **One accent, one meaning.** Teal is the ONLY accent and always means *the system acting, a value, or a result*. Teal never means "decorative". If a shape is teal, the script can point at it and say "this".
4. **People vs environment is a two-color code.** Charcoal (`ink`) figures = the people whose experience the script is about; light-gray (`light`) figures = the surrounding world — perceived but not changed. This lets a busy/quiet contrast be read instantly without any text.
5. **Cuts are hard; graphics arrive at cuts.** Every shot enters fully settled (heading, card outlines opaque) — the viewer never watches a transition AND reads text at the same time. All motion happens inside a shot; nothing crosses a cut.

## 2. Fixed canvas & layout grammar

- 1080 × 1920 @ 30 fps. Margins x 70…1010 (keep your own gutter if different, but fix ONE).
- Zones: heading y 290–385 · content y 440–1300 · footer caps band ~1330–1390 · caption plate bottom-anchored at y 1606.
- Every code-drawn scene opens with the **heading lockup** `heading(kicker, title)`: gray letterspaced caps kicker (`"nn / KICKER"`, 24 px, ls 2, center y317) + ink bold display title (54 px, center y380). STATIC at every cut — the kicker/title are content tokens, their placement is style.
- **Card anatomy:** white `#FFFDF8` rounded-rect, ink 3 px border, radius 20–28 (24 typical). Card titles: ink bold 19–26 px at card-left + 28 px inset, with a 2 px `rule` hairline under any card that has stacked internal minis. Warm panels (`#F2F0E9`, rule border) = "environment/input" contexts inside cards.
- **Tag pills** (`pill(label,x,y,{anchor,h,size,dot})`): pale fill + teal border + teal bold caps. Two sizes in the wild: standard h47/size22, compact h36–40/size15–17. A teal dot r6 marks the "live state" variant only.
- **Footer qualifiers:** two forms — (a) letterspaced ink/gray caps plain text, (b) `labelBar` claim bar: pale fill, teal border r22, teal semibold caps 21 px, h56, revealed by a horizontal wipe 0.25–0.60 s before the shot tail.
- **Caption plate (fixed):** one box x74 w856, bottom y1606, radius 24, crisp ink border 2.5 px, NO shadow. Height follows line count: 1/2/3-line tops = 1502/1462/1451; leading 54/54/48; last-line baselines 1552/1582/1588; every line centered on the plate (center x 501). Plate in/out = cue start +0.15 s / cue end −0.10 s. Text 44 px Segoe UI w600; emphasized words w700 teal (top 2–3 words/clause, chosen per cue). Line breaks are authored per cue — never auto-wrapped.

## 3. Scene grammar: script beat → scene archetype

The 12-shot reel is a repeating **register duet** (talking-head ↔ motion graphic). Host windows belong to the creator footage rules (four windows, real camera, no overlays except the plate). Motion windows come in the following archetypes; each has fixed bones and content slots:

| Beat in script | Archetype (as-built id) | Fixed bones | Content slots |
|---|---|---|---|
| Analogy / hook ("you already know this…") | **Morph-pipeline** (MG-01) | outline prop → process card (INLET panel + SCENE block + 2 output slots) | prop contents, card label, block sub-label, slot tag, kicker/title |
| Mechanism intro ("what it can/can't do") | **Gate-split** (MG-02) | gate card w/ teal block · list card w/ stacked warm minis · intent card + stub+✕ | block sub-label, mini labels, intent lines |
| Context examples ("same place, different world") | **Twin comparison** (MG-03) | two tall pair cards + header rule + turn-token + focus underline/label bar | card labels only |
| Everyday friction ("keeps fiddling…") | **Route-selector** (MG-04) | 3 lane minis + route line w/ ring stops + selector card + cursor(s) + caps footer | mini labels, stop labels, selector rows, footer line |
| Two behaviors compared ("old vs new") | **Two-lane** (MG-05) | 2 tall lanes: taps→settings vs classifier panel→settings + tag pill + claim bar | lane headings, mini scene label, detected word, pill text, claim bar |
| Verdict moment ("so it decides…") | **Block-result** (MG-06) | input card w/ crowded vignette + center SCENE block + result card w/ pill + L-connector | card title, block text, pill text |
| Settings metaphor ("depend on knobs…") | **Two-row metaphor** (MG-07) | tag pill + sliders card + two-row metaphor card (slide + blend → shared well) | knob labels, row labels, chip word, placeholder word, pill text |
| Payoff ("life is just…") | **Conversation card** (MG-08) | one big card: gray crowd above, chunky pair below, 2 primary bubbles + connector + claim bar | card title, claim bar |

**Blocking constants (all archetypes):** kicker+title at top y290–385; content zone 440–1300; tall side-by-side cards leave a ≥60 px gutter; center column reserved for the SCENE block whenever the beat is about classification. Nothing essential beyond x1030.

## 4. Component interaction rules (fixed)

- **Connectors** (`connector(pts, drawT, col, lw, dotR)`): teal, round caps, length-proportional draw-on ~0.5–1.3 s, ease-out. Start dot always; end dots only for resolved flow-shot connectors (r7). No elbow rounding while drawing; elbows may get soft dots at resolution. Rule lines (gray `#B5B7B2`) are the non-accent counterpart.
- **Travel-under occlusion:** a travelling mini-card is drawn BEFORE the teal block each frame, so it visually slides INTO the block and disappears — the signature "absorbed" beat (MG-01 INLET, MG-06 block).
- **Processing phase:** the SCENE block turns `procInk` (near-black) for ~1.0 s with an ink border, then returns teal at the exact moment its result pill pops. Processing is shown exactly twice per reel (MG-01 t+1.65–2.55, MG-06 t+1.30–2.30) — a result pill pop without a prior ink phase is a style violation.
- **Result grammar:** result pill = pale fill, teal border r16, teal dot r11 left, ink bold 17 px caps, land with `easePop` (≈2% overshoot, 0.35 s). Pops only ever apply to tags/pills/chips — cards and connectors always ease-out, never bounce.
- **Tap grammar:** human input = white arrow cursor (`pointer`, ink stroke, radius joints) + teal pulse ring on tap; the system reacts AFTER the tap (manual lane). Automatic reaction = no cursor at all (scene-classifier lane). Manual cost vs automatic benefit is expressed by this asymmetry — keep the cursor count honest (one idle parked cursor is allowed).
- **Rejection grammar:** dead ends are gray stubs ending in the deny-red ✕ (MG-02) or an empty gray slot (`SLOT 1`, MG-07). Never a filled error card, never text warnings.
- **Turn-token:** a teal dot r8 ping-pongs between the two speech positions on `tri03` (~3 s cycle) any time two speakers take turns in a card — it encodes conversation rhythm with zero text.
- **Idle drift:** background crowds drift horizontally ≤10 px on a ~6 s sine; foreground never idles.
- **Focus accent:** after a contrast is established, a teal underline (with optional end ticks) or label-bar wipe re-frames the shared element (MG-03) and a claim bar names it. Underline first, label bar lands over/after it.

## 5. Representation dictionary (script state → visual)

| Script context | Visual |
|---|---|
| Person speaking / heard | ink figure + white/accented speech bubble (teal first dash) |
| Person muted / unheard | light figure + muted bubble (`mutedFill` fill, light border, no teal) OR white-outline bubble with light dashes |
| Crowd / environment | light figures + benches/tables in light; optional tilted `chipGray` debris for chaos |
| Device doing its job | teal SCENE block; processing = procInk phase; results = pale/teal pills |
| A setting / value | teal chip or pill in a `slotfill` slot cell; vacated slot = gray placeholder caps |
| State carried between shots | tag pill repeated at shot top (BUSY CONVERSATION carries MG-06→07) |
| Sequence over time | route line + ring stops + teal marker |
| Continuous control | teal knob r19 on a 12 px rule track (MODEL right-biased, FITTING left-biased) |
| Judgment / claim | pale label bar, teal caps, wipe reveal |
| Failure / not possible | gray stub + deny-red ✕ only |
| The analogy object | one-off prop (phone outline + ochre sun) living only in its own scene |

Primitives (do not re-invent): `figure(cx,cy,s,col)` head r24s + torso 78s×94s r28s; `bubble`/`chipBubble`/`mbubble`/`paleBubble` (4 bubble grades); `table(x,y,w,light)` bar+legs+chair marks; `laneMini` mini card (white fill, ink bold label, 2 pale chips, slim ink pair, plain table line, optional gray flankers + tilt); `pairCard`; `pill`; `resultPill` (legacy white variant, do not use for results — see §9); `labelBar`; `connector`; `pointer`; `heading`.

**Emphasis ladder (strict):** teal-filled > pale+teal-border > white+ink-border > slotfill/warm > gray/light > muted. Any new component must pick its rung by how load-bearing the script clause is.

## 6. Palette & type contract (flat code values)

| Token | Value | Meaning |
|---|---|---|
| `paper` | `#F5F2EA` | every motion-scene background |
| `ink` | `#20252B` | figures/borders/titles + caption plate border |
| `gray` | `#8B9298` | kickers, sub-labels, placeholders |
| `light` | `#B5B7B2` | crowd, muted strokes, stub ends, rule lines |
| `teal` | `#2D8C85` | THE accent |
| `pale` | `#E7F2EF` | pill/panel/bar fills, active rows, output well |
| `white` | `#FFFDF8` | card + plate fills |
| `rule` | `#D6D3C8` | tracks, hairlines, inactive rows |
| `ochre` | `#C9A65E` | the analogy prop only (sun) |
| `denyRed` | `#D04B46` | the ✕ glyph only |
| `procInk` | `#1F242A` | processing phase of SCENE blocks |
| `chipGray` | `#D9D9D4` | tilted debris chips |
| `mutedFill` | `#EDECE7` | muted bubble fill |
| `slotfill` | `#EBE9E3` | slot cells |
| `warm` | `#F2F0E9` | environment panels/minis |

Type = Segoe UI only (Reg/Semibold/Bold). Sizes: display title 54 bold · kicker 24 ls2 gray · card titles 19–26 bold · mini labels 19 (700) compact minis 17 pill text · pill body 15–22 (700) · labels-in-row 17–20 (600) · caption 44 (600; emphasis 700). Never introduce a fifth weight or a new size — rescale the component instead.

*(Pipeline note: the master's H.264 encode shifts every flat value down ~1-3 units/channel. Do not "fix" code values toward sampled video pixels — the runner is already matched to the master's YUV.)*

## 7. Motion laws

- Easing: `easeOutCubic` for every path/reveal; `easePop` (≈2% overshoot) only for tag/pill/chip landings; `tri03` only for the turn-token; sine only for crowd drift. No linear motion, no springy overshoot beyond 2%.
- Every beat is a *draw* (outline→fill, connector length, bar wipe) or a *reposition* with a landing; fades are limited to the phone→card swap and take <0.25 s.
- Cut discipline: all draws complete ≥0.05 s before the cut; a hold (≥0.3 s) precedes every cut; headings and cards are opaque at frame 0 of a scene.
- Scene-local timings are authored per beat (t+0.15 stepping is typical). Reuse the as-built constants in §3 rows of the storyboard rather than inventing new durations.
- Host windows: real camera, zero motion graphics, caption plate as sole overlay. Cut on audio beats.

## 8. Using the kit for a new script (swappability)

1. **Write the beat sheet** against the §3 archetype table (12-slot or fewer; every maximum motion window ≤ 4.0 s — §9 covers the master's as-built exception).
2. **Fill content slots** in the template: SRT (`lines`+`hl` per cue — breaks authored), heading pairs per scene, card/mini/pill/row strings, claim-bar wording. Nothing else changes.
3. **Set `bounds`/`SCENE_COUNTS`** to your cut map; keep fill-out structure identical.
4. **QA pass:** render tail-frames of every scene (`--frames=<cut−1 of each shot>`), plus per-cue caption strips; check (a) settle-before-cut, (b) caption plate height/line-center, (c) teal never appears without a script clause, (d) manual-vs-auto cursor asymmetry intact.
5. **Production render:** `render.mjs` reads `piece.html`'s `window.render`, asserts `READY`/`FPS`/`NF`/`bounds`, diffs the canvas per frame into libx264 (silent H.264); voice + music composite after, per the talking-head integration rules.

## 9. As-built deltas to carry forward (accepted)

- **Host windows exceed the 4.0 s storyboard-style rule** (6.53/8.43/5.47/6.63 s in the master). The style's 4 s max applies to *motion* windows; as-built host windows are audio-bound. Keep motion windows ≤ 4.0 s in new productions.
- **MG-06→MG-07 cut truth:** detector puts it at/before frame 1250; the manifest/bounds keep 1251. Do not re-time.
- **MG-03 foreground pair torso is slim** (40×58) vs the 68 px canon torso — accepted (compact pair sizing for tall cards).
- **`resultPill` (white/gray variant) is legacy** — superseded by the pale/teal/ink result pill (MG-06); kept alive only as a component reference.
- **Route line is single-tone 9 px** in MG-04 (two-tone was an artifact of a stale crop version).
- Caption plate is FIXED-width (not shrink-to-fit) with a crisp ink border and baked per-cue line breaks; 3-line cues compress leading (54→48) — never expose mid-word wraps.
