#!/usr/bin/env node
// Deterministic technical/timeline QA and scene sampling for code-drawn clinic Reels.
// Usage: node review-reel.mjs --video reel.mp4 --timeline shots.json [--out qa]
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const HARD_MAX_SHOT_SEC = 4.0;
const SHEET_COLS = 3;
const SHEET_ROWS = 3;
const SHEET_CAPACITY = SHEET_COLS * SHEET_ROWS;

function usage() {
  console.log('Usage: node review-reel.mjs --video <render.mp4> --timeline <shots.json> [--out <qa-folder>]');
  console.log('Checks video specs, audio policy, shot timing and gaps; extracts 3 review frames per shot into contact sheets.');
}

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--help' || arg === '-h') { out.help = true; continue; }
    if (!arg.startsWith('--')) throw new Error(`Unexpected argument: ${arg}`);
    const key = arg.slice(2);
    const value = argv[++i];
    if (!value || value.startsWith('--')) throw new Error(`Missing value for ${arg}`);
    out[key] = value;
  }
  return out;
}

function run(bin, args, { allowFailure = false, maxBuffer = 32 * 1024 * 1024 } = {}) {
  const result = spawnSync(bin, args, { encoding: 'utf8', maxBuffer, windowsHide: true });
  if (result.error) throw new Error(`Could not run ${bin}: ${result.error.message}`);
  if (!allowFailure && result.status !== 0) {
    throw new Error(`${bin} exited ${result.status}: ${(result.stderr || result.stdout || '').trim()}`);
  }
  return { status: result.status, stdout: result.stdout || '', stderr: result.stderr || '' };
}

function fraction(value) {
  if (!value || value === '0/0') return NaN;
  const [a, b] = String(value).split('/').map(Number);
  return b ? a / b : a;
}

function safeName(value) {
  return String(value).replace(/[^a-zA-Z0-9_-]+/g, '-').replace(/^-+|-+$/g, '').toLowerCase() || 'reel';
}

function add(checks, id, ok, detail) {
  checks.push({ id, status: ok ? 'PASS' : 'FAIL', detail });
}

function validateTimeline(timeline, duration, fps, checks) {
  const shots = timeline.shots;
  if (!Array.isArray(shots) || shots.length === 0) {
    add(checks, 'timeline-shots', false, 'Timeline must contain a non-empty shots array.');
    return [];
  }
  let valid = true;
  const ids = new Set();
  const frameTolerance = Math.max(1 / (Number.isFinite(fps) && fps > 0 ? fps : 30), 0.001);
  for (let i = 0; i < shots.length; i++) {
    const shot = shots[i];
    const id = String(shot.id ?? `S${String(i + 1).padStart(2, '0')}`);
    shot.id = id;
    const start = Number(shot.start);
    const end = Number(shot.end);
    const length = end - start;
    if (ids.has(id)) { add(checks, `timeline-${id}-unique`, false, `Duplicate shot ID ${id}.`); valid = false; }
    ids.add(id);
    if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end <= start) {
      add(checks, `timeline-${id}-bounds`, false, `Invalid start/end values: ${shot.start}–${shot.end}.`); valid = false;
    }
    if (length > HARD_MAX_SHOT_SEC + 1e-6) {
      add(checks, `timeline-${id}-duration`, false, `${id} lasts ${length.toFixed(3)}s; the permanent maximum is ${HARD_MAX_SHOT_SEC.toFixed(1)}s.`); valid = false;
    } else {
      add(checks, `timeline-${id}-duration`, true, `${id} lasts ${length.toFixed(3)}s.`);
    }
    if (!String(shot.description ?? '').trim()) {
      add(checks, `timeline-${id}-description`, false, `${id} needs a visual description.`); valid = false;
    }
    if (!String(shot.motion ?? '').trim()) {
      add(checks, `timeline-${id}-motion`, false, `${id} needs a continuously moving element or an explicit intentional-hold note.`); valid = false;
    }
    if (!['code-drawn', 'creator-talking-head'].includes(String(shot.visualSource ?? ''))) {
      add(checks, `timeline-${id}-visual-source`, false, `${id} must declare visualSource as code-drawn or creator-talking-head.`); valid = false;
    } else {
      add(checks, `timeline-${id}-visual-source`, true, `${id} source: ${shot.visualSource}.`);
    }
    if (i === 0 && Math.abs(start) > frameTolerance) {
      add(checks, 'timeline-start', false, `The first shot starts at ${start.toFixed(3)}s instead of 0.`); valid = false;
    }
    if (i > 0) {
      const prevEnd = Number(shots[i - 1].end);
      const gap = start - prevEnd;
      if (Math.abs(gap) > 0.001) {
        add(checks, `timeline-${id}-cut`, false, gap > 0 ? `${gap.toFixed(3)}s gap before ${id}.` : `${Math.abs(gap).toFixed(3)}s overlap before ${id}.`); valid = false;
      }
    }
  }
  const finalEnd = Number(shots.at(-1)?.end);
  if (!Number.isFinite(duration)) {
    add(checks, 'timeline-tail', false, 'Video duration is unavailable, so the timeline end cannot be verified.'); valid = false;
  } else if (Math.abs(finalEnd - duration) > Math.max(frameTolerance, 0.04)) {
    add(checks, 'timeline-tail', false, `Timeline ends at ${finalEnd.toFixed(3)}s but video ends at ${duration.toFixed(3)}s.`); valid = false;
  } else {
    add(checks, 'timeline-tail', true, `Timeline end matches the ${duration.toFixed(3)}s render.`);
  }
  add(checks, 'timeline-contiguity', valid, valid ? `${shots.length} contiguous shots; none exceeds ${HARD_MAX_SHOT_SEC.toFixed(1)}s.` : 'Fix the timeline failures listed above.');
  return shots;
}

function collectSamples(shots, fps) {
  const samples = [];
  const frameStep = 1 / (Number.isFinite(fps) && fps > 0 ? fps : 30);
  for (let i = 0; i < shots.length; i++) {
    const shot = shots[i];
    const start = Number(shot.start), end = Number(shot.end), length = end - start;
    if (!Number.isFinite(start) || !Number.isFinite(end) || length <= 0) continue;
    const edge = Math.min(0.2, length / 4);
    const points = [
      { label: 'entry', time: start + edge },
      { label: 'mid', time: (start + end) / 2 },
      { label: 'exit', time: end - edge },
    ];
    const seen = new Set();
    for (const point of points) {
      const time = Math.max(0, Math.min(point.time, end - 0.001));
      const rounded = Number(time.toFixed(3));
      if (seen.has(rounded)) continue;
      seen.add(rounded);
      samples.push({ shotId: shot.id, shotNumber: i + 1, label: point.label, time: rounded, description: shot.description, motion: shot.motion, visualSource: shot.visualSource });
    }
    if (i < shots.length - 1) {
      const next = shots[i + 1];
      const cut = Number(shot.end);
      const pre = Number(Math.max(0, cut - frameStep).toFixed(3));
      const post = Number((Number(next.start) + frameStep).toFixed(3));
      samples.push({ shotId: shot.id, shotNumber: i + 1, label: 'cut-before', time: pre, description: shot.description, motion: shot.motion, visualSource: shot.visualSource });
      samples.push({ shotId: next.id, shotNumber: i + 2, label: 'cut-after', time: post, description: next.description, motion: next.motion, visualSource: next.visualSource });
    }
  }
  return samples;
}

function parseFilterEvents(stderr, key) {
  const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`${escaped}[^\\n]*?${key === 'freeze' ? 'freeze_duration' : 'black_duration'}:\\s*([0-9.]+)`, 'g');
  return [...stderr.matchAll(pattern)].map(match => Number(match[1])).filter(Number.isFinite);
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) { usage(); return; }
  if (!args.video || !args.timeline) { usage(); throw new Error('Both --video and --timeline are required.'); }

  const videoPath = path.resolve(args.video);
  const timelinePath = path.resolve(args.timeline);
  if (!fs.existsSync(videoPath)) throw new Error(`Video not found: ${videoPath}`);
  if (!fs.existsSync(timelinePath)) throw new Error(`Timeline not found: ${timelinePath}`);
  const timeline = JSON.parse(fs.readFileSync(timelinePath, 'utf8'));
  if (timeline.version !== 1) throw new Error('Timeline version must be 1.');

  const baseOut = path.resolve(args.out || path.join(path.dirname(videoPath), 'qa'));
  fs.mkdirSync(baseOut, { recursive: true });
  const runStamp = new Date().toISOString().replace(/[-:.]/g, '');
  const runDir = path.join(baseOut, `${safeName(path.basename(videoPath, path.extname(videoPath)))}-${runStamp}`);
  const framesDir = path.join(runDir, 'frames');
  const pagesDir = path.join(runDir, 'pages');
  fs.mkdirSync(framesDir, { recursive: true });
  fs.mkdirSync(pagesDir, { recursive: true });

  const probeResult = run('ffprobe', ['-v', 'error', '-show_streams', '-show_format', '-of', 'json', videoPath]);
  const probe = JSON.parse(probeResult.stdout);
  const videoStream = (probe.streams || []).find(stream => stream.codec_type === 'video');
  const audioStreams = (probe.streams || []).filter(stream => stream.codec_type === 'audio');
  if (!videoStream) throw new Error('No video stream was found.');
  const formatDuration = Number(probe.format?.duration);
  const duration = Number.isFinite(formatDuration) ? formatDuration : Number(videoStream.duration);
  const fps = fraction(videoStream.avg_frame_rate || videoStream.r_frame_rate);
  const expected = timeline.expectedVideo || {};
  const expectedWidth = Number(expected.width ?? 1080);
  const expectedHeight = Number(expected.height ?? 1920);
  const expectedFps = Number(expected.fps ?? 30);
  const audioPolicy = expected.audio ?? 'silent';
  if (!['silent', 'user-voice-or-silent'].includes(audioPolicy)) throw new Error('expectedVideo.audio must be silent or user-voice-or-silent.');

  const checks = [];
  add(checks, 'video-resolution', Number(videoStream.width) === expectedWidth && Number(videoStream.height) === expectedHeight,
    `${videoStream.width}×${videoStream.height}; expected ${expectedWidth}×${expectedHeight}.`);
  add(checks, 'video-frame-rate', Number.isFinite(fps) && Math.abs(fps - expectedFps) < 0.05,
    `${Number.isFinite(fps) ? fps.toFixed(3) : 'unknown'} fps; expected ${expectedFps}.`);
  const isMp4 = /mp4|mov|3gp|3g2/i.test(String(probe.format?.format_name || ''));
  add(checks, 'video-container', isMp4, `${probe.format?.format_name || 'unknown'} container; expected an MP4-compatible container.`);
  if (audioPolicy === 'silent') {
    add(checks, 'audio-policy', audioStreams.length === 0, audioStreams.length ? `Found ${audioStreams.length} audio stream(s); the review cut must be silent.` : 'No audio streams; silent review-cut policy passed.');
  } else {
    add(checks, 'audio-policy', true, audioStreams.length ? 'Audio stream is present. This check does not identify its speaker or prove it is the creator’s recording.' : 'Silent proof is allowed by the manifest.');
  }
  validateTimeline(timeline, duration, fps, checks);

  const samples = collectSamples(timeline.shots || [], fps);
  const indexLines = [
    '# Visual review index',
    '',
    `Video: ${videoPath}`,
    `Timeline: ${timelinePath}`,
    `Samples: ${samples.length} (entry, midpoint, exit, and one-frame-before/after samples around each cut)`,
    '',
    'Contact sheets use three columns and three rows. Read each page left-to-right, then top-to-bottom. The numbered cell maps to the entries below. Cut-before and cut-after samples are exactly one frame on each side of a scene boundary.',
    '',
  ];
  for (let i = 0; i < samples.length; i++) {
    const sample = samples[i];
    const page = Math.floor(i / SHEET_CAPACITY) + 1;
    const cell = (i % SHEET_CAPACITY) + 1;
    const fileName = `sample-${String(i + 1).padStart(3, '0')}.png`;
    sample.file = path.join(framesDir, fileName);
    sample.page = page;
    sample.cell = cell;
    indexLines.push(`- Page ${String(page).padStart(2, '0')}, cell ${cell}: **${sample.shotId} ${sample.label}**, ${sample.time.toFixed(2)}s (${sample.visualSource || 'source missing'}) — ${sample.description}. Motion to verify: ${sample.motion}`);
  }

  for (let i = 0; i < samples.length; i++) {
    const sample = samples[i];
    const filter = 'scale=320:568:force_original_aspect_ratio=decrease,pad=320:568:(ow-iw)/2:(oh-ih)/2:color=black';
    run('ffmpeg', ['-y', '-hide_banner', '-loglevel', 'error', '-ss', sample.time.toFixed(3), '-i', videoPath,
      '-frames:v', '1', '-vf', filter, '-an', sample.file]);
    const pageDir = path.join(pagesDir, `page-${String(sample.page).padStart(2, '0')}`);
    fs.mkdirSync(pageDir, { recursive: true });
    fs.copyFileSync(sample.file, path.join(pageDir, `sample-${String(sample.cell).padStart(3, '0')}.png`));
  }

  const pageCount = Math.ceil(samples.length / SHEET_CAPACITY);
  const contactSheets = [];
  for (let page = 1; page <= pageCount; page++) {
    const pageDir = path.join(pagesDir, `page-${String(page).padStart(2, '0')}`);
    const output = path.join(runDir, `contact-sheet-${String(page).padStart(2, '0')}.png`);
    const tileFilter = `tile=${SHEET_COLS}x${SHEET_ROWS}:nb_frames=${SHEET_CAPACITY}`;
    run('ffmpeg', ['-y', '-hide_banner', '-loglevel', 'error', '-framerate', '1', '-start_number', '1',
      '-i', path.join(pageDir, 'sample-%03d.png'), '-vf', tileFilter, '-frames:v', '1', output]);
    contactSheets.push(output);
  }
  fs.writeFileSync(path.join(runDir, 'review-index.md'), `${indexLines.join('\n')}\n`, 'utf8');

  const motionResult = run('ffmpeg', ['-hide_banner', '-nostats', '-loglevel', 'info', '-i', videoPath,
    '-vf', 'freezedetect=n=-60dB:d=1.2,blackdetect=d=0.5:pix_th=0.08', '-an', '-f', 'null', '-'], { allowFailure: true });
  const freezeDurations = parseFilterEvents(motionResult.stderr, 'freeze');
  const blackDurations = parseFilterEvents(motionResult.stderr, 'black');
  const warnings = [];
  if (motionResult.status !== 0) warnings.push(`FFmpeg freeze/black analysis exited ${motionResult.status}; review the frames visually.`);
  if (freezeDurations.length) warnings.push(`Low-global-motion candidates (${freezeDurations.map(value => `${value.toFixed(2)}s`).join(', ')}). A small element may still be moving; inspect these intervals before changing the art.`);
  if (blackDurations.length) warnings.push(`Near-black stretches detected: ${blackDurations.map(value => `${value.toFixed(2)}s`).join(', ')}. Confirm whether each transition is intentional.`);

  const failures = checks.filter(check => check.status === 'FAIL');
  const report = {
    generatedAt: new Date().toISOString(),
    video: videoPath,
    timeline: timelinePath,
    runDirectory: runDir,
    metadata: {
      durationSeconds: duration,
      width: Number(videoStream.width),
      height: Number(videoStream.height),
      fps,
      videoCodec: videoStream.codec_name,
      pixelFormat: videoStream.pix_fmt,
      container: probe.format?.format_name,
      audioStreams: audioStreams.length,
      audioPolicy,
      shotCount: timeline.shots?.length || 0,
      visualSourceCounts: (timeline.shots || []).reduce((counts, shot) => { const source = String(shot.visualSource || 'missing'); counts[source] = (counts[source] || 0) + 1; return counts; }, {}),
      maxShotSeconds: HARD_MAX_SHOT_SEC,
      sampledFrames: samples.length,
      contactSheets,
    },
    checks,
    warnings,
    status: failures.length ? 'FAIL' : (warnings.length ? 'PASS_WITH_WARNINGS' : 'PASS'),
  };
  fs.writeFileSync(path.join(runDir, 'qa-report.json'), `${JSON.stringify(report, null, 2)}\n`, 'utf8');
  const markdown = [
    '# Reel QA report', '',
    `**Status:** ${report.status}`, '',
    `- Duration: ${duration.toFixed(3)}s`,
    `- Frame: ${videoStream.width}×${videoStream.height} at ${Number.isFinite(fps) ? fps.toFixed(3) : 'unknown'} fps`,
    `- Video: ${videoStream.codec_name} / ${videoStream.pix_fmt || 'unknown pixel format'}`,
    `- Audio streams: ${audioStreams.length} (policy: ${audioPolicy})`,
    `- Shots: ${timeline.shots?.length || 0}; hard maximum ${HARD_MAX_SHOT_SEC.toFixed(1)}s`,
    `- Sampled frames: ${samples.length}`,
    '', '## Structural checks', '',
    ...checks.map(check => `- **${check.status} ${check.id}:** ${check.detail}`),
    '', '## Warnings', '',
    ...(warnings.length ? warnings.map(warning => `- ${warning}`) : ['- None from the motion/black-frame scan.']),
    '', '## Visual review', '',
    'Inspect every contact sheet listed below and use `review-index.md` to map cells to shot IDs and timestamps. Open individual PNGs in `frames/` at full size where detail is unclear. Apply the full rubric in the skill’s `references/visual-critique.md`; then repair, rerender, and run this command again.',
    '', ...contactSheets.map(file => `- ${file}`),
    '', `Review index: ${path.join(runDir, 'review-index.md')}`, '',
  ].join('\n');
  fs.writeFileSync(path.join(runDir, 'qa-report.md'), `${markdown}\n`, 'utf8');

  console.log(`QA ${report.status}: ${videoPath}`);
  console.log(`Report: ${path.join(runDir, 'qa-report.md')}`);
  console.log(`Review index: ${path.join(runDir, 'review-index.md')}`);
  for (const sheet of contactSheets) console.log(`Contact sheet: ${sheet}`);
  if (failures.length) process.exitCode = 1;
}

try {
  main();
} catch (error) {
  console.error(`review-reel: ${error.message}`);
  process.exitCode = 1;
}
