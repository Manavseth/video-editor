# Reel Editing Agent Knowledge Bank

**Purpose:** A practical reference for a Codex-based reel/video editing agent. Use this knowledge bank to plan and execute edits that improve storytelling, visual continuity, pacing, transitions, sound design, and perceived production quality.

**Primary rule:** Choose an edit because the moment needs it—not because the technique is available. The job is to make the story clearer, more engaging, and more emotionally precise, not to maximize the number of effects, layers, or transitions.

---

## 1. How to use this knowledge bank

This document combines four training sections supplied by the user:

1. A lesson on ten common editing cuts.
2. A lesson on sound-design fundamentals, sound-effect categories, thematic consistency, sourcing sounds, and monitoring.
3. A lesson on eight techniques for making cuts smoother and less noticeable.
4. A lesson on seven high-value cuts and the role of rhythm in storytelling.

The sections overlap. Where two names refer to related techniques, this bank keeps the distinction clear while explaining how they work together.

### Evidence labels used in this document

- **Source principle:** A teaching explicitly contained in the supplied sections.
- **Operational rule:** A practical instruction inferred from the source principles to make the agent's decisions consistent and testable. It is not presented as a verbatim claim from the training videos.

The training sources are educational transcripts, not a complete technical specification for every editing application. They do not define universal numerical settings for zoom, audio levels, transition duration, loudness, or frame offsets. The agent must determine these from the footage, project settings, and intended result rather than treating any one number as a universal standard.

---

## 2. Editing philosophy and priorities

### 2.1 Story first; effects second

**Source principle:** Great storytelling does not require complicated edits. Simple, intentional cuts can make a video feel coherent and meaningful. Editing should feel like storytelling, not a demonstration of effects.

**Operational rules:**

1. Preserve the meaning and order of the story unless the brief explicitly asks for restructuring.
2. Make speech, actions, ideas, and emotional beats easy to understand.
3. Prefer the least complicated edit that accomplishes the purpose.
4. Add a transition, effect, sound, zoom, overlay, or graphic only when it improves clarity, continuity, pacing, mood, emphasis, or meaning.
5. Do not force every technique from this document into the same reel.
6. Do not conceal every cut automatically. Some pauses, visible cuts, and changes in rhythm feel natural and human.

### 2.2 Two legitimate goals: invisible editing and visible emphasis

Some edits should be **invisible**: the viewer follows the action or story without being distracted by the cut. Flow cuts, action cuts, well-matched J/L cuts, eye-line continuity, and relevant B-roll can help achieve this.

Other edits should be **noticeable on purpose**: a smash cut, a sudden silence, a strong rhythm change, or a graphic match may signal surprise, a turning point, humor, urgency, or a new idea.

**Decision rule:** Before making a cut, decide whether the moment needs continuity or disruption. Do not smooth an intentional impact away, and do not make an ordinary explanatory cut disruptive without a reason.

### 2.3 Guide the viewer's attention

A viewer's eye is drawn by movement, faces, gaze, contrast, and important details. A good edit guides that attention from one shot to the next.

Check:
- Where is the viewer looking immediately before the cut?
- Where should they look immediately afterward?
- Does movement continue in a compatible direction?
- Does the subject's position or eye-line jump unintentionally?
- Does a new shot reveal useful information, an action, or an emotion?
- Does the cut make the point easier to follow?

### 2.4 Rhythm is part of storytelling

**Source principle:** If a video moves at one pace throughout, the audience can become disengaged. Faster cuts can build energy or tension; slower cuts can give an emotional beat time to land. Contrast is more expressive than a single unchanging tempo.

The edit should have a deliberate pattern of acceleration, steadiness, pauses, and release where appropriate. Do not make every cut land on the music beat. Beat synchronization is a useful option, not a mandatory law.

### 2.5 Audio is not an afterthought

**Source principle:** A video moment is built from more than the visible action. Breath, wind, footsteps, environmental sound, and silence can help create the moment. Voice-over, music, and sound effects each have distinct jobs.

The primary purpose of sound design in a narrated or talking-head edit is to complement the voice-over—not overpower it. Sound effects should make the edit feel more intentional, not distract from the words or story.

---

## 3. Editing-agent operating protocol

Use this sequence when working on a reel. Adapt it to the available files, requested deliverables, and the editing software or codebase.

### Phase A — Understand the brief and assets

1. Identify the intended platform and format, such as a vertical reel, short, or other deliverable.
2. Identify the audience, subject, message, tone, intended duration, and any required call to action.
3. Inspect all supplied footage, audio, scripts, transcripts, graphics, brand assets, and reference edits before choosing techniques.
4. Determine the project frame rate, dimensions, aspect ratio, audio sample rate where relevant, and existing timeline structure if available. Do not guess settings when the project can be inspected.
5. Identify restrictions: required wording, footage that must remain, prohibited imagery or sounds, branding, caption requirements, music restrictions, and delivery format.
6. Keep source media intact. Prefer non-destructive edits or a duplicate project/timeline when the environment supports it.

### Phase B — Build the story before polishing

1. Summarize the core message in one sentence.
2. Break the reel into beats: hook, setup, explanation or development, proof/example, payoff, and close/CTA when relevant. Not every reel requires every beat.
3. Identify the purpose of every beat: attract attention, orient the viewer, explain, demonstrate, create emotion, contrast, reveal, or conclude.
4. Choose the strongest available take or visual for each beat.
5. Assemble a clean first pass using straightforward cuts. Do not begin by decorating every cut with effects.
6. Remove genuine mistakes, distracting dead time, redundant statements, and unintended repetitions while preserving natural speech and meaningful pauses.
7. Watch the first pass without effects. If the story is unclear, fix the order, timing, or shot selection before adding transitions and sound design.

### Phase C — Choose cut types intentionally

At each edit point, evaluate:

- **Story purpose:** What does this cut accomplish?
- **Continuity:** Should the viewer feel an invisible connection or an obvious change?
- **Motion:** Is the subject or camera moving? Can the movement continue across the cut?
- **Framing:** Are the subject position, eye-line, screen direction, and shot scale appropriate?
- **Speech:** Is a word, consonant, breath, or thought being damaged by the cut?
- **Audio:** Should the audio cut with the picture, lead it, or continue over it?
- **Rhythm:** Should the cut land on a beat, follow natural speech cadence, accelerate the sequence, or create a pause?
- **Information:** Does the next shot provide new information or just repeat what is already obvious?
- **Naturalness:** Would hiding this cut improve the video, or make it feel overproduced?

Choose one primary cut strategy. Secondary techniques may support it, but avoid stacking multiple techniques without a reason.

### Phase D — Add sound design

1. Establish intelligible dialogue/voice-over first.
2. Add music only if it supports the tone, pace, and emotional arc.
3. Add relevant production audio, Foley, ambience, transition textures, and creative effects where they add value.
4. Keep a coherent sound theme across the reel and consistent with the visual/brand theme.
5. Align important sound effects with the action, animation, transition, or emotional beat they support.
6. Ensure sound effects and music do not mask the voice-over.
7. Check audio transitions independently from the visuals. A visually clean cut can still sound abrupt, and a visible cut can be made smoother by a suitable audio bridge.

### Phase E — Add visual polish

Use B-roll, motion graphics, overlays, framing changes, zooms, titles, and transitions only where they support the story or solve a specific edit problem. Avoid random stock footage, ornamental movement, or effects that contradict the intended tone.

### Phase F — Review and quality control

Review at least once for story and once for technical defects. Use the checklist in Section 13. If possible, watch the completed edit in real time at normal speed, then inspect difficult cut points frame by frame.

---

## 4. The cut taxonomy

The terms below overlap in practice. A single edit can be, for example, an action cut that also follows a flow cut principle and uses an L-cut on the audio. Name the primary technique according to the main purpose of the edit.

### 4.1 Standard cut (straight cut)

**Definition:** An immediate switch from one shot to another. The picture and, when appropriate, the sound switch directly rather than using a visible transition.

**Use it when:**
- The next shot provides new information.
- The scene changes cleanly.
- A reaction, detail, angle, or new story beat is needed.
- The cut itself should not draw attention.

**Procedure:**
1. Pick the out-point of the first shot and in-point of the next.
2. Check speech and movement on both sides.
3. Confirm the change in framing or content reads clearly.
4. Listen for clicks, clipped syllables, sudden room-tone changes, or unwanted audio gaps.

**Common mistakes:** Cutting in the middle of a word; cutting to an almost identical frame without a reason; allowing a distracting position jump; or assuming that the picture cut alone guarantees a smooth edit.

### 4.2 Jump cut

**Definition:** A segment is removed from a shot and the remaining parts are joined, making time appear to jump forward while the framing or scene remains similar.

**Useful for:**
- Removing mistakes, pauses, and dead time in talking-head footage.
- Compressing repetitive actions.
- Showing progress or the passage of time.
- Creating deliberately fast, chaotic, playful, or high-energy pacing.
- Landing on a musical beat when appropriate.

**How to make it feel cleaner:**
- Use relevant B-roll, overlays, graphics, or text to cover a necessary discontinuity.
- Use a subtle post-cut framing change if it improves the edit and the crop retains sufficient image quality.
- Use a J-cut or L-cut if the audio bridge sounds natural.
- Match eye-line and subject position as closely as practical.
- Avoid clipping words or removing breaths in a way that makes speech robotic.
- Consider switching camera angles when coverage exists.

**Important:** Jump cuts do not always need to be hidden. A visible jump can intentionally communicate speed, repetition, or energy. Avoid applying a zoom to every jump cut by default.

### 4.3 Match cut

**Definition:** Two shots are joined using a similarity or correspondence that helps them feel connected. The connection may be visual, movement-based, compositional, or audio-based.

Three forms from the training material:

1. **Graphic match:** Similar shapes, colors, subject outlines, or framing connect the shots.
2. **Movement match:** The camera, character, or object continues compatible motion across the cut.
3. **Audio match:** A sound or audio feature connects the two scenes.

**Useful for:**
- Linking places, moments in time, objects, or ideas.
- Creating a visual metaphor.
- Making a transition between very different scenes feel intentional.
- Connecting a past and present version of a subject.

**Procedure:** Find a specific shared feature—not merely a vague similarity. Align its position, scale, shape, direction, or timing so the relationship can be understood quickly. For a match between people, check eye position and screen placement.

**Failure mode:** A supposed match cut may feel accidental if the matched element is too different, too poorly aligned, or not meaningful to the story.

### 4.4 J-cut

**Definition:** The audio from the incoming shot starts before its picture appears. The viewer hears what is coming before seeing it.

**Purpose:** Anticipation and audio continuity. It can make scene changes feel more immersive and soften abrupt picture changes.

**Procedure:**
1. Separate or independently edit the clip's audio and video if necessary.
2. Move the incoming audio earlier than the incoming video.
3. Use a short lead-in that allows the sound to be understood as a bridge, not as an accidental sync error.
4. Listen through the entire transition and confirm that the incoming audio is appropriate for the scene.
5. Preserve intentional synchronization for sounds that must visibly happen at the same moment, unless an intentional pre-lap is the point.

The source example uses the sound of an upcoming scene to lead into its picture. No single number of frames is appropriate for every clip; choose the offset by ear and context.

### 4.5 L-cut

**Definition:** The audio from the outgoing shot continues after the picture has switched to the incoming shot.

**Purpose:** Carry dialogue, ambience, or a sound bed across the visual change so that the shots remain connected.

**Useful for:**
- Conversations and reaction shots.
- Continuing a character's line over related B-roll or a visual reenactment.
- Maintaining atmosphere while the image changes.
- Avoiding a hard stop in the middle of a thought.

**Procedure:** Keep the outgoing sound under the next shot only while it remains meaningful and clean. Make sure the continued dialogue does not conflict with new dialogue. Check the edit for unwanted overlap, room-tone mismatch, or a sound that persists after its narrative relevance has ended.

### 4.6 Fade

**Definition:** A picture fades from or to a solid color, most commonly black. A fade can mark a beginning or ending. A fade to white may be used for a dreamlike, overwhelming, or death-related moment when appropriate to the story.

**Use it when:** A deliberate ending, opening, pause, passage, or tonal shift benefits from a clear visual transition.

**Avoid:** Applying fades to every scene change just because the feature exists. A fade generally carries more weight than a routine straight cut and should fit the narrative.

### 4.7 Dissolve

**Definition:** One shot gradually blends into another shot rather than fading through a solid color.

**Use it when:** Showing the passage of time, a soft transition, an association between two moments, or a deliberate overlap in visual space/time.

**Watch for:** Ghosting, doubled movement, competing faces, or an unclear subject during the overlap. A dissolve is not automatically smoother than a cut; it creates a distinct visual meaning and texture.

### 4.8 Cut on action / action cut

**Definition:** The cut occurs while a person, object, or camera is moving. The second shot picks up the action so that the movement appears to continue naturally.

**Why it works:** The viewer is already following the movement. If the direction and timing carry across the cut, the eye can stay engaged with the action instead of noticing the edit.

**Procedure:**
1. Identify a clear movement arc: begin, movement, completion.
2. Choose the first shot's out-point during the action, not after the movement has fully finished if that would create a stop-start feeling.
3. Find the second shot's in-point where the same action can continue.
4. Match direction, speed, body/object position, and screen placement as closely as the footage allows.
5. Review a little before and after the edit. Move the cut a few frames earlier or later if the action stutters or repeats.
6. Optional: a subtle scale or reframing adjustment can help if the visual treatment remains natural and the image supports it.

**One angle only:** If no alternate angle exists, the agent may use a relevant B-roll cutaway, a deliberate jump cut, a subtle crop change, or a J/L audio bridge. Do not pretend that a true multi-angle action cut is possible without alternate coverage.

### 4.9 Flow cut

**Definition:** A cut designed so that movement in one shot flows naturally into movement in the next. The movement may belong to a person, object, or camera.

**Principle:** The viewer's eyes begin following movement. If the next shot continues in a compatible direction and at a compatible time, the eyes continue smoothly. If motion abruptly reverses or changes direction without motivation, the viewer may feel friction.

**Procedure:**
- Track the direction and speed of movement in the outgoing shot.
- Inspect the incoming shot for a continuation or motivated change.
- Match the key movement, screen direction, and timing.
- Consider camera movement as well as subject movement.
- If a directional break is intentional, make the break clear and purposeful rather than accidentally confusing.

**Difference from an action cut:** A flow cut emphasizes the continuity of motion direction and visual flow between shots. A cut on action emphasizes the moment of cutting during an action so that the action continues. One edit can satisfy both.

### 4.10 Cross-cutting

**Definition:** The edit alternates between two or more scenes, often events occurring at the same time.

**Useful for:** Parallel storylines, a phone conversation, simultaneous events, suspense, or showing a relationship between actions in different locations.

**Procedure:** Establish enough context for the viewer to understand each strand, then alternate at a pace appropriate to the tension and clarity required. Make sure each return to a scene provides a useful development, reaction, or escalation.

**Common mistake:** Switching between scenes merely for variety without helping the audience understand the relationship between them.

### 4.11 Smash cut

**Definition:** An abrupt cut from one scene or sound state to a contrasting one. The contrast can be visual, sonic, tonal, or all three.

**Useful for:** Surprise, humor, tension, shock, a turning point, or a forceful emotional reset.

**Sound option:** An abrupt music or ambience stop can intensify the change. Alternatively, a strong sound may enter on the new shot. Sound should support the intended contrast rather than become loud merely to seem dramatic.

**Control:** The impact depends on contrast. If every edit is a smash cut, the audience stops experiencing surprise. Reserve it for moments where a break in rhythm means something.

### 4.12 Wide–medium–close sequence

This is a **shot sequence**, not one isolated cut.

- **Wide shot:** Establishes place, context, spatial relationships, or the whole action.
- **Medium shot:** Clarifies what is happening and how the subject interacts with the scene.
- **Close-up:** Reveals detail, expression, texture, or emotion.

**Typical order:** Wide → medium → close. This gives the viewer context, then action, then detail or emotional emphasis.

**Variations:**
- Wide → close can create a stronger emotional jump or quickly emphasize a detail.
- Close → wide can withhold context and reveal the bigger picture later.
- A missing medium shot can be effective if the story benefits from a stronger shift.

**Rule:** Start by using the pattern to improve clarity. Break it intentionally when the emotional or narrative purpose calls for a different reveal.

### 4.13 Rhythm cut / tempo editing

**Definition:** Choosing the timing and frequency of cuts to shape the energy of a scene.

- Faster cuts can build tension, excitement, urgency, or chaos.
- Slower cuts can create calm, anticipation, weight, or emotional space.
- A pause can let a reveal, reaction, line, or visual detail land.
- A faster section followed by a slower one—or the reverse—creates contrast.

**Operational method:** Map the emotional trajectory of the moment. Decide where energy should rise, peak, and release. Then vary shot duration accordingly. Do not rely on a fixed average cut length for the entire reel.

### 4.14 Cutting on the beat

**Definition:** Aligning a visual cut with a discernible beat or rhythmic accent in the music.

**Why it can work:** If music changes and the picture changes at unrelated moments, the edit can feel busier. Aligning a cut with a meaningful beat may consolidate those changes into one event and make the flow feel deliberate.

**Procedure:**
1. Listen to the music and identify plausible beats or accents.
2. Inspect the waveform as a clue, but do not assume every waveform peak is a musical beat.
3. Choose the beat that supports the story and shot change.
4. Align the cut and review the result at normal speed.
5. Add a whoosh or riser only if it improves the transition.

**Important:** Do not sacrifice a strong performance, clear word, action match, or emotional pause merely to hit a beat. Off-beat cuts can feel more natural or powerful when the scene calls for them.

### 4.15 Concealing a cut with B-roll, overlays, or motion graphics

**Definition:** Covering a visible discontinuity with relevant additional imagery or graphics so the edit stays understandable and feels intentional.

**Useful options:**
- B-roll directly related to the sentence or action.
- A close-up of the object being discussed.
- A purposeful text callout or animated graphic.
- A relevant overlay or stock shot, when appropriate and licensed.

**Procedure:** Identify the exact edit problem, then choose the simplest relevant cover. Keep the voice-over or contextual audio understandable. Return to the primary shot when it serves the story.

**Do not:** Use random B-roll solely to hide an edit, insert irrelevant stock imagery, or cover an edit that should remain visible for rhythmic or emotional reasons.

### 4.16 Subtle post-cut zoom or crop change

A small change in framing after a jump cut can distinguish two otherwise similar frames and reduce the abruptness of the cut. One of the supplied lessons gives 110% as an example, not as a universal preset.

**Operational rules:**
- Use the smallest change that solves the problem.
- Check image resolution, crop boundaries, face size, headroom, and composition.
- Avoid repeating the same zoom pattern so often that the style becomes mechanical.
- Do not apply a zoom when it would weaken the composition or make the footage visibly soft.

### 4.17 Eye-line and subject-position matching

When cutting between talking-head takes or people, keep eye positions and relevant subject positions consistent where continuity is the goal.

**Procedure:**
1. Compare the outgoing frame with the incoming frame.
2. Check eye height and horizontal position, head size, shoulder line, camera angle, and gaze direction.
3. Use guides or alignment overlays in the editing application if available.
4. Reframe with position/scale adjustments only as far as the source permits.
5. Review playback to confirm the viewer's attention does not jump unintentionally.

**Why it matters:** The viewer commonly looks at the face, especially the eyes. An unexplained shift can distract from the words. For a deliberately expressive jump, that shift may be acceptable if it is intentional.

### 4.18 Speech-aware cuts: do not cut mid-word or mid-breath

**Source principle:** Avoid cutting through a word or removing breaths in the middle of a sentence. Unnatural speech edits distract from the content. It can be useful to remove unnecessary breathing before a sentence starts or after it finishes.

**Procedure:**
- Keep words intact whenever possible.
- Prefer edits at natural pauses, phrase boundaries, or moments where the visual action can cover the transition.
- When removing a breath, listen for the natural cadence of the sentence before and after the edit.
- Preserve breaths that convey exertion, emotion, intimacy, or intentional timing.
- Use a short audio crossfade when it resolves a click or abrupt room-tone change, but do not smooth away a deliberately sharp sound transition.

### 4.19 Multiple-angle coverage for self-shot content

When footage was recorded from several camera angles, planned alternation can hide edits and reduce the need to memorize a very long script in one take.

**Pre-production method:**
- Assign script lines or narrative beats to camera angles.
- Keep framing and eye-line conventions reasonably consistent.
- Record enough coverage to avoid repetitive angle switching.
- Maintain continuity of gestures, posture, props, and direction where needed.

**Post-production method:** Alternate angles where they improve pacing, cover a jump, or emphasize a point. A camera-angle change should feel motivated, not like a random switch.

---

## 5. Cut-selection decision guide

Use this as a quick mapping from intended result to likely technique. It is a starting point, not a rigid rule.

| Intended result | Techniques to consider | Main checks |
|---|---|---|
| Cleanly move to new information | Straight cut | Does the new shot add information? Is the audio transition clean? |
| Remove mistakes or dead time in a talking head | Jump cut, B-roll cover, crop change, alternate angle, J/L cut | Are words intact? Does the cut feel intentional? |
| Continue visible movement | Action cut, flow cut | Direction, timing, speed, screen position, action continuity |
| Link related images or concepts | Match cut | Is the shared shape, movement, position, color, or sound clear? |
| Lead the audience into the next scene | J-cut | Does incoming audio begin naturally before the image? |
| Let a current line or ambience bridge scenes | L-cut | Is the outgoing audio still relevant and intelligible? |
| Show passage of time softly | Dissolve | Is blending appropriate, not visually muddy? |
| Create an opening or ending | Fade | Does the moment need a deliberate fade? |
| Show two concurrent story strands | Cross-cutting | Can viewers follow both strands, and does each return advance the story? |
| Create surprise or an emotional reset | Smash cut | Is the contrast strong and purposeful? Is surprise being overused? |
| Clarify space and then detail | Wide–medium–close | Does each shot add new context, action, or detail? |
| Increase energy or let emotion land | Rhythm/tempo variation | Is shot duration changing with the story? |
| Synchronize the edit with music | Cut on the beat | Does the beat support rather than override story timing? |
| Hide a necessary jump without confusing the story | Relevant B-roll, motion graphics, text, subtle crop change | Is the insert directly related and visually motivated? |
| Make a face-to-face cut feel stable | Eye-line / subject-position match | Do eyes, head size, and gaze direction remain coherent? |

---

## 6. Sound-design fundamentals

### 6.1 The three principal audio layers

The supplied training describes three important components of a video's audio:

1. **Voice-over / dialogue:** The narrator or speaker's voice. In a narrated explainer or talking-head reel, this usually carries the main information and must remain intelligible.
2. **Music:** Establishes pacing and emotional connection. It can influence how quickly the edit feels, where energy rises, and how the audience experiences the story.
3. **Sound effects (SFX):** Add specificity, texture, impact, realism, emphasis, and polish. They can help visual actions and motion graphics feel tangible, but they should not overpower the voice.

Environmental sound and silence can be essential parts of the soundscape even when they are not listed as separate top-level tracks.

### 6.2 The voice-over is the priority in narrated edits

**Source principle:** The primary goal of sound design is to complement the voice-over, not overpower it.

**Operational rules:**
- Make speech understandable before adding decorative sound layers.
- Keep music and effects at levels that do not compete with key words.
- Lower, pause, or simplify music/SFX when the narration becomes dense or emotionally important.
- Avoid placing a sharp effect directly on a consonant or important word unless the effect intentionally punctuates that word and clarity remains intact.
- Listen to the finished mix at a normal viewing level, not only while monitoring loudly.

The source material does not specify a universal dB difference between narration, music, and SFX. Do not hard-code one number for every project. Set levels by listening and by applicable delivery requirements.

### 6.3 Silence is a design choice

Silence or reduced sound can make a moment feel exposed, tense, intimate, calm, or final. It can also make the next sound more impactful. Do not fill every gap with music, ambience, or a transition effect.

Use silence intentionally and check that it is not an accidental mute, missing asset, or broken audio edit.

---

## 7. Six categories of sound effects

Classify an intended effect by its main purpose. Some sounds can fit more than one category.

### 7.1 Literal / production sounds

**Definition:** Sounds naturally associated with the visible action or recorded at the scene.

**Examples from the training:** Traffic horns, door slams, and the real sound of an action on screen.

**Purpose:** Preserve realism and establish the direct acoustic identity of an event.

**Use when:** The sound is clearly linked to the action and helps the audience understand or feel it.

**Checks:** Is it the correct type of event? Does it occur at the right time? Does it fit the perspective and apparent distance? Is it cleaner to use the original recording or a replacement?

### 7.2 Foley / supplementary action sounds

**Definition:** Sounds recorded or sourced later to add detail to an action that may not have been captured clearly during shooting.

**Examples:** Footsteps and cloth rustling.

**Purpose:** Make physical actions more tangible and specific.

**Use when:** A visible action feels empty, too quiet, or disconnected from its physical environment.

**Checks:** Match the material, surface, pace, weight, and rhythm of the action. Avoid adding footsteps where the subject is not walking or cloth sounds where there is no plausible movement.

### 7.3 Ambient / atmospheric sounds

**Definition:** Sounds that establish the environment around the action.

**Examples:** Wind in a forest, flowing river water, birds, room tone, or a broader environmental bed.

**Purpose:** Give a scene a sense of place, space, and continuity.

**Use when:** The scene needs environmental context, a transition needs a sonic bed, or the image alone feels too isolated.

**Checks:** Match the environment and time implied by the picture. Avoid a forest ambience under an indoor office shot unless it is a deliberate metaphor. Use ambience consistently across edits within the same space, or transition it deliberately when the location changes.

### 7.4 Textures and transitions

**Definition:** Often abstract sounds used to intensify mood, tension, movement, or a transition.

**Examples from the training:** Bass rumble, risers, swells, whooshes, sweeps, hits, impacts, and bass drops. Echo and reverb are also named as sound-design concepts in the source material.

**Purpose:**
- **Riser:** Build anticipation toward a cut, reveal, or event.
- **Swell:** Gradually increase perceived energy or emotional weight.
- **Whoosh / sweep:** Suggest a fast movement, reveal, transition, or motion-graphic movement.
- **Bass rumble:** Add low-frequency tension or weight.
- **Hit / impact:** Punctuate a moment, reveal, title, or change.
- **Bass drop:** Create a sense of release or a strong energy change after buildup.
- **Echo / reverb:** Change the perceived space, distance, or quality of a sound when the creative context calls for it.

**Checks:** Does the sound correspond to the movement or emotional beat? Is the build long enough to create anticipation but not so long that it becomes predictable? Does the hit compete with speech? Does the sound's tail extend into the next moment appropriately?

### 7.5 Elements for motion design and text

**Definition:** Sounds used to make animated text, icons, shapes, interfaces, or graphic movements feel tactile and purposeful.

**Examples:** Typewriter sounds, tactile typing sounds, clicks, pops, and keyboard-like sounds.

**Purpose:** Make graphic movement feel responsive, concrete, or more satisfying.

**Use when:** A text animation or graphic actually has a perceived action that the sound can reinforce.

**Creative search rule:** The source lesson recommends searching by the sound quality or physical sensation desired, rather than limiting search terms to the literal object shown. A sound recorded for a different activity may work for a text animation if its timing, texture, and emotional effect fit.

**Checks:** Does the SFX timing match the animation? Are repeated clicks becoming tiring? Is the sound too literal, too cartoonish, or inconsistent with the visual theme?

### 7.6 Creative / symbolic sound effects

**Definition:** Sounds added to suggest meaning or emotion that is not literally present in the frame.

**Examples from the training:** A thunderstorm under a simple shot to imply emotional depth; birdsong with a peaceful image even when birds are not visible, using birds as a symbolic link to peace or silence.

**Purpose:** Add subtext, metaphor, anticipation, irony, or emotional interpretation.

**Use when:** The sound gives the visual a meaningful layer that the image alone does not state.

**Checks:** Is the metaphor understandable or at least emotionally coherent? Does the sound enrich the moment rather than contradict it accidentally? Does it preserve the intended tone? A symbolic sound may also create continuity across a hard visual cut.

---

## 8. Sound-effect vocabulary and practical selection

When a user or brief describes a sound vaguely—such as “make this transition feel expensive,” “give the text more weight,” or “make the scene feel tense”—translate the desired result into a small sound-design search plan. Do not assume a single label will find the correct asset.

| Desired effect or role | Terms to explore | Use carefully because… |
|---|---|---|
| Fast movement or reveal | Whoosh, sweep, swish, airy pass-by | Overuse makes every motion feel identical. |
| Build anticipation | Riser, build, swell, tension rise | A long build can delay the point or create false urgency. |
| Weight or menace | Low rumble, sub hit, dark drone | Excessive bass can mask speech and sound muddy on some devices. |
| Emphasize a reveal | Impact, hit, cinematic hit, accent | The hit should not obscure the key line or visual. |
| Release tension | Drop, bass drop, release, short impact | A drop is not always appropriate after every riser. |
| Animated typography | Tactile click, typewriter, key tap, pop, UI click | The effect must match the speed and style of the animation. |
| Physical movement | Foley, footsteps, fabric/cloth rustle, handling | Wrong material or timing makes the action less believable. |
| Environment | Ambience, atmosphere, room tone, wind, water, birds | Avoid mismatched locations and abruptly changing background beds. |
| Abrupt change | Stop, cut-out, silence, hard impact | Sudden silence should be intentional, not a technical error. |
| Emotional or symbolic subtext | Thunder, distant birds, wind, texture, drone | A metaphor can be too literal or overstate the emotion. |

### Search from sensation, not only from the object name

**Source principle:** A sound for text animation can come from a seemingly unrelated source if the physical texture and feeling are right. Creative sound design can be made by combining two things that unexpectedly make sense together.

Example workflow:
1. Describe the intended feeling: soft, crisp, heavy, airy, organic, mechanical, playful, eerie, premium, tactile, distant, intimate.
2. Describe the sonic shape: short click, double tap, low thump, rising noise, airy sweep, granular texture, long tail, sharp transient.
3. Search both literal and abstract labels.
4. Preview multiple candidates against the actual footage.
5. Select based on timing, texture, level, and thematic fit—not the filename alone.
6. If no asset fits, consider recording a simple Foley sound or layering compatible sounds, provided the project allows it.

---

## 9. The sound-design universe: match sound to the content's theme

The supplied lesson groups content into four broad sound-design “universes.” They are overlapping style families, not rigid boxes. The same sound may work in multiple styles, and a reel can blend styles when the blend is intentional.

### 9.1 Entertainment

**Typical content:** Challenges, reactions, gaming highlights, playful or comedy-led reels.

**Sound palette described in the source:** Cartoon-like pops, meme sounds, louder transitions, and hits.

**Effect:** Energy, comic emphasis, immediacy, and exaggerated reactions.

**Risk:** Too many loud or meme-like effects can make the edit exhausting or undermine a sincere moment.

### 9.2 Explainer / educational

**Typical content:** Educational videos, science content, tutorials, information-heavy reels.

**Sound palette described in the source:** Typewriter sounds, tactile clicks, and transition SFX.

**Effect:** Support the flow of information and give text or graphic elements a tangible rhythm.

**Risk:** Effects can interfere with comprehension when every bullet, word, or graphic is punctuated. Keep narration primary.

### 9.3 Cinematic

**Typical content:** Storytelling videos, short films, high-production travel content, emotionally shaped narratives.

**Sound palette described in the source:** Detailed sound design, atmospheric sounds, risers, deep whooshes, impacts, and Foley.

**Effect:** Immersion, space, anticipation, physical presence, and emotional development.

**Risk:** Layering too many cinematic sounds can make a small moment feel artificially epic or mask the actual location and performance.

### 9.4 Minimal / premium restrained

**Typical content:** Product reviews, lifestyle content, tutorials, or clean brand-led videos.

**Sound palette described in the source:** Few but carefully selected effects, such as soft whooshes, text pops, and keyboard sounds.

**Effect:** Precision, restraint, clarity, and polish.

**Risk:** Minimal should not mean lifeless. Preserve useful room tone, natural details, and meaningful silence.

### 9.5 Theme coherence across the whole content package

**Source principle:** Think of the content as one creative universe. Speaking style, music, fonts, graphics, animation, visual treatment, and sound effects should feel as though they belong together.

For example, a paper-cut visual style suggests physical, tactile, paper-like sound choices more naturally than unrelated electronic laser sounds. A dark, glowing, futuristic visual style may support digital or synthetic textures. A vibrant, organic, Indian-inspired brand identity may call for more natural, tactile, or culturally compatible sound details.

These are examples of matching sound to a visual concept, not fixed prescriptions. The agent must inspect the actual brand and assets before choosing a palette.

### 9.6 Build a simple sound-style brief before selecting SFX

Record a short internal note containing:
- **Content universe:** entertainment, explainer, cinematic, minimal, or a deliberate blend.
- **Emotional direction:** e.g. calm → curious → confident; tense → reveal → relief.
- **Sonic materials:** organic, mechanical, digital, tactile, airy, low-frequency, percussive, environmental.
- **Density:** sparse, moderate, or detailed.
- **Signature sounds:** recurring whoosh, click, accent, room tone, or other recognizable cue where helpful.
- **Avoid list:** sounds that are too comedic, too dramatic, too bass-heavy, too synthetic, too noisy, or otherwise wrong for the theme.

Keep the same sonic identity across the reel unless the story intentionally changes style.

---

## 10. Music, pacing, and transitions as one system

Sound design should not be treated as a pile of independent effects. Music, cuts, animation, and SFX are interacting rhythms.

### 10.1 Plan the musical arc

Before placing every effect, identify whether the music is:
- Setting a stable emotional bed.
- Establishing an energetic rhythm for cuts.
- Building toward a reveal or key statement.
- Releasing tension.
- Deliberately disappearing to expose speech, ambience, or silence.

Then fit the edit to the music only where it supports the narrative. A beat is an option for a cut, not a command to cut.

### 10.2 Use effects to reinforce a transition, not decorate it automatically

A transition may need:
- No additional effect, if the existing music or ambience is sufficient.
- A short whoosh/sweep to reinforce visible motion.
- A riser or swell if anticipation is important.
- A hit/impact if the new image is a reveal or a strong point.
- A continuing ambient bed or L-cut to provide continuity.
- A deliberate drop to silence or music cut for surprise.

Choose only what the moment needs. If the cut is already strong, an extra SFX may weaken it.

### 10.3 Layering principles

A soundscape may contain multiple layers, but each layer should have a purpose. Examples:
- Dialogue + low music bed + light environmental ambience.
- Dialogue + subtle click timed to a graphic + restrained music.
- Music build + short whoosh + reveal impact, with the impact placed so it does not mask the spoken point.
- Environmental bed + Foley action sounds + sparse music for a more immersive scene.

**Operational rule:** When the mix feels cluttered, first remove or reduce the least important layer. Do not automatically solve clutter by adding more processing or another sound.

---

## 11. Audio asset sourcing and monitoring

The supplied lesson names examples of paid resources such as Envato Elements, Epidemic Sound, Artlist, and Storyblocks, and free sources such as Mixkit, Pixabay, FreeSound, and YouTube uploads. The examples are drawn from the source material; they are not a current ranking, endorsement, or guarantee that any individual asset is usable for a particular project.

### 11.1 Source-selection principles

- Free and paid audio can both work. Price alone does not determine whether the sound suits the edit.
- Paid libraries may save searching time or provide a broad, curated collection; free sources may be sufficient for many projects.
- A custom-recorded Foley sound can be a better match than an online asset when the desired sound is specific.
- Search quality varies. Try synonyms and sensory terms instead of repeating one literal phrase.
- A creator-compiled “sound pack” is not automatically original, exclusive, or properly licensed. Verify the provenance and rights for assets used in professional work.

### 11.2 License and attribution checks

**Operational rule:** Before using any downloaded sound in a delivered project, verify the actual license and its conditions. Do not treat a filename or a description such as “no copyright” or “royalty free” as complete proof by itself.

Check:
- Commercial-use permissions, if the reel is commercial or client work.
- Attribution requirements.
- Whether monetized/social-platform use is permitted.
- Restrictions on redistribution, standalone asset delivery, or use in templates.
- Any account/subscription requirements and whether the project is covered by the applicable license.
- Whether a claim or dispute process requires retaining a license receipt or record.

Keep a note of the asset URL or library name, asset title, license basis, and any attribution requirement where relevant. Do not reuse a sound when the project brief or rights cannot be resolved.

### 11.3 Monitoring and headphones

The source lesson recommends good headphones for sound design, favors studio-oriented listening over strongly bass-emphasized gaming headphones, and warns that wireless latency can make tight visual sync more difficult. It also notes that comfort matters during long sessions.

**Operational interpretation:**
- Use the most reliable monitoring available and learn how it represents bass, dialogue, high frequencies, and stereo position.
- If latency creates a timing problem, use a wired connection or compensate through the verified monitoring setup.
- Avoid trusting a heavily bass-boosted playback device as the sole judge of low-frequency content.
- Check the export on more than one practical playback condition when possible—for example, headphones and a phone speaker—because viewers will not all hear the same balance.
- Do not assume that expensive gear guarantees a good mix. Listening judgment and repeated playback checks remain essential.

---

## 12. A practical editing algorithm for a reel

This is an operational framework the Codex agent can follow. It translates the training principles into a repeatable sequence.

### Step 1 — Create a media inventory

List the available assets and what role they can play:
- Primary A-roll / talking-head footage.
- Alternate angles and retakes.
- B-roll / cutaways.
- Existing location or production audio.
- Voice-over or dialogue tracks.
- Music tracks.
- Sound effects and ambience.
- Titles, graphics, overlays, logos, and brand assets.

Note missing coverage. Do not fabricate footage or pretend a suitable asset exists when it does not.

### Step 2 — Build a story/beat map

For each beat, record:
- Start/end or approximate duration.
- Spoken line or key idea.
- Purpose of the beat.
- Best available shot or visual.
- Desired viewer feeling or attention target.
- Whether the pace should rise, hold, or release.
- Any essential audio or graphic cue.

### Step 3 — Perform a clean assembly

Use straightforward cuts to establish the story. Avoid adding sound effects and visual transitions before the edit's structure is understandable. Keep necessary words and actions intact.

### Step 4 — Repair obvious discontinuities

For each jump or abrupt change, decide whether it needs repair.

- If movement exists across two shots: test an action/flow cut.
- If the same face and framing repeat: test eye-line matching, a slight crop change, B-roll, or another angle.
- If the next scene's sound can introduce it: test a J-cut.
- If the outgoing dialogue or ambience can bridge the new image: test an L-cut.
- If two shots share a meaningful visual feature: test a match cut.
- If the cut should carry emotional force: retain or design the abruptness rather than hiding it.

### Step 5 — Shape rhythm

Review shot durations and transitions as a sequence. Check for monotony, arbitrary speed changes, and overly frequent cuts. Align selected edits with music beats when the music supports that choice. Leave room for key statements, visual details, and reactions.

### Step 6 — Design sound from the voice outward

1. Clean and balance dialogue/voice-over.
2. Decide the music theme and arc.
3. Add relevant ambience/room tone.
4. Add Foley or literal action sounds.
5. Add transition textures and impacts selectively.
6. Add text/motion-design clicks or pops where the animation needs them.
7. Add creative/symbolic effects only when they contribute meaning.
8. Rebalance after every major new layer.

### Step 7 — Add visual accents

Add titles, graphics, B-roll, overlays, and reframing where they clarify or emphasize information. Match their motion and sound to the same style. Avoid a graphic or sound cue for every single phrase unless that density is an intentional style choice.

### Step 8 — Review in real time

Watch the full reel without pausing. Ask:
- Does the story make sense on first viewing?
- Does the hook arrive quickly enough for this project's goal?
- Are cuts natural where they should be invisible?
- Do intentional disruptions actually feel meaningful?
- Is the visual rhythm varied but coherent?
- Can every spoken word be understood?
- Does sound feel like one designed world?

### Step 9 — Inspect problem points

Frame-step or zoom in on points where there is:
- A visible jump in face/eye position.
- A movement stutter, repeated action, or direction flip.
- A clipped word or abrupt breath.
- A click or pop in the audio waveform.
- A sound effect arriving too early/late.
- A music change that conflicts with the image.
- A graphic movement whose sound does not match the animation.

### Step 10 — Export and verify

Confirm the intended dimensions, aspect ratio, frame rate, codec/container, file destination, and audio settings from the project or brief. Reopen or play the exported file and verify it actually rendered correctly. Do not report an export as successful until its file and playback have been checked where the environment allows.

---

## 13. Quality-control checklist

### 13.1 Story and clarity

- [ ] The core message is clear.
- [ ] Each shot or graphic has a reason to be present.
- [ ] The order of information makes sense.
- [ ] B-roll is relevant to the point being discussed.
- [ ] The hook and payoff are not weakened by unnecessary setup or effects.
- [ ] The ending feels intentional and does not cut off required information.

### 13.2 Cut continuity

- [ ] The purpose of every major cut is identifiable.
- [ ] Motion direction and timing are coherent where flow is intended.
- [ ] Action continues naturally across action cuts.
- [ ] Eye-line, face size, and subject position are consistent where continuity is intended.
- [ ] Speech is not cut mid-word.
- [ ] Breaths are edited naturally, not removed indiscriminately.
- [ ] J/L cuts sound natural and do not cause confusing dialogue overlaps.
- [ ] Dissolves/fades are used intentionally, not as default decoration.
- [ ] Smash cuts are reserved for real contrast or emphasis.
- [ ] Shot scale changes (wide/medium/close) clarify the scene rather than create random variation.

### 13.3 Sound design

- [ ] Dialogue/voice-over is intelligible throughout.
- [ ] Music supports rather than masks speech.
- [ ] SFX are not louder or more attention-grabbing than the content requires.
- [ ] Every SFX supports a visible action, motion graphic, transition, atmosphere, or deliberate subtext.
- [ ] Foley matches movement and physical context.
- [ ] Ambience matches the apparent place and transitions coherently.
- [ ] Sound textures are appropriate to the emotional tone.
- [ ] Important sound events are synchronized with their visual purpose.
- [ ] No accidental clicks, pops, clipped tails, or abrupt room-tone changes remain.
- [ ] Silence is intentional where present.
- [ ] The whole mix belongs to one consistent creative theme.

### 13.4 Rhythm and pacing

- [ ] The pace changes when the story or emotion calls for a change.
- [ ] Fast sections are not fast just for the sake of being fast.
- [ ] Important lines and reveals have enough room to land.
- [ ] Cuts on the beat are used selectively.
- [ ] There is sufficient contrast between buildup and release where appropriate.
- [ ] The video does not feel monotonous or excessively restless.

### 13.5 Graphics and style

- [ ] Text, graphics, sound effects, and animation feel stylistically compatible.
- [ ] Overlays or B-roll do not obscure critical information.
- [ ] Zooms/crops do not degrade image quality or create awkward framing.
- [ ] Effects do not distract from faces, spoken information, or important visual detail.
- [ ] The visual style and audio style feel part of the same content universe.

### 13.6 Technical delivery and asset rights

- [ ] Export settings match the brief or project's intended platform.
- [ ] The final file exists and playback has been checked.
- [ ] Audio does not unintentionally clip or distort.
- [ ] Required captions, logos, or end cards are present.
- [ ] External audio/video assets have a verified basis for use.
- [ ] Any required attribution is preserved.

---

## 14. Failure modes and how to correct them

### Problem: The reel feels choppy even though each cut is technically clean

**Likely causes:** Random shot changes, mismatched motion direction, jumping eye-line, too many simultaneous changes, or cuts that do not follow speech/action.

**Corrections:** Review motion flow, align eye position, choose a motivated cut point, try an action/flow cut, or bridge audio. Do not add a transition automatically.

### Problem: There are too many jump cuts in a talking-head edit

**Likely causes:** Too much dead time was removed without covering visual discontinuities, or every gap was treated the same way.

**Corrections:** Use relevant B-roll for key concepts, alternate angles if available, vary framing sparingly, add an audio pre-lap/post-lap where natural, and preserve deliberate pauses. Leave some visible cuts when they fit the delivery style.

### Problem: The sound design feels amateurish or cluttered

**Likely causes:** Too many effects, unrelated sound styles, effects competing with voice-over, or a whoosh/hit on every cut.

**Corrections:** Remove unnecessary layers, define one sound theme, reduce effect level, prioritize narration, and reserve strong accents for meaningful beats.

### Problem: The video is over-synchronized to music

**Likely causes:** Every beat triggers a cut, graphic, or SFX.

**Corrections:** Keep the strongest beat alignments, then allow speech, motion, and story to determine other cut points. Vary pace and leave unaccented moments so accents retain impact.

### Problem: The cut is hidden, but the edit feels unnatural

**Likely causes:** Irrelevant B-roll, an excessive zoom, an unnaturally removed breath, or a cut concealed even though it should be an intentional pause.

**Corrections:** Remove the cover, reduce the zoom, restore some natural speech rhythm, or keep the cut visible. The purpose is storytelling—not invisibility at all costs.

### Problem: The transition sound feels wrong even though its label seems correct

**Likely causes:** The sound has the wrong texture, duration, energy, frequency content, or thematic character.

**Corrections:** Search using sensory terms; try an alternative category; preview the sound with the actual footage; shorten/trim it if appropriate; or record a custom sound. Choose the sound by effect, not file name.

### Problem: Visual and audio styles do not match

**Likely causes:** The graphics, music, animation, and SFX were chosen independently.

**Corrections:** Define a single creative universe for the project. Re-evaluate all elements—fonts, colors, motion, music, and sound materials—against that style.

### Problem: The edit is polished but feels robotic

**Likely causes:** Every breath removed, every cut hidden, every motion synchronized, and no variation in pauses or tempo.

**Corrections:** Restore natural pauses and selected breaths; preserve genuine performance; allow the rhythm to vary. Add polish only where it serves the story.

---

## 15. Agent behavior rules

Use these as high-priority working rules when editing autonomously.

1. **Do not maximize effects.** Maximize storytelling clarity and emotional precision.
2. **Do not hide every cut.** Decide first whether the cut should be invisible or disruptive.
3. **Do not add arbitrary B-roll.** It must relate to the narration, action, or emotion.
4. **Do not force cuts to music beats.** Only use beat alignment when it supports the intended rhythm.
5. **Do not cut words in half.** Preserve speech intelligibility and natural cadence.
6. **Do not remove every breath.** Keep breaths that make speech human or carry emotion.
7. **Do not use a sound effect because its name sounds appropriate.** Test the actual sound against the picture and mix.
8. **Do not use all six SFX categories in every project.** Select only what the edit needs.
9. **Do not treat the four sound-design universes as rigid genres.** Use them as a palette and keep any blend intentional.
10. **Do not let SFX or music overpower narration.** Voice intelligibility has priority for narrated reels.
11. **Do not assume a paid asset is better than a free or custom-recorded one.** Select based on quality, fit, workflow, and rights.
12. **Do not assume “royalty-free” means unrestricted.** Check the actual usage terms.
13. **Do not apply numeric settings as universal defaults** unless the project or user defines them. Zoom amount, transition offset, mix level, cut timing, and duration depend on footage and context.
14. **Do not fabricate assets or pretend that missing coverage exists.** Use the best available material and note meaningful limitations.
15. **Do not overwrite source media unnecessarily.** Preserve the original assets and work non-destructively where possible.
16. **Do not claim a task is complete without verifying the output.** Inspect the timeline or rendered file when tools allow it.
17. **When uncertain, choose the least risky edit that preserves story and clarity.** Prefer a clean cut over an elaborate but unsupported effect.
18. **Use human judgment.** A rule is a guide, not a substitute for noticing what the moment actually needs.

---

## 16. Suggested internal edit-decision record

For complicated sequences or automated editing, keep a compact record for each significant cut. This makes the edit explainable and easier to revise.

```yaml
cut_id: C012
story_beat: "Introduce the next key idea"
source_outgoing: "talking_head_take_02"
source_incoming: "broll_exposure_closeup"
primary_cut_type: "L-cut"
secondary_principles:
  - "relevant B-roll cover"
  - "voice-over continuity"
intent: "Keep narration connected while showing the concept being discussed"
visual_checks:
  motion_direction: "not applicable / matched / intentionally changed"
  eye_line: "not applicable / checked"
  subject_position: "checked where relevant"
audio_checks:
  voice_clear: true
  music_competes: false
  sfx_purpose: "none / action / transition / typography / ambience / symbolic"
  transition_sounds_relevant: true
rhythm:
  music_beat_alignment: "yes / no / not applicable"
  reason: "brief explanation"
review_status: "needs_review / checked"
```

This is a proposed operational template, not a format prescribed by the source videos. Use actual asset names and actual properties from the project. Do not fill in facts that were not inspected.

---

## 17. Suggested Codex task instructions

The following can be used as a starting instruction alongside this knowledge bank. Adapt it to the actual repository, video-editing tool, libraries, and project conventions.

> **Role:** You are a reel-editing agent. Use `Reel_Editing_Agent_Knowledge_Bank.md` as your editing reference. Your objective is to produce clear, engaging, rhythmically intentional videos with coherent sound design—not to maximize the number of cuts or effects.
>
> **Workflow:** Inspect the brief and all supplied media first. Build a story/beat map; assemble the core story with straightforward cuts; solve continuity and speech issues; shape rhythm; design audio from dialogue/voice-over outward; apply visual polish selectively; then conduct story, continuity, audio, style, license, and export checks.
>
> **Decision-making:** For each significant cut, consider story purpose, motion direction, action continuity, eye-line, speech boundaries, audio continuity, musical rhythm, and whether the moment needs flow or disruption. Use the relevant cut technique only when its purpose matches the moment.
>
> **Sound:** Treat dialogue/voice-over as the priority in narrated edits. Music shapes energy; effects support action, atmosphere, motion graphics, transitions, or deliberate subtext. Keep one coherent sound theme and do not use irrelevant effects. Verify asset usage terms before delivery.
>
> **Restraint:** Do not force every technique into every video. Preserve meaningful pauses, natural speech, and intentional visible cuts. If an edit feels cluttered, remove the least useful layer before adding another effect.
>
> **Verification:** Do not claim success until the final timeline/export has been checked as far as available tools allow. Report missing media, unresolved licensing, uncertain settings, or limitations instead of inventing solutions.

---

## 18. Compact reference: the full technique inventory

### Picture-editing techniques

- Straight/standard cut
- Jump cut
- Graphic match cut
- Movement match cut
- Audio match cut
- J-cut
- L-cut
- Fade to/from color
- Dissolve
- Cut on action / action cut
- Flow cut
- Cross-cutting / parallel editing
- Smash cut
- Wide–medium–close shot sequence
- Rhythm/tempo editing
- Cutting on the musical beat
- B-roll / graphics / overlay to cover a cut
- Subtle crop or zoom change after a jump
- Eye-line and subject-position matching
- Speech-aware edit points
- Planned multi-angle alternation

### Sound-design components

- Voice-over / dialogue
- Music
- Literal / production sound
- Foley / supplementary action sound
- Ambient / atmospheric sound
- Texture and transition SFX
- Motion-design / typography SFX
- Creative / symbolic SFX
- Silence and intentional reduction of sound

### Common sound elements

- Whoosh / sweep / swish
- Riser / build
- Swell
- Bass rumble / low drone
- Hit / impact
- Bass drop / release
- Echo / reverb
- Click / tactile click
- Typewriter / keyboard sound
- Pop
- Footsteps
- Cloth rustle
- Traffic horn
- Door slam
- Wind / water / birds / room tone

### Four broad style universes

- Entertainment: playful, energetic, reaction-led, often with more overt accents.
- Explainer: clear, informative, tactile graphic cues, restrained transitions.
- Cinematic: immersive ambience, Foley, builds, impacts, emotional sound arcs.
- Minimal: sparse, carefully selected accents and a clean, restrained soundscape.

---

## 19. Final governing principle

The best edit is not the one that uses every technique in this bank. It is the one that selects the right technique for each moment and makes the complete reel feel intentional.

For every proposed edit, ask:

1. **What should the viewer understand or feel here?**
2. **Should this transition be invisible or noticeable?**
3. **What is the simplest visual and audio choice that achieves that?**
4. **Does the result preserve clarity, continuity, natural rhythm, and thematic consistency?**
5. **After watching the result, does the technique help the story—or merely announce itself?**

If the technique does not improve the story, remove it or choose a simpler approach.
