---
name: apple-motion-edit
description: "The Apple Keynote & Commercial Kinetic Mixed-Media format for high-production explainer reels (9:16 vertical or 16:9). Combines authentic 4K studio product cutouts (not generic primitive shapes or AI slop), deep obsidian studio backgrounds (#060709), frosted glass Bento cards with specular top sheens, Apple SF Pro / Inter typography, HUD telemetry & live animated counters, and continuous damped harmonic spring physics with motion or scene changes every ≤2s. Zero talking head (or optional minimal hybrid face takeover)."
---

# APPLE MOTION EDIT — Kinetic Mixed-Media Commercial Format

> **THE ESSENCE:** A broadcast commercial motion design format inspired by Apple Keynote, Cupertino product launch films, and high-end After Effects motion design. Every beat feels tactile, cinematic, and authoritative. Abstract claims are replaced by **real-world photographic benchmarks** (e.g. comparing a 1.8g micro-instrument to a 1,200kg car, a basmati rice grain with digital vernier calipers, sweating AirPods, or 3D neural brain scans). **Zero generic 2D SVG stick doodles and zero untextured primitive 3D meshes.**

---

## 1. When to Use This Format

Use **`apple-motion-edit`** whenever:
- The user requests **"Apple style"**, **"Apple Keynote"**, **"Apple marketing/commercial design"**, **"After Effects motion design"**, or **"Kinetic Mixed-Media"**.
- The script is a high-stakes explainer, debunk, reality check, or tech teardown that requires **extreme credibility and broadcast polish**.
- The edit requires **zero talking head** (100% pure motion graphics & visual demonstrations) or a hybrid where motion design takes up $\ge 70\%$ of screen time.
- The user explicitly rejects amateur doodle graphics or generic AI slop and demands **studio product photography, metallic materials, and tactile realism**.

---

## 2. Core Non-Negotiables & Rules

1. **The ≤2.0-Second Motion Cadence:**  
   The screen must **never sit static for longer than 2.0 seconds**. Every 1.5–2.0 seconds, there MUST be an active visual event:
   - A spring-loaded Bento card entry or exit.
   - An active camera micro-drift or scale push (`scale: 1.0 → 1.05`).
   - A live odometer counter roll (e.g. `0 → 18,250 HOURS`).
   - A precision telemetry measurement animation (e.g. `0.00 → 14.20 mm`).
   - Active particles, spark deflections, or concentric audio/acid shockwave ripples.
2. **Real Photographic Cutouts Only (Anti-AI Slop Rule):**  
   Never substitute real objects with generic primitive shapes (untextured boxes/spheres) or crude 2D SVG stick doodles. Every tangible hero object MUST be an authentic, high-resolution commercial studio photograph with real lighting and specular reflections.
3. **Rounded Bento Frame Containment:**  
   Product cutouts must be housed inside rounded Bento cards (`border-radius: 20–32px`) with frosted glass borders, or composited with specular rim drop-shadows. Never leave unclipped rectangular bounding box edges.
4. **Isolated Text Alignment (No Leaking Canvas States):**  
   In programmatic canvas engines, always wrap HUD elements and timecode overlays in `ctx.save()` / `ctx.restore()` and explicitly reset `ctx.textAlign = 'left'` and `ctx.textBaseline = 'alphabetic'` before card text rendering.
5. **Peak-Aligned Sound Design (-14.0 LUFS):**  
   Every major visual event (slam, scale drop, caliper clamp, odometer ping, glitch shock) must have a peak-aligned sound effect. The final mixed audio must be measured and normalized to exactly **-14.0 LUFS** (True Peak $\le -1.5\text{ dBFS}$) with headroom for voiceover.

---

## 3. Visual Grammar & Design System

### A. Color Palette (Obsidian Studio Matrix)

```
Background Base:      #060709 (Deep Obsidian Black)
Radial Ambient Glow:  #0a0d14 (Center) → #020304 (Vignette Edge)
Frosted Glass Card:   rgba(255, 255, 255, 0.04 - 0.08)
Card Border Stroke:   rgba(255, 255, 255, 0.12 - 0.20) (1.5px)
Card Specular Top:    Linear Gradient: rgba(255,255,255,0.12) → rgba(0,0,0,0.3)
Primary Accent:       #2997FF (Apple Electric Blue)
Success / Intact:     #30D158 (Clinical Green)
Warning / Value:      #FF9F0A (Warm Amber) / #FFD60A (Electric Gold)
Critical / Failure:   #FF453A (Coral Warning Red)
Neurology / Synapse:  #A259FF (Royal Neural Violet)
Text Primary:         #FFFFFF (Pure White)
Text Secondary:       #86868B (Apple Titanium Muted Grey)
```

### B. Typography Hierarchy (Apple SF Pro / Inter)

- **Hero Numbers / Headlines:** 900 Black / Heavy (`76px – 120px`). Use linear metallic gradients (`#FFFFFF` to `#2997FF` or specular shimmer).
- **Section Headers:** 800 Bold (`34px – 48px`). Clear, punchy statements.
- **HUD Telemetry & Metrics:** `JetBrains Mono` or SF Pro Rounded (`13px – 16px`, uppercase, letter-spacing: `1px`).
- **Body & Dialogue Quotes:** 600–700 Semibold (`18px – 24px`).
- **Pill Badges:** Capsule shape (`border-radius: 9999px`), `1.5px` accent border, dark semi-transparent fill (`rgba(0,0,0,0.75)`).

### C. Damped Harmonic Spring Physics

Motion must feel organic and hydraulic, not linear or stiff:

$$\text{Spring}(t, t_0, \text{dur}, \omega, \zeta) = 1 - e^{-\zeta \omega \Delta t} \left[ \cos(\omega_d \Delta t) + \frac{\zeta}{\sqrt{1 - \zeta^2}} \sin(\omega_d \Delta t) \right]$$

- **Heavy Industrial Elements (Cars, Hydraulic Scales):**  
  `stiffness: 160 – 200`, `damping: 18 – 22`, `mass: 1.5`
- **Standard Bento Cards & Cutouts:**  
  `stiffness: 220 – 260`, `damping: 24 – 26`
- **Punchy Text Slams & Stamp Hits:**  
  `stiffness: 300 – 340`, `damping: 20 – 24` (with micro camera shake: `±6px` for 4–6 frames)

---

## 4. Standard Act Architecture (Commercial Explainer Template)

A typical 45–50s commercial reel in this style follows a 7-Act progression:

```mermaid
flowchart TD
    Act1["<b>ACT 1: THE INTAKE & SHOCK</b><br/>Clinical card enters • Heart rate / ECG spike • Glitch slam"]
    Act2["<b>ACT 2: THE PHYSICAL INVERSION</b><br/>Mass-to-cost paradox • Dynamic balance scale • Hydraulic car slam"]
    Act3["<b>ACT 3: THE TRUE MACRO BENCHMARK</b><br/>1:1 Real-world scale comparison • Animated digital vernier caliper clamp"]
    Act4["<b>ACT 4: THE CONSUMER COMPARISON & FAILURE</b><br/>Everyday consumer tech • Corrosive degradation pulse • Failure stamp"]
    Act5["<b>ACT 5: THE BIOLOGICAL TORTURE CHAMBER</b><br/>Hostile internal telemetry • Active nano-shield deflection • High-speed odometer roll"]
    Act6["<b>ACT 6: THE VALUE SHIFT (NOT PLASTIC. NEUROLOGY.)</b><br/>Luminous 3D medical visualization • Synaptic energy lasers • Mindset reframe"]
    Act7["<b>ACT 7: THE CALLOUT & MORAL CLOSE</b><br/>Sarcastic gadget upgrade tilt • Keynote statement slam • High-status takeaway"]

    Act1 --> Act2 --> Act3 --> Act4 --> Act5 --> Act6 --> Act7
```

| Act | Typical Duration | Visual Elements | Sound Design (SFX) |
|---|---|---|---|
| **1. Intake & Shock** | 3 – 5s | Frosted clinical clipboard, animated ECG monitor (78→145 BPM), quote box, glitch shock text. | Clinical click, warning alert beep, riser, heavy impact slam. |
| **2. Physical Inversion** | 5 – 7s | Huge metallic price headline, dynamic 2.5D balance beam, 1,200kg car vs 1.8g micro-device, equilibrium lock. | Deep whoosh, metallic impact, car zoom, hydraulic thud, balance chime ping. |
| **3. True Macro Benchmark** | 4 – 6s | Macro studio pedestal, rice grain / fingertip comparison, digital caliper closing, precision measurement readout. | Precision whoosh, metallic caliper slide (`shhk-clink`), clamp click, digital telemetry ping. |
| **4. Consumer Tech Failure** | 6 – 8s | Bento card with consumer earbuds, macro sweat droplets, red acid ripple pulse, "DEAD IN 60 DAYS" slam, "EXACTLY." punch. | Card whoosh, acid warning pop, electrical short thud, crisp snap. |
| **5. Biological Torture Chamber** | 7 – 9s | 37°C ear canal heatmap, titanium IP68 forcefield with spark deflections, rolling 18,250 hours odometer counter, chai comparison. | Atmospheric riser, shield spark pings, rapid odometer ticks (`t-t-t-ping!`), liquid splash whoosh. |
| **6. The Value Shift (Neurology)** | 7 – 9s | Luminous 3D neural brain scan, synaptic laser beams into Auditory Cortex, cognitive decline vs recovery contrast card. | Deep harmonic synth swell, crystalline data chatter, warm acoustic tone wash. |
| **7. Callout & Moral Close** | 6 – 8s | 1.2° smartphone camera tilt, sarcastic priority contrast grid, giant Keynote moral statement card slam. | Camera shutter click, mechanical angle latch, riser, sub-bass moral impact slam. |

---

## 5. Technical Implementation Blueprint

### Fast Deterministic Pipeline (Puppeteer + FFmpeg Pipe)
For high-efficiency generation without heavy Remotion bundle duplication:
1. **HTML/Canvas Scene:** Standard HTML5 canvas (`1080 × 1920`) with preloaded photorealistic cutouts.
2. **Frame Grabber:** Deterministic `window.grabFrame(frameIndex)` that calculates time $t = f / \text{FPS}$, evaluates spring equations, and renders layers.
3. **Browser Engine:** Puppeteer-Core controlling Edge/Chrome with hardware acceleration flags (`--use-gl=angle --use-angle=d3d11 --enable-webgl`).
4. **Encoding Pipe:** Stream base64/PNG frames directly into FFmpeg `image2pipe` stdin (`-c:v libx264 -preset fast -crf 17 -pix_fmt yuv420p`).
5. **Audio Muxing:** Mux with peak-aligned SFX soundtrack normalized to `-14.0 LUFS` (`loudnorm=I=-14:TP=-1.5:LRA=11`).

---

## 6. Verification Checklist Before Delivery

- [ ] **Duration Gated:** Under 50 seconds (typically 45.0s – 48.0s).
- [ ] **Loudness Gated:** Encoded file measures exactly **-14.0 LUFS** (±0.5 LUFS) via `ebur128`.
- [ ] **Motion Cadence Proved:** No static hold $> 2.0$ seconds anywhere on the timeline.
- [ ] **Zero AI Slop:** All hero physical objects are real studio photograph cutouts.
- [ ] **Text Containment:** All titles, badges, and readouts are within Instagram vertical safe areas (`y180 – y1740`).
- [ ] **Visual Proof:** Verification stills captured and inspected across all acts before presenting.
