import sys
import io
import subprocess
import numpy as np
import faster_whisper

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def load_audio(file_path, start_sec, duration_sec):
    cmd = ["ffmpeg", "-ss", str(start_sec), "-t", str(duration_sec), "-i", file_path, "-f", "f32le", "-ar", "16000", "-ac", "1", "-"]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    raw, _ = p.communicate()
    return np.frombuffer(raw, dtype=np.float32)

model = faster_whisper.WhisperModel("small", device="cpu", compute_type="int8")

print("--- Master Audio 17.0s to 22.0s detailed words ---")
audio = load_audio("remotion_ci_reel/public/audiogram2_master_voice.wav", 17.0, 5.0)
segments, info = model.transcribe(audio, word_timestamps=True)

for seg in segments:
    print(f"Segment: {seg.text}")
    for w in seg.words:
        t0 = 17.0 + w.start
        t1 = 17.0 + w.end
        print(f"  [{t0:.3f}s - {t1:.3f}s | F{round(t0*30):4d}-F{round(t1*30):4d}] {w.word}")
