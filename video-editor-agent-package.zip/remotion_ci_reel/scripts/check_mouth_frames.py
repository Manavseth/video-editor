import cv2
import numpy as np

cap = cv2.VideoCapture("remotion_ci_reel/public/clips/audiogram2_clip1.mp4")

# Check frames 43 to 48 (pause after Moderate)
# Check frames 84 to 88 (pause after hearing loss)
frames_to_check = [43, 44, 45, 46, 47, 84, 85, 86, 87, 88]

for f in frames_to_check:
    cap.set(cv2.CAP_PROP_POS_FRAMES, f)
    ret, frame = cap.read()
    if ret:
        # Crop to mouth region (approx y: 900-1200, x: 400-680)
        h, w, _ = frame.shape
        mouth_crop = frame[int(h*0.48):int(h*0.65), int(w*0.38):int(w*0.62)]
        cv2.imwrite(f"remotion_ci_reel/mouth_f{f:03d}.jpg", mouth_crop)

cap.release()
print("Saved mouth frames for inspection!")
