import sys
import io
import subprocess
import numpy as np

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def get_rms(file_path, start_sec, duration_sec, fps=30):
    cmd = ["ffmpeg", "-ss", str(start_sec), "-t", str(duration_sec), "-i", file_path, "-f", "f32le", "-ar", "48000", "-ac", "1", "-"]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    raw, _ = p.communicate()
    samples = np.frombuffer(raw, dtype=np.float32)
    spf = int(48000 / fps)
    num_frames = len(samples) // spf
    rms_list = []
    for i in range(num_frames):
        chunk = samples[i*spf : (i+1)*spf]
        rms = np.sqrt(np.mean(chunk**2))
        rms_list.append(rms)
    return rms_list

master_rms = get_rms("remotion_ci_reel/public/audiogram2_master_voice.wav", 18.0, 4.0, fps=30)
clip_rms = get_rms(r"E:\Courses\audiogram part2 clip1.mp4", 0.0, 4.0, fps=30)

print("Frame | Time (Master) | Master RMS | Clip1 Time | Clip1 RMS")
for f in range(min(len(master_rms), len(clip_rms))):
    t_m = 18.0 + f / 30.0
    t_c = f / 30.0
    m_val = master_rms[f]
    c_val = clip_rms[f]
    m_bar = "#" * int(m_val * 100)
    c_bar = "*" * int(c_val * 100)
    print(f"F{f:2d} (Abs F{round(t_m*30):3d}) | {t_m:5.2f}s | {m_val:6.4f} {m_bar[:15]:15s} | {t_c:5.2f}s | {c_val:6.4f} {c_bar[:15]:15s}")
