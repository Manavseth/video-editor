import sys
import io
import subprocess
import numpy as np
import faster_whisper

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def load_audio(file_path, start_sec=None, duration_sec=None):
    cmd = ["ffmpeg"]
    if start_sec is not None:
        cmd.extend(["-ss", str(start_sec)])
    if duration_sec is not None:
        cmd.extend(["-t", str(duration_sec)])
    cmd.extend(["-i", file_path, "-f", "f32le", "-ar", "16000", "-ac", "1", "-"])
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    raw, _ = p.communicate()
    return np.frombuffer(raw, dtype=np.float32)

model = faster_whisper.WhisperModel("small", device="cpu", compute_type="int8")

print("--- Clip 2 Audio check ---")
audio_c2 = load_audio(r"E:\Courses\audiogram part2 clip2.mp4")
segments_c2, _ = model.transcribe(audio_c2, word_timestamps=True)
for seg in segments_c2:
    for w in seg.words:
        print(f"Clip2: [{w.start:.2f}s - {w.end:.2f}s | F{round(w.start*30):3d}-F{round(w.end*30):3d}] {w.word}")

print("\n--- Master Audio 42.5s to 49.5s ---")
audio_m2 = load_audio("remotion_ci_reel/public/audiogram2_master_voice.wav", 42.5, 7.0)
segments_m2, _ = model.transcribe(audio_m2, word_timestamps=True)
for seg in segments_m2:
    for w in seg.words:
        t0 = 42.5 + w.start
        t1 = 42.5 + w.end
        print(f"Master: [{t0:.2f}s - {t1:.2f}s | F{round(t0*30):4d}-F{round(t1*30):4d}] {w.word}")
