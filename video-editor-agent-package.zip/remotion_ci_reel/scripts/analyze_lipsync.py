import sys
import io
import subprocess
import numpy as np
import faster_whisper
import json

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def load_audio(file_path, start_sec=None, duration_sec=None):
    cmd = ["ffmpeg"]
    if start_sec is not None:
        cmd.extend(["-ss", str(start_sec)])
    if duration_sec is not None:
        cmd.extend(["-t", str(duration_sec)])
    cmd.extend(["-i", file_path, "-f", "f32le", "-ar", "16000", "-ac", "1", "-"])
    
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    raw, _ = p.communicate()
    return np.frombuffer(raw, dtype=np.float32)

print("Loading Whisper model (small)...")
model = faster_whisper.WhisperModel("small", device="cpu", compute_type="int8")

print("\n--- 1. MASTER VOICE (18.0s to 26.0s) ---")
audio_master = load_audio("remotion_ci_reel/public/audiogram2_master_voice.wav", start_sec=18.0, duration_sec=8.0)
segments_master, info_master = model.transcribe(audio_master, word_timestamps=True, language="hi")

master_words = []
for seg in segments_master:
    for w in seg.words:
        t_start = 18.0 + w.start
        t_end = 18.0 + w.end
        frame_start = round(t_start * 30)
        frame_end = round(t_end * 30)
        master_words.append({
            "word": w.word.strip(),
            "start": round(t_start, 3),
            "end": round(t_end, 3),
            "frame_start": frame_start,
            "frame_end": frame_end
        })
        print(f"Master: [{t_start:6.2f}s - {t_end:6.2f}s | F{frame_start:4d}-F{frame_end:4d}] {w.word}")

print("\n--- 2. PROFESSIONAL CLIP 1 (E:\\Courses\\audiogram part2 clip1.mp4) ---")
audio_clip1 = load_audio(r"E:\Courses\audiogram part2 clip1.mp4")
segments_clip1, info_clip1 = model.transcribe(audio_clip1, word_timestamps=True, language="hi")

clip1_words = []
for seg in segments_clip1:
    for w in seg.words:
        t_start = w.start
        t_end = w.end
        frame_start = round(t_start * 30)
        frame_end = round(t_end * 30)
        clip1_words.append({
            "word": w.word.strip(),
            "start": round(t_start, 3),
            "end": round(t_end, 3),
            "frame_start": frame_start,
            "frame_end": frame_end
        })
        print(f"Clip1:  [{t_start:6.2f}s - {t_end:6.2f}s | F{frame_start:4d}-F{frame_end:4d}] {w.word}")

# Save results for comparison
with open("remotion_ci_reel/scripts/lipsync_comparison.json", "w", encoding="utf-8") as f:
    json.dump({"master": master_words, "clip1": clip1_words}, f, indent=2, ensure_ascii=False)
print("\nSaved lipsync_comparison.json successfully!")
