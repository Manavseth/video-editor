import sys
import subprocess
import numpy as np

# Input video
src_path = "remotion_ci_reel/public/clips/audiogram2_clip1.mp4"
dst_path = "remotion_ci_reel/public/clips/audiogram2_clip1_synced.mp4"

# Read dimensions
probe_cmd = ["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,nb_frames", "-of", "csv=s=x:p=0", src_path]
out = subprocess.check_output(probe_cmd).decode().strip().split("x")
W, H = int(out[0]), int(out[1])
print(f"Source video dimensions: {W}x{H}")

# Read all source frames into memory
# 169 frames of 1080x1920 in YUV420p is 169 * 1080 * 1920 * 1.5 bytes = ~525 MB, very easily fits in RAM!
frame_size_yuv = int(W * H * 1.5)
read_cmd = ["ffmpeg", "-i", src_path, "-f", "rawvideo", "-pix_fmt", "yuv420p", "-"]
p_read = subprocess.Popen(read_cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)

src_frames = []
while True:
    buf = p_read.stdout.read(frame_size_yuv)
    if len(buf) < frame_size_yuv:
        break
    src_frames.append(np.frombuffer(buf, dtype=np.uint8))
p_read.wait()
num_src = len(src_frames)
print(f"Loaded {num_src} source frames.")

# Anchor points: (t_out, f_in)
# t_out: frame in output video (0 to 178, total 179 frames = 5.966s)
anchors = [
    (0, 0.0),
    (26, 26.0),
    (43, 43.0),
    (56, 47.0),
    (70, 58.0),
    (98, 84.0),
    (101, 88.0),
    (119, 109.0),
    (125, 113.0),
    (132, 121.0),
    (148, 142.0),
    (160, 151.0),
    (178, 165.0)
]

def get_input_frame(t):
    for i in range(len(anchors) - 1):
        t0, f0 = anchors[i]
        t1, f1 = anchors[i+1]
        if t0 <= t <= t1:
            ratio = (t - t0) / (t1 - t0)
            return f0 + ratio * (f1 - f0)
    return anchors[-1][1]

# Set up FFmpeg writer
write_cmd = [
    "ffmpeg", "-y",
    "-f", "rawvideo",
    "-pix_fmt", "yuv420p",
    "-s", f"{W}x{H}",
    "-r", "30",
    "-i", "-",
    "-c:v", "libx264",
    "-preset", "veryfast",
    "-crf", "16",
    "-g", "1",
    "-keyint_min", "1",
    "-bf", "0",
    "-pix_fmt", "yuv420p",
    dst_path
]
p_write = subprocess.Popen(write_cmd, stdin=subprocess.PIPE, stderr=subprocess.DEVNULL)

total_out = 179 # 0 to 178
print(f"Generating {total_out} synchronized frames...")

for t in range(total_out):
    f_in = get_input_frame(t)
    f_low = int(np.floor(f_in))
    f_high = min(f_low + 1, num_src - 1)
    alpha = f_in - f_low
    
    if alpha < 0.01:
        out_frame = src_frames[f_low]
    elif alpha > 0.99:
        out_frame = src_frames[f_high]
    else:
        # Blend YUV frames
        # For Y, U, V channels:
        f0 = src_frames[f_low].astype(np.float32)
        f1 = src_frames[f_high].astype(np.float32)
        blended = (1.0 - alpha) * f0 + alpha * f1
        out_frame = np.clip(blended, 0, 255).astype(np.uint8)
        
    p_write.stdin.write(out_frame.tobytes())

p_write.stdin.close()
p_write.wait()
print(f"Finished writing {dst_path} successfully!")
