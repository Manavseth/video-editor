import { execSync, spawn } from 'child_process';
import fs from 'fs';
import path from 'path';

const REEL_DIR = path.resolve('.');
const OUT_DIR = path.join(REEL_DIR, 'out');
const STILLS_DIR = path.join(REEL_DIR, 'stills');
const ROOT_OUT = path.resolve('../out');
const CODEX_DIR = fs.existsSync('E:/codex/Documentry/out') ? 'E:/codex/Documentry/out' : path.resolve('../out');

fs.mkdirSync(OUT_DIR, { recursive: true });
fs.mkdirSync(STILLS_DIR, { recursive: true });
fs.mkdirSync(CODEX_DIR, { recursive: true });
fs.mkdirSync(ROOT_OUT, { recursive: true });

const SCENES = [
  { id: 'Scene1', name: 'Scene 1: Comparison Hook', frames: 180 },
  { id: 'Scene2', name: 'Scene 2: Inner Ear Hair Cells', frames: 180 },
  { id: 'Scene3', name: 'Scene 3: Sensory Limitation', frames: 168 },
  { id: 'Scene4', name: 'Scene 4: Speaker Metaphor', frames: 78 },
  { id: 'Scene5', name: 'Scene 5: Bypassing Structures', frames: 138 },
  { id: 'Scene6', name: 'Scene 6: Frequency Bands', frames: 150 },
  { id: 'Scene7', name: 'Scene 7: Electrical Stimulation', frames: 156 },
  { id: 'Scene8', name: 'Scene 8: Brain Tonotopic Learning', frames: 150 },
];

console.log('================================================================');
console.log('REMOTION MASTER RENDER ENGINE: COCHLEAR IMPLANT REEL');
console.log('8 Scenes • 1,200 Frames • Exactly 40.0s @ 30 FPS · 1080x1920');
console.log('================================================================');

async function renderAll() {
  const startTime = Date.now();

  // 1. Render each scene individually
  for (let i = 0; i < SCENES.length; i++) {
    const sc = SCENES[i];
    const outClip = path.join(OUT_DIR, `${sc.id.toLowerCase()}.mp4`);
    console.log(`\nRendering [${i + 1}/8] ${sc.id} (${sc.frames} frames)...`);
    
    const cmd = `npx remotion render src/index.ts ${sc.id} "${outClip}" --gl=angle`;
    console.log(`> ${cmd}`);
    execSync(cmd, { stdio: 'inherit', cwd: REEL_DIR });

    // Render mid-still
    const midFrame = Math.floor(sc.frames / 2);
    const stillOut = path.join(STILLS_DIR, `${sc.id.toLowerCase()}_mid.png`);
    const stillCmd = `npx remotion still src/index.ts ${sc.id} "${stillOut}" --frame=${midFrame} --gl=angle`;
    execSync(stillCmd, { stdio: 'inherit', cwd: REEL_DIR });
  }

  // 2. Render Assembled 40.0s Master Reel
  const masterOut = path.join(OUT_DIR, 'MasterReel_40s.mp4');
  console.log(`\nRendering Full Master Reel (1200 frames @ 30 fps with audio)...`);
  const masterCmd = `npx remotion render src/index.ts MasterReel "${masterOut}" --gl=angle`;
  console.log(`> ${masterCmd}`);
  execSync(masterCmd, { stdio: 'inherit', cwd: REEL_DIR });

  // 3. Copy outputs to codex Documentry out and Root out
  console.log('\nDistributing deliverables...');
  const filesToCopy = [
    { src: masterOut, destName: 'Cochlear_Implant_vs_Hearing_Aid_MasterReel.mp4' },
    ...SCENES.map(sc => ({
      src: path.join(OUT_DIR, `${sc.id.toLowerCase()}.mp4`),
      destName: `${sc.id.toLowerCase()}.mp4`
    }))
  ];

  for (const item of filesToCopy) {
    if (fs.existsSync(item.src)) {
      fs.copyFileSync(item.src, path.join(CODEX_DIR, item.destName));
      fs.copyFileSync(item.src, path.join(ROOT_OUT, item.destName));
      console.log(`  ✓ Copied ${item.destName} to codex and root out`);
    }
  }

  const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
  console.log(`\n================================================================`);
  console.log(`ALL 8 SCENES AND MASTER REEL RENDERED SUCCESSFULLY IN ${elapsed}s!`);
  console.log('================================================================');
}

renderAll().catch(err => {
  console.error('Render error:', err);
  process.exit(1);
});
