export const FAITH_THEME = {
  width: 1080,
  height: 1920,
  fps: 30,
  totalFrames: 1065, // Exactly 35.50s — All scenes STRICTLY <= 3.50s (Max ceiling 4.0s)

  colors: {
    bg: '#0A0F1D',           // Deep Midnight Slate
    bgDark: '#050811',       // Outer vignette edge
    radialGlow: 'rgba(255, 200, 100, 0.22)',
    innerGlow: 'rgba(255, 225, 140, 0.35)',

    // The signature Gold Palette
    gold: '#FFC83B',         // Radiant Amber Gold
    goldBright: '#FFD700',   // Pure Bright Gold
    goldMuted: '#D4AF37',    // Antique Metallic Gold
    goldSoft: 'rgba(255, 200, 59, 0.15)',

    // Technical Blueprint Accents
    blueAccent: '#64B5F6',   // Technical Cyan / Luminous Blue
    blueMuted: '#1E293B',    // Card Fill
    blueBorder: '#334155',   // Subtle Card Outline

    // Noise & Negative Dynamics
    redNoise: '#EF4444',     // Restaurant Babble Noise
    slateNoise: '#94A3B8',   // Unfocused Acoustic Clatter

    // Anatomy & Paper Layers
    paperSkin: '#D4B8A5',
    paperShadow: 'rgba(0, 0, 0, 0.45)',
    white: '#FFFFFF',
    cream: '#F7F3E9',
  },

  fonts: {
    serif: 'Cinzel, "Cormorant Garamond", "Times New Roman", Georgia, serif',
    sans: 'Inter, -apple-system, "Segoe UI", Roboto, sans-serif',
    mono: '"SF Mono", "Fira Code", monospace',
  },

  safeArea: {
    top: 180,
    bottom: 260,
    captionY: 1530,
  },

  // HARD RULE: Every scene duration MUST be <= 120 frames (4.0s)
  scenes: [
    { id: 'scene1', name: 'Acoustic Chaos Hook', startFrame: 0, duration: 96, time: '00:00–00:03.2' },
    { id: 'scene2', name: 'Linear Amplification Trap', startFrame: 96, duration: 96, time: '00:03.2–00:06.4' },
    { id: 'scene3', name: 'Micro-Architecture Reveal', startFrame: 192, duration: 96, time: '00:06.4–00:09.6' },
    { id: 'scene4', name: 'DSP Environmental Classifier', startFrame: 288, duration: 96, time: '00:09.6–00:12.8' },
    { id: 'scene5', name: 'Speech Envelope Modulation', startFrame: 384, duration: 96, time: '00:12.8–00:16.0' },
    { id: 'scene6', name: 'Noise Attenuation & SNR', startFrame: 480, duration: 96, time: '00:16.0–00:19.2' },
    { id: 'scene7', name: 'State: Quiet 360', startFrame: 576, duration: 96, time: '00:19.2–00:22.4' },
    { id: 'scene8', name: 'State: Noisy Beamforming', startFrame: 672, duration: 96, time: '00:22.4–00:25.6' },
    { id: 'scene9', name: 'State: Wind Cancellation', startFrame: 768, duration: 96, time: '00:25.6–00:28.8' },
    { id: 'scene10', name: 'Autonomous Switching', startFrame: 864, duration: 96, time: '00:28.8–00:32.0' },
    { id: 'scene11', name: 'Golden Clarity Dome', startFrame: 960, duration: 105, time: '00:32.0–00:35.5' },
  ] as const,
};
