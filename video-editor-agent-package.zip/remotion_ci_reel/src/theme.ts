export const THEME = {
  width: 1080,
  height: 1920,
  fps: 30,
  totalFrames: 1200,

  colors: {
    bg: '#060A14',
    bgDeep: '#03060C',
    bgCard: 'rgba(13, 24, 44, 0.65)',
    panel: 'rgba(15, 23, 42, 0.75)',
    line: 'rgba(148, 163, 184, 0.2)',
    lineBright: 'rgba(245, 242, 235, 0.4)',

    // Anatomy & Acoustic (Ivory / warm neutral)
    ivory: '#F5F2EB',
    ivoryMuted: '#CBD5E1',
    amber: '#F59E0B',
    amberGlow: 'rgba(245, 158, 11, 0.35)',

    // Implant & Electrical Stimulation (Restrained Cyan)
    cyan: '#22D3EE',
    cyanBright: '#38BDF8',
    cyanGlow: 'rgba(34, 211, 238, 0.4)',
    cyanDeep: 'rgba(14, 116, 144, 0.5)',

    // Nerve & Brain
    nerve: '#E2E8F0',
    nerveActive: '#67E8F9',
    grey: '#64748B',
    muted: '#64748B',
    mutedDark: '#334155',
  },

  fonts: {
    title: 'system-ui, -apple-system, "SF Pro Display", "Segoe UI", Inter, Roboto, sans-serif',
    mono: '"SF Mono", "Fira Code", "Courier New", monospace',
  },

  safeArea: {
    top: 180,
    bottom: 260,
    left: 80,
    right: 80,
    captionY: 1360,
  },

  scenes: [
    { id: 'scene1', name: 'Comparison Hook', startFrame: 0, duration: 180, time: '00:00–00:06' },
    { id: 'scene2', name: 'Inner Ear Hair Cells', startFrame: 180, duration: 180, time: '00:06–00:12' },
    { id: 'scene3', name: 'Sensory Limitation', startFrame: 360, duration: 168, time: '00:12–00:17.6' },
    { id: 'scene4', name: 'Speaker Metaphor', startFrame: 528, duration: 78, time: '00:17.6–00:20.2' },
    { id: 'scene5', name: 'Bypassing Structures', startFrame: 606, duration: 138, time: '00:20.2–00:24.8' },
    { id: 'scene6', name: 'Frequency Bands', startFrame: 744, duration: 150, time: '00:24.8–00:29.8' },
    { id: 'scene7', name: 'Electrical Stimulation', startFrame: 894, duration: 156, time: '00:29.8–00:35.0' },
    { id: 'scene8', name: 'Brain Tonotopic Learning', startFrame: 1050, duration: 150, time: '00:35.0–00:40.0' },
  ] as const,
};
