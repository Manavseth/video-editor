import React from 'react';
import {
  useCurrentFrame,
  Sequence,
  Audio,
  OffthreadVideo,
  staticFile,
} from 'remotion';

// =============================================================================
// MINIMALISTIC BRAND TOKENS & SYSTEM
// =============================================================================
const W = 1080;
const H = 1920;
const PAPER = '#F6F2E9';
const GRID = '#E4DECC';
const INK = '#20252B';
const INK_SOFT = '#5B5970';
const TEAL = '#2D8C85';
const TEAL_LIGHT = '#E6F4F2';
const AIR = '#DF7A2B';
const AIR_LIGHT = '#FDF2E9';
const BONE = '#2E56C9';
const OK = '#2E9E6B';
const OK_LIGHT = '#EAF7EE';
const STOP = '#C63B3B';
const STOP_LIGHT = '#FDF0F0';
const PALE_CARD = '#FFFDF8';

// Frequency axis coordinates
const OCTAVES = [250, 500, 1000, 2000, 4000, 8000];
const fx = (f: number) => 160 + 152 * Math.log2(f / 250);
const dy = (db: number) => 380 + 7.5 * db;

// Easing helpers
const clamp = (v: number, min = 0, max = 1) => Math.max(min, Math.min(max, v));
const easeOutCubic = (t: number) => 1 - Math.pow(1 - clamp(t), 3);
const easeStamp = (t: number) => {
  t = clamp(t);
  if (t < 0.3) return 1.0 + 0.18 * Math.sin((t / 0.3) * (Math.PI / 2));
  if (t < 0.7) return 1.18 - 0.22 * ((t - 0.3) / 0.4);
  return 0.96 + 0.04 * ((t - 0.7) / 0.3);
};

// Captions data
const CUES = [
  { start: 0.00, end: 1.50, text: "Tumne pichhli reel mein dekha tha:" },
  { start: 1.50, end: 4.08, text: "Sirf 10 dB ka gap batata hai", hl: "10 dB ka gap" },
  { start: 4.08, end: 6.48, text: "problem parde mein hai ya nerve mein.", hl: "parde ya nerve" },
  { start: 6.48, end: 9.42, text: "As an audiologist, audiogram mere liye", hl: "As an audiologist" },
  { start: 9.42, end: 11.26, text: "aapke kaan ka ek Sound Equalizer hai,", hl: "Sound Equalizer" },
  { start: 11.26, end: 12.96, text: "jahan left pe Bass hota hai", hl: "left pe Bass" },
  { start: 12.96, end: 15.80, text: "aur right pe Treble, yaani Speech Clarity.", hl: "Treble = Speech Clarity" },
  { start: 15.80, end: 17.78, text: "Agar graph right side se drop ho,", hl: "right side se drop" },
  { start: 17.78, end: 20.85, text: "yaani Sloping Hearing Loss...", hl: "Sloping Hearing Loss" },
  { start: 20.85, end: 24.54, text: "Volume toh sunai deta hai, par words muffled lagte hain,", hl: "words muffled lagte hain" },
  { start: 24.54, end: 27.29, text: "jo natural aging ka ek classic sign hai.", hl: "natural aging (Presbycusis)" },
  { start: 27.29, end: 30.16, text: "Aur agar 4000 Hz par ek sharp notch ho,", hl: "4000 Hz sharp notch" },
  { start: 30.16, end: 35.04, text: "yeh loud headphones aur noise exposure ka direct proof hai.", hl: "Noise Exposure Proof" },
  { start: 35.04, end: 38.14, text: "Audiogram tumhari hearing health ka blueprint hai,", hl: "Hearing Health Blueprint" },
  { start: 38.14, end: 40.76, text: "jo kabhi jhooth nahi bolta.", hl: "kabhi jhooth nahi bolta" },
  { start: 40.76, end: 43.32, text: "Next part mein: do logon ka graph", hl: "Next part mein" },
  { start: 43.32, end: 45.02, text: "bilkul same hone par bhi,", hl: "same hone par bhi" },
  { start: 45.02, end: 47.16, text: "Clarity alag kyun hoti hai?", hl: "Clarity alag kyun?" },
  { start: 47.16, end: 48.64, text: "Ispe baat karenge.", hl: "Follow for Part 5" },
];

export const AudiogramPart4Master: React.FC = () => {
  const frame = useCurrentFrame();
  const time = frame / 30;

  // Active caption
  const activeCue = CUES.find((c) => time >= c.start && time < c.end);

  // Host Take Registers (Spot-on Lip Sync with intra-only 30fps sub-clips)
  const isHostClip1 = frame >= 625 && frame < 739;        // Scene 08: 20.85s - 24.65s (3.80s · 114 frames)
  const isPresbycusisScene = frame >= 739 && frame < 818; // Scene 09: 24.65s - 27.29s (2.64s · 79 frames)
  const isHostClip2 = frame >= 1053 && frame < 1222;      // Scene 12: 35.10s - 40.73s (5.63s · 169 frames)

  return (
    <div
      style={{
        width: W,
        height: H,
        backgroundColor: PAPER,
        position: 'relative',
        overflow: 'hidden',
        fontFamily: 'Inter, "Segoe UI", system-ui, sans-serif',
      }}
    >
      {/* 1. Master Audio from Original File */}
      <Audio src={staticFile('audiogram4_master_voice.wav')} />

      {/* 2. Global Technical Background Grid */}
      <svg
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: W,
          height: H,
          pointerEvents: 'none',
        }}
      >
        <defs>
          <pattern
            id="part4-grid"
            width={48}
            height={48}
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M 48 0 L 0 0 0 48"
              fill="none"
              stroke={GRID}
              strokeWidth={1.5}
              opacity={0.65}
            />
          </pattern>
        </defs>
        <rect width={W} height={H} fill="url(#part4-grid)" />
      </svg>

      {/* 3. Header Stamp (Permanent Clinical Identity - Safe Zone Aligned) */}
      {!isHostClip1 && !isHostClip2 && !(frame >= 114 && frame < 194) && (
        <div
          style={{
            position: 'absolute',
            top: 130,
            left: 64,
            right: 116,
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            zIndex: 8000,
          }}
        >
          <div
            style={{
              backgroundColor: INK,
              color: PAPER,
              padding: '10px 24px',
              borderRadius: 12,
              fontSize: 22,
              fontWeight: 800,
              letterSpacing: '1.5px',
            }}
          >
            AUDIOGRAM DECODED · PART 4
          </div>
          <div
            style={{
              backgroundColor: '#FFFFFF',
              border: `2px solid ${INK}`,
              color: TEAL,
              padding: '10px 20px',
              borderRadius: 12,
              fontSize: 20,
              fontWeight: 750,
            }}
          >
            CLINICAL EXPLAINER
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 1: (0.00s - 3.80s · Frames 0 - 114) · Duration: 3.80s
          ARCHETYPE MG-02: GATE-SPLIT DECISION ENGINE
          "Tumne pichhli reel mein dekha tha: Sirf 10 dB ka gap batata hai..."
          Zero text overlap with symbols; clear 10 dB criterion.
          ===================================================================== */}
      {frame < 114 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: 210,
              left: 64,
              width: 900,
              height: 1040,
              backgroundColor: '#FFFFFF',
              border: `3px solid ${INK}`,
              borderRadius: 24,
              boxShadow: '0 12px 36px rgba(38, 36, 48, 0.08)',
              padding: '24px 28px',
              boxSizing: 'border-box',
            }}
          >
            {/* Header with clear pills */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <span style={{ fontSize: 26, fontWeight: 900, color: INK }}>
                PART 3 RECAP: THE 10 dB CRITERION
              </span>
              <div style={{ display: 'flex', gap: 10 }}>
                <span
                  style={{
                    fontSize: 16,
                    fontWeight: 800,
                    backgroundColor: OK_LIGHT,
                    color: OK,
                    padding: '6px 14px',
                    borderRadius: 20,
                  }}
                >
                  NORMAL: ≤ 20 dB
                </span>
                <span
                  style={{
                    fontSize: 16,
                    fontWeight: 800,
                    backgroundColor: TEAL_LIGHT,
                    color: TEAL,
                    padding: '6px 14px',
                    borderRadius: 20,
                  }}
                >
                  AIR-BONE GAP
                </span>
              </div>
            </div>

            {/* Audiological Grid SVG */}
            <svg width={844} height={880} viewBox="80 300 890 880">
              {/* Frequency Top Labels */}
              {OCTAVES.map((f) => (
                <text
                  key={f}
                  x={fx(f)}
                  y={340}
                  textAnchor="middle"
                  fill={INK}
                  fontSize={24}
                  fontWeight={800}
                >
                  {f < 1000 ? `${f}Hz` : `${f / 1000}k`}
                </text>
              ))}

              {/* dB HL Lines (0 to 100 dB) */}
              {[0, 20, 40, 60, 80, 100].map((db) => (
                <g key={db}>
                  <line
                    x1={150}
                    y1={dy(db)}
                    x2={930}
                    y2={dy(db)}
                    stroke={db === 20 ? OK : GRID}
                    strokeWidth={db === 20 ? 3 : 1.5}
                    strokeDasharray={db === 20 ? "8 4" : "none"}
                  />
                  <text
                    x={138}
                    y={dy(db) + 6}
                    textAnchor="end"
                    fill={db === 20 ? OK : INK_SOFT}
                    fontSize={20}
                    fontWeight={700}
                  >
                    {db}
                  </text>
                </g>
              ))}

              {/* Shaded Normal Zone */}
              <rect x={150} y={dy(0)} width={780} height={dy(20) - dy(0)} fill="rgba(46, 158, 107, 0.08)" />

              {/* Normal Threshold Zone Label: Positioned at y=415 (EMPTY band between 0dB and 10dB) */}
              <text x={160} y={415} textAnchor="start" fill={OK} fontSize={17} fontWeight={800}>
                ● NORMAL AUDITORY SENSITIVITY (0 - 20 dB HL)
              </text>

              {/* Bone Conduction (<) at 10 dB */}
              {OCTAVES.map((f) => (
                <g key={`b-${f}`}>
                  <text x={fx(f)} y={dy(10) + 8} textAnchor="middle" fill={BONE} fontSize={28} fontWeight={900}>
                    &lt;
                  </text>
                </g>
              ))}

              {/* Air Conduction (O) at 20 dB */}
              {OCTAVES.map((f) => (
                <g key={`a-${f}`}>
                  <circle cx={fx(f)} cy={dy(20)} r={9} fill="#FFFFFF" stroke={AIR} strokeWidth={3.5} />
                </g>
              ))}

              {/* 10 dB Caliper Highlight */}
              {(() => {
                const anim = easeOutCubic(frame / 30);
                const cy = dy(15);
                return (
                  <g opacity={anim}>
                    <line x1={fx(1000) + 30} y1={dy(10)} x2={fx(1000) + 50} y2={dy(10)} stroke={TEAL} strokeWidth={3} />
                    <line x1={fx(1000) + 40} y1={dy(10)} x2={fx(1000) + 40} y2={dy(20)} stroke={TEAL} strokeWidth={4} />
                    <line x1={fx(1000) + 30} y1={dy(20)} x2={fx(1000) + 50} y2={dy(20)} stroke={TEAL} strokeWidth={3} />

                    <rect x={fx(1000) + 60} y={cy - 24} width={260} height={48} rx={10} fill={TEAL} />
                    <text x={fx(1000) + 190} y={cy + 7} textAnchor="middle" fill="#FFFFFF" fontSize={20} fontWeight={800}>
                      GAP = 10 dB (NORMAL)
                    </text>
                  </g>
                );
              })()}
            </svg>
          </div>

          {/* Bottom Decision Split Banner */}
          <div
            style={{
              position: 'absolute',
              top: 1290,
              left: 64,
              right: 116,
              display: 'flex',
              gap: 20,
            }}
          >
            <div
              style={{
                flex: 1,
                backgroundColor: '#FFFFFF',
                border: `2px solid ${GRID}`,
                borderRadius: 20,
                padding: '20px 24px',
                boxShadow: '0 8px 24px rgba(38, 36, 48, 0.04)',
              }}
            >
              <div style={{ fontSize: 16, fontWeight: 800, color: TEAL, letterSpacing: 1 }}>CRITERION RULE</div>
              <div style={{ fontSize: 24, fontWeight: 800, color: INK, marginTop: 4 }}>Gap ≤ 10 dB</div>
              <div style={{ fontSize: 16, color: INK_SOFT, marginTop: 4 }}>Bone aur Air saath chalte hain (No ABG)</div>
            </div>
            <div
              style={{
                flex: 1,
                backgroundColor: '#FFFFFF',
                border: `2px solid ${GRID}`,
                borderRadius: 20,
                padding: '20px 24px',
                boxShadow: '0 8px 24px rgba(38, 36, 48, 0.04)',
              }}
            >
              <div style={{ fontSize: 16, fontWeight: 800, color: AIR, letterSpacing: 1 }}>CONDUCTIVE GAP</div>
              <div style={{ fontSize: 24, fontWeight: 800, color: INK, marginTop: 4 }}>Gap ≥ 15 dB</div>
              <div style={{ fontSize: 16, color: INK_SOFT, marginTop: 4 }}>Parda ya middle ear block ka indicator</div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 2: (3.80s - 6.48s · Frames 114 - 194) · Duration: 2.68s
          ARCHETYPE MG-03: ANATOMICAL TWIN COMPARISON (Parda vs Nerve)
          "problem parde mein hai ya nerve mein."
          Anatomical Ear Canal, Tympanic Membrane, Cochlea Snail & CN VIII Fascicle
          ===================================================================== */}
      {frame >= 114 && frame < 194 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          {/* Top Question Header for Silent Viewers */}
          <div
            style={{
              position: 'absolute',
              top: 175,
              left: 64,
              width: 900,
              backgroundColor: INK,
              borderRadius: 16,
              padding: '12px 24px',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              boxShadow: '0 8px 24px rgba(32,37,43,0.15)',
              zIndex: 10,
              boxSizing: 'border-box',
            }}
          >
            <span style={{ fontSize: 20, fontWeight: 900, color: '#FFFFFF', letterSpacing: '1px' }}>
              DIAGNOSTIC QUESTION: WHERE IS THE ISSUE?
            </span>
            <span style={{ fontSize: 16, fontWeight: 800, backgroundColor: TEAL, color: '#FFFFFF', padding: '4px 14px', borderRadius: 10 }}>
              PARDA YA NAS?
            </span>
          </div>

          <div
            style={{
              position: 'absolute',
              top: 245,
              left: 64,
              width: 900,
              display: 'flex',
              gap: 20,
              boxSizing: 'border-box',
            }}
          >
            {/* Left Card: Anatomical Ear Canal & Eardrum (Parda) */}
            <div
              style={{
                flex: 1,
                height: 1015,
                backgroundColor: '#FFFFFF',
                border: `3px solid ${AIR}`,
                borderRadius: 24,
                boxShadow: '0 12px 36px rgba(223, 122, 43, 0.12)',
                padding: '24px 20px',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                boxSizing: 'border-box',
              }}
            >
              <div style={{ alignSelf: 'flex-start', backgroundColor: AIR_LIGHT, color: AIR, padding: '6px 14px', borderRadius: 12, fontSize: 15, fontWeight: 800 }}>
                CONDUCTIVE SITE · AIR PATHWAY
              </div>
              <div style={{ fontSize: 30, fontWeight: 900, color: INK, marginTop: 10, textAlign: 'center' }}>
                👂 PARDA (Ear Drum)
              </div>
              <div style={{ fontSize: 16, color: INK_SOFT, textAlign: 'center', marginTop: 2, fontWeight: 600 }}>
                Ear Canal &amp; Vibrating Eardrum
              </div>

              {/* Anatomical Ear Canal & Tympanic Membrane SVG */}
              <svg width={380} height={460} viewBox="0 0 380 460" style={{ marginTop: 20 }}>
                {/* Canal Cartilage/Bone Walls */}
                <path
                  d="M 25 120 C 55 130, 80 145, 120 145 C 160 145, 195 155, 230 160"
                  fill="none"
                  stroke={INK}
                  strokeWidth={6}
                  strokeLinecap="round"
                />
                <path
                  d="M 25 280 C 55 270, 80 255, 120 255 C 160 255, 195 265, 240 280"
                  fill="none"
                  stroke={INK}
                  strokeWidth={6}
                  strokeLinecap="round"
                />
                {/* Canal Lumen Flesh Tint */}
                <path
                  d="M 25 120 C 55 130, 80 145, 120 145 C 160 145, 195 155, 230 160 L 240 280 C 195 265, 160 255, 120 255 C 80 255, 55 270, 25 280 Z"
                  fill="#FAF4EB"
                  opacity={0.85}
                />

                {/* Animated Incoming Acoustic Sound Waves */}
                {(() => {
                  const waveStep = ((frame - 114) * 5) % 60;
                  return (
                    <g>
                      <path d={`M ${40 + waveStep} 150 A 45 45 0 0 1 ${40 + waveStep} 240`} fill="none" stroke={AIR} strokeWidth={5} strokeLinecap="round" opacity={1 - waveStep / 80} />
                      <path d={`M ${75 + waveStep} 155 A 40 40 0 0 1 ${75 + waveStep} 235`} fill="none" stroke={AIR} strokeWidth={5} strokeLinecap="round" opacity={1 - waveStep / 80} />
                      <path d={`M ${110 + waveStep} 160 A 35 35 0 0 1 ${110 + waveStep} 230`} fill="none" stroke={AIR} strokeWidth={5} strokeLinecap="round" opacity={1 - waveStep / 80} />
                    </g>
                  );
                })()}
                <text x={85} y={135} fill={AIR} fontSize={14} fontWeight={800} textAnchor="middle">
                  SOUND WAVES
                </text>

                {/* Oblique Tympanic Membrane (Parda) with Vibration */}
                {(() => {
                  const vib = Math.sin(frame * 1.2) * 3;
                  return (
                    <g>
                      <path
                        d={`M 230 160 Q ${242 + vib} 220 240 280`}
                        fill="none"
                        stroke={AIR}
                        strokeWidth={8}
                        strokeLinecap="round"
                      />
                      <ellipse cx={236 + vib} cy={220} rx={8} ry={55} fill="rgba(223, 122, 43, 0.3)" />
                      {/* Umbo center depression */}
                      <circle cx={236 + vib} cy={220} r={6} fill={INK} />
                    </g>
                  );
                })()}

                {/* Middle Ear Cavity & Ossicular Chain */}
                {/* Malleus (Hammer) handle attached to umbo */}
                <path d="M 252 140 L 236 220" stroke={INK} strokeWidth={6} strokeLinecap="round" />
                <circle cx={252} cy={140} r={9} fill={INK} />

                {/* Incus (Anvil) */}
                <path d="M 252 140 L 285 148 L 280 195" fill="none" stroke={INK} strokeWidth={6} strokeLinecap="round" strokeLinejoin="round" />
                <circle cx={280} cy={195} r={5} fill={INK} />

                {/* Stapes (Stirrup) Arch & Footplate in Oval Window */}
                <path d="M 280 195 L 302 186 L 318 186 M 280 195 L 302 204 L 318 204" fill="none" stroke={INK} strokeWidth={4} strokeLinecap="round" />
                <line x1={318} y1={180} x2={318} y2={210} stroke={INK} strokeWidth={6} strokeLinecap="round" />

                {/* Anatomical Callouts & Leader Lines */}
                <line x1={120} y1={255} x2={120} y2={325} stroke={INK_SOFT} strokeWidth={2} strokeDasharray="4 3" />
                <text x={120} y={345} fill={INK} fontSize={16} fontWeight={800} textAnchor="middle">
                  EAR CANAL
                </text>
                <text x={120} y={363} fill={INK_SOFT} fontSize={13} textAnchor="middle">
                  External Auditory Meatus
                </text>

                <line x1={236} y1={280} x2={236} y2={390} stroke={AIR} strokeWidth={2} strokeDasharray="4 3" />
                <rect x={155} y={395} width={162} height={42} rx={10} fill={AIR_LIGHT} stroke={AIR} strokeWidth={2} />
                <text x={236} y={415} fill={AIR} fontSize={15} fontWeight={900} textAnchor="middle">
                  EARDRUM (PARDA)
                </text>
                <text x={236} y={431} fill={INK_SOFT} fontSize={12} fontWeight={700} textAnchor="middle">
                  Vibrating Tympanic Membrane
                </text>

                <line x1={290} y1={148} x2={330} y2={125} stroke={INK} strokeWidth={2} strokeDasharray="4 3" />
                <text x={330} y={115} fill={INK} fontSize={14} fontWeight={800} textAnchor="middle">
                  OSSICLES
                </text>
                <text x={330} y={130} fill={INK_SOFT} fontSize={12} textAnchor="middle">
                  Hammer/Anvil/Stirrup
                </text>
              </svg>

              <div style={{ width: '100%', backgroundColor: '#FDF8F3', border: `1.5px solid ${AIR}`, borderRadius: 16, padding: '14px 16px', marginTop: 14 }}>
                <div style={{ fontSize: 15, fontWeight: 900, color: AIR, letterSpacing: 0.5 }}>
                  COMMON CONDUCTIVE BLOCKS:
                </div>
                <div style={{ fontSize: 14, color: INK, marginTop: 4, fontWeight: 700, lineHeight: 1.45 }}>
                  • Kaan ka Mail (Wax Blockage)<br/>
                  • Parda Phatna (Tympanic Tear)<br/>
                  • Middle Ear Fluid / Infection
                </div>
              </div>

              <div style={{ marginTop: 'auto', width: '100%', backgroundColor: AIR_LIGHT, border: `2px solid ${AIR}`, borderRadius: 16, padding: '14px', textAlign: 'center' }}>
                <div style={{ fontSize: 18, fontWeight: 900, color: AIR }}>
                  Air-Bone Gap ≥ 15 dB
                </div>
                <div style={{ fontSize: 13, color: INK_SOFT, marginTop: 2, fontWeight: 700 }}>
                  Acoustic sound wave is physically blocked
                </div>
              </div>
            </div>

            {/* Right Card: Anatomical Snail Cochlea & Cranial Nerve VIII Fascicle */}
            <div
              style={{
                flex: 1,
                height: 1015,
                backgroundColor: '#FFFFFF',
                border: `3px solid ${TEAL}`,
                borderRadius: 24,
                boxShadow: '0 12px 36px rgba(45, 140, 133, 0.12)',
                padding: '24px 20px',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                boxSizing: 'border-box',
              }}
            >
              <div style={{ alignSelf: 'flex-start', backgroundColor: TEAL_LIGHT, color: TEAL, padding: '6px 14px', borderRadius: 12, fontSize: 15, fontWeight: 800 }}>
                SENSORINEURAL SITE · BONE PATHWAY
              </div>
              <div style={{ fontSize: 30, fontWeight: 900, color: INK, marginTop: 10, textAlign: 'center' }}>
                ⚡ NAS (Auditory Nerve)
              </div>
              <div style={{ fontSize: 16, color: INK_SOFT, textAlign: 'center', marginTop: 2, fontWeight: 600 }}>
                Cochlea Snail &amp; CN VIII Nerve Wire
              </div>

              {/* Anatomical Snail Cochlea & Myelinated Axon Fascicle SVG */}
              <svg width={380} height={460} viewBox="0 0 380 460" style={{ marginTop: 20 }}>
                {/* Cochlea Snail Spiral Shell Body */}
                <path
                  d="M 95 160 C 55 180, 40 235, 68 285 C 100 340, 175 345, 215 300 C 248 260, 240 200, 192 175 C 150 155, 115 180, 120 220 C 124 252, 155 262, 172 245 C 185 230, 180 208, 162 204 C 148 200, 138 214, 148 222"
                  fill="#E8F4F2"
                  stroke={TEAL}
                  strokeWidth={6}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />

                {/* Snail Shell Internal Basilar Partition */}
                <path
                  d="M 88 230 C 98 280, 160 290, 190 255 C 212 225, 204 190, 172 180"
                  fill="none"
                  stroke={TEAL}
                  strokeWidth={3}
                  strokeDasharray="6 4"
                />

                {/* Stapes Oval Window Entrance */}
                <ellipse cx={96} cy={160} rx={10} ry={6} fill="#FFFFFF" stroke={TEAL} strokeWidth={3} />

                {/* Multi-fiber Auditory Nerve Fascicle (Cranial Nerve VIII) */}
                <rect x={200} y={192} width={168} height={76} rx={14} fill="#F6FAF9" stroke={TEAL} strokeWidth={4} />

                {/* 3 Parallel Axon Tracks */}
                <line x1={205} y1={210} x2={365} y2={210} stroke={INK} strokeWidth={3} />
                <line x1={205} y1={230} x2={365} y2={230} stroke={INK} strokeWidth={3} />
                <line x1={205} y1={250} x2={365} y2={250} stroke={INK} strokeWidth={3} />

                {/* Myelin Sheaths (Schwann Cells) with Nodes of Ranvier */}
                {/* Axon 1 Sheaths */}
                <rect x={218} y={203} width={30} height={14} rx={4} fill="#D1ECE8" stroke={TEAL} strokeWidth={2} />
                <rect x={262} y={203} width={34} height={14} rx={4} fill="#D1ECE8" stroke={TEAL} strokeWidth={2} />
                <rect x={310} y={203} width={32} height={14} rx={4} fill="#D1ECE8" stroke={TEAL} strokeWidth={2} />

                {/* Axon 2 Sheaths */}
                <rect x={218} y={223} width={30} height={14} rx={4} fill="#D1ECE8" stroke={TEAL} strokeWidth={2} />
                <rect x={262} y={223} width={34} height={14} rx={4} fill="#D1ECE8" stroke={TEAL} strokeWidth={2} />
                <rect x={310} y={223} width={32} height={14} rx={4} fill="#D1ECE8" stroke={TEAL} strokeWidth={2} />

                {/* Axon 3 Sheaths */}
                <rect x={218} y={243} width={30} height={14} rx={4} fill="#D1ECE8" stroke={TEAL} strokeWidth={2} />
                <rect x={262} y={243} width={34} height={14} rx={4} fill="#D1ECE8" stroke={TEAL} strokeWidth={2} />
                <rect x={310} y={243} width={32} height={14} rx={4} fill="#D1ECE8" stroke={TEAL} strokeWidth={2} />

                {/* Animated Electrical Action Potentials (Saltatory Jumping Pulses) */}
                {(() => {
                  const nodeX = [255, 303, 350][Math.floor(((frame - 114) / 6) % 3)];
                  return (
                    <g>
                      <circle cx={nodeX} cy={210} r={7} fill="#DF7A2B" stroke="#FFFFFF" strokeWidth={2} />
                      <circle cx={nodeX} cy={230} r={7} fill="#DF7A2B" stroke="#FFFFFF" strokeWidth={2} />
                      <circle cx={nodeX} cy={250} r={7} fill="#DF7A2B" stroke="#FFFFFF" strokeWidth={2} />
                    </g>
                  );
                })()}

                <text x={265} y={166} fill="#DF7A2B" fontSize={13} fontWeight={900} textAnchor="middle">
                  ⚡ ELECTRICAL PULSES
                </text>

                {/* Direction arrow to brain */}
                <text x={365} y={185} fill={TEAL} fontSize={17} fontWeight={900} textAnchor="end">
                  → BRAIN
                </text>

                {/* Labels and Leader Lines */}
                <line x1={120} y1={335} x2={120} y2={390} stroke={TEAL} strokeWidth={2} strokeDasharray="4 3" />
                <rect x={55} y={395} width={140} height={42} rx={10} fill={TEAL_LIGHT} stroke={TEAL} strokeWidth={2} />
                <text x={125} y={415} fill={TEAL} fontSize={16} fontWeight={900} textAnchor="middle">
                  COCHLEA
                </text>
                <text x={125} y={431} fill={INK_SOFT} fontSize={12} fontWeight={700} textAnchor="middle">
                  Snail Shell · Hair Cells
                </text>

                <line x1={290} y1={270} x2={290} y2={340} stroke={TEAL} strokeWidth={2} strokeDasharray="4 3" />
                <text x={290} y={358} fill={INK} fontSize={16} fontWeight={900} textAnchor="middle">
                  AUDITORY NERVE
                </text>
                <text x={290} y={376} fill={INK_SOFT} fontSize={13} fontWeight={700} textAnchor="middle">
                  CN VIII Fascicle Wire
                </text>
              </svg>

              <div style={{ width: '100%', backgroundColor: '#F0FDF4', border: `1.5px solid ${TEAL}`, borderRadius: 16, padding: '14px 16px', marginTop: 14 }}>
                <div style={{ fontSize: 15, fontWeight: 900, color: TEAL, letterSpacing: 0.5 }}>
                  COMMON NERVE DAMAGE:
                </div>
                <div style={{ fontSize: 14, color: INK, marginTop: 4, fontWeight: 700, lineHeight: 1.45 }}>
                  • Sensory Hair Cell Loss (Aging)<br/>
                  • Loud Sound Acoustic Trauma<br/>
                  • Auditory Nerve Signal Loss
                </div>
              </div>

              <div style={{ marginTop: 'auto', width: '100%', backgroundColor: TEAL_LIGHT, border: `2px solid ${TEAL}`, borderRadius: 16, padding: '14px', textAlign: 'center' }}>
                <div style={{ fontSize: 18, fontWeight: 900, color: TEAL }}>
                  No Gap (≤ 10 dB)
                </div>
                <div style={{ fontSize: 13, color: INK_SOFT, marginTop: 2, fontWeight: 700 }}>
                  Nerve or inner ear hair cells damaged
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 3: (6.48s - 9.42s · Frames 194 - 282) · Duration: 2.94s
          ARCHETYPE MG-01: THE AUDIOLOGIST'S DIAGNOSTIC CONSOLE
          "As an audiologist, audiogram mere liye aapke kaan ka ek..."
          ===================================================================== */}
      {frame >= 194 && frame < 282 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: 210,
              left: 64,
              width: 900,
              height: 1040,
              backgroundColor: '#FFFFFF',
              border: `3px solid ${INK}`,
              borderRadius: 24,
              boxShadow: '0 12px 36px rgba(38, 36, 48, 0.08)',
              padding: '40px',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              boxSizing: 'border-box',
            }}
          >
            <div style={{ backgroundColor: TEAL_LIGHT, color: TEAL, padding: '8px 20px', borderRadius: 20, fontSize: 18, fontWeight: 800, letterSpacing: 1.5 }}>
              CLINICAL METAPHOR INTRO
            </div>
            <div style={{ fontSize: 44, fontWeight: 900, color: INK, marginTop: 20, textAlign: 'center' }}>
              HOW AUDIOLOGISTS SEE IT
            </div>
            <div style={{ fontSize: 22, color: INK_SOFT, marginTop: 8 }}>
              Not just lines on paper — an interactive sound controller
            </div>

            <svg width={800} height={520} viewBox="0 0 800 520" style={{ marginTop: 40 }}>
              <rect x={40} y={40} width={720} height={440} rx={24} fill="#FDFCF9" stroke={INK} strokeWidth={4} />
              <circle cx={80} cy={80} r={8} fill={OK} />
              <circle cx={110} cy={80} r={8} fill={AIR} />
              <circle cx={140} cy={80} r={8} fill={TEAL} />
              <text x={700} y={88} textAnchor="end" fill={INK_SOFT} fontSize={20} fontWeight={800} letterSpacing={2}>
                AUDIOMETRIC SOUND CONSOLE
              </text>

              <rect x={80} y={130} width={640} height={200} rx={16} fill={INK} />
              <path
                d={(() => {
                  let d = 'M 90 230';
                  for (let x = 90; x <= 710; x += 10) {
                    const wave = Math.sin((x + frame * 8) * 0.05) * 45 * Math.sin(x * 0.01);
                    d += ` L ${x} ${230 + wave}`;
                  }
                  return d;
                })()}
                fill="none"
                stroke={TEAL}
                strokeWidth={4}
                strokeLinecap="round"
              />
              <line x1={80} y1={230} x2={720} y2={230} stroke="rgba(255,255,255,0.15)" strokeWidth={2} strokeDasharray="6 6" />
              <line x1={400} y1={130} x2={400} y2={330} stroke="rgba(255,255,255,0.15)" strokeWidth={2} strokeDasharray="6 6" />

              <g transform="translate(140, 410)">
                <circle cx={0} cy={0} r={35} fill="#FFFFFF" stroke={INK} strokeWidth={4} />
                <line x1={0} y1={0} x2={-15} y2={-20} stroke={TEAL} strokeWidth={5} strokeLinecap="round" />
                <text x={0} y={50} textAnchor="middle" fill={INK} fontSize={18} fontWeight={800}>BASS</text>
              </g>
              <g transform="translate(400, 410)">
                <circle cx={0} cy={0} r={35} fill="#FFFFFF" stroke={INK} strokeWidth={4} />
                <line x1={0} y1={0} x2={0} y2={-25} stroke={OK} strokeWidth={5} strokeLinecap="round" />
                <text x={0} y={50} textAnchor="middle" fill={INK} fontSize={18} fontWeight={800}>MID</text>
              </g>
              <g transform="translate(660, 410)">
                <circle cx={0} cy={0} r={35} fill="#FFFFFF" stroke={INK} strokeWidth={4} />
                <line x1={0} y1={0} x2={18} y2={-18} stroke={AIR} strokeWidth={5} strokeLinecap="round" />
                <text x={0} y={50} textAnchor="middle" fill={INK} fontSize={18} fontWeight={800}>TREBLE</text>
              </g>
            </svg>

            <div
              style={{
                marginTop: 30,
                backgroundColor: TEAL,
                color: '#FFFFFF',
                borderRadius: 16,
                padding: '16px 36px',
                fontSize: 22,
                fontWeight: 800,
                boxShadow: '0 8px 24px rgba(45, 140, 133, 0.25)',
              }}
            >
              🎛️ KAAN KA SOUND EQUALIZER
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 4: (9.42s - 12.96s · Frames 282 - 389) · Duration: 3.54s
          ARCHETYPE MG-07: EQUALIZER CONSOLE — BASS SLIDERS ON THE LEFT
          "...Sound Equalizer hai, jahan left pe Bass hota hai..."
          ===================================================================== */}
      {frame >= 282 && frame < 389 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: 210,
              left: 64,
              width: 900,
              height: 1040,
              backgroundColor: '#FFFFFF',
              border: `3px solid ${INK}`,
              borderRadius: 24,
              boxShadow: '0 12px 36px rgba(38, 36, 48, 0.08)',
              padding: '32px',
              display: 'flex',
              flexDirection: 'column',
              boxSizing: 'border-box',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 32, fontWeight: 900, color: INK }}>
                LEFT REGION: BASS & VOLUME
              </span>
              <span style={{ backgroundColor: TEAL_LIGHT, color: TEAL, padding: '6px 18px', borderRadius: 20, fontSize: 18, fontWeight: 800 }}>
                250Hz - 500Hz
              </span>
            </div>
            <div style={{ fontSize: 20, color: INK_SOFT, marginTop: 4 }}>
              Responsible for acoustic fullness, background room tone, and vowel power
            </div>

            <svg width={872} height={600} viewBox="0 0 872 600" style={{ marginTop: 30 }}>
              <rect x={60} y={40} width={280} height={520} rx={20} fill="rgba(45, 140, 133, 0.08)" stroke={TEAL} strokeWidth={3} strokeDasharray="8 6" />
              <text x={200} y={80} textAnchor="middle" fill={TEAL} fontSize={22} fontWeight={900}>
                BASS ZONE (INTACT)
              </text>

              {OCTAVES.map((freq, i) => {
                const trackX = 130 + i * 120;
                const isBass = freq <= 500;
                const faderLevel = isBass
                  ? 180 + Math.sin((frame + i * 15) * 0.15) * 35
                  : 380;
                const activeColor = isBass ? TEAL : GRID;

                return (
                  <g key={freq}>
                    <line x1={trackX} y1={120} x2={trackX} y2={480} stroke={activeColor} strokeWidth={isBass ? 8 : 4} strokeLinecap="round" />
                    {[160, 220, 280, 340, 400, 460].map((tickY) => (
                      <line key={tickY} x1={trackX - 12} y1={tickY} x2={trackX + 12} y2={tickY} stroke={GRID} strokeWidth={2} />
                    ))}
                    <rect
                      x={trackX - 28}
                      y={faderLevel - 18}
                      width={56}
                      height={36}
                      rx={8}
                      fill={isBass ? TEAL : '#FFFFFF'}
                      stroke={INK}
                      strokeWidth={3}
                    />
                    <line x1={trackX - 16} y1={faderLevel} x2={trackX + 16} y2={faderLevel} stroke="#FFFFFF" strokeWidth={3} />
                    <text x={trackX} y={520} textAnchor="middle" fill={isBass ? TEAL : INK_SOFT} fontSize={22} fontWeight={850}>
                      {freq < 1000 ? `${freq}Hz` : `${freq / 1000}k`}
                    </text>
                  </g>
                );
              })}

              {(() => {
                const waveR = ((frame - 282) * 6) % 100;
                return (
                  <g transform="translate(200, 300)">
                    <circle cx={0} cy={0} r={waveR + 20} fill="none" stroke={TEAL} strokeWidth={3} opacity={1 - waveR / 100} />
                    <circle cx={0} cy={0} r={waveR + 50} fill="none" stroke={TEAL} strokeWidth={3} opacity={1 - waveR / 100} />
                  </g>
                );
              })()}
            </svg>

            <div
              style={{
                marginTop: 'auto',
                backgroundColor: TEAL_LIGHT,
                borderRadius: 18,
                padding: '20px 28px',
                display: 'flex',
                alignItems: 'center',
                gap: 20,
              }}
            >
              <div style={{ fontSize: 36 }}>🔊</div>
              <div>
                <div style={{ fontSize: 22, fontWeight: 900, color: TEAL }}>VOWEL POWER & VOLUME</div>
                <div style={{ fontSize: 17, color: INK_SOFT, marginTop: 2 }}>
                  A, E, I, O, U ke sounds aur ambient background isi frequency mein aate hain.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 5: (12.96s - 15.80s · Frames 389 - 474) · Duration: 2.84s
          ARCHETYPE MG-07: EQUALIZER CONSOLE — TREBLE SLIDERS (CLARITY)
          "...aur right pe Treble, yaani Speech Clarity."
          ===================================================================== */}
      {frame >= 389 && frame < 474 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: 210,
              left: 64,
              width: 900,
              height: 1040,
              backgroundColor: '#FFFFFF',
              border: `3px solid ${INK}`,
              borderRadius: 24,
              boxShadow: '0 12px 36px rgba(38, 36, 48, 0.08)',
              padding: '32px',
              display: 'flex',
              flexDirection: 'column',
              boxSizing: 'border-box',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 32, fontWeight: 900, color: INK }}>
                RIGHT REGION: TREBLE & CLARITY
              </span>
              <span style={{ backgroundColor: AIR_LIGHT, color: AIR, padding: '6px 18px', borderRadius: 20, fontSize: 18, fontWeight: 800 }}>
                2k - 4k - 8k Hz
              </span>
            </div>
            <div style={{ fontSize: 20, color: INK_SOFT, marginTop: 4 }}>
              Critical consonants (/s/, /f/, /th/, /sh/) that separate words from noise
            </div>

            <svg width={872} height={600} viewBox="0 0 872 600" style={{ marginTop: 30 }}>
              <rect x={480} y={40} width={360} height={520} rx={20} fill="rgba(223, 122, 43, 0.08)" stroke={AIR} strokeWidth={3} strokeDasharray="8 6" />
              <text x={660} y={80} textAnchor="middle" fill={AIR} fontSize={22} fontWeight={900}>
                TREBLE ZONE (SPEECH CLARITY)
              </text>

              {OCTAVES.map((freq, i) => {
                const trackX = 130 + i * 120;
                const isTreble = freq >= 2000;
                const faderLevel = isTreble
                  ? 200 + Math.sin((frame + i * 20) * 0.2) * 30
                  : 320;
                const activeColor = isTreble ? AIR : GRID;

                return (
                  <g key={freq}>
                    <line x1={trackX} y1={120} x2={trackX} y2={480} stroke={activeColor} strokeWidth={isTreble ? 8 : 4} strokeLinecap="round" />
                    {[160, 220, 280, 340, 400, 460].map((tickY) => (
                      <line key={tickY} x1={trackX - 12} y1={tickY} x2={trackX + 12} y2={tickY} stroke={GRID} strokeWidth={2} />
                    ))}
                    <rect
                      x={trackX - 28}
                      y={faderLevel - 18}
                      width={56}
                      height={36}
                      rx={8}
                      fill={isTreble ? AIR : '#FFFFFF'}
                      stroke={INK}
                      strokeWidth={3}
                    />
                    <line x1={trackX - 16} y1={faderLevel} x2={trackX + 16} y2={faderLevel} stroke="#FFFFFF" strokeWidth={3} />
                    <text x={trackX} y={520} textAnchor="middle" fill={isTreble ? AIR : INK_SOFT} fontSize={22} fontWeight={850}>
                      {freq < 1000 ? `${freq}Hz` : `${freq / 1000}k`}
                    </text>
                  </g>
                );
              })}

              {['/s/', '/f/', '/th/', '/p/'].map((c, idx) => {
                const chipX = 520 + idx * 80;
                const chipY = 240 + Math.sin((frame + idx * 25) * 0.1) * 25;
                return (
                  <g key={c} transform={`translate(${chipX}, ${chipY})`}>
                    <rect x={-25} y={-20} width={50} height={40} rx={10} fill={AIR} />
                    <text x={0} y={7} textAnchor="middle" fill="#FFFFFF" fontSize={20} fontWeight={900}>
                      {c}
                    </text>
                  </g>
                );
              })}
            </svg>

            <div
              style={{
                marginTop: 'auto',
                backgroundColor: AIR_LIGHT,
                borderRadius: 18,
                padding: '20px 28px',
                display: 'flex',
                alignItems: 'center',
                gap: 20,
              }}
            >
              <div style={{ fontSize: 36 }}>🎯</div>
              <div>
                <div style={{ fontSize: 22, fontWeight: 900, color: AIR }}>SPEECH INTELLIGIBILITY</div>
                <div style={{ fontSize: 17, color: INK_SOFT, marginTop: 2 }}>
                  Treble girne par shabd "muffled" lagte hain: "saat" aur "haath" ka farq mit jata hai.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 6: (15.80s - 18.50s · Frames 474 - 555) · Duration: 2.70s
          ARCHETYPE MG-04: DYNAMIC AUDIOGRAM PLOTTER (The Sloping Dive)
          "Agar graph right side se drop ho..."
          Zero text collision with the curve.
          ===================================================================== */}
      {frame >= 474 && frame < 555 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: 210,
              left: 64,
              width: 900,
              height: 1040,
              backgroundColor: '#FFFFFF',
              border: `3px solid ${INK}`,
              borderRadius: 24,
              boxShadow: '0 12px 36px rgba(38, 36, 48, 0.08)',
              padding: '28px 32px',
              boxSizing: 'border-box',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <span style={{ fontSize: 30, fontWeight: 900, color: INK }}>
                RIGHT-SIDE DIVE IN PROGRESS
              </span>
              <span style={{ backgroundColor: STOP_LIGHT, color: STOP, padding: '6px 16px', borderRadius: 20, fontSize: 18, fontWeight: 800 }}>
                HIGH FREQUENCY DROP
              </span>
            </div>

            <svg width={872} height={880} viewBox="80 300 890 880">
              {OCTAVES.map((f) => (
                <text key={f} x={fx(f)} y={340} textAnchor="middle" fill={INK} fontSize={24} fontWeight={800}>
                  {f < 1000 ? `${f}Hz` : `${f / 1000}k`}
                </text>
              ))}

              {[0, 20, 40, 60, 80, 100].map((db) => (
                <g key={db}>
                  <line x1={150} y1={dy(db)} x2={930} y2={dy(db)} stroke={db === 20 ? OK : GRID} strokeWidth={db === 20 ? 3 : 1.5} strokeDasharray={db === 20 ? "8 4" : "none"} />
                  <text x={138} y={dy(db) + 6} textAnchor="end" fill={db === 20 ? OK : INK_SOFT} fontSize={20} fontWeight={700}>
                    {db}
                  </text>
                </g>
              ))}

              <rect x={150} y={dy(0)} width={780} height={dy(20) - dy(0)} fill="rgba(46, 158, 107, 0.08)" />
              {/* Placed at y=415: Clear empty space above the 500 Hz curve */}
              <text x={160} y={415} textAnchor="start" fill={OK} fontSize={17} fontWeight={800}>
                ● NORMAL HEARING THRESHOLD (≤ 20 dB HL)
              </text>

              {/* Dynamic Sloping Curve Animation */}
              {(() => {
                const prog = easeOutCubic((frame - 474) / 50);
                const pts = [
                  { f: 250, db: 15 },
                  { f: 500, db: 15 },
                  { f: 1000, db: 15 + 10 * prog },
                  { f: 2000, db: 15 + 30 * prog },
                  { f: 4000, db: 15 + 50 * prog },
                  { f: 8000, db: 15 + 65 * prog },
                ];
                const d = pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${fx(p.f)} ${dy(p.db)}`).join(' ');

                return (
                  <g>
                    <path d={d} fill="none" stroke={STOP} strokeWidth={8} strokeLinecap="round" />
                    {pts.map((p) => (
                      <g key={p.f}>
                        <circle cx={fx(p.f)} cy={dy(p.db)} r={13} fill="#FFFFFF" stroke={STOP} strokeWidth={4} />
                        <circle cx={fx(p.f)} cy={dy(p.db)} r={5} fill={STOP} />
                      </g>
                    ))}
                    <circle cx={fx(8000)} cy={dy(15 + 65 * prog)} r={18} fill="rgba(198, 59, 59, 0.25)" />
                    <line x1={fx(8000)} y1={dy(15 + 65 * prog)} x2={fx(8000) + 40} y2={dy(15 + 65 * prog) - 40} stroke={STOP} strokeWidth={4} />

                    {/* Silent Viewer Indicators: Bass vs Treble */}
                    <g transform="translate(160, 750)">
                      <rect x={0} y={0} width={250} height={75} rx={16} fill="#EAF7EE" stroke={OK} strokeWidth={3} />
                      <text x={125} y={32} fill={OK} fontSize={19} fontWeight={900} textAnchor="middle">BASS: INTACT ✅</text>
                      <text x={125} y={56} fill={INK_SOFT} fontSize={14} fontWeight={700} textAnchor="middle">Volume &amp; Vowels Audible</text>
                    </g>
                    <g transform="translate(560, 750)">
                      <rect x={0} y={0} width={260} height={75} rx={16} fill="#FDF0F0" stroke={STOP} strokeWidth={3} />
                      <text x={130} y={32} fill={STOP} fontSize={19} fontWeight={900} textAnchor="middle">TREBLE: CRUSHED ❌</text>
                      <text x={130} y={56} fill={INK_SOFT} fontSize={14} fontWeight={700} textAnchor="middle">Speech Clarity Vanishes</text>
                    </g>
                  </g>
                );
              })()}
            </svg>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 7: (18.50s - 20.85s · Frames 555 - 625) · Duration: 2.35s
          ARCHETYPE MG-06: BLOCK-RESULT — SLOPING HEARING LOSS VERDICT
          "yaani Sloping Hearing Loss..."
          Balanced cards with clinical complaint quote.
          ===================================================================== */}
      {frame >= 555 && frame < 625 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: 210,
              left: 64,
              width: 900,
              height: 1040,
              backgroundColor: '#FFFFFF',
              border: `3px solid ${INK}`,
              borderRadius: 24,
              boxShadow: '0 12px 36px rgba(38, 36, 48, 0.08)',
              padding: '36px',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              boxSizing: 'border-box',
            }}
          >
            <div style={{ backgroundColor: STOP_LIGHT, color: STOP, padding: '8px 20px', borderRadius: 20, fontSize: 18, fontWeight: 800 }}>
              AUDIOGRAM CONFIGURATION
            </div>

            <div
              style={{
                marginTop: 30,
                transform: `scale(${easeStamp((frame - 555) / 25)})`,
                backgroundColor: STOP,
                color: '#FFFFFF',
                padding: '24px 48px',
                borderRadius: 20,
                boxShadow: '0 16px 40px rgba(198, 59, 59, 0.35)',
                textAlign: 'center',
              }}
            >
              <div style={{ fontSize: 44, fontWeight: 900, letterSpacing: 1.5 }}>SLOPING HEARING LOSS</div>
              <div style={{ fontSize: 20, fontWeight: 650, marginTop: 6, opacity: 0.9 }}>High-Frequency Sensorineural Impairment</div>
            </div>

            <div style={{ marginTop: 40, width: '100%', display: 'flex', gap: 24 }}>
              <div
                style={{
                  flex: 1,
                  backgroundColor: TEAL_LIGHT,
                  border: `2px solid ${TEAL}`,
                  borderRadius: 20,
                  padding: '24px 20px',
                  textAlign: 'center',
                }}
              >
                <div style={{ fontSize: 40 }}>🔊</div>
                <div style={{ fontSize: 24, fontWeight: 900, color: TEAL, marginTop: 8 }}>VOLUME IS HEARD</div>
                <div style={{ fontSize: 16, color: INK_SOFT, marginTop: 4 }}>Bass frequencies intact</div>
              </div>
              <div
                style={{
                  flex: 1,
                  backgroundColor: STOP_LIGHT,
                  border: `2px solid ${STOP}`,
                  borderRadius: 20,
                  padding: '24px 20px',
                  textAlign: 'center',
                }}
              >
                <div style={{ fontSize: 40 }}>❌</div>
                <div style={{ fontSize: 24, fontWeight: 900, color: STOP, marginTop: 8 }}>CLARITY IS LOST</div>
                <div style={{ fontSize: 16, color: INK_SOFT, marginTop: 4 }}>High consonants dropped</div>
              </div>
            </div>

            {/* Real Patient Quote Card */}
            <div
              style={{
                marginTop: 'auto',
                width: '100%',
                backgroundColor: '#FAF8F4',
                border: `2px dashed ${INK_SOFT}`,
                borderRadius: 18,
                padding: '20px 24px',
                textAlign: 'center',
              }}
            >
              <div style={{ fontSize: 22, fontWeight: 800, color: INK, fontStyle: 'italic' }}>
                "Aawaz toh aa rahi hai... par bol kya rahe hain, samajh nahi aa raha!"
              </div>
              <div style={{ fontSize: 15, color: INK_SOFT, marginTop: 4 }}>
                Classic Presbycusis Patient Presentation
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 8: (20.85s - 24.65s · Frames 625 - 739) · Duration: 3.80s (114 frames)
          PROFESSIONAL HOST CLINICIAN REGISTER [CLIP 1]
          "Volume toh sunai deta hai, par words muffled lagte hain..."
          Master audio continuous, sub-clip muted, spot-on lip sync
          ===================================================================== */}
      {isHostClip1 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H, backgroundColor: PAPER }}>
          <Sequence from={625} durationInFrames={114}>
            <OffthreadVideo
              src={staticFile('clips/audiogram4_clip1_synced.mp4')}
              style={{ width: W, height: H, objectFit: 'cover' }}
              muted
            />
          </Sequence>

          {/* Top Context Pill for Silent Viewers */}
          <div
            style={{
              position: 'absolute',
              top: 175,
              left: 64,
              right: 116,
              backgroundColor: 'rgba(32, 37, 43, 0.94)',
              borderRadius: 16,
              padding: '12px 24px',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              boxShadow: '0 8px 24px rgba(32,37,43,0.18)',
              zIndex: 9000,
            }}
          >
            <span style={{ fontSize: 18, fontWeight: 900, color: '#FFFFFF', letterSpacing: '1px' }}>
              THE SLOPING LOSS PARADOX
            </span>
            <span style={{ fontSize: 15, fontWeight: 800, backgroundColor: STOP, color: '#FFFFFF', padding: '4px 14px', borderRadius: 10 }}>
              AAWAZ HAI, PAR CLARITY NAHI
            </span>
          </div>

          {/* Lower Diagnostic Comparison Badges across Chest Safe Zone */}
          <div
            style={{
              position: 'absolute',
              top: 1300,
              left: 64,
              right: 116,
              display: 'flex',
              justifyContent: 'space-between',
              gap: 20,
              zIndex: 9000,
            }}
          >
            <div
              style={{
                flex: 1,
                backgroundColor: 'rgba(255, 255, 255, 0.96)',
                border: `2px solid ${OK}`,
                borderRadius: 18,
                padding: '16px 20px',
                boxShadow: '0 8px 24px rgba(32,37,43,0.12)',
              }}
            >
              <div style={{ fontSize: 14, fontWeight: 800, color: OK, textTransform: 'uppercase' }}>
                VOLUME / LOUDNESS
              </div>
              <div style={{ fontSize: 24, fontWeight: 900, color: INK, marginTop: 2 }}>
                HEARING: OK
              </div>
              <div style={{ fontSize: 14, color: INK_SOFT, marginTop: 2 }}>
                Low-frequency bass intact
              </div>
            </div>

            <div
              style={{
                flex: 1,
                backgroundColor: 'rgba(255, 255, 255, 0.96)',
                border: `2px solid ${STOP}`,
                borderRadius: 18,
                padding: '16px 20px',
                boxShadow: '0 8px 24px rgba(32,37,43,0.12)',
              }}
            >
              <div style={{ fontSize: 14, fontWeight: 800, color: STOP, textTransform: 'uppercase' }}>
                SPEECH CLARITY
              </div>
              <div style={{ fontSize: 24, fontWeight: 900, color: STOP, marginTop: 2 }}>
                WORDS: MUFFLED
              </div>
              <div style={{ fontSize: 14, color: INK_SOFT, marginTop: 2 }}>
                High-frequency treble dropped
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 9: (24.65s - 27.29s · Frames 739 - 818) · Duration: 2.64s (79 frames)
          MINIMALISTIC ARCHETYPE MG-01: BIOLOGICAL TIMELINE (PRESBYCUSIS)
          "...jo natural aging ka ek classic sign hai."
          ===================================================================== */}
      {isPresbycusisScene && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: 210,
              left: 64,
              width: 900,
              height: 1040,
              backgroundColor: '#FFFFFF',
              border: `3px solid ${INK}`,
              borderRadius: 24,
              boxShadow: '0 12px 36px rgba(32, 37, 43, 0.08)',
              padding: '36px',
              display: 'flex',
              flexDirection: 'column',
              boxSizing: 'border-box',
            }}
          >
            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 16, fontWeight: 800, color: INK_SOFT, letterSpacing: '1.5px', textTransform: 'uppercase' }}>
                  03 / ETIOLOGY
                </div>
                <div style={{ fontSize: 34, fontWeight: 900, color: INK, marginTop: 4 }}>
                  PRESBYCUSIS: NATURAL AGING
                </div>
              </div>
              <div
                style={{
                  backgroundColor: OK_LIGHT,
                  color: OK,
                  padding: '8px 18px',
                  borderRadius: 14,
                  fontSize: 16,
                  fontWeight: 800,
                  border: `2px solid ${OK}`,
                }}
              >
                NATURAL AGING
              </div>
            </div>

            {/* Sub-label */}
            <div style={{ marginTop: 24, fontSize: 18, color: INK_SOFT, fontWeight: 600 }}>
              CLASSIC BIOLOGICAL PROGRESSION · Sensory Hair Cell Attrition
            </div>

            {/* Minimalist Timeline Graphic */}
            <svg width={864} height={420} viewBox="0 0 864 420" style={{ marginTop: 30 }}>
              {/* Timeline Track */}
              <line x1={80} y1={180} x2={784} y2={180} stroke={GRID} strokeWidth={6} strokeLinecap="round" />
              
              {/* Progress Line */}
              {(() => {
                const progress = Math.min(1, easeOutCubic((frame - 739) / 45));
                const progX = 80 + progress * 704;
                return (
                  <line x1={80} y1={180} x2={progX} y2={180} stroke={TEAL} strokeWidth={6} strokeLinecap="round" />
                );
              })()}

              {/* Milestones */}
              {[
                { age: 'Age 30', label: 'Normal Base', x: 120, state: 'ok' },
                { age: 'Age 45', label: 'Mild High Drop', x: 320, state: 'ok' },
                { age: 'Age 60', label: 'Sloping Loss', x: 530, state: 'stop' },
                { age: 'Age 75+', label: 'Speech Muffled', x: 740, state: 'stop' },
              ].map((m) => {
                const isStop = m.state === 'stop';
                const col = isStop ? STOP : TEAL;
                const bg = isStop ? STOP_LIGHT : TEAL_LIGHT;
                return (
                  <g key={m.age}>
                    <circle cx={m.x} cy={180} r={20} fill={bg} stroke={col} strokeWidth={4} />
                    <circle cx={m.x} cy={180} r={8} fill={col} />
                    <text x={m.x} y={130} textAnchor="middle" fill={INK} fontSize={22} fontWeight={800}>
                      {m.age}
                    </text>
                    <text x={m.x} y={235} textAnchor="middle" fill={col} fontSize={16} fontWeight={700}>
                      {m.label}
                    </text>
                  </g>
                );
              })}
            </svg>

            {/* Bottom Insight Pill */}
            <div
              style={{
                marginTop: 'auto',
                backgroundColor: TEAL_LIGHT,
                border: `2px solid ${TEAL}`,
                borderRadius: 18,
                padding: '20px 24px',
                textAlign: 'center',
              }}
            >
              <div style={{ fontSize: 22, fontWeight: 900, color: TEAL }}>
                HIGH-FREQUENCY ROLL-OFF IS EXPECTED OVER TIME
              </div>
              <div style={{ fontSize: 16, color: INK_SOFT, marginTop: 4, fontWeight: 600 }}>
                Low frequencies (vowels & loudness) remain intact while high frequencies (clarity) decline.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 10: (27.29s - 30.16s · Frames 818 - 905) · Duration: 2.87s
          ARCHETYPE MG-05: PRECISION RETICLE — 4000 Hz ACOUSTIC NOISE NOTCH
          "Aur agar 4000 Hz par ek sharp notch ho..."
          ===================================================================== */}
      {frame >= 818 && frame < 905 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: 210,
              left: 64,
              width: 900,
              height: 1040,
              backgroundColor: '#FFFFFF',
              border: `3px solid ${INK}`,
              borderRadius: 24,
              boxShadow: '0 12px 36px rgba(38, 36, 48, 0.08)',
              padding: '24px 28px',
              boxSizing: 'border-box',
              display: 'flex',
              flexDirection: 'column',
            }}
          >
            {(() => {
              // Gradual Notch Animation
              // Frames 818 - 828: Baseline normal flat line (~18 dB)
              // Frames 828 - 868: Progressive dive from 18 dB down to 60 dB
              // Frames 868 - 905: Locked notch at 60 dB with pulsing reticle
              const diveProg = Math.min(1, Math.max(0, (frame - 828) / 38));
              const easeDive = 1 - Math.pow(1 - diveProg, 3);
              const curDb4k = 18 + easeDive * 42; // Dives from 18 dB to 60 dB
              const curDb8k = 20 + easeDive * 5;  // Rebounds from 20 dB to 25 dB
              const isForming = diveProg > 0 && diveProg < 1;
              const isLocked = diveProg >= 1;

              const notchPts = [
                { f: 250, db: 15 },
                { f: 500, db: 15 },
                { f: 1000, db: 15 },
                { f: 2000, db: 18 },
                { f: 4000, db: curDb4k },
                { f: 8000, db: curDb8k },
              ];
              const d = notchPts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${fx(p.f)} ${dy(p.db)}`).join(' ');
              const reticleR = isLocked
                ? 24 + Math.sin(frame * 0.3) * 6
                : 38 - easeDive * 14;

              return (
                <>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                    <div>
                      <div style={{ fontSize: 30, fontWeight: 900, color: isLocked ? STOP : INK }}>
                        4000 Hz ACOUSTIC NOISE NOTCH
                      </div>
                      <div style={{ fontSize: 16, color: INK_SOFT, fontWeight: 700, marginTop: 2 }}>
                        {isLocked
                          ? '🚨 Sharp -42 dB Acoustic Trauma Drop Detected'
                          : isForming
                          ? '⚠️ Progressive Notch Developing at 4 kHz...'
                          : 'Normal High-Frequency Baseline'}
                      </div>
                    </div>
                    <div
                      style={{
                        backgroundColor: isLocked ? STOP_LIGHT : '#FEF3C7',
                        color: isLocked ? STOP : '#B45309',
                        border: `2px solid ${isLocked ? STOP : '#F59E0B'}`,
                        padding: '8px 18px',
                        borderRadius: 20,
                        fontSize: 16,
                        fontWeight: 900,
                        letterSpacing: 0.5,
                      }}
                    >
                      {isLocked
                        ? '🚨 4 kHz NOTCH: 60 dB'
                        : isForming
                        ? `DIPPING: -${Math.round(curDb4k)} dB`
                        : 'MONITORING 4 kHz'}
                    </div>
                  </div>

                  <svg width={844} height={760} viewBox="80 300 890 760">
                    {OCTAVES.map((f) => (
                      <text
                        key={f}
                        x={fx(f)}
                        y={340}
                        textAnchor="middle"
                        fill={f === 4000 ? STOP : INK}
                        fontSize={f === 4000 ? 28 : 24}
                        fontWeight={900}
                      >
                        {f < 1000 ? `${f}Hz` : `${f / 1000}k`}
                      </text>
                    ))}

                    {[0, 20, 40, 60, 80, 100].map((db) => (
                      <g key={db}>
                        <line x1={150} y1={dy(db)} x2={930} y2={dy(db)} stroke={GRID} strokeWidth={1.5} />
                        <text x={138} y={dy(db) + 6} textAnchor="end" fill={INK_SOFT} fontSize={20} fontWeight={700}>
                          {db}
                        </text>
                      </g>
                    ))}

                    {/* Normal 20 dB Reference Boundary */}
                    <line x1={150} y1={dy(20)} x2={930} y2={dy(20)} stroke={OK} strokeWidth={2} strokeDasharray="6 4" opacity={0.6} />

                    {/* Connecting Notch Path */}
                    <path d={d} fill="none" stroke={isLocked ? STOP : '#D97706'} strokeWidth={8} strokeLinecap="round" />

                    {/* Frequency Nodes */}
                    {notchPts.map((p) => {
                      const is4k = p.f === 4000;
                      return (
                        <g key={p.f}>
                          <circle
                            cx={fx(p.f)}
                            cy={dy(p.db)}
                            r={is4k ? 16 : 11}
                            fill="#FFFFFF"
                            stroke={is4k ? STOP : (isLocked ? STOP : '#D97706')}
                            strokeWidth={4}
                          />
                          <circle
                            cx={fx(p.f)}
                            cy={dy(p.db)}
                            r={is4k ? 8 : 4}
                            fill={is4k ? STOP : (isLocked ? STOP : '#D97706')}
                          />
                        </g>
                      );
                    })}

                    {/* Dynamic Tracking Reticle & Crosshairs at 4000 Hz */}
                    <circle
                      cx={fx(4000)}
                      cy={dy(curDb4k)}
                      r={reticleR}
                      fill="none"
                      stroke={STOP}
                      strokeWidth={3}
                      strokeDasharray={isLocked ? "6 4" : "none"}
                    />
                    <line x1={fx(4000) - 35} y1={dy(curDb4k)} x2={fx(4000) + 35} y2={dy(curDb4k)} stroke={STOP} strokeWidth={2} />
                    <line x1={fx(4000)} y1={dy(curDb4k) - 35} x2={fx(4000)} y2={dy(curDb4k) + 35} stroke={STOP} strokeWidth={2} />

                    {/* Dynamic Depth Caliper Delta */}
                    {curDb4k > 22 && (
                      <g>
                        <line x1={fx(4000) + 38} y1={dy(18)} x2={fx(4000) + 54} y2={dy(18)} stroke={STOP} strokeWidth={2.5} />
                        <line x1={fx(4000) + 46} y1={dy(18)} x2={fx(4000) + 46} y2={dy(curDb4k)} stroke={STOP} strokeWidth={3} />
                        <line x1={fx(4000) + 38} y1={dy(curDb4k)} x2={fx(4000) + 54} y2={dy(curDb4k)} stroke={STOP} strokeWidth={2.5} />

                        <rect
                          x={fx(4000) + 62}
                          y={dy((18 + curDb4k) / 2) - 22}
                          width={170}
                          height={44}
                          rx={10}
                          fill={STOP}
                        />
                        <text
                          x={fx(4000) + 147}
                          y={dy((18 + curDb4k) / 2) + 7}
                          textAnchor="middle"
                          fill="#FFFFFF"
                          fontSize={18}
                          fontWeight={900}
                        >
                          {isLocked ? '42 dB DROP' : `-${Math.round(curDb4k - 18)} dB`}
                        </text>
                      </g>
                    )}

                    {/* 8 kHz Upward Rebound Marker */}
                    {diveProg >= 0.7 && (
                      <g>
                        <rect x={fx(8000) - 135} y={dy(curDb8k) + 24} width={135} height={32} rx={8} fill={TEAL_LIGHT} stroke={TEAL} strokeWidth={1.5} />
                        <text x={fx(8000) - 67} y={dy(curDb8k) + 46} textAnchor="middle" fill={TEAL} fontSize={14} fontWeight={900}>
                          ▲ 8 kHz RECOVERY
                        </text>
                      </g>
                    )}
                  </svg>

                  {/* Bottom Diagnostic Callout Box for Doomscroller */}
                  <div
                    style={{
                      marginTop: 'auto',
                      backgroundColor: '#F8F6F0',
                      border: `2px solid ${INK}`,
                      borderRadius: 16,
                      padding: '16px 20px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                    }}
                  >
                    <div>
                      <div style={{ fontSize: 18, fontWeight: 900, color: INK }}>
                        FORENSIC SIGNATURE: NOISE-INDUCED HEARING LOSS (NIHL)
                      </div>
                      <div style={{ fontSize: 14, color: INK_SOFT, marginTop: 2, fontWeight: 600 }}>
                        4 kHz hair cells suffer maximum acoustic pressure in ear canal resonance
                      </div>
                    </div>
                    <div
                      style={{
                        backgroundColor: INK,
                        color: '#FFFFFF',
                        padding: '8px 16px',
                        borderRadius: 12,
                        fontSize: 15,
                        fontWeight: 800,
                      }}
                    >
                      ACOUSTIC TRAUMA
                    </div>
                  </div>
                </>
              );
            })()}
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 11: (30.16s - 35.10s · Frames 905 - 1053) · Duration: 4.93s
          ARCHETYPE MG-01: ACOUSTIC TRAUMA FORENSIC PROOF
          "yeh loud headphones aur noise exposure ka direct proof hai."
          ===================================================================== */}
      {frame >= 905 && frame < 1053 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: 210,
              left: 64,
              width: 900,
              height: 1040,
              backgroundColor: '#FFFFFF',
              border: `3px solid ${INK}`,
              borderRadius: 24,
              boxShadow: '0 12px 36px rgba(38, 36, 48, 0.08)',
              padding: '36px',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              boxSizing: 'border-box',
            }}
          >
            <div style={{ backgroundColor: STOP_LIGHT, color: STOP, padding: '8px 20px', borderRadius: 20, fontSize: 18, fontWeight: 800 }}>
              FORENSIC ETIOLOGY
            </div>
            <div style={{ fontSize: 38, fontWeight: 900, color: INK, marginTop: 16, textAlign: 'center' }}>
              ACOUSTIC TRAUMA PROOF
            </div>

            <svg width={500} height={360} viewBox="0 0 500 360" style={{ marginTop: 24 }}>
              <path d="M 120 180 A 130 130 0 0 1 380 180" fill="none" stroke={INK} strokeWidth={16} strokeLinecap="round" />
              <rect x={100} y={150} width={40} height={90} rx={16} fill={STOP} stroke={INK} strokeWidth={4} />
              <rect x={360} y={150} width={40} height={90} rx={16} fill={STOP} stroke={INK} strokeWidth={4} />

              {(() => {
                const blast = ((frame - 905) * 8) % 80;
                return (
                  <g>
                    <path d={`M ${160 + blast} 160 Q ${170 + blast} 195 ${160 + blast} 230`} fill="none" stroke={STOP} strokeWidth={5} opacity={1 - blast / 80} />
                    <path d={`M ${340 - blast} 160 Q ${330 - blast} 195 ${340 - blast} 230`} fill="none" stroke={STOP} strokeWidth={5} opacity={1 - blast / 80} />
                  </g>
                );
              })()}

              <circle cx={250} cy={195} r={45} fill={STOP} />
              <text x={250} y={203} textAnchor="middle" fill="#FFFFFF" fontSize={26} fontWeight={900}>
                &gt;95dB
              </text>
            </svg>

            {/* Direct Causation Flowchart for Silent Viewers */}
            <div
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 12,
                marginTop: 10,
              }}
            >
              <div style={{ backgroundColor: '#FDF0F0', border: `2px solid ${STOP}`, borderRadius: 12, padding: '10px 14px', textAlign: 'center' }}>
                <div style={{ fontSize: 13, fontWeight: 800, color: STOP }}>LOUD MUSIC</div>
                <div style={{ fontSize: 16, fontWeight: 900, color: INK }}>&gt; 85 dB SPL</div>
              </div>
              <span style={{ fontSize: 22, fontWeight: 900, color: STOP }}>➔</span>
              <div style={{ backgroundColor: '#FDF0F0', border: `2px solid ${STOP}`, borderRadius: 12, padding: '10px 14px', textAlign: 'center' }}>
                <div style={{ fontSize: 13, fontWeight: 800, color: STOP }}>INNER EAR DAMAGE</div>
                <div style={{ fontSize: 16, fontWeight: 900, color: INK }}>4 kHz Hair Cells</div>
              </div>
              <span style={{ fontSize: 22, fontWeight: 900, color: STOP }}>➔</span>
              <div style={{ backgroundColor: STOP, borderRadius: 12, padding: '10px 14px', textAlign: 'center' }}>
                <div style={{ fontSize: 13, fontWeight: 800, color: '#FFFFFF' }}>AUDIOGRAM</div>
                <div style={{ fontSize: 16, fontWeight: 900, color: '#FFFFFF' }}>Sharp 4k Notch!</div>
              </div>
            </div>

            <div
              style={{
                marginTop: 'auto',
                width: '100%',
                backgroundColor: STOP_LIGHT,
                border: `2px solid ${STOP}`,
                borderRadius: 20,
                padding: '24px',
                textAlign: 'center',
              }}
            >
              <div style={{ fontSize: 26, fontWeight: 900, color: STOP }}>
                🎧 LOUD HEADPHONES & NOISE EXPOSURE
              </div>
              <div style={{ fontSize: 18, color: INK_SOFT, marginTop: 6 }}>
                4000 Hz cochlear basal turn ki hair cells sound energy se sabse pehle damage hoti hain.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 12: (35.10s - 40.73s · Frames 1053 - 1222) · Duration: 5.63s (169 frames)
          PROFESSIONAL HOST CLINICIAN REGISTER [CLIP 2]
          "Audiogram tumhari hearing health ka blueprint hai, jo kabhi jhooth nahi bolta."
          Master audio continuous, sub-clip muted, spot-on lip sync
          ===================================================================== */}
      {isHostClip2 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H, backgroundColor: PAPER }}>
          <Sequence from={1053} durationInFrames={169}>
            <OffthreadVideo
              src={staticFile('clips/audiogram4_clip2_synced.mp4')}
              style={{ width: W, height: H, objectFit: 'cover' }}
              muted
            />
          </Sequence>

          {/* Lower Blueprint Authority Card across Chest Safe Zone */}
          <div
            style={{
              position: 'absolute',
              top: 1300,
              left: 64,
              right: 116,
              backgroundColor: 'rgba(255, 255, 255, 0.96)',
              border: `3px solid ${INK}`,
              borderRadius: 20,
              padding: '22px 28px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              boxShadow: '0 12px 32px rgba(32, 37, 43, 0.18)',
              zIndex: 9000,
            }}
          >
            <div>
              <div style={{ fontSize: 14, fontWeight: 800, color: TEAL, letterSpacing: '1.5px', textTransform: 'uppercase' }}>
                05 / CLINICAL EVIDENCE
              </div>
              <div style={{ fontSize: 26, fontWeight: 900, color: INK, marginTop: 4 }}>
                KABHI JHOOTH NAHI BOLTA
              </div>
              <div style={{ fontSize: 16, color: INK_SOFT, marginTop: 4, fontWeight: 600 }}>
                Hearing Health Ka 100% Objective Blueprint
              </div>
            </div>
            <div
              style={{
                backgroundColor: TEAL_LIGHT,
                border: `2px solid ${TEAL}`,
                borderRadius: 14,
                padding: '10px 18px',
                fontSize: 16,
                fontWeight: 800,
                color: TEAL,
              }}
            >
              OBJECTIVE BIOMARKER
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 14: (40.76s - 44.50s · Frames 1222 - 1335) · Duration: 3.74s
          ARCHETYPE MG-03: THE PART 5 MYSTERY (Two Identical Audiograms)
          "Next part mein: do logon ka graph bilkul same hone par bhi..."
          Eliminates static/empty look with active dual-laser scanning,
          high-contrast clinical twin grids, and paradox visualizer!
          ===================================================================== */}
      {frame >= 1222 && frame < 1335 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: 210,
              left: 64,
              width: 900,
              height: 1040,
              backgroundColor: '#FFFFFF',
              border: `3px solid ${INK}`,
              borderRadius: 24,
              boxShadow: '0 12px 36px rgba(38, 36, 48, 0.08)',
              padding: '24px 28px',
              display: 'flex',
              flexDirection: 'column',
              boxSizing: 'border-box',
            }}
          >
            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ backgroundColor: TEAL_LIGHT, color: TEAL, border: `2px solid ${TEAL}`, padding: '6px 18px', borderRadius: 20, fontSize: 16, fontWeight: 900 }}>
                ⚡ COMING IN PART 5 · CLINICAL MYSTERY
              </div>
              <div style={{ backgroundColor: '#F3F4F6', color: INK, padding: '6px 14px', borderRadius: 14, fontSize: 15, fontWeight: 800 }}>
                AUDIOGRAM PARADOX
              </div>
            </div>

            <div style={{ fontSize: 34, fontWeight: 900, color: INK, marginTop: 10 }}>
              TWO 100% IDENTICAL AUDIOGRAMS
            </div>
            <div style={{ fontSize: 16, color: INK_SOFT, fontWeight: 700, marginTop: 2 }}>
              Both patients have identical 40 dB moderate loss... yet hear completely differently!
            </div>

            {/* Side-by-Side Twin Audiograms with Synchronous Laser Sweep */}
            {(() => {
              const sweepX = 40 + ((frame - 1222) * 4) % 310;
              const twinPts = [
                { f: 250, x: 50, y: 70, db: 15 },
                { f: 500, x: 105, y: 95, db: 20 },
                { f: 1000, x: 165, y: 135, db: 25 },
                { f: 2000, x: 225, y: 190, db: 35 },
                { f: 4000, x: 285, y: 235, db: 42 },
                { f: 8000, x: 340, y: 255, db: 45 },
              ];
              const twinD = twinPts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');

              return (
                <div style={{ display: 'flex', gap: 20, marginTop: 14, position: 'relative' }}>
                  {/* Patient A Card */}
                  <div
                    style={{
                      flex: 1,
                      border: `2px solid #2E9E6B`,
                      borderRadius: 20,
                      padding: '16px',
                      backgroundColor: '#F0FDF4',
                      boxShadow: '0 6px 20px rgba(46, 158, 107, 0.08)',
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontSize: 20, fontWeight: 900, color: INK }}>👤 PATIENT A</span>
                      <span style={{ backgroundColor: '#DCFCE7', color: '#166534', padding: '3px 10px', borderRadius: 10, fontSize: 13, fontWeight: 800 }}>
                        40 dB LOSS
                      </span>
                    </div>

                    <svg width={380} height={310} viewBox="0 0 380 310" style={{ marginTop: 10, backgroundColor: '#FFFFFF', borderRadius: 12, border: `1px solid ${GRID}` }}>
                      {/* Freq text */}
                      {['250', '500', '1k', '2k', '4k', '8k'].map((txt, i) => (
                        <text key={txt} x={50 + i * 58} y={24} textAnchor="middle" fill={INK_SOFT} fontSize={13} fontWeight={800}>
                          {txt}
                        </text>
                      ))}
                      {/* dB grid lines */}
                      {[0, 20, 40, 60, 80].map((db, i) => (
                        <g key={db}>
                          <line x1={30} y1={45 + i * 55} x2={360} y2={45 + i * 55} stroke={db === 20 ? OK : GRID} strokeWidth={db === 20 ? 1.5 : 1} strokeDasharray={db === 20 ? "4 3" : "none"} />
                          <text x={24} y={50 + i * 55} textAnchor="end" fill={INK_SOFT} fontSize={12} fontWeight={700}>{db}</text>
                        </g>
                      ))}
                      {/* Threshold Path */}
                      <path d={twinD} fill="none" stroke="#2E9E6B" strokeWidth={5} strokeLinecap="round" />
                      {twinPts.map((p) => (
                        <circle key={p.f} cx={p.x} cy={p.y} r={7} fill="#FFFFFF" stroke="#2E9E6B" strokeWidth={3.5} />
                      ))}
                      {/* Active Laser Line */}
                      <line x1={sweepX} y1={35} x2={sweepX} y2={290} stroke="#2E9E6B" strokeWidth={3} opacity={0.8} />
                      <line x1={sweepX} y1={35} x2={sweepX} y2={290} stroke="#A7F3D0" strokeWidth={8} opacity={0.3} />
                    </svg>
                    <div style={{ marginTop: 8, fontSize: 15, fontWeight: 800, color: '#166534', textAlign: 'center' }}>
                      Hearing Threshold: 40 dB HL
                    </div>
                  </div>

                  {/* Patient B Card */}
                  <div
                    style={{
                      flex: 1,
                      border: `2px solid #E06830`,
                      borderRadius: 20,
                      padding: '16px',
                      backgroundColor: '#FFF7ED',
                      boxShadow: '0 6px 20px rgba(224, 104, 48, 0.08)',
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontSize: 20, fontWeight: 900, color: INK }}>👤 PATIENT B</span>
                      <span style={{ backgroundColor: '#FFEDD5', color: '#9A3412', padding: '3px 10px', borderRadius: 10, fontSize: 13, fontWeight: 800 }}>
                        40 dB LOSS
                      </span>
                    </div>

                    <svg width={380} height={310} viewBox="0 0 380 310" style={{ marginTop: 10, backgroundColor: '#FFFFFF', borderRadius: 12, border: `1px solid ${GRID}` }}>
                      {/* Freq text */}
                      {['250', '500', '1k', '2k', '4k', '8k'].map((txt, i) => (
                        <text key={txt} x={50 + i * 58} y={24} textAnchor="middle" fill={INK_SOFT} fontSize={13} fontWeight={800}>
                          {txt}
                        </text>
                      ))}
                      {/* dB grid lines */}
                      {[0, 20, 40, 60, 80].map((db, i) => (
                        <g key={db}>
                          <line x1={30} y1={45 + i * 55} x2={360} y2={45 + i * 55} stroke={db === 20 ? OK : GRID} strokeWidth={db === 20 ? 1.5 : 1} strokeDasharray={db === 20 ? "4 3" : "none"} />
                          <text x={24} y={50 + i * 55} textAnchor="end" fill={INK_SOFT} fontSize={12} fontWeight={700}>{db}</text>
                        </g>
                      ))}
                      {/* Threshold Path */}
                      <path d={twinD} fill="none" stroke="#E06830" strokeWidth={5} strokeLinecap="round" />
                      {twinPts.map((p) => (
                        <circle key={p.f} cx={p.x} cy={p.y} r={7} fill="#FFFFFF" stroke="#E06830" strokeWidth={3.5} />
                      ))}
                      {/* Active Laser Line */}
                      <line x1={sweepX} y1={35} x2={sweepX} y2={290} stroke="#E06830" strokeWidth={3} opacity={0.8} />
                      <line x1={sweepX} y1={35} x2={sweepX} y2={290} stroke="#FED7AA" strokeWidth={8} opacity={0.3} />
                    </svg>
                    <div style={{ marginTop: 8, fontSize: 15, fontWeight: 800, color: '#9A3412', textAlign: 'center' }}>
                      Hearing Threshold: 40 dB HL
                    </div>
                  </div>

                  {/* Central 100% Identical Link Badge */}
                  <div
                    style={{
                      position: 'absolute',
                      top: '50%',
                      left: '50%',
                      transform: 'translate(-50%, -50%)',
                      backgroundColor: INK,
                      color: '#FFFFFF',
                      border: `2px solid #F7C948`,
                      padding: '8px 18px',
                      borderRadius: 20,
                      fontSize: 14,
                      fontWeight: 900,
                      boxShadow: '0 8px 24px rgba(0,0,0,0.25)',
                      zIndex: 20,
                      whiteSpace: 'nowrap',
                    }}
                  >
                    🔒 100% IDENTICAL GRAPHS
                  </div>
                </div>
              );
            })()}

            {/* Middle Diagnostic Takeaway Bar (Eliminates dead empty space) */}
            <div
              style={{
                backgroundColor: '#F8F6F0',
                border: `2px solid ${INK}`,
                borderRadius: 16,
                padding: '12px 20px',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                margin: '14px 0',
              }}
            >
              <div>
                <div style={{ fontSize: 16, fontWeight: 900, color: INK }}>THRESHOLD DELTA = 0.0 dB HL</div>
                <div style={{ fontSize: 13, color: INK_SOFT, fontWeight: 700, marginTop: 2 }}>Dono kaano ko sound detect karne ke liye exact same volume chahiye</div>
              </div>
              <div style={{ backgroundColor: TEAL, color: '#FFFFFF', padding: '6px 14px', borderRadius: 12, fontSize: 13, fontWeight: 800 }}>
                100% IDENTICAL
              </div>
            </div>

            {/* Bottom Clinical Paradox Bar: High contrast, mute-friendly storytelling */}
            <div
              style={{
                marginTop: 'auto',
                backgroundColor: INK,
                borderRadius: 20,
                padding: '20px 24px',
                boxShadow: '0 12px 32px rgba(32, 37, 43, 0.2)',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 16, fontWeight: 900, color: '#F7C948', letterSpacing: 1 }}>
                  ❓ THE MYSTERY
                </span>
                <span style={{ fontSize: 14, color: PAPER, opacity: 0.8, fontWeight: 700 }}>
                  PART 5 TEASER
                </span>
              </div>
              <div style={{ fontSize: 24, fontWeight: 900, color: '#FFFFFF', marginTop: 6 }}>
                Graph bilkul same... par sunai alag kyun?
              </div>

              <div style={{ display: 'flex', gap: 16, marginTop: 14 }}>
                <div style={{ flex: 1, backgroundColor: 'rgba(46, 158, 107, 0.2)', border: '1px solid #2E9E6B', borderRadius: 12, padding: '10px 14px' }}>
                  <div style={{ color: '#A7F3D0', fontSize: 13, fontWeight: 800 }}>PATIENT A EXPERIENCE:</div>
                  <div style={{ color: '#FFFFFF', fontSize: 15, fontWeight: 700, marginTop: 2 }}>
                    "Har word crystal clear samajh aata hai!"
                  </div>
                </div>
                <div style={{ flex: 1, backgroundColor: 'rgba(224, 104, 48, 0.2)', border: '1px solid #E06830', borderRadius: 12, padding: '10px 14px' }}>
                  <div style={{ color: '#FED7AA', fontSize: 13, fontWeight: 800 }}>PATIENT B EXPERIENCE:</div>
                  <div style={{ color: '#FFFFFF', fontSize: 15, fontWeight: 700, marginTop: 2 }}>
                    "Awaaz aati hai, par words jumbled lagte hain!"
                  </div>
                </div>
              </div>

              <div style={{ marginTop: 12, fontSize: 14, color: '#E2E8F0', textAlign: 'center', fontWeight: 600 }}>
                👂 Kaan sirf microphone hai · Asli speech decoding Brain karta hai
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SCENE 15: (44.50s - 48.64s · Frames 1335 - 1459) · Duration: 4.14s
          ARCHETYPE MG-06: BRAIN SPEECH DISCRIMINATION TEASER & CLINIC CTA
          "Clarity alag kyun hoti hai? Ispe baat karenge."
          Dynamic rolling counters (0 -> 92% vs 0 -> 48%), concrete speech
          waveform demonstration ("CHAMPION" test), and pulsing Follow CTA!
          ===================================================================== */}
      {frame >= 1335 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <div
            style={{
              position: 'absolute',
              top: 210,
              left: 64,
              width: 900,
              height: 1040,
              backgroundColor: '#FFFFFF',
              border: `3px solid ${INK}`,
              borderRadius: 24,
              boxShadow: '0 12px 36px rgba(38, 36, 48, 0.08)',
              padding: '24px 28px',
              display: 'flex',
              flexDirection: 'column',
              boxSizing: 'border-box',
            }}
          >
            {(() => {
              // Dynamic Rolling Counters
              const rollProg = Math.min(1, Math.max(0, (frame - 1335) / 26));
              const easeRoll = 1 - Math.pow(1 - rollProg, 3);
              const scoreA = Math.round(easeRoll * 92);
              const scoreB = Math.round(easeRoll * 48);
              const ctaPulse = 1 + Math.sin(frame * 0.15) * 0.04;

              return (
                <>
                  {/* Header */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ backgroundColor: TEAL_LIGHT, color: TEAL, border: `2px solid ${TEAL}`, padding: '6px 18px', borderRadius: 20, fontSize: 16, fontWeight: 900 }}>
                      🔬 PART 5 DEEP DIVE · CLINICAL REVELATION
                    </div>
                    <div style={{ backgroundColor: '#F3F4F6', color: INK, padding: '6px 14px', borderRadius: 14, fontSize: 15, fontWeight: 800 }}>
                      SDS SCORE
                    </div>
                  </div>

                  <div style={{ fontSize: 34, fontWeight: 900, color: INK, marginTop: 10 }}>
                    THE BRAIN SPEECH CLARITY GAP
                  </div>
                  <div style={{ fontSize: 16, color: INK_SOFT, fontWeight: 700, marginTop: 2 }}>
                    Speech Discrimination Score (SDS) · Word Recognition in Quiet
                  </div>

                  {/* Twin Brain Cards with Dynamic Rolling Counters & Concrete Waveforms */}
                  <div style={{ display: 'flex', gap: 20, marginTop: 14 }}>
                    {/* Patient A Brain */}
                    <div
                      style={{
                        flex: 1,
                        backgroundColor: '#F0FDF4',
                        border: `3px solid #2E9E6B`,
                        borderRadius: 20,
                        padding: '18px 16px',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        boxShadow: '0 8px 24px rgba(46, 158, 107, 0.1)',
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
                        <span style={{ fontSize: 18, fontWeight: 900, color: INK }}>🧠 PATIENT A</span>
                        <span style={{ backgroundColor: '#DCFCE7', color: '#166534', padding: '3px 10px', borderRadius: 10, fontSize: 13, fontWeight: 800 }}>
                          HEALTHY CORTEX
                        </span>
                      </div>

                      {/* Animated Circular Ring Gauge */}
                      <svg width={130} height={130} viewBox="0 0 130 130" style={{ margin: '10px 0 4px 0' }}>
                        <circle cx={65} cy={65} r={52} fill="none" stroke="#DCFCE7" strokeWidth={11} />
                        <circle
                          cx={65}
                          cy={65}
                          r={52}
                          fill="none"
                          stroke="#166534"
                          strokeWidth={11}
                          strokeDasharray={326.7}
                          strokeDashoffset={326.7 * (1 - scoreA / 100)}
                          strokeLinecap="round"
                          transform="rotate(-90 65 65)"
                        />
                        <text x={65} y={78} textAnchor="middle" fill="#166534" fontSize={38} fontWeight={950}>
                          {scoreA}%
                        </text>
                      </svg>
                      <div style={{ fontSize: 15, fontWeight: 900, color: '#166534', textAlign: 'center' }}>
                        EXCELLENT WORD CLARITY
                      </div>

                      {/* Concrete Word Test Visualizer */}
                      <div style={{ backgroundColor: '#FFFFFF', borderRadius: 14, padding: '12px 14px', border: '1.5px solid #BBF7D0', marginTop: 'auto', width: '100%', boxSizing: 'border-box' }}>
                        <div style={{ fontSize: 12, fontWeight: 800, color: INK_SOFT }}>CLINICAL WORD TEST:</div>
                        <div style={{ fontSize: 22, fontWeight: 900, color: '#166534', marginTop: 2, letterSpacing: 0.5 }}>
                          HEARD: "CHAMPION"
                        </div>
                        {/* Crisp Waveform */}
                        <svg width={330} height={42} viewBox="0 0 330 42" style={{ marginTop: 4 }}>
                          <path
                            d="M 10 21 Q 30 2, 50 21 T 90 21 T 130 6 T 170 36 T 210 10 T 250 32 T 290 21 T 320 21"
                            fill="none"
                            stroke="#2E9E6B"
                            strokeWidth={3.5}
                            strokeLinecap="round"
                          />
                        </svg>
                        <div style={{ fontSize: 13, fontWeight: 800, color: '#166534', marginTop: 4 }}>
                          ✓ 10/10 Consonants Decoded Accurately
                        </div>
                      </div>
                    </div>

                    {/* Patient B Brain */}
                    <div
                      style={{
                        flex: 1,
                        backgroundColor: '#FEF2F2',
                        border: `3px solid #E06830`,
                        borderRadius: 20,
                        padding: '18px 16px',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        boxShadow: '0 8px 24px rgba(224, 104, 48, 0.1)',
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
                        <span style={{ fontSize: 18, fontWeight: 900, color: INK }}>🧠 PATIENT B</span>
                        <span style={{ backgroundColor: '#FEE2E2', color: '#991B1B', padding: '3px 10px', borderRadius: 10, fontSize: 13, fontWeight: 800 }}>
                          CORTICAL DISTORTION
                        </span>
                      </div>

                      {/* Animated Circular Ring Gauge */}
                      <svg width={130} height={130} viewBox="0 0 130 130" style={{ margin: '10px 0 4px 0' }}>
                        <circle cx={65} cy={65} r={52} fill="none" stroke="#FEE2E2" strokeWidth={11} />
                        <circle
                          cx={65}
                          cy={65}
                          r={52}
                          fill="none"
                          stroke="#DC2626"
                          strokeWidth={11}
                          strokeDasharray={326.7}
                          strokeDashoffset={326.7 * (1 - scoreB / 100)}
                          strokeLinecap="round"
                          transform="rotate(-90 65 65)"
                        />
                        <text x={65} y={78} textAnchor="middle" fill="#DC2626" fontSize={38} fontWeight={950}>
                          {scoreB}%
                        </text>
                      </svg>
                      <div style={{ fontSize: 15, fontWeight: 900, color: '#DC2626', textAlign: 'center' }}>
                        WORDS MUFFLED & BLURRED
                      </div>

                      {/* Concrete Word Test Visualizer */}
                      <div style={{ backgroundColor: '#FFFFFF', borderRadius: 14, padding: '12px 14px', border: '1.5px solid #FECACA', marginTop: 'auto', width: '100%', boxSizing: 'border-box' }}>
                        <div style={{ fontSize: 12, fontWeight: 800, color: INK_SOFT }}>CLINICAL WORD TEST:</div>
                        <div style={{ fontSize: 22, fontWeight: 900, color: '#DC2626', marginTop: 2, letterSpacing: 0.5 }}>
                          HEARD: "CH... M... ON"
                        </div>
                        {/* Distorted / Flattened Waveform */}
                        <svg width={330} height={42} viewBox="0 0 330 42" style={{ marginTop: 4 }}>
                          <path
                            d="M 10 21 Q 35 17, 60 21 T 110 21 T 160 25 T 210 18 T 260 21 T 310 21 T 320 21"
                            fill="none"
                            stroke="#DC2626"
                            strokeWidth={3.5}
                            strokeLinecap="round"
                            strokeDasharray="6 4"
                          />
                        </svg>
                        <div style={{ fontSize: 13, fontWeight: 800, color: '#DC2626', marginTop: 4 }}>
                          ✗ 5/10 Consonants Lost in Brain Processing
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Middle Clinical Takeaway Bar (Eliminates dead empty space) */}
                  <div
                    style={{
                      backgroundColor: '#F8F6F0',
                      border: `2px solid ${INK}`,
                      borderRadius: 16,
                      padding: '16px 20px',
                      display: 'flex',
                      justifyContent: 'space-around',
                      alignItems: 'center',
                      margin: '16px 0',
                    }}
                  >
                    <div style={{ textAlign: 'center', flex: 1 }}>
                      <div style={{ fontSize: 13, fontWeight: 800, color: INK_SOFT }}>AUDIOGRAM MEASURES:</div>
                      <div style={{ fontSize: 18, fontWeight: 900, color: INK, marginTop: 2 }}>👂 VOLUME (Did you hear the beep?)</div>
                    </div>
                    <div style={{ width: 2, height: 40, backgroundColor: GRID }} />
                    <div style={{ textAlign: 'center', flex: 1 }}>
                      <div style={{ fontSize: 13, fontWeight: 800, color: INK_SOFT }}>BRAIN SDS MEASURES:</div>
                      <div style={{ fontSize: 18, fontWeight: 900, color: TEAL, marginTop: 2 }}>🧠 CLARITY (Did you understand the word?)</div>
                    </div>
                  </div>

                  {/* High-Energy Follow CTA Card at Bottom */}
                  <div
                    style={{
                      marginTop: 'auto',
                      backgroundColor: INK,
                      borderRadius: 20,
                      padding: '18px 24px',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      boxShadow: '0 12px 32px rgba(32, 37, 43, 0.25)',
                      border: `2px solid ${TEAL}`,
                    }}
                  >
                    <div>
                      <div style={{ color: '#FFFFFF', fontSize: 24, fontWeight: 900 }}>
                        PART 5 DECODED SOON 🔔
                      </div>
                      <div style={{ color: PAPER, opacity: 0.85, fontSize: 15, marginTop: 2, fontWeight: 600 }}>
                        Follow to understand why the brain decodes speech differently
                      </div>
                    </div>
                    <div
                      style={{
                        transform: `scale(${ctaPulse})`,
                        backgroundColor: TEAL,
                        color: '#FFFFFF',
                        padding: '12px 24px',
                        borderRadius: 14,
                        fontSize: 18,
                        fontWeight: 900,
                        boxShadow: '0 4px 16px rgba(45, 140, 133, 0.4)',
                      }}
                    >
                      FOLLOW →
                    </div>
                  </div>
                </>
              );
            })()}
          </div>
        </div>
      )}

      {/* =====================================================================
          GLOBAL CAPTIONS OVERLAY (Fixed safe zone plate at bottom)
          Positioned safely at bottom: 295px to clear Instagram's bottom 280px UI!
          ===================================================================== */}
      {activeCue && (
        <div
          style={{
            position: 'absolute',
            bottom: 295,
            left: 64,
            right: 116,
            display: 'flex',
            justifyContent: 'center',
            zIndex: 9500,
          }}
        >
          <div
            style={{
              backgroundColor: 'rgba(32, 37, 43, 0.95)',
              backdropFilter: 'blur(12px)',
              padding: '18px 36px',
              borderRadius: 20,
              maxWidth: 920,
              textAlign: 'center',
              boxShadow: '0 16px 40px rgba(0, 0, 0, 0.3)',
              border: '2px solid rgba(255, 255, 255, 0.16)',
            }}
          >
            {activeCue.hl && activeCue.text.toLowerCase().includes(activeCue.hl.toLowerCase()) ? (
              <span
                style={{
                  fontSize: 34,
                  fontWeight: 800,
                  color: '#FFFFFF',
                  lineHeight: 1.35,
                  letterSpacing: '0.2px',
                }}
              >
                {(() => {
                  const idx = activeCue.text.toLowerCase().indexOf(activeCue.hl.toLowerCase());
                  const before = activeCue.text.slice(0, idx);
                  const match = activeCue.text.slice(idx, idx + activeCue.hl.length);
                  const after = activeCue.text.slice(idx + activeCue.hl.length);
                  return (
                    <>
                      {before}
                      <span style={{ color: '#F7C948', fontWeight: 900 }}>
                        {match}
                      </span>
                      {after}
                    </>
                  );
                })()}
              </span>
            ) : (
              <span
                style={{
                  fontSize: 34,
                  fontWeight: 800,
                  color: '#FFFFFF',
                  lineHeight: 1.35,
                  letterSpacing: '0.2px',
                }}
              >
                {activeCue.text}
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
