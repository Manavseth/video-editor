import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { FAITH_THEME } from '../theme_faithvsfact';

interface SubtitleRun {
  text: string;
  isGold?: boolean;
}

interface Props {
  lines: SubtitleRun[][];
  delay?: number;
}

export const FaithSubtitles: React.FC<Props> = ({ lines, delay = 0 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const entrance = spring({
    frame: frame - delay,
    fps,
    config: { damping: 15, stiffness: 140, mass: 0.5 },
  });

  const opacity = interpolate(frame - delay, [0, 6], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  if (frame < delay) return null;

  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        top: FAITH_THEME.safeArea.captionY,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        opacity,
        transform: `translateY(${interpolate(entrance, [0, 1], [15, 0])}px)`,
        padding: '0 60px',
        pointerEvents: 'none',
      }}
    >
      {/* Subtle backdrop pill to ensure 100% legibility */}
      <div
        style={{
          backgroundColor: 'rgba(5, 8, 17, 0.75)',
          backdropFilter: 'blur(8px)',
          border: '1px solid rgba(255, 200, 59, 0.25)',
          borderRadius: 12,
          padding: '16px 36px',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 8,
          boxShadow: '0 8px 30px rgba(0, 0, 0, 0.7)',
        }}
      >
        {lines.map((lineRuns, lineIdx) => (
          <div
            key={lineIdx}
            style={{
              fontFamily: FAITH_THEME.fonts.serif,
              fontSize: 38,
              fontWeight: 700,
              textTransform: 'uppercase',
              letterSpacing: '0.09em',
              textAlign: 'center',
              lineHeight: 1.25,
              textShadow: '0 2px 10px rgba(0,0,0,0.9), 0 0 5px rgba(0,0,0,0.8)',
            }}
          >
            {lineRuns.map((chunk, chunkIdx) => (
              <span
                key={chunkIdx}
                style={{
                  color: chunk.isGold
                    ? FAITH_THEME.colors.gold
                    : FAITH_THEME.colors.white,
                  margin: '0 4px',
                  display: 'inline-block',
                }}
              >
                {chunk.text}
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};
