import React from 'react';
import { THEME } from '../theme';

interface AcousticWaveProps {
  x?: number;
  y?: number;
  width?: number;
  amplitude?: number; // peak height in px
  frequency?: number; // cycles across width
  phase?: number; // radians offset
  color?: string;
  strokeWidth?: number;
  distortion?: number; // 0 (pure sine) to 1 (clipped / harmonic crowding)
  taper?: 'none' | 'left' | 'right' | 'both';
  opacity?: number;
  glow?: boolean;
}

export const AcousticWave: React.FC<AcousticWaveProps> = ({
  x = 0,
  y = 0,
  width = 600,
  amplitude = 40,
  frequency = 4,
  phase = 0,
  color = THEME.colors.ivory,
  strokeWidth = 3,
  distortion = 0,
  taper = 'none',
  opacity = 1,
  glow = false,
}) => {
  const points: { x: number; y: number }[] = [];
  const steps = 140;

  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const px = t * width;

    // Envelope multiplier
    let env = 1;
    if (taper === 'left') env = Math.sin((t * Math.PI) / 2);
    else if (taper === 'right') env = Math.cos((t * Math.PI) / 2);
    else if (taper === 'both') env = Math.sin(t * Math.PI);

    // Fundamental sinusoid
    const theta = t * frequency * 2 * Math.PI + phase;
    let wave = Math.sin(theta);

    // Add harmonic distortion if requested (Scene 3 & 4)
    if (distortion > 0) {
      const harm3 = 0.35 * Math.sin(3 * theta);
      const harm5 = 0.15 * Math.sin(5 * theta);
      wave = (wave + (harm3 + harm5) * distortion) / (1 + 0.5 * distortion);
      // Soft saturation clip
      if (Math.abs(wave) > 0.85) {
        wave = Math.sign(wave) * (0.85 + 0.15 * Math.tanh((Math.abs(wave) - 0.85) * 2));
      }
    }

    const py = wave * amplitude * env;
    points.push({ x: px, y: py });
  }

  let d = `M ${points[0].x} ${points[0].y}`;
  for (let i = 1; i < points.length; i++) {
    d += ` L ${points[i].x} ${points[i].y}`;
  }

  return (
    <g transform={`translate(${x}, ${y})`} opacity={opacity}>
      {glow && (
        <path
          d={d}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth * 3}
          strokeOpacity={0.25}
          strokeLinecap="round"
        />
      )}
      <path
        d={d}
        fill="none"
        stroke={color}
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </g>
  );
};
