import React from 'react';
import { THEME } from '../theme';

interface BrainSilhouetteProps {
  x?: number;
  y?: number;
  scale?: number;
  opacity?: number;
  signalArrivalProgress?: number; // 0 to 1
  pathwayActivation?: number; // 0 to 1
  waveformResolved?: number; // 0 to 1
}

export const BrainSilhouette: React.FC<BrainSilhouetteProps> = ({
  x = 540,
  y = 880,
  scale = 1,
  opacity = 1,
  signalArrivalProgress = 1,
  pathwayActivation = 1,
  waveformResolved = 1,
}) => {
  return (
    <g transform={`translate(${x}, ${y}) scale(${scale})`} opacity={opacity}>
      <defs>
        <radialGradient id="brain-glow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#1E293B" stopOpacity="0.7" />
          <stop offset="70%" stopColor="#0B132B" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#020617" stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* 1. Lateral Hemisphere Outline (Cerebrum, Temporal Lobe, Cerebellum, Brainstem) */}
      <path
        d="M -30 220 C -40 180, -50 120, -50 60 C -120 70, -180 30, -220 -30 C -260 -100, -240 -200, -160 -260 C -80 -320, 80 -330, 180 -270 C 260 -210, 280 -100, 260 0 C 240 80, 190 140, 110 160 C 120 180, 140 210, 130 250 C 110 280, 60 280, 30 260 C 10 280, -20 280, -30 220 Z"
        fill="url(#brain-glow)"
        stroke={THEME.colors.ivory}
        strokeWidth="3"
        strokeOpacity="0.35"
        strokeLinejoin="round"
      />

      {/* Internal Sulcal Folds (Soft diagrammatic lines) */}
      <path
        d="M -140 -160 C -90 -120, 20 -150, 110 -180"
        fill="none"
        stroke={THEME.colors.line}
        strokeWidth="2"
      />
      <path
        d="M -170 -60 C -110 -70, -20 -90, 80 -60 C 150 -40, 190 20, 170 80"
        fill="none"
        stroke={THEME.colors.line}
        strokeWidth="2"
      />
      {/* Sylvian Fissure dividing frontal/parietal from temporal lobe */}
      <path
        d="M -100 20 C -30 20, 40 -10, 120 10"
        fill="none"
        stroke={THEME.colors.ivoryMuted}
        strokeWidth="2.5"
        strokeOpacity="0.5"
      />

      {/* 2. Auditory Cortex Region (Superior Temporal Gyrus - Heschl's Gyrus) */}
      <g transform="translate(10, 30)">
        <ellipse
          cx="0"
          cy="0"
          rx="55"
          ry="32"
          fill="rgba(34, 211, 238, 0.12)"
          stroke={THEME.colors.cyan}
          strokeWidth="2.5"
          strokeDasharray="4 4"
        />
        <circle
          cx="0"
          cy="0"
          r={signalArrivalProgress > 0.5 ? 8 : 4}
          fill={THEME.colors.cyanBright}
          opacity={0.8}
        />
        <text
          x="75"
          y="4"
          fill={THEME.colors.cyanBright}
          fontFamily={THEME.fonts.mono}
          fontSize="13"
          fontWeight="600"
          letterSpacing="0.08em"
        >
          PRIMARY AUDITORY CORTEX
        </text>
      </g>

      {/* 3. Ascending Auditory Pathway (Cochlear Nuclei -> Superior Olive -> Inferior Colliculus) */}
      <path
        d={`M -40 220 C -30 180, -20 120, 10 30`}
        fill="none"
        stroke={signalArrivalProgress > 0.2 ? THEME.colors.cyan : THEME.colors.nerve}
        strokeWidth={signalArrivalProgress > 0.2 ? 3.5 : 2}
        strokeOpacity={signalArrivalProgress > 0.2 ? 0.9 : 0.3}
      />

      {/* 4. Cortical Associative Pathways (Neuroplastic Re-organization) */}
      {pathwayActivation > 0.1 && (
        <g opacity={pathwayActivation}>
          <path
            d="M 10 30 C 50 -20, 90 -80, 120 -150"
            fill="none"
            stroke={THEME.colors.cyanBright}
            strokeWidth="2"
            strokeDasharray="6 4"
            strokeOpacity="0.7"
          />
          <path
            d="M 10 30 C -30 -30, -80 -60, -130 -100"
            fill="none"
            stroke={THEME.colors.cyanBright}
            strokeWidth="2"
            strokeDasharray="6 4"
            strokeOpacity="0.7"
          />
          {/* Subtle synapsing nodes */}
          <circle cx="120" cy="-150" r="5" fill={THEME.colors.cyan} />
          <circle cx="-130" cy="-100" r="5" fill={THEME.colors.cyan} />
        </g>
      )}

      {/* 5. Decoded Cortical Pattern / Modest Speech Representation Waveform */}
      {waveformResolved > 0.1 && (
        <g transform="translate(0, 370)" opacity={waveformResolved}>
          {/* Backing Card */}
          <rect
            x="-260"
            y="-60"
            width="520"
            height="110"
            rx="8"
            fill={THEME.colors.panel}
            stroke={THEME.colors.line}
            strokeWidth="1.5"
          />
          <text
            x="0"
            y="-32"
            textAnchor="middle"
            fill={THEME.colors.ivoryMuted}
            fontFamily={THEME.fonts.mono}
            fontSize="13"
            letterSpacing="0.1em"
          >
            NEUROPLASTIC INTEGRATION · CORTICAL ENVELOPE
          </text>

          {/* Calibrated Modest Speech Formant Waveform (Medically realistic, not exaggerated) */}
          <path
            d="M -230 10 Q -190 -18, -160 5 T -100 15 T -40 -12 T 20 8 T 80 -15 T 140 10 T 200 -5 T 230 0"
            fill="none"
            stroke={THEME.colors.cyanBright}
            strokeWidth="2.5"
            strokeLinecap="round"
          />
        </g>
      )}
    </g>
  );
};
