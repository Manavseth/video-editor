import React, { useMemo } from 'react';
import { useCurrentFrame } from 'remotion';
import { FAITH_THEME } from '../theme_faithvsfact';

interface Particle {
  id: number;
  baseX: number;
  baseY: number;
  size: number;
  speedY: number;
  freqX: number;
  ampX: number;
  alpha: number;
}

export const DustParticles: React.FC<{ count?: number }> = ({ count = 35 }) => {
  const frame = useCurrentFrame();

  const particles = useMemo<Particle[]>(() => {
    const list: Particle[] = [];
    for (let i = 0; i < count; i++) {
      // Deterministic pseudorandom seed
      const seed = (i * 9301 + 49297) % 233280;
      const rnd = seed / 233280;
      const rnd2 = ((seed * 9301 + 49297) % 233280) / 233280;
      const rnd3 = ((rnd2 * 233280 * 9301 + 49297) % 233280) / 233280;

      list.push({
        id: i,
        baseX: 80 + rnd * (FAITH_THEME.width - 160),
        baseY: 150 + rnd2 * (FAITH_THEME.height - 350),
        size: 2.5 + rnd3 * 3.5,
        speedY: 0.6 + rnd * 0.8,
        freqX: 0.02 + rnd2 * 0.03,
        ampX: 15 + rnd3 * 25,
        alpha: 0.35 + rnd * 0.45,
      });
    }
    return list;
  }, [count]);

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        pointerEvents: 'none',
        overflow: 'hidden',
      }}
    >
      {particles.map((p) => {
        // Continuous upward vertical drift + horizontal sine sway
        const currentY = (p.baseY - frame * p.speedY) % (FAITH_THEME.height - 300);
        const y = currentY < 100 ? currentY + (FAITH_THEME.height - 400) : currentY;
        const x = p.baseX + Math.sin(frame * p.freqX + p.id) * p.ampX;

        return (
          <div
            key={p.id}
            style={{
              position: 'absolute',
              left: x,
              top: y,
              width: p.size,
              height: p.size,
              borderRadius: '50%',
              backgroundColor: FAITH_THEME.colors.goldBright,
              opacity: p.alpha,
              boxShadow: `0 0 ${p.size * 2}px ${FAITH_THEME.colors.gold}`,
            }}
          />
        );
      })}
    </div>
  );
};
