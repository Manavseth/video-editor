import React, { useId } from 'react';
import { THEME } from '../theme';

export interface CochleaProps {
  x?: number;
  y?: number;
  scale?: number;
  rotation?: number;
  opacity?: number;
  fluidWaveProgress?: number; // 0 to 1: travels along spiral
  hairCellState?: 'healthy' | 'damaged' | 'none';
  hairCellActivation?: number[]; // activation levels 0-1 for ~24 hair cell clusters
  showElectrode?: boolean;
  electrodeInsertion?: number; // 0 to 1
  activeElectrodeIndices?: number[]; // which contacts pulse cyan
  pulseIntensity?: number; // 0 to 1
  showNerveFibers?: boolean;
  nerveActivity?: number[];
  highlightTonotopy?: boolean;
  style?: React.CSSProperties;
}

// Parametric logarithmic spiral for anatomical fidelity
// r(theta) = a * exp(b * theta)
function getSpiralPoint(t: number, cx: number, cy: number, scale = 1): { x: number; y: number; angle: number; r: number } {
  // t from 0 (apex / center) to 1 (base / outer vestibule)
  // 2.5 turns = 5 * PI
  const maxTheta = 5.0 * Math.PI;
  const theta = (1 - t) * maxTheta + 0.3;
  const a = 32 * scale;
  const b = 0.165;
  const r = a * Math.exp(b * theta);
  const x = cx + r * Math.cos(theta);
  const y = cy + r * Math.sin(theta);
  return { x, y, angle: theta, r };
}

export const Cochlea: React.FC<CochleaProps> = ({
  x = 540,
  y = 960,
  scale = 1,
  rotation = 0,
  opacity = 1,
  fluidWaveProgress = 0,
  hairCellState = 'none',
  hairCellActivation = [],
  showElectrode = false,
  electrodeInsertion = 1,
  activeElectrodeIndices = [],
  pulseIntensity = 0,
  showNerveFibers = true,
  nerveActivity = [],
  highlightTonotopy = false,
  style = {},
}) => {
  const id = useId();
  const gradOuter = `cochlea-grad-outer-${id}`;
  const gradLumen = `cochlea-grad-lumen-${id}`;
  const gradCyan = `cochlea-grad-cyan-${id}`;
  const glowFilter = `cochlea-glow-${id}`;

  const cx = 0;
  const cy = 0;
  const steps = 60;

  // Build outer shell and inner lumen paths
  const outerPoints: { x: number; y: number }[] = [];
  const innerPoints: { x: number; y: number }[] = [];
  const membranePoints: { x: number; y: number }[] = [];

  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const pt = getSpiralPoint(t, cx, cy, 1.0);
    const wallThickness = 28 * (0.35 + 0.65 * t); // wider at base
    const lumenWidth = 18 * (0.3 + 0.7 * t);

    // Normal vector
    const nx = Math.cos(pt.angle + Math.PI / 2);
    const ny = Math.sin(pt.angle + Math.PI / 2);

    outerPoints.push({ x: pt.x + nx * wallThickness, y: pt.y + ny * wallThickness });
    innerPoints.push({ x: pt.x - nx * wallThickness * 0.3, y: pt.y - ny * wallThickness * 0.3 });
    membranePoints.push({ x: pt.x, y: pt.y });
  }

  // Generate SVG path for outer capsule
  let outerPathD = `M ${outerPoints[0].x} ${outerPoints[0].y}`;
  for (let i = 1; i < outerPoints.length; i++) {
    outerPathD += ` L ${outerPoints[i].x} ${outerPoints[i].y}`;
  }
  for (let i = innerPoints.length - 1; i >= 0; i--) {
    outerPathD += ` L ${innerPoints[i].x} ${innerPoints[i].y}`;
  }
  outerPathD += ' Z';

  // Basilar membrane midline path
  let membraneD = `M ${membranePoints[0].x} ${membranePoints[0].y}`;
  for (let i = 1; i < membranePoints.length; i++) {
    membraneD += ` L ${membranePoints[i].x} ${membranePoints[i].y}`;
  }

  // Modiolus (central core)
  const modiolusPt = getSpiralPoint(0.05, cx, cy, 1.0);

  // Discrete hair cell positions (approx 20 along the membrane)
  const hairCellCount = 20;
  const hairCells: Array<{ x: number; y: number; angle: number; index: number; isDamaged: boolean; active: number }> = [];
  for (let i = 0; i < hairCellCount; i++) {
    const t = 0.15 + (i / (hairCellCount - 1)) * 0.8;
    const pt = getSpiralPoint(t, cx, cy, 1.0);
    // Medical rule: damaged does not mean every cell is gone
    // In damaged state, ~50% irregular/faded, some intact
    const isDamaged = hairCellState === 'damaged' && (i % 3 === 0 || i % 4 === 1);
    const active = hairCellActivation[i] ?? 0;
    hairCells.push({ x: pt.x, y: pt.y, angle: pt.angle, index: i, isDamaged, active });
  }

  // Electrode array contacts (14 contacts along scala tympani)
  const contactCount = 14;
  const contacts: Array<{ x: number; y: number; index: number; active: boolean }> = [];
  const maxContactIdx = Math.floor(contactCount * electrodeInsertion);

  let electrodePathD = '';
  for (let i = 0; i < contactCount; i++) {
    const t = 0.95 - (i / (contactCount - 1)) * 0.75; // base to mid-apex
    const pt = getSpiralPoint(t, cx, cy, 1.0);
    // Offset slightly into scala tympani
    const nx = Math.cos(pt.angle + Math.PI / 2);
    const ny = Math.sin(pt.angle + Math.PI / 2);
    const posX = pt.x + nx * 6;
    const posY = pt.y + ny * 6;

    if (i <= maxContactIdx) {
      if (i === 0) electrodePathD = `M ${posX + 30} ${posY - 40} L ${posX} ${posY}`;
      else electrodePathD += ` L ${posX} ${posY}`;
      const isPulsing = activeElectrodeIndices.includes(i);
      contacts.push({ x: posX, y: posY, index: i, active: isPulsing });
    }
  }

  return (
    <g
      transform={`translate(${x}, ${y}) rotate(${rotation}) scale(${scale})`}
      opacity={opacity}
      style={{ transition: 'opacity 0.2s ease', ...style }}
    >
      <defs>
        {/* Soft cyan glow for electrical stimuli */}
        <filter id={glowFilter} x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="6" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>

        {/* Translucent outer shell gradient */}
        <radialGradient id={gradOuter} cx="45%" cy="45%" r="65%">
          <stop offset="0%" stopColor="#1E293B" stopOpacity="0.85" />
          <stop offset="60%" stopColor="#0F172A" stopOpacity="0.7" />
          <stop offset="100%" stopColor="#020617" stopOpacity="0.9" />
        </radialGradient>

        {/* Lumen canal soft fluid tone */}
        <linearGradient id={gradLumen} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#334155" stopOpacity="0.5" />
          <stop offset="50%" stopColor="#1E293B" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#0F172A" stopOpacity="0.6" />
        </linearGradient>

        <linearGradient id={gradCyan} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={THEME.colors.cyan} stopOpacity="1" />
          <stop offset="100%" stopColor={THEME.colors.cyanBright} stopOpacity="0.8" />
        </linearGradient>
      </defs>

      {/* 1. Translucent Cochlear Capsule */}
      <path
        d={outerPathD}
        fill={`url(#${gradOuter})`}
        stroke={THEME.colors.line}
        strokeWidth="2.5"
        strokeLinejoin="round"
      />

      {/* Outer shell contour line with warm ivory hint */}
      <path
        d={outerPathD}
        fill="none"
        stroke={THEME.colors.ivory}
        strokeWidth="1.2"
        strokeOpacity="0.35"
      />

      {/* Central modiolus core */}
      <circle
        cx={modiolusPt.x}
        cy={modiolusPt.y}
        r="32"
        fill="#0F172A"
        stroke={THEME.colors.lineBright}
        strokeWidth="1.5"
        strokeOpacity="0.5"
      />
      <circle
        cx={modiolusPt.x}
        cy={modiolusPt.y}
        r="14"
        fill="#1E293B"
        stroke={THEME.colors.grey}
        strokeWidth="1"
      />

      {/* 2. Auditory Nerve Fibers / Spiral Ganglion radiating from modiolus */}
      {showNerveFibers && (
        <g opacity="0.8">
          {hairCells.map((hc, idx) => {
            const isFiberActive = (nerveActivity[idx] ?? 0) > 0.1 || (contacts.some(c => c.active && Math.abs(c.index - idx) <= 1));
            return (
              <line
                key={`nerve-${idx}`}
                x1={modiolusPt.x}
                y1={modiolusPt.y}
                x2={hc.x}
                y2={hc.y}
                stroke={isFiberActive ? THEME.colors.cyanBright : THEME.colors.nerve}
                strokeWidth={isFiberActive ? 2.5 : 1}
                strokeOpacity={isFiberActive ? 0.95 : 0.22}
                filter={isFiberActive ? `url(#${glowFilter})` : undefined}
              />
            );
          })}
        </g>
      )}

      {/* 3. Basilar Membrane & Travelling Fluid Wave */}
      <path
        d={membraneD}
        fill="none"
        stroke={THEME.colors.ivoryMuted}
        strokeWidth="2.5"
        strokeOpacity="0.4"
        strokeDasharray="4 4"
      />

      {/* Acoustic Travelling Fluid Wave along membrane */}
      {fluidWaveProgress > 0 && fluidWaveProgress <= 1 && (
        <g>
          {(() => {
            const wavePt = getSpiralPoint(fluidWaveProgress, cx, cy, 1.0);
            return (
              <circle
                cx={wavePt.x}
                cy={wavePt.y}
                r="16"
                fill={THEME.colors.amber}
                fillOpacity="0.5"
                filter={`url(#${glowFilter})`}
              />
            );
          })()}
        </g>
      )}

      {/* 4. Hair Cell Cluster Row */}
      {hairCellState !== 'none' && (
        <g>
          {hairCells.map((hc) => {
            if (hc.isDamaged) {
              // Dimmed / reduced cell (not completely gone, adhering to medical accuracy)
              return (
                <circle
                  key={`hc-${hc.index}`}
                  cx={hc.x}
                  cy={hc.y}
                  r="3"
                  fill={THEME.colors.muted}
                  opacity="0.35"
                />
              );
            }
            const isStimulated = hc.active > 0.1;
            return (
              <g key={`hc-${hc.index}`}>
                <circle
                  cx={hc.x}
                  cy={hc.y}
                  r={isStimulated ? 6 : 4.5}
                  fill={isStimulated ? THEME.colors.amber : THEME.colors.ivory}
                  stroke="#060A14"
                  strokeWidth="1"
                  opacity={isStimulated ? 1 : 0.85}
                  filter={isStimulated ? `url(#${glowFilter})` : undefined}
                />
                {/* Hair bundle stereocilia line */}
                <line
                  x1={hc.x}
                  y1={hc.y}
                  x2={hc.x + Math.cos(hc.angle) * 7}
                  y2={hc.y + Math.sin(hc.angle) * 7}
                  stroke={isStimulated ? THEME.colors.amber : THEME.colors.ivoryMuted}
                  strokeWidth="1.5"
                  opacity="0.9"
                />
              </g>
            );
          })}
        </g>
      )}

      {/* 5. Cochlear Implant Electrode Array (Scala Tympani) */}
      {showElectrode && electrodePathD && (
        <g>
          {/* Flexible silicone carrier backing */}
          <path
            d={electrodePathD}
            fill="none"
            stroke="rgba(148, 163, 184, 0.4)"
            strokeWidth="7"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Central cyan conductive trace */}
          <path
            d={electrodePathD}
            fill="none"
            stroke={THEME.colors.cyan}
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeOpacity="0.9"
            filter={`url(#${glowFilter})`}
          />

          {/* Platinum-Iridium Contacts along Array */}
          {contacts.map((c) => (
            <g key={`contact-${c.index}`}>
              <circle
                cx={c.x}
                cy={c.y}
                r={c.active ? 7 : 4.5}
                fill={c.active ? '#FFFFFF' : THEME.colors.cyanBright}
                stroke={c.active ? THEME.colors.cyan : '#060A14'}
                strokeWidth="1.5"
                filter={c.active ? `url(#${glowFilter})` : undefined}
              />
              {/* Restrained biphasic pulse radiation */}
              {c.active && pulseIntensity > 0 && (
                <circle
                  cx={c.x}
                  cy={c.y}
                  r={12 + pulseIntensity * 14}
                  fill="none"
                  stroke={THEME.colors.cyanBright}
                  strokeWidth="2"
                  strokeOpacity={0.8 * (1 - pulseIntensity)}
                />
              )}
            </g>
          ))}
        </g>
      )}

      {/* 6. Tonotopic Place Map Highlights (Base = High Freq, Apex = Low Freq) */}
      {highlightTonotopy && (
        <g font-family={THEME.fonts.mono} fontSize="14" fill={THEME.colors.ivory}>
          {/* Base / Entrance */}
          {(() => {
            const basePt = getSpiralPoint(0.92, cx, cy, 1.0);
            return (
              <g transform={`translate(${basePt.x + 35}, ${basePt.y - 15})`}>
                <rect x="-4" y="-16" width="130" height="24" rx="4" fill="rgba(15, 23, 42, 0.85)" stroke={THEME.colors.line} strokeWidth="1" />
                <text x="6" y="0" fill={THEME.colors.cyanBright} fontWeight="600" fontSize="13">
                  BASE · HIGH kHz
                </text>
              </g>
            );
          })()}

          {/* Apex / Inner Turn */}
          {(() => {
            const apexPt = getSpiralPoint(0.18, cx, cy, 1.0);
            return (
              <g transform={`translate(${apexPt.x - 140}, ${apexPt.y - 15})`}>
                <rect x="-4" y="-16" width="125" height="24" rx="4" fill="rgba(15, 23, 42, 0.85)" stroke={THEME.colors.line} strokeWidth="1" />
                <text x="6" y="0" fill={THEME.colors.ivory} fontWeight="600" fontSize="13">
                  APEX · LOW Hz
                </text>
              </g>
            );
          })()}
        </g>
      )}
    </g>
  );
};
