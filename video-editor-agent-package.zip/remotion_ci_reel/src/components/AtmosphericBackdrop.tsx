import React from 'react';
import { interpolate, useCurrentFrame } from 'remotion';
import { FAITH_THEME } from '../theme_faithvsfact';

interface Props {
  spotlightY?: number;
  pulseSpeed?: number;
}

export const AtmosphericBackdrop: React.FC<Props> = ({
  spotlightY = 860,
  pulseSpeed = 0.05,
}) => {
  const frame = useCurrentFrame();

  // Subtle continuous breathing pulse of the radial golden spotlight
  const pulse = interpolate(
    Math.sin(frame * pulseSpeed),
    [-1, 1],
    [0.96, 1.04]
  );

  const glowAlpha = interpolate(
    Math.sin(frame * pulseSpeed * 0.8),
    [-1, 1],
    [0.18, 0.25]
  );

  return (
    <div
      style={{
        position: 'absolute',
        width: FAITH_THEME.width,
        height: FAITH_THEME.height,
        backgroundColor: FAITH_THEME.colors.bg,
        overflow: 'hidden',
      }}
    >
      {/* Outer Deep Vignette */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: `radial-gradient(circle at 50% 50%, transparent 45%, ${FAITH_THEME.colors.bgDark} 100%)`,
        }}
      />

      {/* Central Volumetric Golden Radial Spotlight */}
      <div
        style={{
          position: 'absolute',
          left: FAITH_THEME.width / 2 - 450 * pulse,
          top: spotlightY - 450 * pulse,
          width: 900 * pulse,
          height: 900 * pulse,
          borderRadius: '50%',
          background: `radial-gradient(circle, rgba(255, 200, 100, ${glowAlpha}) 0%, rgba(255, 180, 50, ${glowAlpha * 0.4}) 45%, transparent 70%)`,
          filter: 'blur(35px)',
          pointerEvents: 'none',
        }}
      />

      {/* Inner Intense Golden Halo */}
      <div
        style={{
          position: 'absolute',
          left: FAITH_THEME.width / 2 - 220,
          top: spotlightY - 220,
          width: 440,
          height: 440,
          borderRadius: '50%',
          background: `radial-gradient(circle, rgba(255, 225, 140, ${glowAlpha * 1.5}) 0%, transparent 65%)`,
          filter: 'blur(20px)',
          pointerEvents: 'none',
        }}
      />
    </div>
  );
};
