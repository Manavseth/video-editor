import React from 'react';
import { THEME } from '../theme';

interface SpeakerConeProps {
  x?: number;
  y?: number;
  scale?: number;
  vibrationOffset?: number; // displacement in px
  irregularity?: number; // 0 to 1
  blurFactor?: number; // 0 to 1 (for Scene 3 -> Scene 4 transition)
  opacity?: number;
}

export const SpeakerCone: React.FC<SpeakerConeProps> = ({
  x = 540,
  y = 960,
  scale = 1,
  vibrationOffset = 0,
  irregularity = 0,
  blurFactor = 0,
  opacity = 1,
}) => {
  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      opacity={opacity}
      filter={blurFactor > 0.1 ? `blur(${blurFactor * 12}px)` : undefined}
    >
      <defs>
        <radialGradient id="speaker-basket" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#1E293B" stopOpacity="0.8" />
          <stop offset="70%" stopColor="#0F172A" stopOpacity="0.9" />
          <stop offset="100%" stopColor="#020617" stopOpacity="1" />
        </radialGradient>
      </defs>

      {/* Outer Chassis / Basket Frame */}
      <circle
        cx="0"
        cy="0"
        r="240"
        fill="url(#speaker-basket)"
        stroke={THEME.colors.line}
        strokeWidth="4"
      />

      {/* Surround Roll (Rubber / Foam Edge) */}
      <circle
        cx="0"
        cy="0"
        r="200"
        fill="none"
        stroke={THEME.colors.mutedDark}
        strokeWidth="24"
        strokeOpacity="0.6"
      />

      {/* Diaphragm / Cone with mechanical vibration offset */}
      <g transform={`translate(${vibrationOffset * 0.4}, ${vibrationOffset})`}>
        {/* Conical body */}
        <circle
          cx="0"
          cy="0"
          r="165"
          fill="#111827"
          stroke={irregularity > 0.5 ? THEME.colors.amber : THEME.colors.ivoryMuted}
          strokeWidth={irregularity > 0.5 ? 3 : 2}
          strokeOpacity={0.7}
        />

        {/* Dust Cap (Center Dome) */}
        <circle
          cx="0"
          cy="0"
          r="65"
          fill="#1E293B"
          stroke={THEME.colors.lineBright}
          strokeWidth="2"
        />

        {/* Voice Coil Ring */}
        <circle
          cx="0"
          cy="0"
          r="75"
          fill="none"
          stroke={irregularity > 0.4 ? THEME.colors.amber : THEME.colors.muted}
          strokeWidth="1.5"
          strokeDasharray="4 4"
        />
      </g>

      {/* Vibration Shockwaves / Metaphoric acoustic ripples */}
      {irregularity > 0.2 && (
        <g opacity={irregularity}>
          <path
            d="M 190 -120 C 230 -60, 240 60, 190 120"
            fill="none"
            stroke={THEME.colors.amber}
            strokeWidth="3"
            strokeDasharray="8 6"
            strokeOpacity="0.75"
          />
          <path
            d="M 230 -150 C 280 -80, 290 80, 230 150"
            fill="none"
            stroke={THEME.colors.amber}
            strokeWidth="2"
            strokeDasharray="5 5"
            strokeOpacity="0.45"
          />
        </g>
      )}

      {/* Technical Label Card */}
      <g transform="translate(0, 280)">
        <rect
          x="-140"
          y="-20"
          width="280"
          height="38"
          rx="6"
          fill={THEME.colors.panel}
          stroke={THEME.colors.line}
          strokeWidth="1"
        />
        <text
          x="0"
          y="4"
          textAnchor="middle"
          fill={THEME.colors.ivoryMuted}
          fontFamily={THEME.fonts.mono}
          fontSize="14"
          letterSpacing="0.08em"
        >
          ANALOG AMPLIFICATION LIMIT
        </text>
      </g>
    </g>
  );
};
