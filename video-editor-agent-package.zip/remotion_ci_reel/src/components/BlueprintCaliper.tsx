import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { FAITH_THEME } from '../theme_faithvsfact';

interface Props {
  x1: number;
  x2: number;
  y: number;
  label: string;
  subLabel?: string;
  delay?: number;
  color?: string;
}

export const BlueprintCaliper: React.FC<Props> = ({
  x1,
  x2,
  y,
  label,
  subLabel,
  delay = 0,
  color = FAITH_THEME.colors.gold,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const progress = spring({
    frame: frame - delay,
    fps,
    config: { damping: 14, stiffness: 120, mass: 0.6 },
  });

  const width = (x2 - x1) * progress;
  const currentX2 = x1 + width;
  const centerX = (x1 + x2) / 2;

  const opacity = interpolate(frame - delay, [0, 8], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  if (frame < delay) return null;

  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        top: 0,
        width: FAITH_THEME.width,
        height: FAITH_THEME.height,
        opacity,
        pointerEvents: 'none',
      }}
    >
      <svg
        style={{
          position: 'absolute',
          inset: 0,
          width: '100%',
          height: '100%',
        }}
      >
        {/* Main Caliper Horizontal Line */}
        <line
          x1={x1}
          y1={y}
          x2={currentX2}
          y2={y}
          stroke={color}
          strokeWidth={2}
          strokeDasharray="4 2"
        />

        {/* Left Tick End */}
        <line
          x1={x1}
          y1={y - 12}
          x2={x1}
          y2={y + 12}
          stroke={color}
          strokeWidth={3}
        />

        {/* Right Tick End */}
        {progress > 0.05 && (
          <line
            x1={currentX2}
            y1={y - 12}
            x2={currentX2}
            y2={y + 12}
            stroke={color}
            strokeWidth={3}
          />
        )}
      </svg>

      {/* Centered Technical Label */}
      {progress > 0.4 && (
        <div
          style={{
            position: 'absolute',
            left: centerX,
            top: y + 16,
            transform: 'translateX(-50%)',
            textAlign: 'center',
            fontFamily: FAITH_THEME.fonts.serif,
            letterSpacing: '0.12em',
            color,
            textShadow: '0 2px 8px rgba(0,0,0,0.85)',
          }}
        >
          <div style={{ fontSize: 26, fontWeight: 700, textTransform: 'uppercase' }}>
            {label}
          </div>
          {subLabel && (
            <div
              style={{
                fontSize: 18,
                color: FAITH_THEME.colors.blueAccent,
                fontFamily: FAITH_THEME.fonts.mono,
                marginTop: 4,
                letterSpacing: '0.08em',
              }}
            >
              {subLabel}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
