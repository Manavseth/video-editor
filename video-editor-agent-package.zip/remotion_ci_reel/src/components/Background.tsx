import React from 'react';
import { THEME } from '../theme';

interface BackgroundProps {
  title?: string;
  subtitle?: string;
}

export const Background: React.FC<BackgroundProps> = ({ title, subtitle }) => {
  return (
    <div
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: THEME.width,
        height: THEME.height,
        backgroundColor: THEME.colors.bg,
        backgroundImage: `radial-gradient(circle at 50% 45%, #0B132B 0%, ${THEME.colors.bg} 75%, ${THEME.colors.bgDeep} 100%)`,
        overflow: 'hidden',
        pointerEvents: 'none',
      }}
    >
      {/* Subtle scientific grid lines */}
      <svg
        width={THEME.width}
        height={THEME.height}
        style={{ position: 'absolute', top: 0, left: 0, opacity: 0.08 }}
      >
        <defs>
          <pattern id="grid-pattern" width="80" height="80" patternUnits="userSpaceOnUse">
            <path d="M 80 0 L 0 0 0 80" fill="none" stroke={THEME.colors.ivory} strokeWidth="1" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid-pattern)" />
      </svg>

      {/* Top Header Badge */}
      <div
        style={{
          position: 'absolute',
          top: 90,
          left: THEME.safeArea.left,
          right: THEME.safeArea.right,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          borderBottom: `1px solid ${THEME.colors.line}`,
          paddingBottom: 16,
        }}
      >
        <div>
          <div
            style={{
              fontFamily: THEME.fonts.mono,
              fontSize: 18,
              fontWeight: 600,
              letterSpacing: '0.12em',
              textTransform: 'uppercase',
              color: THEME.colors.cyanBright,
            }}
          >
            {title || 'AUDITORY PHYSIOLOGY & TRANSDUCTION'}
          </div>
          {subtitle && (
            <div
              style={{
                fontFamily: THEME.fonts.title,
                fontSize: 16,
                color: THEME.colors.muted,
                marginTop: 4,
              }}
            >
              {subtitle}
            </div>
          )}
        </div>

        <div
          style={{
            fontFamily: THEME.fonts.mono,
            fontSize: 14,
            padding: '6px 12px',
            borderRadius: 4,
            backgroundColor: THEME.colors.panel,
            border: `1px solid ${THEME.colors.line}`,
            color: THEME.colors.ivoryMuted,
          }}
        >
          40S · 30 FPS
        </div>
      </div>

      {/* Frame Vignette */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          boxShadow: 'inset 0 0 120px rgba(2, 6, 23, 0.95)',
        }}
      />
    </div>
  );
};
