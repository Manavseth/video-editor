import React from 'react';
import { THEME } from '../theme';

interface EarOutlineProps {
  x?: number;
  y?: number;
  scale?: number;
  opacity?: number;
  showHearingAid?: boolean;
  showImplantProcessor?: boolean;
  hearingAidGlow?: number; // 0 to 1
  implantSignalProgress?: number; // 0 to 1
  style?: React.CSSProperties;
}

export const EarOutline: React.FC<EarOutlineProps> = ({
  x = 540,
  y = 960,
  scale = 1,
  opacity = 1,
  showHearingAid = true,
  showImplantProcessor = false,
  hearingAidGlow = 0,
  implantSignalProgress = 0,
  style = {},
}) => {
  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      opacity={opacity}
      style={{ transition: 'opacity 0.2s ease', ...style }}
    >
      <defs>
        <filter id="ear-cyan-glow" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="5" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <filter id="ear-amber-glow" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="5" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* 1. Pinna / Outer Ear Silhouette (Warm Ivory) */}
      <path
        d="M -120 -280 C -40 -340, 90 -330, 150 -240 C 200 -160, 210 -40, 180 60 C 150 160, 110 240, 40 290 C -20 330, -80 320, -110 260 C -130 220, -110 170, -70 140 C -30 110, -20 50, -40 0 C -60 -50, -120 -80, -120 -150 C -120 -220, -140 -260, -120 -280 Z"
        fill="rgba(245, 242, 235, 0.04)"
        stroke={THEME.colors.ivory}
        strokeWidth="3.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Antihelix / Inner Cartilage Crease */}
      <path
        d="M 60 -190 C 110 -130, 120 -20, 80 70 C 50 130, 0 170, -40 160"
        fill="none"
        stroke={THEME.colors.ivoryMuted}
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeOpacity="0.6"
      />

      {/* Tragus / Concha Bowl */}
      <path
        d="M -50 -10 C -20 -10, 0 20, -20 50 C -40 70, -70 50, -60 20 Z"
        fill="rgba(15, 23, 42, 0.6)"
        stroke={THEME.colors.ivoryMuted}
        strokeWidth="2"
      />

      {/* External Auditory Canal (Horizontal Inward Passage) */}
      <path
        d="M -50 30 L -180 30 C -210 30, -230 40, -250 50"
        fill="none"
        stroke={THEME.colors.lineBright}
        strokeWidth="18"
        strokeLinecap="round"
        strokeOpacity="0.25"
      />
      <path
        d="M -50 30 L -180 30 C -210 30, -230 40, -250 50"
        fill="none"
        stroke={THEME.colors.ivoryMuted}
        strokeWidth="2"
        strokeDasharray="4 4"
        strokeOpacity="0.5"
      />

      {/* Tympanic Membrane (Eardrum) Angled Slant */}
      <line
        x1="-245"
        y1="36"
        x2="-255"
        y2="64"
        stroke={THEME.colors.ivory}
        strokeWidth="3.5"
        strokeLinecap="round"
      />

      {/* 2. Behind-The-Ear (BTE) Hearing Aid Silhouette */}
      {showHearingAid && (
        <g opacity={0.3 + hearingAidGlow * 0.7}>
          {/* Main Body curved behind pinna */}
          <path
            d="M -135 -260 C -170 -230, -195 -160, -190 -80 C -185 -10, -155 40, -125 70 C -115 80, -100 70, -110 50 C -135 15, -155 -40, -150 -100 C -145 -160, -125 -220, -95 -245 Z"
            fill="rgba(245, 158, 11, 0.15)"
            stroke={THEME.colors.amber}
            strokeWidth="3"
            strokeLinejoin="round"
            filter={hearingAidGlow > 0.4 ? 'url(#ear-amber-glow)' : undefined}
          />
          {/* Sound Tube arching over top of ear into canal */}
          <path
            d="M -95 -245 C -40 -300, 30 -290, 40 -200 C 45 -140, 20 -80, -45 30"
            fill="none"
            stroke={THEME.colors.amber}
            strokeWidth="3"
            strokeLinecap="round"
            strokeOpacity="0.85"
          />
          {/* Volume / Gain Indicator */}
          <circle
            cx="-175"
            cy="-110"
            r={5 + hearingAidGlow * 3}
            fill={THEME.colors.amber}
            filter="url(#ear-amber-glow)"
          />
        </g>
      )}

      {/* 3. External Cochlear Implant Processor & Transmitter Coil */}
      {showImplantProcessor && (
        <g>
          {/* Behind-ear sleek slim processor */}
          <path
            d="M -130 -220 C -160 -180, -175 -120, -170 -60 C -165 -20, -145 20, -125 40"
            fill="none"
            stroke={THEME.colors.cyanBright}
            strokeWidth="4"
            strokeLinecap="round"
          />
          {/* Cable to RF transmitter coil */}
          <path
            d="M -150 -150 C -180 -180, -180 -230, -150 -280 C -120 -330, -50 -350, 0 -340"
            fill="none"
            stroke={THEME.colors.cyan}
            strokeWidth="2.5"
            strokeDasharray="6 4"
            strokeOpacity="0.8"
          />
          {/* Transcutaneous Magnetic Transmitter Coil (Over Temporoparietal Skull) */}
          <circle
            cx="0"
            cy="-340"
            r="38"
            fill="rgba(34, 211, 238, 0.12)"
            stroke={THEME.colors.cyan}
            strokeWidth="3"
            filter="url(#ear-cyan-glow)"
          />
          <circle
            cx="0"
            cy="-340"
            r="16"
            fill="rgba(15, 23, 42, 0.8)"
            stroke={THEME.colors.cyanBright}
            strokeWidth="2"
          />

          {/* Subdermal Signal Pulse line propagating inward */}
          {implantSignalProgress > 0 && (
            <path
              d={`M 0 -340 C -80 -320, -180 -250, -220 -150 L ${-220 - implantSignalProgress * 50} ${-150 + implantSignalProgress * 150}`}
              fill="none"
              stroke={THEME.colors.cyanBright}
              strokeWidth="3"
              filter="url(#ear-cyan-glow)"
            />
          )}
        </g>
      )}
    </g>
  );
};
