import React from 'react';
import { THEME } from '../theme';

export interface CaptionCue {
  id: number;
  startSec: number;
  endSec: number;
  text: string;
  highlightText?: string;
  highlightColor?: string;
}

export const CAPTIONS_DATA: CaptionCue[] = [
  { id: 1, startSec: 0.0, endSec: 1.8, text: "As an audiologist, here's why" },
  { id: 2, startSec: 1.8, endSec: 3.6, text: "cranking up a hearing aid", highlightText: "hearing aid", highlightColor: THEME.colors.amber },
  { id: 3, startSec: 3.6, endSec: 6.0, text: "can NEVER do what a cochlear implant does.", highlightText: "cochlear implant", highlightColor: THEME.colors.cyanBright },
  { id: 4, startSec: 6.0, endSec: 8.2, text: "Hearing aids amplify acoustic pressure waves", highlightText: "amplify acoustic", highlightColor: THEME.colors.amber },
  { id: 5, startSec: 8.2, endSec: 10.5, text: "for hair cells in the Organ of Corti.", highlightText: "hair cells", highlightColor: THEME.colors.ivory },
  { id: 6, startSec: 10.5, endSec: 12.8, text: "But in severe sensorineural loss,", highlightText: "sensorineural loss", highlightColor: THEME.colors.muted },
  { id: 7, startSec: 12.8, endSec: 14.8, text: "when those hair cells are damaged,", highlightText: "damaged", highlightColor: '#EF4444' },
  { id: 8, startSec: 14.8, endSec: 17.6, text: "extra decibels just mean severe harmonic distortion!", highlightText: "harmonic distortion", highlightColor: THEME.colors.amber },
  { id: 9, startSec: 17.6, endSec: 20.2, text: "Like blasting sound through a blown speaker.", highlightText: "blown speaker", highlightColor: THEME.colors.amber },
  { id: 10, startSec: 20.2, endSec: 22.8, text: "A cochlear implant bypasses", highlightText: "bypasses", highlightColor: THEME.colors.cyanBright },
  { id: 11, startSec: 22.8, endSec: 24.8, text: "mechanical transduction entirely.", highlightText: "mechanical transduction", highlightColor: THEME.colors.cyan },
  { id: 12, startSec: 24.8, endSec: 27.2, text: "The processor decomposes audio into frequency bands,", highlightText: "frequency bands", highlightColor: THEME.colors.cyanBright },
  { id: 13, startSec: 27.2, endSec: 29.8, text: "and an electrode array inside the scala tympani", highlightText: "electrode array", highlightColor: THEME.colors.cyanBright },
  { id: 14, startSec: 29.8, endSec: 32.8, text: "fires biphasic pulses directly into spiral ganglion neurons.", highlightText: "biphasic pulses", highlightColor: THEME.colors.cyanBright },
  { id: 15, startSec: 32.8, endSec: 35.0, text: "Base for high pitch, apex for lows-", highlightText: "Base for high pitch", highlightColor: THEME.colors.cyan },
  { id: 16, startSec: 35.0, endSec: 37.0, text: "delivering tonotopic frequency order!", highlightText: "tonotopic order", highlightColor: THEME.colors.cyanBright },
  { id: 17, startSec: 37.0, endSec: 40.0, text: "Your auditory cortex decodes electricity into speech.", highlightText: "auditory cortex", highlightColor: THEME.colors.cyanBright },
];

interface CaptionsOverlayProps {
  currentSeconds: number;
}

export const CaptionsOverlay: React.FC<CaptionsOverlayProps> = ({ currentSeconds }) => {
  const activeCue = CAPTIONS_DATA.find(
    (c) => currentSeconds >= c.startSec && currentSeconds < c.endSec
  );

  if (!activeCue) return null;

  const parts = activeCue.highlightText
    ? activeCue.text.split(activeCue.highlightText)
    : [activeCue.text];

  return (
    <div
      style={{
        position: 'absolute',
        top: THEME.safeArea.captionY,
        left: THEME.safeArea.left,
        right: THEME.safeArea.right,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        pointerEvents: 'none',
        zIndex: 50,
      }}
    >
      <div
        style={{
          backgroundColor: 'rgba(6, 10, 20, 0.88)',
          border: `1px solid ${THEME.colors.line}`,
          backdropFilter: 'blur(10px)',
          padding: '16px 28px',
          borderRadius: 14,
          maxWidth: 900,
          textAlign: 'center',
          boxShadow: '0 12px 32px rgba(0, 0, 0, 0.6)',
        }}
      >
        <span
          style={{
            fontFamily: THEME.fonts.title,
            fontSize: 34,
            fontWeight: 700,
            lineHeight: 1.32,
            color: THEME.colors.ivory,
            letterSpacing: '-0.01em',
          }}
        >
          {parts.length === 2 ? (
            <>
              {parts[0]}
              <span
                style={{
                  color: activeCue.highlightColor || THEME.colors.cyanBright,
                  textDecoration: 'underline',
                  textUnderlineOffset: '6px',
                  textDecorationColor: activeCue.highlightColor || THEME.colors.cyanBright,
                }}
              >
                {activeCue.highlightText}
              </span>
              {parts[1]}
            </>
          ) : (
            activeCue.text
          )}
        </span>
      </div>
    </div>
  );
};
