import React from 'react';
import {
  useCurrentFrame,
  Audio,
  OffthreadVideo,
  Sequence,
  staticFile,
} from 'remotion';

import {
  PAPER,
  GRID,
  INK,
  INK_SOFT,
  AIR,
  AIR_PALE,
  BONE,
  BONE_PALE,
  OK,
  OK_PALE,
  STOP,
  STOP_PALE,
  SLATE,
  WAX,
  W,
  H,
  SHEET,
  PLOT,
  fx,
  dy,
  easeSettle,
  easeStamp,
  clamp,
} from './tokens';
import { CURVES } from './data';
import { CaptionsLayer } from './CaptionsLayer';

import { AudSheet } from './assets/sheet';
import { HeadCut } from './assets/head';
import { Chip, TabCard, ArrowDown } from './assets/labels';

export const AudiogramPart2Master: React.FC = () => {
  const frame = useCurrentFrame();

  return (
    <div
      style={{
        width: W,
        height: H,
        backgroundColor: PAPER,
        position: 'relative',
        overflow: 'hidden',
        fontFamily: 'Inter, "Segoe UI", system-ui, sans-serif',
      }}
    >
      {/* 1. Global Master Voice Audio Track (48kHz Stereo, -14 LUFS, seamless audio sync) */}
      <Audio src={staticFile('audiogram2_master_voice.wav')} />

      {/* 2. Global Static Grid Background (for ISO registers) */}
      <svg
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: W,
          height: H,
          pointerEvents: 'none',
        }}
      >
        <defs>
          <pattern
            id="global-grid-pattern-part2"
            width={48}
            height={48}
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M 48 0 L 0 0 0 48"
              fill="none"
              stroke={GRID}
              strokeWidth={1.5}
              opacity={0.65}
            />
          </pattern>
        </defs>
        <rect width={W} height={H} fill="url(#global-grid-pattern-part2)" />
      </svg>

      {/* =========================================================================
          REGISTER 1: CODE-DRAWN MOTION GRAPHICS (Frames 0 to 579 · 19.30s)
          S01: Hook & Audiogram Sheet Entrance (0 to 96)
          S02: World Loudness & Acoustic Waves (96 to 176)
          S03: Normal Hearing Threshold Line <= 20 dB (176 to 322)
          S04: 20 dB Whisper Capture & Auditory Cortex (322 to 457)
          S05: Thresholds Falling into Mild / Moderate / Severe Zones (457 to 579)
          ========================================================================= */}
      {frame >= 0 && frame < 579 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          {/* S01: Hook & Sheet Entrance (Frames 0 to 96) */}
          {frame < 96 && (
            <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
              <g transform={`translate(0, ${(1 - easeSettle(frame / 24)) * 60})`}>
                <AudSheet
                  sheetTitle="AUDIOGRAM REPORT"
                  airValues={CURVES.NORMAL}
                  airProgress={clamp((frame - 20) / 40)}
                  opacity={easeSettle(frame / 18)}
                />
              </g>
              <TabCard
                x={540}
                y={200}
                title="AUDIOGRAM DECODED · PART 2"
                ruleColor={AIR}
                scale={easeStamp(frame / 14)}
              />
              <Chip
                x={540}
                y={260}
                text="HOW LOUD IS YOUR WORLD?"
                variant="black"
                scale={easeStamp((frame - 12) / 14)}
              />
            </svg>
          )}

          {/* S02: Acoustic Waves & World Loudness (Frames 96 to 176) */}
          {frame >= 96 && frame < 176 && (
            <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
              <AudSheet
                sheetTitle="AUDIOGRAM REPORT"
                airValues={CURVES.NORMAL}
                airProgress={1}
                opacity={0.35}
              />
              {/* Central Acoustic Loudness Gauge Card */}
              <g transform="translate(140, 520)">
                <rect
                  width={800}
                  height={560}
                  rx={28}
                  fill="white"
                  stroke={GRID}
                  strokeWidth={2}
                  style={{ filter: 'drop-shadow(0 16px 40px rgba(38,36,48,0.08))' }}
                />
                <text x={400} y={70} textAnchor="middle" fill={INK_SOFT} fontSize={22} fontWeight={700} letterSpacing={2}>
                  ACOUSTIC SOUND PRESSURE
                </text>
                <text x={400} y={130} textAnchor="middle" fill={INK} fontSize={46} fontWeight={800}>
                  Duniya Kitni Loud Hai?
                </text>

                {/* Animated Concentric Sound Wave Rings */}
                {[0, 1, 2, 3].map((ringIdx) => {
                  const ringProgress = ((frame - 96 + ringIdx * 18) % 60) / 60;
                  const ringR = 60 + ringProgress * 140;
                  const ringOp = 1 - ringProgress;
                  return (
                    <circle
                      key={ringIdx}
                      cx={400}
                      cy={320}
                      r={ringR}
                      fill="none"
                      stroke={AIR}
                      strokeWidth={3}
                      opacity={ringOp * 0.75}
                    />
                  );
                })}
                {/* Center Ear Icon Halo */}
                <circle cx={400} cy={320} r={46} fill={AIR_PALE} stroke={AIR} strokeWidth={2.5} />
                <text x={400} y={335} textAnchor="middle" fontSize={38}>
                  👂
                </text>

                {/* dB Scale Bar */}
                <g transform="translate(100, 470)">
                  <rect width={600} height={18} rx={9} fill={SLATE.s100} />
                  <rect
                    width={clamp((frame - 96) / 50) * 480}
                    height={18}
                    rx={9}
                    fill={AIR}
                  />
                  <text x={0} y={42} fill={INK_SOFT} fontSize={18} fontWeight={600}>0 dB (Quiet)</text>
                  <text x={600} y={42} textAnchor="end" fill={INK_SOFT} fontSize={18} fontWeight={600}>100 dB (Loud)</text>
                </g>
              </g>

              <TabCard
                x={540}
                y={200}
                title="DECIBELS (dB) SCALE"
                ruleColor={AIR}
              />
            </svg>
          )}

          {/* S03: Normal Hearing Baseline <= 20 dB (Frames 176 to 322) */}
          {frame >= 176 && frame < 322 && (
            <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
              <AudSheet
                sheetTitle="AUDIOGRAM REPORT"
                airValues={CURVES.NORMAL}
                airProgress={clamp((frame - 180) / 40)}
                opacity={1}
              />
              {/* Highlight Normal Hearing Band (0 to 25 dB) */}
              <rect
                x={PLOT.x0}
                y={dy(0)}
                width={PLOT.x1 - PLOT.x0}
                height={dy(25) - dy(0)}
                fill={OK_PALE}
                opacity={0.35 + 0.15 * Math.sin((frame - 176) / 10)}
                rx={12}
              />
              {/* Pulsing 20 dB Threshold Line */}
              <line
                x1={PLOT.x0}
                y1={dy(20)}
                x2={PLOT.x1}
                y2={dy(20)}
                stroke={OK}
                strokeWidth={3.5}
                strokeDasharray="8 6"
              />
              <g transform={`translate(${PLOT.x1 - 10}, ${dy(20) - 14})`}>
                <rect x={-200} y={0} width={200} height={32} rx={16} fill={OK} />
                <text x={-100} y={21} textAnchor="middle" fill="white" fontSize={16} fontWeight={800}>
                  NORMAL LINE (≤20 dB)
                </text>
              </g>

              <TabCard
                x={540}
                y={200}
                title="THE NORMAL THRESHOLD"
                ruleColor={OK}
                scale={easeStamp((frame - 176) / 14)}
              />
              <Chip
                x={540}
                y={260}
                text="ALL CURVES ABOVE 20 dB = HEALTHY"
                variant="white"
              />
            </svg>
          )}

          {/* S04: 20 dB Whisper Capture & Auditory Cortex (Frames 322 to 457) */}
          {frame >= 322 && frame < 457 && (
            <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
              <AudSheet
                sheetTitle="AUDIOGRAM REPORT"
                airValues={CURVES.NORMAL}
                airProgress={1}
                opacity={0.25}
              />
              {/* Whisper Connection Card */}
              <g transform="translate(140, 480)">
                <rect
                  width={800}
                  height={620}
                  rx={28}
                  fill="white"
                  stroke={GRID}
                  strokeWidth={2}
                  style={{ filter: 'drop-shadow(0 16px 40px rgba(38,36,48,0.08))' }}
                />
                <text x={400} y={65} textAnchor="middle" fill={OK} fontSize={22} fontWeight={800} letterSpacing={2}>
                  20 dB FAINT WHISPER
                </text>
                <text x={400} y={120} textAnchor="middle" fill={INK} fontSize={40} fontWeight={800}>
                  Dimaag Easily Catch Kar Raha Hai
                </text>

                {/* Left: Whisper Source */}
                <g transform="translate(180, 260)">
                  <circle cx={0} cy={0} r={55} fill={OK_PALE} stroke={OK} strokeWidth={3} />
                  <text x={0} y={12} textAnchor="middle" fontSize={42}>🤫</text>
                  <text x={0} y={90} textAnchor="middle" fill={INK} fontSize={20} fontWeight={700}>
                    Faint Whisper
                  </text>
                  <text x={0} y={115} textAnchor="middle" fill={OK} fontSize={18} fontWeight={800}>
                    20 dB
                  </text>
                </g>

                {/* Traveling Acoustic Signal Dots */}
                {[0, 1, 2, 3].map((dotIdx) => {
                  const p = ((frame - 322 + dotIdx * 15) % 45) / 45;
                  const dotX = 180 + p * (620 - 180);
                  const dotY = 260 + Math.sin(p * Math.PI * 4) * 16;
                  return (
                    <circle
                      key={dotIdx}
                      cx={dotX}
                      cy={dotY}
                      r={6}
                      fill={OK}
                      opacity={0.8}
                    />
                  );
                })}

                {/* Right: Brain Receptor */}
                <g transform="translate(620, 260)">
                  <circle
                    cx={0}
                    cy={0}
                    r={55 + 5 * Math.sin((frame - 322) / 8)}
                    fill={BONE_PALE}
                    stroke={BONE}
                    strokeWidth={3}
                  />
                  <text x={0} y={14} textAnchor="middle" fontSize={46}>🧠</text>
                  <text x={0} y={90} textAnchor="middle" fill={INK} fontSize={20} fontWeight={700}>
                    Auditory Cortex
                  </text>
                  <text x={0} y={115} textAnchor="middle" fill={BONE} fontSize={18} fontWeight={800}>
                    Effortless Detection
                  </text>
                </g>

                {/* Result Pill */}
                <g transform="translate(400, 520)">
                  <rect x={-220} y={0} width={440} height={50} rx={25} fill={OK_PALE} stroke={OK} strokeWidth={2} />
                  <text x={0} y={32} textAnchor="middle" fill={OK} fontSize={22} fontWeight={800}>
                    ✓ ZERO AUDITORY STRAIN
                  </text>
                </g>
              </g>

              <TabCard
                x={540}
                y={200}
                title="WHISPER CAPTURE"
                ruleColor={OK}
              />
            </svg>
          )}

          {/* S05: Thresholds Falling into Zones (Frames 457 to 579) */}
          {frame >= 457 && (
            <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
              <AudSheet
                sheetTitle="AUDIOGRAM REPORT"
                airValues={CURVES.MILD}
                airProgress={1}
                opacity={1}
              />
              {/* Shaded Severity Bands on the Audiogram Sheet */}
              <g transform="translate(0, 0)">
                {/* Mild Zone: 26 to 40 dB */}
                <rect
                  x={PLOT.x0}
                  y={dy(26)}
                  width={PLOT.x1 - PLOT.x0}
                  height={dy(40) - dy(26)}
                  fill={AIR_PALE}
                  opacity={0.35}
                />
                <text x={PLOT.x0 + 15} y={dy(35)} fill={AIR} fontSize={16} fontWeight={800}>
                  MILD LOSS (26-40 dB)
                </text>

                {/* Moderate Zone: 41 to 55 dB */}
                <rect
                  x={PLOT.x0}
                  y={dy(41)}
                  width={PLOT.x1 - PLOT.x0}
                  height={dy(55) - dy(41)}
                  fill={AIR_PALE}
                  opacity={0.55}
                />
                <text x={PLOT.x0 + 15} y={dy(50)} fill={AIR} fontSize={16} fontWeight={800}>
                  MODERATE LOSS (41-55 dB)
                </text>

                {/* Severe Zone: 71 to 90 dB */}
                <rect
                  x={PLOT.x0}
                  y={dy(71)}
                  width={PLOT.x1 - PLOT.x0}
                  height={dy(90) - dy(71)}
                  fill={STOP_PALE}
                  opacity={0.45}
                />
                <text x={PLOT.x0 + 15} y={dy(82)} fill={STOP} fontSize={16} fontWeight={800}>
                  SEVERE LOSS (71-90 dB)
                </text>
              </g>

              <TabCard
                x={540}
                y={200}
                title="WHEN THRESHOLDS FALL"
                ruleColor={STOP}
                scale={easeStamp((frame - 457) / 14)}
              />
              <Chip
                x={540}
                y={260}
                text="MILD · MODERATE · SEVERE LEVELS"
                variant="black"
              />
            </svg>
          )}
        </div>
      )}

      {/* =========================================================================
          REGISTER 2: HOST CLIP 1 (Frames 579 to 758 · 179 frames · 5.97s)
          Professional Studio Take 1 in Moving Video Playback via <Sequence>
          "Mild, moderate, ya severe hearing loss... bhai ye koi fancy English terms nahi hain!"
          ========================================================================= */}
      <Sequence from={579} durationInFrames={179} layout="none">
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          {/* Moving Video Element with Preserved Full 30fps Playback, Synchronized Lip Landmarks & Automatic Audio Mute */}
          <OffthreadVideo
            src={staticFile('clips/audiogram2_clip1_synced.mp4')}
            muted
            style={{ width: W, height: H, objectFit: 'cover' }}
          />

          {/* Refined Clinical Glass Bento Badge (Safe Top-Left Zone, Clear of Face/Hair) */}
          <div
            style={{
              position: 'absolute',
              top: 90,
              left: 60,
              backgroundColor: 'rgba(255, 255, 255, 0.94)',
              backdropFilter: 'blur(16px)',
              WebkitBackdropFilter: 'blur(16px)',
              border: '1.5px solid rgba(228, 222, 204, 0.95)',
              borderRadius: 22,
              padding: '18px 26px',
              boxShadow: '0 12px 36px rgba(38, 36, 48, 0.14)',
              display: 'flex',
              flexDirection: 'column',
              gap: 8,
              pointerEvents: 'none',
              maxWidth: 480,
            }}
          >
            {/* Category Pip & Title */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div
                style={{
                  width: 10,
                  height: 10,
                  borderRadius: '50%',
                  backgroundColor: '#DF7A2B',
                  boxShadow: '0 0 10px rgba(223, 122, 43, 0.6)',
                }}
              />
              <span
                style={{
                  fontFamily: 'Inter, system-ui, sans-serif',
                  fontSize: 14,
                  fontWeight: 800,
                  color: '#DF7A2B',
                  letterSpacing: '0.12em',
                  textTransform: 'uppercase',
                }}
              >
                Clinical Reality Check
              </span>
            </div>

            {/* Headline */}
            <div
              style={{
                fontFamily: 'Inter, system-ui, sans-serif',
                fontSize: 26,
                fontWeight: 800,
                color: '#262430',
                lineHeight: 1.25,
              }}
            >
              Severity is Loudness, Not Jargon
            </div>

            {/* Severity Sub-Badges */}
            <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
              <span
                style={{
                  fontSize: 13,
                  fontWeight: 700,
                  color: '#5B5970',
                  backgroundColor: 'rgba(38, 36, 48, 0.06)',
                  padding: '5px 12px',
                  borderRadius: 10,
                }}
              >
                Mild (26–40 dB)
              </span>
              <span
                style={{
                  fontSize: 13,
                  fontWeight: 700,
                  color: '#DF7A2B',
                  backgroundColor: 'rgba(223, 122, 43, 0.12)',
                  padding: '5px 12px',
                  borderRadius: 10,
                }}
              >
                Moderate (41–55 dB)
              </span>
              <span
                style={{
                  fontSize: 13,
                  fontWeight: 700,
                  color: '#C63B3B',
                  backgroundColor: 'rgba(198, 59, 59, 0.12)',
                  padding: '5px 12px',
                  borderRadius: 10,
                }}
              >
                Severe (71–90 dB)
              </span>
            </div>
          </div>
        </div>
      </Sequence>

      {/* =========================================================================
          REGISTER 3: CODE-DRAWN MOTION GRAPHICS (Frames 758 to 1293 · 535 frames · 17.83s)
          S07: Real Volume Attenuation Slider (758 to 885)
          S08: Mild Loss (26-40 dB) Whisper Lost (885 to 1010)
          S09: Moderate Loss (41-55 dB) Normal Speech Muffled (1010 to 1150)
          S10: Severe Loss (71-90 dB) Shouting Threshold Barrier (1150 to 1293)
          ========================================================================= */}
      {frame >= 758 && frame < 1293 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          {/* S07: Master Volume Slider Card (Frames 758 to 885) */}
          {frame < 885 && (
            <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
              <g transform="translate(140, 480)">
                <rect
                  width={800}
                  height={640}
                  rx={28}
                  fill="white"
                  stroke={GRID}
                  strokeWidth={2}
                  style={{ filter: 'drop-shadow(0 16px 40px rgba(38,36,48,0.08))' }}
                />
                <text x={400} y={70} textAnchor="middle" fill={STOP} fontSize={22} fontWeight={800} letterSpacing={2}>
                  REAL-WORLD IMPACT
                </text>
                <text x={400} y={130} textAnchor="middle" fill={INK} fontSize={44} fontWeight={800}>
                  Duniya Ka Volume Kam Ho Gaya
                </text>

                {/* Vertical Master Volume Fader Rig */}
                <g transform="translate(400, 360)">
                  {/* Track */}
                  <rect x={-20} y={-160} width={40} height={320} rx={20} fill={SLATE.s100} />
                  {/* Fill */}
                  {(() => {
                    const faderProgress = clamp((frame - 765) / 60);
                    const handleY = -120 + faderProgress * 200; // slides downward
                    const fillHeight = 160 - handleY;
                    return (
                      <>
                        <rect
                          x={-20}
                          y={handleY}
                          width={40}
                          height={fillHeight}
                          rx={20}
                          fill={STOP}
                        />
                        {/* Fader Handle */}
                        <g transform={`translate(0, ${handleY})`}>
                          <rect
                            x={-60}
                            y={-22}
                            width={120}
                            height={44}
                            rx={14}
                            fill="white"
                            stroke={INK}
                            strokeWidth={3}
                            style={{ filter: 'drop-shadow(0 4px 12px rgba(38,36,48,0.18))' }}
                          />
                          <line x1={-30} y1={0} x2={30} y2={0} stroke={INK} strokeWidth={3} />
                        </g>
                      </>
                    );
                  })()}
                </g>

                {/* Level tags */}
                <g transform="translate(560, 360)">
                  <text x={0} y={-110} fill={OK} fontSize={20} fontWeight={800}>100% · Normal</text>
                  <text x={0} y={-20} fill={AIR} fontSize={20} fontWeight={800}>60% · Mild Loss</text>
                  <text x={0} y={80} fill={STOP} fontSize={20} fontWeight={800}>20% · Severe Loss</text>
                </g>
              </g>

              <TabCard
                x={540}
                y={200}
                title="VOLUME ATTENUATION"
                ruleColor={STOP}
              />
            </svg>
          )}

          {/* S08: Mild Loss · Whisper Cutoff (Frames 885 to 1010) */}
          {frame >= 885 && frame < 1010 && (
            <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
              <AudSheet
                sheetTitle="AUDIOGRAM REPORT"
                airValues={CURVES.MILD}
                airProgress={1}
                opacity={0.3}
              />
              <g transform="translate(140, 480)">
                <rect
                  width={800}
                  height={620}
                  rx={28}
                  fill="white"
                  stroke={GRID}
                  strokeWidth={2}
                  style={{ filter: 'drop-shadow(0 16px 40px rgba(38,36,48,0.08))' }}
                />
                <text x={400} y={65} textAnchor="middle" fill={STOP} fontSize={22} fontWeight={800} letterSpacing={2}>
                  STAGE 1 · MILD LOSS (26–40 dB)
                </text>
                <text x={400} y={125} textAnchor="middle" fill={INK} fontSize={40} fontWeight={800}>
                  Whisper Sunna Band!
                </text>

                {/* Diagram: Whisper Lost Against Barrier */}
                <g transform="translate(200, 280)">
                  <circle cx={0} cy={0} r={55} fill={SLATE.s100} stroke={GRID} strokeWidth={2.5} />
                  <text x={0} y={14} textAnchor="middle" fontSize={42}>🤫</text>
                  <text x={0} y={85} textAnchor="middle" fill={INK_SOFT} fontSize={18} fontWeight={700}>
                    Faint Whisper (20 dB)
                  </text>
                </g>

                {/* Red X Cross Barrier */}
                <g transform="translate(400, 280)">
                  <circle cx={0} cy={0} r={46} fill={STOP_PALE} stroke={STOP} strokeWidth={3} />
                  <text x={0} y={15} textAnchor="middle" fill={STOP} fontSize={42} fontWeight={900}>✕</text>
                  <text x={0} y={85} textAnchor="middle" fill={STOP} fontSize={18} fontWeight={800}>
                    Threshold Dropped
                  </text>
                </g>

                {/* Deaf Ear / Brain */}
                <g transform="translate(600, 280)">
                  <circle cx={0} cy={0} r={55} fill={SLATE.s50} stroke={GRID} strokeWidth={2.5} />
                  <text x={0} y={14} textAnchor="middle" fontSize={42}>👂</text>
                  <text x={0} y={85} textAnchor="middle" fill={INK_SOFT} fontSize={18} fontWeight={700}>
                    No Sound Reaches
                  </text>
                </g>

                {/* Bottom Tag */}
                <g transform="translate(400, 490)">
                  <rect x={-320} y={0} width={640} height={54} rx={27} fill={STOP_PALE} stroke={STOP} strokeWidth={2} />
                  <text x={0} y={35} textAnchor="middle" fill={STOP} fontSize={19} fontWeight={800} letterSpacing={0.5}>
                    🚫 20 dB SOUNDS BECOME INAUDIBLE
                  </text>
                </g>
              </g>

              <TabCard
                x={540}
                y={200}
                title="MILD HEARING LOSS"
                ruleColor={STOP}
              />
            </svg>
          )}

          {/* S09: Moderate Loss · Normal Speech Muffled (Frames 1010 to 1150) */}
          {frame >= 1010 && frame < 1150 && (
            <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
              <AudSheet
                sheetTitle="AUDIOGRAM REPORT"
                airValues={CURVES.MODERATE}
                airProgress={1}
                opacity={0.3}
              />
              <g transform="translate(140, 480)">
                <rect
                  width={800}
                  height={620}
                  rx={28}
                  fill="white"
                  stroke={GRID}
                  strokeWidth={2}
                  style={{ filter: 'drop-shadow(0 16px 40px rgba(38,36,48,0.08))' }}
                />
                <text x={400} y={65} textAnchor="middle" fill={AIR} fontSize={22} fontWeight={800} letterSpacing={2}>
                  STAGE 2 · MODERATE LOSS (41–55 dB)
                </text>
                <text x={400} y={125} textAnchor="middle" fill={INK} fontSize={40} fontWeight={800}>
                  Normal Baat-Cheet Bhi Dabi Hui
                </text>

                {/* Visual Muffled Waveform Representation */}
                <g transform="translate(400, 290)">
                  {/* Speech Bubble */}
                  <rect x={-260} y={-80} width={520} height={160} rx={24} fill={SLATE.s50} stroke={GRID} strokeWidth={2} />
                  <text x={0} y={-35} textAnchor="middle" fill={INK_SOFT} fontSize={20} fontWeight={700}>
                    Normal Speech (~60 dB) Passing Through
                  </text>
                  {/* Attenuated / Flattened Waves */}
                  <path
                    d={`M -200 30 Q -100 ${30 - 35 * Math.sin((frame - 1010) / 6)} 0 30 T 200 30`}
                    fill="none"
                    stroke={AIR}
                    strokeWidth={4.5}
                    strokeDasharray="10 6"
                  />
                </g>

                {/* Subtitle Muffled Tag */}
                <g transform="translate(400, 480)">
                  <rect x={-280} y={0} width={560} height={52} rx={26} fill={AIR_PALE} stroke={AIR} strokeWidth={2} />
                  <text x={0} y={33} textAnchor="middle" fill={AIR} fontSize={22} fontWeight={800}>
                    🔉 COMPRESSED & LOW CLARITY
                  </text>
                </g>
              </g>

              <TabCard
                x={540}
                y={200}
                title="MODERATE HEARING LOSS"
                ruleColor={AIR}
              />
            </svg>
          )}

          {/* S10: Severe Loss · Shouting Threshold (Frames 1150 to 1293) */}
          {frame >= 1150 && (
            <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
              <AudSheet
                sheetTitle="AUDIOGRAM REPORT"
                airValues={CURVES.SEVERE}
                airProgress={1}
                opacity={0.3}
              />
              <g transform="translate(140, 480)">
                <rect
                  width={800}
                  height={620}
                  rx={28}
                  fill="white"
                  stroke={GRID}
                  strokeWidth={2}
                  style={{ filter: 'drop-shadow(0 16px 40px rgba(38,36,48,0.08))' }}
                />
                <text x={400} y={65} textAnchor="middle" fill={STOP} fontSize={22} fontWeight={800} letterSpacing={2}>
                  STAGE 3 · SEVERE LOSS (71–90 dB)
                </text>
                <text x={400} y={125} textAnchor="middle" fill={INK} fontSize={40} fontWeight={800}>
                  Jab Tak Koi Aake Chillaye Na...
                </text>

                {/* Shouting Pulse Barrier Animation */}
                <g transform="translate(180, 290)">
                  <circle cx={0} cy={0} r={55} fill={STOP_PALE} stroke={STOP} strokeWidth={3} />
                  <text x={0} y={14} textAnchor="middle" fontSize={46}>📢</text>
                  <text x={0} y={85} textAnchor="middle" fill={STOP} fontSize={20} fontWeight={800}>
                    Shouting (85 dB)
                  </text>
                </g>

                {/* Barrier Wall */}
                <g transform="translate(400, 290)">
                  <rect x={-15} y={-90} width={30} height={180} rx={12} fill={STOP} />
                  <text x={-25} y={-100} textAnchor="middle" fill={STOP} fontSize={16} fontWeight={800}>
                    70 dB BARRIER
                  </text>
                </g>

                {/* Right: Brain Finally Awakening */}
                <g transform="translate(620, 290)">
                  <circle cx={0} cy={0} r={55} fill={SLATE.s100} stroke={INK_SOFT} strokeWidth={3} />
                  <text x={0} y={14} textAnchor="middle" fontSize={46}>🧠</text>
                  <text x={0} y={85} textAnchor="middle" fill={INK_SOFT} fontSize={20} fontWeight={700}>
                    Only Shouts Reach
                  </text>
                </g>

                {/* Bottom Tag */}
                <g transform="translate(400, 500)">
                  <rect x={-260} y={0} width={520} height={52} rx={26} fill={STOP} />
                  <text x={0} y={34} textAnchor="middle" fill="white" fontSize={22} fontWeight={800}>
                    ⚠ QUIET & NORMAL SPEECH INAUDIBLE
                  </text>
                </g>
              </g>

              <TabCard
                x={540}
                y={200}
                title="SEVERE HEARING LOSS"
                ruleColor={STOP}
              />
            </svg>
          )}
        </div>
      )}

      {/* =========================================================================
          REGISTER 4: HOST CLIP 2 (Frames 1293 to 1462 · 169 frames · 5.63s)
          Professional Studio Take 2 in Moving Video Playback via <Sequence>
          "Toh isiliye graph pe 2 alag-alag lines banti hain, aur inke beech ka gap yeh batata hai..."
          ========================================================================= */}
      <Sequence from={1293} durationInFrames={169} layout="none">
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          {/* Moving Video Element with Preserved Full 30fps Playback & Automatic Audio Mute */}
          <OffthreadVideo
            src={staticFile('clips/audiogram2_clip2.mp4')}
            muted
            style={{ width: W, height: H, objectFit: 'cover' }}
          />

          {/* Refined Clinical Glass Bento Badge (Safe Top-Left Zone, Clear of Face/Hair) */}
          <div
            style={{
              position: 'absolute',
              top: 90,
              left: 60,
              backgroundColor: 'rgba(255, 255, 255, 0.94)',
              backdropFilter: 'blur(16px)',
              WebkitBackdropFilter: 'blur(16px)',
              border: '1.5px solid rgba(228, 222, 204, 0.95)',
              borderRadius: 22,
              padding: '18px 26px',
              boxShadow: '0 12px 36px rgba(38, 36, 48, 0.14)',
              display: 'flex',
              flexDirection: 'column',
              gap: 8,
              pointerEvents: 'none',
              maxWidth: 480,
            }}
          >
            {/* Category Pip & Title */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div
                style={{
                  width: 10,
                  height: 10,
                  borderRadius: '50%',
                  backgroundColor: '#2E56C9',
                  boxShadow: '0 0 10px rgba(46, 86, 201, 0.6)',
                }}
              />
              <span
                style={{
                  fontFamily: 'Inter, system-ui, sans-serif',
                  fontSize: 14,
                  fontWeight: 800,
                  color: '#2E56C9',
                  letterSpacing: '0.12em',
                  textTransform: 'uppercase',
                }}
              >
                Diagnostic Protocol
              </span>
            </div>

            {/* Headline */}
            <div
              style={{
                fontFamily: 'Inter, system-ui, sans-serif',
                fontSize: 26,
                fontWeight: 800,
                color: '#262430',
                lineHeight: 1.25,
              }}
            >
              The 2 Lines: Air vs Bone Conduction
            </div>

            {/* Dual Line Indicators */}
            <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
              <span
                style={{
                  fontSize: 13,
                  fontWeight: 700,
                  color: '#DF7A2B',
                  backgroundColor: 'rgba(223, 122, 43, 0.12)',
                  padding: '5px 12px',
                  borderRadius: 10,
                }}
              >
                Air Line (O) · Full Ear
              </span>
              <span
                style={{
                  fontSize: 13,
                  fontWeight: 700,
                  color: '#2E56C9',
                  backgroundColor: 'rgba(46, 86, 201, 0.12)',
                  padding: '5px 12px',
                  borderRadius: 10,
                }}
              >
                Bone Line (&lt;) · Direct Cochlea
              </span>
            </div>
          </div>
        </div>
      </Sequence>

      {/* =========================================================================
          REGISTER 5: CODE-DRAWN MOTION GRAPHICS (Frames 1462 to 1705 · 243 frames · 8.10s)
          Dynamic Clinical Explainer & Storytelling Animation (Eliminating All Static Frames)
          - Beat 1 (Frames 1462 to 1530): Full Audiogram Air-Bone Gap Caliper Focus
          - Beat 2 (Frames 1530 to 1610): Full Anatomical Conduction Engine (Middle Ear Blockage vs Intact Cochlea)
          - Beat 3 (Frames 1610 to 1665): Clinical Decision Matrix Rule Card (ABG ≥ 15 dB)
          - Beat 4 (Frames 1665 to 1705): Part 3 Teaser & Clinic Follow CTA
          ========================================================================= */}
      {frame >= 1462 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          {/* Beat 1: Full Clinical Audiogram Sheet Focus (Frames 1462 to 1530) */}
          {frame < 1530 && (
            <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
              <AudSheet
                sheetTitle="AUDIOGRAM REPORT"
                airValues={CURVES.AIR_CONDUCTIVE}
                boneValues={CURVES.BONE_NORMAL}
                airProgress={1}
                boneProgress={1}
                opacity={1}
                highlightGap={{ startDb: 15, endDb: 50, freq: 1000, label: 'AIR-BONE GAP' }}
              />

              <TabCard
                x={540}
                y={160}
                title="THE AIR-BONE GAP"
                ruleColor={BONE}
                scale={easeStamp((frame - 1462) / 14)}
              />
              <Chip
                x={540}
                y={224}
                text="BONE NORMAL (15 dB) · AIR DROPPED (50 dB)"
                variant="white"
                scale={easeStamp((frame - 1474) / 14)}
              />
            </svg>
          )}

          {/* Beat 2: Two-Lane Clinical Pathway Schematic (Frames 1530 to 1610 · 51s to 53.7s) */}
          {frame >= 1530 && frame < 1610 && (
            <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
              {/* Central Bento Housing Card */}
              <g transform="translate(110, 390)">
                <rect
                  width={860}
                  height={800}
                  rx={28}
                  fill="white"
                  stroke={GRID}
                  strokeWidth={2}
                  style={{ filter: 'drop-shadow(0 20px 48px rgba(38,36,48,0.10))' }}
                />

                {/* Card Header */}
                <text x={430} y={65} textAnchor="middle" fill={BONE} fontSize={20} fontWeight={800} letterSpacing={2}>
                  ANATOMICAL SITE LOCALIZATION
                </text>
                <text x={430} y={120} textAnchor="middle" fill={INK} fontSize={38} fontWeight={800}>
                  Kaan Ke Kis Hissay Me Problem Hai?
                </text>
                <line x1={80} y1={155} x2={780} y2={155} stroke={GRID} strokeWidth={1.5} />

                {/* Lane 1: Conductive Pathway (Outer & Middle Ear) */}
                <g transform="translate(60, 190)">
                  <rect
                    width={740}
                    height={235}
                    rx={20}
                    fill="rgba(223, 122, 43, 0.08)"
                    stroke={AIR}
                    strokeWidth={2}
                  />
                  {/* Category Pill */}
                  <g transform="translate(30, 26)">
                    <rect width={280} height={36} rx={18} fill={AIR} />
                    <text x={140} y={24} textAnchor="middle" fill="white" fontSize={16} fontWeight={800}>
                      👂 1. CONDUCTIVE PATHWAY
                    </text>
                  </g>
                  {/* Anatomical Structure */}
                  <text x={30} y={105} fill={INK} fontSize={28} fontWeight={800}>
                    Outer Ear & Middle Ear
                  </text>
                  <text x={30} y={140} fill={INK_SOFT} fontSize={20} fontWeight={600}>
                    Pinna → Ear Canal → Tympanic Membrane → Ossicles
                  </text>
                  {/* Diagnostic Indicator */}
                  <g transform="translate(30, 168)">
                    <rect width={680} height={44} rx={10} fill="white" stroke={AIR_PALE} strokeWidth={1.5} />
                    <text x={20} y={28} fill={AIR} fontSize={17} fontWeight={800}>
                      Air Conduction (O): Dropped when blocked by wax or fluid
                    </text>
                  </g>
                </g>

                {/* Lane 2: Sensorineural Pathway (Inner Ear / Cochlea) */}
                <g transform="translate(60, 465)">
                  <rect
                    width={740}
                    height={235}
                    rx={20}
                    fill="rgba(46, 86, 201, 0.08)"
                    stroke={BONE}
                    strokeWidth={2}
                  />
                  {/* Category Pill */}
                  <g transform="translate(30, 26)">
                    <rect width={310} height={36} rx={18} fill={BONE} />
                    <text x={155} y={24} textAnchor="middle" fill="white" fontSize={16} fontWeight={800}>
                      🐚 2. SENSORINEURAL PATHWAY
                    </text>
                  </g>
                  {/* Anatomical Structure */}
                  <text x={30} y={105} fill={INK} fontSize={28} fontWeight={800}>
                    Inner Ear (Cochlea) & Nerve
                  </text>
                  <text x={30} y={140} fill={INK_SOFT} fontSize={20} fontWeight={600}>
                    Sensory Hair Cells → Auditory Nerve (CN VIII) → Brain
                  </text>
                  {/* Diagnostic Indicator */}
                  <g transform="translate(30, 168)">
                    <rect width={680} height={44} rx={10} fill="white" stroke={BONE_PALE} strokeWidth={1.5} />
                    <text x={20} y={28} fill={BONE} fontSize={17} fontWeight={800}>
                      Bone Conduction (&lt;): Preserved normal if cochlea is healthy
                    </text>
                  </g>
                </g>

                {/* Bottom Clinical Conclusion */}
                <g transform="translate(430, 755)">
                  <text x={0} y={0} textAnchor="middle" fill={INK_SOFT} fontSize={18} fontWeight={700}>
                    Inke beech ka GAP batata hai problem kahan hai
                  </text>
                </g>
              </g>

              {/* Top Banner Tabs */}
              <TabCard
                x={540}
                y={190}
                title="SITE OF PATHOLOGY"
                ruleColor={BONE}
                scale={easeStamp((frame - 1530) / 14)}
              />
              <Chip
                x={540}
                y={254}
                text="OUTER/MIDDLE EAR VS COCHLEA"
                variant="white"
                scale={easeStamp((frame - 1542) / 14)}
              />
            </svg>
          )}

          {/* Beat 3: Clinical Decision Matrix (Frames 1610 to 1665) */}
          {frame >= 1610 && frame < 1665 && (
            <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
              <g transform="translate(120, 420)">
                <rect
                  width={840}
                  height={720}
                  rx={28}
                  fill="white"
                  stroke={GRID}
                  strokeWidth={2}
                  style={{ filter: 'drop-shadow(0 20px 48px rgba(38,36,48,0.12))' }}
                />
                <text x={420} y={65} textAnchor="middle" fill={BONE} fontSize={20} fontWeight={800} letterSpacing={2}>
                  CLINICAL DIAGNOSTIC RULE
                </text>
                <text x={420} y={120} textAnchor="middle" fill={INK} fontSize={40} fontWeight={800}>
                  Air-Bone Gap Ka Faisla
                </text>

                {/* Card A: Air-Bone Gap Present >= 15 dB */}
                <g transform="translate(50, 170)">
                  <rect
                    width={740}
                    height={215}
                    rx={20}
                    fill="rgba(223, 122, 43, 0.08)"
                    stroke={AIR}
                    strokeWidth={2.5}
                  />
                  <g transform="translate(30, 42)">
                    <rect width={220} height={34} rx={17} fill={AIR} />
                    <text x={110} y={23} textAnchor="middle" fill="white" fontSize={16} fontWeight={800}>
                      GAP PRESENT (≥15 dB)
                    </text>
                  </g>
                  <text x={30} y={120} fill={INK} fontSize={28} fontWeight={800}>
                    Conductive Hearing Loss
                  </text>
                  <text x={30} y={155} fill={INK_SOFT} fontSize={20} fontWeight={600}>
                    Outer Ear (Wax) ya Middle Ear (Fluid / Bone Fixation)
                  </text>
                  <text x={30} y={190} fill={OK} fontSize={18} fontWeight={800}>
                    ✓ Frequently Medically or Surgically Treatable
                  </text>
                </g>

                {/* Card B: No Air-Bone Gap */}
                <g transform="translate(50, 435)">
                  <rect
                    width={740}
                    height={215}
                    rx={20}
                    fill="rgba(46, 86, 201, 0.08)"
                    stroke={BONE}
                    strokeWidth={2.5}
                  />
                  <g transform="translate(30, 42)">
                    <rect width={230} height={34} rx={17} fill={BONE} />
                    <text x={115} y={23} textAnchor="middle" fill="white" fontSize={16} fontWeight={800}>
                      NO GAP (LINES OVERLAP)
                    </text>
                  </g>
                  <text x={30} y={120} fill={INK} fontSize={28} fontWeight={800}>
                    Sensorineural Hearing Loss
                  </text>
                  <text x={30} y={155} fill={INK_SOFT} fontSize={20} fontWeight={600}>
                    Inner Ear Cochlea (Hair Cells) ya Auditory Nerve
                  </text>
                  <text x={30} y={190} fill={BONE} fontSize={18} fontWeight={800}>
                    ⚙ Requires Hearing Aid / Cochlear Rehabilitation
                  </text>
                </g>
              </g>

              <TabCard
                x={540}
                y={200}
                title="DIAGNOSTIC CRITERIA"
                ruleColor={BONE}
                scale={easeStamp((frame - 1610) / 14)}
              />
            </svg>
          )}

          {/* Beat 4: Part 3 Teaser & Clinic Follow CTA (Frames 1665 to 1705) */}
          {frame >= 1665 && (
            <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
              <g transform="translate(120, 460)">
                <rect
                  width={840}
                  height={660}
                  rx={28}
                  fill="white"
                  stroke={GRID}
                  strokeWidth={2}
                  style={{ filter: 'drop-shadow(0 20px 48px rgba(38,36,48,0.12))' }}
                />
                <g transform="translate(420, 75)">
                  <rect x={-140} y={0} width={280} height={40} rx={20} fill={BONE_PALE} stroke={BONE} strokeWidth={1.5} />
                  <text x={0} y={26} textAnchor="middle" fill={BONE} fontSize={18} fontWeight={800}>
                    NEXT IN THE SERIES
                  </text>
                </g>

                <text x={420} y={180} textAnchor="middle" fill={INK} fontSize={46} fontWeight={800}>
                  PART 3: DO LINES KA RAAZ
                </text>
                <text x={420} y={235} textAnchor="middle" fill={INK_SOFT} fontSize={24} fontWeight={600}>
                  Air Conduction vs Bone Conduction Decoded
                </text>

                {/* Graphic Preview Comparison Chips */}
                <g transform="translate(420, 340)">
                  <g transform="translate(-180, 0)">
                    <rect x={-150} y={-50} width={300} height={100} rx={20} fill={AIR_PALE} stroke={AIR} strokeWidth={2.5} />
                    <text x={0} y={-10} textAnchor="middle" fill={AIR} fontSize={20} fontWeight={800}>AIR CONDUCTION</text>
                    <text x={0} y={22} textAnchor="middle" fill={INK} fontSize={18} fontWeight={700}>Headphones (O Symbol)</text>
                  </g>
                  <g transform="translate(180, 0)">
                    <rect x={-150} y={-50} width={300} height={100} rx={20} fill={BONE_PALE} stroke={BONE} strokeWidth={2.5} />
                    <text x={0} y={-10} textAnchor="middle" fill={BONE} fontSize={20} fontWeight={800}>BONE CONDUCTION</text>
                    <text x={0} y={22} textAnchor="middle" fill={INK} fontSize={18} fontWeight={700}>Bone Oscillator (&lt; Symbol)</text>
                  </g>
                </g>

                {/* Follow Clinic Action Pill */}
                <g transform="translate(420, 520)">
                  <rect
                    x={-280}
                    y={0}
                    width={560}
                    height={64}
                    rx={32}
                    fill={INK}
                    style={{ filter: 'drop-shadow(0 8px 24px rgba(38,36,48,0.25))' }}
                  />
                  <text x={0} y={40} textAnchor="middle" fill="white" fontSize={24} fontWeight={800} letterSpacing={1}>
                    FOLLOW FOR AUDIOLOGY DECODED ✓
                  </text>
                </g>
              </g>

              <TabCard
                x={540}
                y={200}
                title="COMING UP NEXT"
                ruleColor={AIR}
                scale={easeStamp((frame - 1665) / 14)}
              />
            </svg>
          )}
        </div>
      )}

      {/* 3. Global Synced Captions Layer */}
      <CaptionsLayer />
    </div>
  );
};
