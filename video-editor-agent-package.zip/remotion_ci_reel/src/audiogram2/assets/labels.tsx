import React from 'react';
import {
  PAPER,
  INK,
  AIR,
  BONE,
  OK,
  STOP,
} from '../tokens';

interface ChipProps {
  x: number;
  y: number;
  text: string;
  variant?: 'tangerine' | 'cobalt' | 'red' | 'mint' | 'white' | 'black';
  scale?: number;
  opacity?: number;
  fontSize?: number;
}

export const Chip: React.FC<ChipProps> = ({
  x,
  y,
  text,
  variant = 'black',
  scale = 1,
  opacity = 1,
  fontSize = 32,
}) => {
  let bg = INK;
  let fg = PAPER;
  let stroke = INK;

  if (variant === 'tangerine') {
    bg = AIR;
    fg = '#FFFFFF';
    stroke = AIR;
  } else if (variant === 'cobalt') {
    bg = BONE;
    fg = '#FFFFFF';
    stroke = BONE;
  } else if (variant === 'red') {
    bg = STOP;
    fg = '#FFFFFF';
    stroke = STOP;
  } else if (variant === 'mint') {
    bg = OK;
    fg = '#FFFFFF';
    stroke = OK;
  } else if (variant === 'white') {
    bg = PAPER;
    fg = INK;
    stroke = INK;
  }

  const approxWidth = text.length * (fontSize * 0.62) + 36;
  const height = fontSize + 24;

  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      opacity={opacity}
      style={{ transformOrigin: 'center' }}
    >
      <rect
        x={-approxWidth / 2}
        y={-height / 2}
        width={approxWidth}
        height={height}
        rx={12}
        fill={bg}
        stroke={stroke}
        strokeWidth={3}
      />
      <text
        x={0}
        y={fontSize * 0.35}
        textAnchor="middle"
        fill={fg}
        fontFamily='Inter, "Segoe UI", sans-serif'
        fontSize={fontSize}
        fontWeight={700}
        letterSpacing="0.04em"
      >
        {text}
      </text>
    </g>
  );
};

interface TabCardProps {
  x?: number;
  y?: number;
  title: string;
  ruleColor?: string;
  scale?: number;
  opacity?: number;
}

export const TabCard: React.FC<TabCardProps> = ({
  x = 540,
  y = 200,
  title,
  ruleColor = AIR,
  scale = 1,
  opacity = 1,
}) => {
  // Auto-clamp font size and calculate card width so text never overflows
  const fontSize = title.length > 22 ? 38 : title.length > 16 ? 44 : 52;
  const cardW = Math.max(680, Math.min(940, title.length * (fontSize * 0.62) + 90));
  const cardH = 110;

  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      opacity={opacity}
      style={{ transformOrigin: 'center' }}
    >
      <rect
        x={-cardW / 2}
        y={-cardH / 2}
        width={cardW}
        height={cardH}
        rx={18}
        fill="rgba(246, 242, 233, 0.95)"
        stroke={INK}
        strokeWidth={3.5}
      />
      <text
        x={0}
        y={fontSize * 0.22}
        textAnchor="middle"
        fill={INK}
        fontFamily='Fraunces, "Playfair Display", Georgia, serif'
        fontSize={fontSize}
        fontWeight={750}
      >
        {title}
      </text>
      {/* Accent rule below */}
      <line
        x1={-cardW / 2 + 50}
        y1={cardH / 2 - 12}
        x2={cardW / 2 - 50}
        y2={cardH / 2 - 12}
        stroke={ruleColor}
        strokeWidth={6}
        strokeLinecap="round"
      />
    </g>
  );
};

interface RubricProps {
  caseNum: 1 | 2 | 3;
  x?: number;
  y?: number;
  opacity?: number;
}

export const Rubric: React.FC<RubricProps> = ({
  caseNum,
  x = 140,
  y = 220,
  opacity = 1,
}) => {
  return (
    <g transform={`translate(${x}, ${y})`} opacity={opacity}>
      <text
        x={0}
        y={0}
        fill={INK}
        fontFamily='Fraunces, "Playfair Display", Georgia, serif'
        fontSize={64}
        fontWeight={800}
      >
        CASE {caseNum}
      </text>
      <line x1={0} y1={14} x2={70} y2={14} stroke={INK} strokeWidth={6} strokeLinecap="round" />
    </g>
  );
};

interface SpineProps {
  activeCase: 1 | 2 | 3;
  x?: number;
  y?: number;
}

export const ProgressSpine: React.FC<SpineProps> = ({
  activeCase,
  x = 48,
  y = 480,
}) => {
  return (
    <g transform={`translate(${x}, ${y})`}>
      {/* Spine vertical rail */}
      <line x1={0} y1={0} x2={0} y2={100} stroke={INK} strokeWidth={3} opacity={0.3} />
      {[1, 2, 3].map((num) => {
        const ny = (num - 1) * 50;
        const isActive = num === activeCase;
        const isDone = num < activeCase;
        return (
          <g key={`spine-${num}`} transform={`translate(0, ${ny})`}>
            <circle
              cx={0}
              cy={0}
              r={12}
              fill={isActive ? INK : isDone ? INK : 'none'}
              stroke={INK}
              strokeWidth={3}
              opacity={isActive ? 1 : isDone ? 0.35 : 0.2}
            />
            <text
              x={22}
              y={7}
              fill={INK}
              fontFamily='Inter, "Segoe UI", sans-serif'
              fontSize={20}
              fontWeight={700}
              opacity={isActive ? 1 : 0.35}
            >
              {num}
            </text>
          </g>
        );
      })}
    </g>
  );
};

interface ArrowDownProps {
  x: number;
  y: number;
  scale?: number;
}

export const ArrowDown: React.FC<ArrowDownProps> = ({ x, y, scale = 1 }) => {
  return (
    <g transform={`translate(${x}, ${y}) scale(${scale})`}>
      <line x1={0} y1={-36} x2={0} y2={0} stroke={INK} strokeWidth={4} strokeLinecap="round" />
      <polygon points="-10,-8 0,6 10,-8" fill={INK} />
    </g>
  );
};
