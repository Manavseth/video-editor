import React from 'react';
import {
  PAPER,
  GRID,
  INK,
  INK_SOFT,
  AIR,
  BONE,
  OCTAVES,
  fx,
  dy,
  SHEET,
  PLOT,
} from '../tokens';

interface AudSheetProps {
  sheetTitle?: string;
  airValues?: number[];
  boneValues?: number[];
  airProgress?: number; // 0..1 trace progress
  boneProgress?: number; // 0..1 trace progress
  symbolsProgress?: number; // 0..1
  pulse?: number; // 1.0 baseline
  opacity?: number;
  highlightGap?: { startDb: number; endDb: number; freq: number; label?: string } | null;
}

export const AudSheet: React.FC<AudSheetProps> = ({
  sheetTitle = 'AUDIOGRAM REPORT',
  airValues,
  boneValues,
  airProgress = 1,
  boneProgress = 1,
  symbolsProgress = 1,
  pulse = 1,
  opacity = 1,
  highlightGap = null,
}) => {
  const dbSteps = [0, 25, 50, 75, 100];

  // Helper to create polyline points
  const makePoints = (vals: number[], progress: number) => {
    const pts = OCTAVES.map((freq, idx) => ({
      x: fx(freq),
      y: dy(vals[idx]),
    }));
    if (progress >= 1) return pts;
    const totalCount = Math.floor(progress * (pts.length - 1));
    const rem = (progress * (pts.length - 1)) - totalCount;
    const res = pts.slice(0, totalCount + 1);
    if (totalCount < pts.length - 1) {
      const p1 = pts[totalCount];
      const p2 = pts[totalCount + 1];
      res.push({
        x: p1.x + (p2.x - p1.x) * rem,
        y: p1.y + (p2.y - p1.y) * rem,
      });
    }
    return res;
  };

  const airPts = airValues ? makePoints(airValues, airProgress) : [];
  const bonePts = boneValues ? makePoints(boneValues, boneProgress) : [];

  return (
    <g opacity={opacity} transform={`scale(${pulse})`} style={{ transformOrigin: '540px 790px' }}>
      {/* Sheet background shadow & card */}
      <rect
        x={SHEET.x0 + 6}
        y={SHEET.y0 + 8}
        width={SHEET.x1 - SHEET.x0}
        height={SHEET.y1 - SHEET.y0}
        rx={SHEET.r}
        fill="rgba(38, 36, 48, 0.12)"
      />
      <rect
        x={SHEET.x0}
        y={SHEET.y0}
        width={SHEET.x1 - SHEET.x0}
        height={SHEET.y1 - SHEET.y0}
        rx={SHEET.r}
        fill="#FFFFFF"
        stroke={INK}
        strokeWidth={4}
      />

      {/* Header strip */}
      <text
        x={SHEET.x0 + 36}
        y={SHEET.y0 + 52}
        fill={INK}
        fontFamily='Fraunces, "Playfair Display", Georgia, serif'
        fontSize={36}
        fontWeight={700}
      >
        {sheetTitle}
      </text>

      {/* Legend chips */}
      <g transform={`translate(${SHEET.x1 - 320}, ${SHEET.y0 + 26})`}>
        {/* Air Chip */}
        <circle cx={14} cy={14} r={10} fill="none" stroke={AIR} strokeWidth={3.5} />
        <text
          x={32}
          y={22}
          fill={INK}
          fontFamily='Inter, "Segoe UI", sans-serif'
          fontSize={24}
          fontWeight={700}
        >
          AIR
        </text>

        {/* Bone Chip */}
        <path
          d="M 120 4 L 108 14 L 120 24"
          fill="none"
          stroke={BONE}
          strokeWidth={4}
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <text
          x={132}
          y={22}
          fill={INK}
          fontFamily='Inter, "Segoe UI", sans-serif'
          fontSize={24}
          fontWeight={700}
        >
          BONE
        </text>
      </g>

      {/* Divider */}
      <line
        x1={SHEET.x0}
        y1={SHEET.y0 + 72}
        x2={SHEET.x1}
        y2={SHEET.y0 + 72}
        stroke={GRID}
        strokeWidth={2}
      />

      {/* Plot Grid */}
      {/* Horizontal grid lines & dB labels */}
      {dbSteps.map((db) => {
        const y = dy(db);
        return (
          <g key={`db-${db}`}>
            <line x1={PLOT.x0} y1={y} x2={PLOT.x1} y2={y} stroke={GRID} strokeWidth={2} />
            <text
              x={PLOT.x0 - 18}
              y={y + 8}
              textAnchor="end"
              fill={INK_SOFT}
              fontFamily='Inter, "Segoe UI", sans-serif'
              fontSize={24}
              fontWeight={600}
            >
              {db}
            </text>
          </g>
        );
      })}

      {/* Vertical grid lines & Frequency labels */}
      {OCTAVES.map((freq) => {
        const x = fx(freq);
        const label = freq >= 1000 ? `${freq / 1000}k` : `${freq}`;
        return (
          <g key={`freq-${freq}`}>
            <line x1={x} y1={PLOT.y0} x2={x} y2={PLOT.y1} stroke={GRID} strokeWidth={2} />
            <text
              x={x}
              y={PLOT.y1 + 34}
              textAnchor="middle"
              fill={INK_SOFT}
              fontFamily='Inter, "Segoe UI", sans-serif'
              fontSize={24}
              fontWeight={600}
            >
              {label}
            </text>
          </g>
        );
      })}

      {/* Axis Unit Labels */}
      <text
        x={PLOT.x0 - 18}
        y={PLOT.y0 - 14}
        textAnchor="end"
        fill={INK_SOFT}
        fontFamily='Inter, "Segoe UI", sans-serif'
        fontSize={20}
        fontWeight={700}
      >
        dB HL ↓
      </text>
      <text
        x={PLOT.x1}
        y={PLOT.y1 + 34}
        textAnchor="start"
        fill={INK_SOFT}
        fontFamily='Inter, "Segoe UI", sans-serif'
        fontSize={20}
        fontWeight={700}
      >
        Hz
      </text>

      {/* Highlight Air-Bone Gap with Clinical Precision Calipers */}
      {highlightGap && (
        <g>
          {/* Shaded vertical column spanning the gap */}
          <rect
            x={fx(highlightGap.freq) - 45}
            y={dy(highlightGap.startDb)}
            width={90}
            height={dy(highlightGap.endDb) - dy(highlightGap.startDb)}
            fill="rgba(45, 140, 133, 0.16)"
            stroke="#2D8C85"
            strokeWidth={2}
            strokeDasharray="6 4"
            rx={8}
          />

          {/* Precision Vertical Caliper Dimension Line */}
          <line
            x1={fx(highlightGap.freq)}
            y1={dy(highlightGap.startDb) + 8}
            x2={fx(highlightGap.freq)}
            y2={dy(highlightGap.endDb) - 8}
            stroke="#2D8C85"
            strokeWidth={3.5}
          />
          {/* Caliper End Ticks */}
          <line
            x1={fx(highlightGap.freq) - 20}
            y1={dy(highlightGap.startDb)}
            x2={fx(highlightGap.freq) + 20}
            y2={dy(highlightGap.startDb)}
            stroke="#2D8C85"
            strokeWidth={3.5}
            strokeLinecap="round"
          />
          <line
            x1={fx(highlightGap.freq) - 20}
            y1={dy(highlightGap.endDb)}
            x2={fx(highlightGap.freq) + 20}
            y2={dy(highlightGap.endDb)}
            stroke="#2D8C85"
            strokeWidth={3.5}
            strokeLinecap="round"
          />

          {/* Caliper Arrowheads */}
          <path
            d={`M ${fx(highlightGap.freq) - 8} ${dy(highlightGap.startDb) + 14} L ${fx(highlightGap.freq)} ${dy(highlightGap.startDb) + 2} L ${fx(highlightGap.freq) + 8} ${dy(highlightGap.startDb) + 14}`}
            fill="none"
            stroke="#2D8C85"
            strokeWidth={3}
            strokeLinecap="round"
          />
          <path
            d={`M ${fx(highlightGap.freq) - 8} ${dy(highlightGap.endDb) - 14} L ${fx(highlightGap.freq)} ${dy(highlightGap.endDb) - 2} L ${fx(highlightGap.freq) + 8} ${dy(highlightGap.endDb) - 14}`}
            fill="none"
            stroke="#2D8C85"
            strokeWidth={3}
            strokeLinecap="round"
          />

          {/* Clean Clinical Callout Badge */}
          {highlightGap.label && (
            <g transform={`translate(${fx(highlightGap.freq) + 65}, ${dy((highlightGap.startDb + highlightGap.endDb) / 2)})`}>
              <rect
                x={0}
                y={-34}
                width={220}
                height={68}
                rx={12}
                fill="white"
                stroke="#2D8C85"
                strokeWidth={2.5}
                style={{ filter: 'drop-shadow(0 6px 16px rgba(45,140,133,0.18))' }}
              />
              <text
                x={110}
                y={-8}
                textAnchor="middle"
                fill="#2D8C85"
                fontFamily='Inter, "Segoe UI", sans-serif'
                fontSize={18}
                fontWeight={800}
                letterSpacing={0.5}
              >
                {highlightGap.label}
              </text>
              <text
                x={110}
                y={18}
                textAnchor="middle"
                fill={INK_SOFT}
                fontFamily='Inter, "Segoe UI", sans-serif'
                fontSize={15}
                fontWeight={700}
              >
                Δ = {highlightGap.endDb - highlightGap.startDb} dB HL Gap
              </text>
            </g>
          )}
        </g>
      )}

      {/* Bone Conduction Line (Cobalt Dashed) */}
      {bonePts.length > 1 && (
        <path
          d={bonePts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ')}
          fill="none"
          stroke={BONE}
          strokeWidth={6}
          strokeDasharray="10 6"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      )}

      {/* Bone Symbols (< Open Brackets) */}
      {boneValues &&
        symbolsProgress > 0 &&
        OCTAVES.slice(0, Math.floor(symbolsProgress * OCTAVES.length)).map((freq, i) => {
          const x = fx(freq);
          const y = dy(boneValues[i]);
          return (
            <path
              key={`bone-sym-${freq}`}
              d={`M ${x + 12} ${y - 14} L ${x - 4} ${y} L ${x + 12} ${y + 14}`}
              fill="none"
              stroke={BONE}
              strokeWidth={5}
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          );
        })}

      {/* Air Conduction Line (Tangerine Solid) */}
      {airPts.length > 1 && (
        <path
          d={airPts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ')}
          fill="none"
          stroke={AIR}
          strokeWidth={7}
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      )}

      {/* Air Symbols (O Open Circles) */}
      {airValues &&
        symbolsProgress > 0 &&
        OCTAVES.slice(0, Math.floor(symbolsProgress * OCTAVES.length)).map((freq, i) => {
          const x = fx(freq);
          const y = dy(airValues[i]);
          return (
            <circle
              key={`air-sym-${freq}`}
              cx={x}
              cy={y}
              r={12}
              fill={PAPER}
              stroke={AIR}
              strokeWidth={5}
            />
          );
        })}
    </g>
  );
};
