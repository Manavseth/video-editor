import React from 'react';
import {
  SLATE,
  INK,
  INK_SOFT,
  AIR,
  BONE,
  OK,
  STOP,
  WAX,
  TM_FILL,
  HEAD,
} from '../tokens';

interface HeadCutProps {
  x?: number;
  y?: number;
  scale?: number;
  opacity?: number;
  airRouteProgress?: number; // 0..1
  boneRouteProgress?: number; // 0..1
  tokensTraveling?: boolean; // convoy dots along air path
  tokensProgress?: number;
  hasHeadphones?: boolean;
  hasBoneVibrator?: boolean;
  hasWaxBlock?: boolean;
  cochleaState?: 'healthy' | 'damaged' | 'neutral';
  nerveState?: 'healthy' | 'weak';
  chevronsProgress?: number;
}

export const HeadCut: React.FC<HeadCutProps> = ({
  x = HEAD.x0,
  y = HEAD.y0,
  scale = 1,
  opacity = 1,
  airRouteProgress = 0,
  boneRouteProgress = 0,
  tokensTraveling = false,
  tokensProgress = 0,
  hasHeadphones = false,
  hasBoneVibrator = false,
  hasWaxBlock = false,
  cochleaState = 'healthy',
  nerveState = 'healthy',
  chevronsProgress = 0,
}) => {
  // Origin offset for internal relative coordinates (640x680 box)
  const ox = 0;
  const oy = 0;

  // Pinna anchor
  const EA = { x: 380, y: 340 };
  // Mastoid anchor
  const MS = { x: 280, y: 390 };
  // Cochlea center
  const CL = { x: 590, y: 530 };

  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      opacity={opacity}
      style={{ transformOrigin: '400px 400px' }}
    >
      {/* 1. Ground shadow */}
      <ellipse cx={ox + 460} cy={oy + 620} rx={220} ry={48} fill="rgba(38, 36, 48, 0.14)" />

      {/* 2. Skull silhouette & Profile (Isometric view facing lower-left) */}
      <path
        d={`
          M ${ox + 260} ${oy + 220}
          C ${ox + 340} ${oy + 140}, ${ox + 480} ${oy + 140}, ${ox + 580} ${oy + 220}
          C ${ox + 660} ${oy + 290}, ${ox + 680} ${oy + 420}, ${ox + 640} ${oy + 520}
          C ${ox + 600} ${oy + 600}, ${ox + 480} ${oy + 620}, ${ox + 380} ${oy + 610}
          C ${ox + 300} ${oy + 600}, ${ox + 230} ${oy + 530}, ${ox + 220} ${oy + 440}
          C ${ox + 210} ${oy + 340}, ${ox + 220} ${oy + 260}, ${ox + 260} ${oy + 220}
          Z
        `}
        fill={SLATE.s100}
        stroke={INK}
        strokeWidth={4}
      />
      {/* Top skull plane highlight */}
      <path
        d={`
          M ${ox + 280} ${oy + 230}
          C ${ox + 360} ${oy + 160}, ${ox + 470} ${oy + 160}, ${ox + 550} ${oy + 230}
          C ${ox + 480} ${oy + 260}, ${ox + 360} ${oy + 260}, ${ox + 280} ${oy + 230}
          Z
        `}
        fill={SLATE.s50}
        opacity={0.8}
      />

      {/* Mastoid region behind ear */}
      <rect
        x={ox + MS.x - 45}
        y={oy + MS.y - 35}
        width={90}
        height={70}
        rx={18}
        fill={SLATE.s200}
        stroke={hasBoneVibrator ? BONE : INK_SOFT}
        strokeWidth={hasBoneVibrator ? 4 : 2}
        strokeDasharray={hasBoneVibrator ? '6 4' : 'none'}
      />
      <text
        x={ox + MS.x}
        y={oy + MS.y + 5}
        textAnchor="middle"
        fill={INK_SOFT}
        fontFamily='Inter, "Segoe UI", sans-serif'
        fontSize={16}
        fontWeight={700}
      >
        MASTOID
      </text>

      {/* 3. Cutaway Window */}
      <rect
        x={ox + 320}
        y={oy + 260}
        width={340}
        height={320}
        rx={32}
        fill="#FFFFFF"
        stroke={SLATE.s300}
        strokeWidth={6}
      />

      {/* Ear Canal (Tube from pinna mouth to TM) */}
      <path
        d={`
          M ${ox + EA.x} ${oy + EA.y + 35}
          C ${ox + 430} ${oy + 380}, ${ox + 480} ${oy + 400}, ${ox + 520} ${oy + 415}
          L ${ox + 520} ${oy + 445}
          C ${ox + 480} ${oy + 430}, ${ox + 430} ${oy + 410}, ${ox + EA.x} ${oy + EA.y + 65}
          Z
        `}
        fill={hasWaxBlock ? 'rgba(198, 59, 59, 0.25)' : SLATE.s50}
        stroke={INK}
        strokeWidth={3}
      />

      {/* Wax Blockage in canal if active */}
      {hasWaxBlock && (
        <g transform={`translate(${ox + 450}, ${oy + 395})`}>
          <ellipse cx={0} cy={10} rx={28} ry={18} fill={WAX} stroke={INK} strokeWidth={3} />
          <path d="M -15 8 Q 0 16 15 8" stroke="#8E6F10" strokeWidth={2} fill="none" />
        </g>
      )}

      {/* Pinna (External Ear) */}
      <g opacity={hasHeadphones ? 0.45 : 1.0}>
        <path
          d={`
            M ${ox + EA.x} ${oy + EA.y - 60}
            C ${ox + EA.x + 50} ${oy + EA.y - 70}, ${ox + EA.x + 80} ${oy + EA.y - 10}, ${ox + EA.x + 65} ${oy + EA.y + 40}
            C ${ox + EA.x + 50} ${oy + EA.y + 80}, ${ox + EA.x + 10} ${oy + EA.y + 85}, ${ox + EA.x - 10} ${oy + EA.y + 65}
            C ${ox + EA.x} ${oy + EA.y + 40}, ${ox + EA.x + 25} ${oy + EA.y + 30}, ${ox + EA.x + 20} ${oy + EA.y - 10}
            C ${ox + EA.x + 15} ${oy + EA.y - 40}, ${ox + EA.x - 5} ${oy + EA.y - 45}, ${ox + EA.x} ${oy + EA.y - 60}
            Z
          `}
          fill={SLATE.s200}
          stroke={INK}
          strokeWidth={4}
        />
        <circle cx={ox + EA.x + 18} cy={oy + EA.y + 55} r={16} fill={SLATE.s100} stroke={INK} strokeWidth={3} />
      </g>

      {/* Tympanic Membrane (Eardrum disc) */}
      <ellipse
        cx={ox + 524}
        cy={oy + 430}
        rx={18}
        ry={30}
        fill={TM_FILL}
        stroke={INK}
        strokeWidth={3.5}
        transform={`rotate(20, ${ox + 524}, ${oy + 430})`}
      />

      {/* Middle Ear Chamber */}
      <ellipse cx={ox + 560} cy={oy + 440} rx={30} ry={36} fill={SLATE.s50} opacity={0.6} />

      {/* Ossicle Chain (Malleus, Incus, Stapes) */}
      <g stroke={INK} strokeWidth={4} strokeLinecap="round" strokeLinejoin="round" fill={SLATE.s100}>
        {/* Malleus */}
        <line x1={ox + 526} y1={oy + 420} x2={ox + 544} y2={oy + 440} />
        {/* Incus */}
        <line x1={ox + 544} y1={oy + 440} x2={ox + 566} y2={oy + 455} />
        {/* Stapes footplate into oval window */}
        <path d={`M ${ox + 566} ${oy + 455} L ${ox + 580} ${oy + 470} L ${ox + 575} ${oy + 482} Z`} />
      </g>

      {/* Cochlea (2.5-turn Spiral Shell) */}
      <g transform={`translate(${ox + CL.x}, ${oy + CL.y})`}>
        {/* Cochlea body */}
        <circle
          cx={0}
          cy={0}
          r={50}
          fill={cochleaState === 'damaged' ? '#D6D9E0' : SLATE.s100}
          stroke={cochleaState === 'damaged' ? INK_SOFT : INK}
          strokeWidth={4}
        />
        {/* Spiral Arch */}
        <path
          d="
            M -4 28
            C 24 28, 40 12, 38 -14
            C 34 -34, 12 -42, -14 -38
            C -32 -32, -38 -12, -28 10
            C -20 24, -2 24, 8 16
            C 16 8, 14 -4, 4 -8
            C -2 -10, -8 -4, -6 2
          "
          fill="none"
          stroke={cochleaState === 'damaged' ? INK_SOFT : INK}
          strokeWidth={4.5}
          strokeLinecap="round"
        />
        {/* Mint health ring if healthy */}
        {cochleaState === 'healthy' && (
          <circle
            cx={0}
            cy={0}
            r={58}
            fill="none"
            stroke={OK}
            strokeWidth={4.5}
            opacity={0.85}
          />
        )}
        {cochleaState === 'damaged' && (
          <circle
            cx={0}
            cy={0}
            r={58}
            fill="none"
            stroke={STOP}
            strokeWidth={4}
            strokeDasharray="6 4"
            opacity={0.8}
          />
        )}
      </g>

      {/* Cochlear Nerve Bundle (Cranial Nerve VIII) */}
      <path
        d={`
          M ${ox + CL.x - 25} ${oy + CL.y + 35}
          C ${ox + CL.x - 60} ${oy + CL.y + 60}, ${ox + 460} ${oy + 590}, ${ox + 420} ${oy + 580}
        `}
        fill="none"
        stroke={nerveState === 'weak' ? STOP : INK}
        strokeWidth={nerveState === 'weak' ? 3 : 6}
        strokeDasharray={nerveState === 'weak' ? '6 4' : 'none'}
        strokeLinecap="round"
      />

      {/* 4. Routes (AIR route & BONE route) */}
      {/* Air Route (Tangerine) */}
      {airRouteProgress > 0 && (
        <path
          d={`
            M ${ox + EA.x} ${oy + EA.y + 40}
            C ${ox + 430} ${oy + 390}, ${ox + 480} ${oy + 410}, ${ox + 524} ${oy + 430}
            L ${ox + 544} ${oy + 440}
            L ${ox + 566} ${oy + 455}
            L ${ox + 580} ${oy + 480}
            C ${ox + 590} ${oy + 500}, ${ox + CL.x} ${oy + 510}, ${ox + CL.x} ${oy + CL.y}
          `}
          fill="none"
          stroke={AIR}
          strokeWidth={6}
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeDasharray={airRouteProgress < 1 ? '10 8' : 'none'}
        />
      )}

      {/* Traveling Token dots along air path */}
      {tokensTraveling && (
        <g>
          {[0, 0.35, 0.7].map((offset, idx) => {
            const p = (tokensProgress + offset) % 1.0;
            // Approximate pos
            const tx = ox + EA.x + p * (CL.x - EA.x);
            const ty = oy + EA.y + 40 + p * (CL.y - EA.y - 40);
            return (
              <circle
                key={`tok-${idx}`}
                cx={tx}
                cy={ty}
                r={8}
                fill={AIR}
                stroke="#FFFFFF"
                strokeWidth={2.5}
              />
            );
          })}
        </g>
      )}

      {/* Bone Route (Cobalt Braided Bolt Shortcut from Mastoid to Cochlea) */}
      {boneRouteProgress > 0 && (
        <g>
          {/* Braided double line */}
          <path
            d={`
              M ${ox + MS.x + 30} ${oy + MS.y}
              C ${ox + 380} ${oy + 440}, ${ox + 470} ${oy + 480}, ${ox + CL.x - 10} ${oy + CL.y - 10}
            `}
            fill="none"
            stroke={BONE}
            strokeWidth={5}
            strokeLinecap="round"
          />
          <path
            d={`
              M ${ox + MS.x + 30} ${oy + MS.y + 8}
              C ${ox + 380} ${oy + 448}, ${ox + 470} ${oy + 488}, ${ox + CL.x - 10} ${oy + CL.y - 2}
            `}
            fill="none"
            stroke={BONE}
            strokeWidth={3}
            strokeDasharray="8 6"
            strokeLinecap="round"
          />

          {/* Marching Chevrons >> */}
          {[0.25, 0.55, 0.85].map((cp, cidx) => {
            const cx_pos = ox + MS.x + 30 + cp * (CL.x - MS.x - 40);
            const cy_pos = oy + MS.y + cp * (CL.y - MS.y - 10);
            return (
              <path
                key={`chev-${cidx}`}
                d={`M ${cx_pos - 8} ${cy_pos - 8} L ${cx_pos} ${cy_pos} L ${cx_pos - 8} ${cy_pos + 8}`}
                fill="none"
                stroke={BONE}
                strokeWidth={4}
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            );
          })}
        </g>
      )}
    </g>
  );
};
