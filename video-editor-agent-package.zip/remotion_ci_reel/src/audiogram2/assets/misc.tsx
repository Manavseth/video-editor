import React from 'react';
import {
  PAPER,
  INK,
  INK_SOFT,
  AIR,
  BONE,
  OK,
  STOP,
  SLATE,
  SKIN,
  CHARCOAL_FACE,
} from '../tokens';

interface AudiologistFigureProps {
  x?: number;
  y?: number;
  nodAngle?: number; // degrees
  scale?: number;
  opacity?: number;
}

export const AudiologistFigure: React.FC<AudiologistFigureProps> = ({
  x = 840,
  y = 800,
  nodAngle = 0,
  scale = 1,
  opacity = 1,
}) => {
  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      opacity={opacity}
      style={{ transformOrigin: 'center' }}
    >
      {/* Ground contact shadow */}
      <ellipse cx={0} cy={160} rx={70} ry={20} fill="rgba(38, 36, 48, 0.16)" />

      {/* Legs & Trousers */}
      <line x1={-18} y1={50} x2={-20} y2={150} stroke={INK} strokeWidth={16} strokeLinecap="round" />
      <line x1={18} y1={50} x2={20} y2={150} stroke={INK} strokeWidth={16} strokeLinecap="round" />

      {/* Lab Coat & Body */}
      <path
        d="M -40 -30 L 40 -30 L 50 60 L -50 60 Z"
        fill={SLATE.s50}
        stroke={INK}
        strokeWidth={4}
        strokeLinejoin="round"
      />
      {/* Cobalt Shirt & Tie/Lapel */}
      <polygon points="-16,-30 0,0 16,-30" fill={BONE} />
      <line x1={0} y1={-30} x2={0} y2={60} stroke={INK} strokeWidth={2.5} />

      {/* Left arm */}
      <path d="M -40 -25 C -55 10, -50 30, -35 45" fill="none" stroke={SLATE.s50} strokeWidth={12} strokeLinecap="round" />

      {/* Right arm holding pointer pencil */}
      <path d="M 40 -25 C 60 10, 50 20, 20 25" fill="none" stroke={SLATE.s50} strokeWidth={12} strokeLinecap="round" />
      {/* Pointer pencil */}
      <line x1={20} y1={25} x2={-80} y2={-30} stroke={INK} strokeWidth={5} strokeLinecap="round" />
      <polygon points="-80,-30 -86,-34 -76,-36" fill={PAPER} />

      {/* Head with nod angle */}
      <g transform={`rotate(${nodAngle}, 0, -60)`}>
        {/* Neck */}
        <line x1={0} y1={-40} x2={0} y2={-30} stroke={SKIN} strokeWidth={14} />
        {/* Head */}
        <ellipse cx={0} cy={-70} rx={28} ry={34} fill={SKIN} stroke={INK} strokeWidth={3.5} />
        {/* Hair */}
        <path
          d="M -28 -74 C -28 -100, 28 -100, 28 -74 C 20 -86, -10 -88, -28 -74 Z"
          fill={INK}
        />
        {/* Facial features: glasses / smile */}
        <circle cx={-8} cy={-68} r={4} fill={INK} />
        <circle cx={12} cy={-68} r={4} fill={INK} />
        <path d="M -4 -56 Q 2 -50 8 -56" fill="none" stroke={INK} strokeWidth={2.5} strokeLinecap="round" />
      </g>
    </g>
  );
};

interface SplitCardProps {
  x?: number;
  y?: number;
  leftOpen?: boolean;
  rightOpen?: boolean;
  dividerScale?: number;
  doorsProgress?: number; // 0..1
}

export const SplitCardDoors: React.FC<SplitCardProps> = ({
  x = 540,
  y = 820,
  dividerScale = 1,
  doorsProgress = 0,
}) => {
  const doorW = 280;
  const doorH = 340;
  const slideOffset = doorsProgress * 150;

  return (
    <g transform={`translate(${x}, ${y})`}>
      {/* Left Door (BAAHAR - Tangerine) */}
      <g transform={`translate(${-doorW / 2 - slideOffset}, 0)`}>
        <rect
          x={-doorW / 2}
          y={-doorH / 2}
          width={doorW}
          height={doorH}
          rx={20}
          fill="rgba(223, 122, 43, 0.12)"
          stroke={AIR}
          strokeWidth={4}
        />
        <text
          x={0}
          y={-doorH / 2 + 54}
          textAnchor="middle"
          fill={AIR}
          fontFamily='Inter, "Segoe UI", sans-serif'
          fontSize={38}
          fontWeight={800}
        >
          BAAHAR
        </text>
        {/* Outer ear / canal icon */}
        <path
          d="M -30 20 C -10 0, 10 0, 30 20"
          fill="none"
          stroke={AIR}
          strokeWidth={6}
          strokeLinecap="round"
        />
        <circle cx={0} cy={30} r={14} fill={STOP} />
        <text
          x={0}
          y={doorH / 2 - 30}
          textAnchor="middle"
          fill={INK_SOFT}
          fontFamily='Inter, "Segoe UI", sans-serif'
          fontSize={22}
          fontWeight={600}
        >
          Ear Canal / Eardrum
        </text>
      </g>

      {/* Right Door (ANDAR - Cobalt) */}
      <g transform={`translate(${doorW / 2 + slideOffset}, 0)`}>
        <rect
          x={-doorW / 2}
          y={-doorH / 2}
          width={doorW}
          height={doorH}
          rx={20}
          fill="rgba(46, 86, 201, 0.12)"
          stroke={BONE}
          strokeWidth={4}
        />
        <text
          x={0}
          y={-doorH / 2 + 54}
          textAnchor="middle"
          fill={BONE}
          fontFamily='Inter, "Segoe UI", sans-serif'
          fontSize={38}
          fontWeight={800}
        >
          ANDAR
        </text>
        {/* Inner ear / cochlea icon */}
        <circle cx={0} cy={20} r={28} fill="none" stroke={BONE} strokeWidth={5} />
        <path d="M 0 6 C 14 6, 14 34, 0 34 C -8 34, -8 20, 0 20" fill="none" stroke={BONE} strokeWidth={4} />
        <text
          x={0}
          y={doorH / 2 - 30}
          textAnchor="middle"
          fill={INK_SOFT}
          fontFamily='Inter, "Segoe UI", sans-serif'
          fontSize={22}
          fontWeight={600}
        >
          Cochlea / Nerve
        </text>
      </g>

      {/* Vertical Divider (The Gap that became divider) */}
      <line
        x1={0}
        y1={-doorH / 2 - 20}
        x2={0}
        y2={doorH / 2 + 20}
        stroke={INK}
        strokeWidth={8 * dividerScale}
        strokeLinecap="round"
      />
    </g>
  );
};

interface SuspectCardProps {
  x: number;
  y: number;
  type: 'headphones' | 'aging';
  scale?: number;
  opacity?: number;
  cycle?: number;
}

export const SuspectCard: React.FC<SuspectCardProps> = ({
  x,
  y,
  type,
  scale = 1,
  opacity = 1,
  cycle = 0,
}) => {
  const cardW = 440;
  const cardH = 460;

  return (
    <g transform={`translate(${x}, ${y}) scale(${scale})`} opacity={opacity}>
      {/* Drop shadow */}
      <rect
        x={-cardW / 2 + 8}
        y={-cardH / 2 + 10}
        width={cardW}
        height={cardH}
        rx={28}
        fill="rgba(38, 36, 48, 0.12)"
      />
      <rect
        x={-cardW / 2}
        y={-cardH / 2}
        width={cardW}
        height={cardH}
        rx={28}
        fill="#FFFFFF"
        stroke={INK}
        strokeWidth={4.5}
      />

      {type === 'headphones' ? (
        <g transform="translate(0, -40)">
          {/* Headphones Graphic */}
          <path
            d="M -60 -10 C -40 -80, 40 -80, 60 -10"
            fill="none"
            stroke={INK}
            strokeWidth={14}
            strokeLinecap="round"
          />
          <ellipse cx={-60} cy={10} rx={28} ry={40} fill={CHARCOAL_FACE} stroke={INK} strokeWidth={4} />
          <ellipse cx={60} cy={10} rx={28} ry={40} fill={CHARCOAL_FACE} stroke={INK} strokeWidth={4} />

          {/* Sound waves pulsing */}
          {[0, 1].map((widx) => {
            const p = ((cycle + widx * 10) % 20) / 20;
            const r = 36 + p * 40;
            const a = 1 - p;
            return (
              <g key={`sw-${widx}`}>
                <path
                  d={`M ${-60 - r * 0.7} ${10 - r * 0.7} C ${-60 - r} 10, ${-60 - r} 20, ${-60 - r * 0.7} ${10 + r * 0.7}`}
                  fill="none"
                  stroke={AIR}
                  strokeWidth={5}
                  opacity={a}
                />
                <path
                  d={`M ${60 + r * 0.7} ${10 - r * 0.7} C ${60 + r} 10, ${60 + r} 20, ${60 + r * 0.7} ${10 + r * 0.7}`}
                  fill="none"
                  stroke={AIR}
                  strokeWidth={5}
                  opacity={a}
                />
              </g>
            );
          })}

          <text
            x={0}
            y={180}
            textAnchor="middle"
            fill={INK}
            fontFamily='Fraunces, "Playfair Display", Georgia, serif'
            fontSize={38}
            fontWeight={800}
          >
            LOUD HEADPHONES
          </text>
        </g>
      ) : (
        <g transform="translate(0, -40)">
          {/* Aging Clock Graphic */}
          <circle cx={0} cy={20} r={74} fill={PAPER} stroke={INK} strokeWidth={5} />
          {/* 12 clock ticks */}
          {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((deg) => {
            const rad = (deg * Math.PI) / 180;
            const x1 = Math.cos(rad) * 60;
            const y1 = 20 + Math.sin(rad) * 60;
            const x2 = Math.cos(rad) * 68;
            const y2 = 20 + Math.sin(rad) * 68;
            return <line key={`tick-${deg}`} x1={x1} y1={y1} x2={x2} y2={y2} stroke={INK} strokeWidth={3} />;
          })}

          {/* Clock hands animating */}
          <g transform={`rotate(${cycle * 6}, 0, 20)`}>
            <line x1={0} y1={20} x2={0} y2={-30} stroke={INK} strokeWidth={5} strokeLinecap="round" />
          </g>
          <g transform={`rotate(${cycle * 0.6}, 0, 20)`}>
            <line x1={0} y1={20} x2={26} y2={20} stroke={INK} strokeWidth={6} strokeLinecap="round" />
          </g>
          <circle cx={0} cy={20} r={6} fill={INK} />

          <text
            x={0}
            y={180}
            textAnchor="middle"
            fill={INK}
            fontFamily='Fraunces, "Playfair Display", Georgia, serif'
            fontSize={38}
            fontWeight={800}
          >
            AGING
          </text>
        </g>
      )}
    </g>
  );
};
