import React from 'react';
import {
  SLATE,
  INK,
  AIR,
  BONE,
  CHARCOAL_FACE,
  CUSHION,
} from '../tokens';

interface HeadphoneProps {
  x?: number;
  y?: number;
  scale?: number;
  opacity?: number;
  pulseRings?: boolean;
  ringsFrame?: number;
}

export const HeadphoneDevice: React.FC<HeadphoneProps> = ({
  x = 380,
  y = 340,
  scale = 1,
  opacity = 1,
  pulseRings = false,
  ringsFrame = 0,
}) => {
  return (
    <g transform={`translate(${x}, ${y}) scale(${scale})`} opacity={opacity}>
      {/* Headband arc */}
      <path
        d="M -30 -90 C -20 -150, 40 -150, 60 -90"
        fill="none"
        stroke={INK}
        strokeWidth={14}
        strokeLinecap="round"
      />
      <path
        d="M -30 -90 C -20 -150, 40 -150, 60 -90"
        fill="none"
        stroke={SLATE.s100}
        strokeWidth={6}
        strokeLinecap="round"
      />

      {/* Ear Cup (Cylinder / Ellipse) */}
      <ellipse cx={0} cy={10} rx={48} ry={68} fill={CHARCOAL_FACE} stroke={INK} strokeWidth={5} />
      <ellipse cx={0} cy={10} rx={36} ry={54} fill={SLATE.s200} stroke={INK} strokeWidth={3} />
      <ellipse cx={0} cy={10} rx={22} ry={36} fill={SLATE.s100} />
      <circle cx={0} cy={10} r={6} fill={INK} />

      {/* Quarter-arc acoustic sound emission rings */}
      {pulseRings && (
        <g>
          {[0, 1, 2].map((idx) => {
            const cycle = (ringsFrame + idx * 6) % 18;
            const r = 40 + cycle * 5;
            const alpha = Math.max(0, 1 - cycle / 18);
            return (
              <path
                key={`hp-ring-${idx}`}
                d={`M ${r * 0.7} ${10 - r * 0.7} C ${r} 0, ${r} 20, ${r * 0.7} ${10 + r * 0.7}`}
                fill="none"
                stroke={AIR}
                strokeWidth={5}
                strokeLinecap="round"
                opacity={alpha}
              />
            );
          })}
        </g>
      )}
    </g>
  );
};

interface BoneVibratorProps {
  x?: number;
  y?: number;
  scale?: number;
  opacity?: number;
  vibrating?: boolean;
  vibFrame?: number;
}

export const BoneVibratorDevice: React.FC<BoneVibratorProps> = ({
  x = 280,
  y = 390,
  scale = 1,
  opacity = 1,
  vibrating = false,
  vibFrame = 0,
}) => {
  return (
    <g transform={`translate(${x}, ${y}) scale(${scale})`} opacity={opacity}>
      {/* Spring steel headband wrapping around skull */}
      <path
        d="M 10 0 C 80 -60, 120 40, 60 120"
        fill="none"
        stroke={INK}
        strokeWidth={10}
        strokeLinecap="round"
      />

      {/* Bone Vibrator housing (Steel Shell) */}
      <rect
        x={-42}
        y={-28}
        width={84}
        height={56}
        rx={14}
        fill={SLATE.s400}
        stroke={INK}
        strokeWidth={4.5}
      />
      {/* Cushion Pad face touching mastoid */}
      <rect
        x={-30}
        y={-18}
        width={60}
        height={36}
        rx={8}
        fill={CUSHION}
        stroke={INK}
        strokeWidth={2.5}
      />

      {/* Cable exiting lower-right */}
      <path
        d="M 28 20 C 50 40, 70 80, 90 120"
        fill="none"
        stroke={INK}
        strokeWidth={6}
        strokeLinecap="round"
      />

      {/* Cobalt Vibration ripples */}
      {vibrating && (
        <g>
          {[0, 1].map((idx) => {
            const p = ((vibFrame + idx * 8) % 16) / 16;
            const rx = 44 + p * 26;
            const ry = 28 + p * 18;
            const alpha = 1 - p;
            return (
              <rect
                key={`vib-${idx}`}
                x={-rx}
                y={-ry}
                width={rx * 2}
                height={ry * 2}
                rx={18}
                fill="none"
                stroke={BONE}
                strokeWidth={4}
                opacity={alpha}
              />
            );
          })}
        </g>
      )}
    </g>
  );
};
