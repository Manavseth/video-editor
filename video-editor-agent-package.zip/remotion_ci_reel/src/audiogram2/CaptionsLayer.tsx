import React from 'react';
import { useCurrentFrame } from 'remotion';
import { CUES, CueItem } from './data';
import { PAPER, INK, AIR, BONE, OK, STOP, CAP } from './tokens';

export const CaptionsLayer: React.FC = () => {
  const frame = useCurrentFrame();
  const time = frame / 30;

  // Find matching cue
  const activeCue: CueItem | undefined = CUES.find(
    (c) => time >= c.start && time < c.end
  );

  if (!activeCue) return null;

  const renderHighlightedText = (text: string, highlights?: string[]) => {
    if (!highlights || highlights.length === 0) {
      return <span>{text}</span>;
    }

    let parts: React.ReactNode[] = [text];

    highlights.forEach((hl) => {
      const newParts: React.ReactNode[] = [];
      parts.forEach((p) => {
        if (typeof p === 'string') {
          const idx = p.indexOf(hl);
          if (idx !== -1) {
            const before = p.substring(0, idx);
            const match = p.substring(idx, idx + hl.length);
            const after = p.substring(idx + hl.length);
            if (before) newParts.push(before);

            // Determine highlight accent color
            let hlColor = AIR;
            if (hl.includes('Bone') || hl.includes('cochlea') || hl.includes('dimaag') || hl.includes('gap')) {
              hlColor = BONE;
            } else if (hl.includes('normal') || hl.includes('easily') || hl.includes('catch')) {
              hlColor = OK;
            } else if (hl.includes('loss') || hl.includes('band') || hl.includes('neeche') || hl.includes('chillaye') || hl.includes('problem')) {
              hlColor = STOP;
            }

            newParts.push(
              <span
                key={hl}
                style={{
                  color: hlColor,
                  fontWeight: 800,
                  borderBottom: `3px solid ${hlColor}`,
                  paddingBottom: 2,
                }}
              >
                {match}
              </span>
            );
            if (after) newParts.push(after);
          } else {
            newParts.push(p);
          }
        } else {
          newParts.push(p);
        }
      });
      parts = newParts;
    });

    return parts;
  };

  return (
    <div
      style={{
        position: 'absolute',
        top: CAP.top,
        left: 0,
        width: '100%',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        padding: '0 48px',
        boxSizing: 'border-box',
        pointerEvents: 'none',
        zIndex: 50,
      }}
    >
      <div
        style={{
          backgroundColor: 'rgba(255, 255, 255, 0.94)',
          border: '1.5px solid #E4DECC',
          borderRadius: 20,
          padding: '16px 28px',
          boxShadow: '0 8px 24px rgba(38, 36, 48, 0.08)',
          maxWidth: 960,
          textAlign: 'center',
          backdropFilter: 'blur(8px)',
        }}
      >
        <span
          style={{
            color: INK,
            fontSize: 34,
            fontWeight: 700,
            lineHeight: 1.35,
            letterSpacing: '-0.01em',
            fontFamily: 'Inter, "Segoe UI", system-ui, sans-serif',
          }}
        >
          {renderHighlightedText(activeCue.text, activeCue.highlight)}
        </span>
      </div>
    </div>
  );
};
