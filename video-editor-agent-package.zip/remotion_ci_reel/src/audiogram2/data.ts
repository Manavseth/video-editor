export interface CueItem {
  i: number;
  start: number;
  end: number;
  text: string;
  highlight?: string[];
}

export const CUES: CueItem[] = [
  { i: 1, start: 0.0, end: 2.2, text: 'Itni baar kaha tha ki yeh bataunga', highlight: ['Itni baar kaha tha'] },
  { i: 2, start: 2.2, end: 4.1, text: 'ki sirf ek graph dekh kar', highlight: ['sirf ek graph'] },
  { i: 3, start: 4.1, end: 5.88, text: 'duniya aapko kitni loud lagti hai.', highlight: ['kitni loud lagti hai'] },
  { i: 4, start: 5.88, end: 8.5, text: 'Toh suno, audiogram pe ek normal line hoti hai,', highlight: ['normal line'] },
  { i: 5, start: 8.5, end: 10.72, text: 'agar aapke thresholds isse upar hain...', highlight: ['thresholds isse upar'] },
  { i: 6, start: 10.72, end: 13.4, text: 'Matlab 20 dB ki halki whisper bhi', highlight: ['20 dB ki halki whisper'] },
  { i: 7, start: 13.4, end: 15.22, text: 'aapka dimaag easily catch kar raha hai.', highlight: ['easily catch'] },
  { i: 8, start: 15.22, end: 17.6, text: 'Lekin jab yeh thresholds neeche girte hain,', highlight: ['neeche girte hain'] },
  { i: 9, start: 17.6, end: 19.3, text: 'tab yeh level jaate hain...', highlight: ['level jaate hain'] },
  { i: 10, start: 19.3, end: 22.66, text: 'Mild, moderate, ya severe hearing loss!', highlight: ['Mild, moderate, ya severe'] },
  { i: 11, start: 22.66, end: 25.34, text: 'Bhai yeh sirf fancy terms nahi hain!', highlight: ['fancy terms nahi'] },
  { i: 12, start: 25.68, end: 27.6, text: 'Iska seedha matlab hai,', highlight: ['seedha matlab'] },
  { i: 13, start: 27.6, end: 29.62, text: 'ki aapke liye duniya ka volume kitna kam ho chuka hai.', highlight: ['volume kitna kam'] },
  { i: 14, start: 29.62, end: 32.34, text: 'Mild loss me whisper sunna band,', highlight: ['Mild loss', 'whisper sunna band'] },
  { i: 15, start: 32.34, end: 35.48, text: 'Moderate loss me normal baat-cheet bhi dabi hui', highlight: ['Moderate loss', 'baat-cheet bhi dabi hui'] },
  { i: 16, start: 35.48, end: 37.46, text: 'aur kam volume pe sunai deti hai.', highlight: ['kam volume'] },
  { i: 17, start: 37.46, end: 40.5, text: 'Aur severe loss, jab tak aapke saamne', highlight: ['severe loss'] },
  { i: 18, start: 40.5, end: 43.1, text: 'koi aake chillaye na, tab tak dimaag ko awaaz nahi pahunchti.', highlight: ['aake chillaye na', 'awaaz nahi pahunchti'] },
  { i: 19, start: 43.1, end: 46.22, text: 'Toh isiliye graph pe 2 alag-alag lines banti hain,', highlight: ['2 alag-alag lines'] },
  { i: 20, start: 46.22, end: 48.76, text: 'aur inke beech ka gap yeh batata hai...', highlight: ['beech ka gap'] },
  { i: 21, start: 48.76, end: 51.8, text: '...ki problem aapke middle ear, outer ear,', highlight: ['middle ear, outer ear'] },
  { i: 22, start: 51.8, end: 54.64, text: 'ya kaan ke andar cochlea me hai.', highlight: ['cochlea me hai'] },
  { i: 23, start: 54.64, end: 56.83, text: 'Woh sab agli baar decode karenge!', highlight: ['agli baar decode karenge'] },
];

export const CURVES = {
  NORMAL: [15, 15, 15, 20, 20, 20],
  MILD: [30, 35, 35, 40, 40, 40],
  MODERATE: [45, 50, 50, 55, 55, 60],
  SEVERE: [75, 80, 80, 85, 85, 90],
  // Conductive Hearing Loss example: Bone Conduction is Normal (15 dB), Air Conduction is Dropped (50 dB)
  AIR_CONDUCTIVE: [45, 50, 50, 55, 55, 60],
  BONE_NORMAL: [10, 15, 15, 15, 20, 20],
  AIR_GAP: [45, 50, 50, 55, 55, 60],
  BONE_GAP: [10, 15, 15, 15, 20, 20],
};
