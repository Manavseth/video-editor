import React from 'react';
import { interpolate, useCurrentFrame, useVideoConfig } from 'remotion';
import { THEME } from '../theme';
import { Background } from '../components/Background';
import { SpeakerCone } from '../components/SpeakerCone';
import { AcousticWave } from '../components/AcousticWave';
import { CaptionsOverlay } from '../components/CaptionsOverlay';

export const Scene4_SpeakerMetaphor: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const timeSec = 17.6 + frame / fps;

  // 0 - 1s (frames 0 - 30): reveal cone from blurred circle
  const revealProgress = interpolate(frame, [0, 25], [0, 1], { extrapolateRight: 'clamp' });
  const blurFactor = interpolate(frame, [0, 25], [1, 0], { extrapolateRight: 'clamp' });

  // 1 - 2s (frames 30 - 60): controlled vibration, waveform becomes irregular
  const vibration = frame >= 30 && frame <= 60
    ? Math.sin((frame - 30) * 0.8) * interpolate(frame, [30, 45, 60], [0, 16, 0])
    : 0;
  const irregularity = interpolate(frame, [25, 45, 60], [0, 0.9, 0.4], { extrapolateRight: 'clamp' });

  // 2 - 2.6s (frames 60 - 78): waveform compresses into clean cyan line sweeping to frame right
  const cyanCompress = interpolate(frame, [58, 75], [0, 1], { extrapolateRight: 'clamp' });
  const sweepRight = interpolate(frame, [65, 78], [0, 400], { extrapolateRight: 'clamp' });

  return (
    <div style={{ width: THEME.width, height: THEME.height, position: 'relative' }}>
      <Background title="PHYSICAL TRANSDUCTION ANALOGY" subtitle="BLOWN SPEAKER CONE METAPHOR" />

      <svg width={THEME.width} height={THEME.height} style={{ position: 'absolute', top: 0, left: 0 }}>
        {/* Speaker Cone Component */}
        <SpeakerCone
          x={540}
          y={900}
          scale={1.15}
          vibrationOffset={vibration}
          irregularity={irregularity}
          blurFactor={blurFactor}
          opacity={revealProgress * (1 - cyanCompress * 0.5)}
        />

        {/* Entering / Overdriven Acoustic Wave */}
        {cyanCompress < 0.9 && (
          <AcousticWave
            x={180}
            y={900}
            width={720}
            amplitude={interpolate(frame, [0, 40, 60], [45, 70, 20])}
            frequency={4}
            phase={frame * 0.3}
            color={THEME.colors.amber}
            strokeWidth={3}
            distortion={irregularity}
            opacity={1 - cyanCompress}
            glow
          />
        )}

        {/* Clean Cyan Implant Signal Line Sweeping Right (Scene 5 bridge) */}
        {cyanCompress > 0.1 && (
          <g opacity={cyanCompress}>
            <line
              x1={400 + sweepRight * 0.3}
              y1={900}
              x2={700 + sweepRight}
              y2={900}
              stroke={THEME.colors.cyanBright}
              strokeWidth={4.5}
              strokeLinecap="round"
            />
            {/* Glowing leading pulse dot */}
            <circle
              cx={700 + sweepRight}
              cy={900}
              r={9}
              fill="#FFFFFF"
              stroke={THEME.colors.cyanBright}
              strokeWidth={3}
            />
          </g>
        )}
      </svg>

      <CaptionsOverlay currentSeconds={timeSec} />
    </div>
  );
};
