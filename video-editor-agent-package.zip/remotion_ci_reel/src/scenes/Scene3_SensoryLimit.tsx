import React from 'react';
import { interpolate, useCurrentFrame, useVideoConfig } from 'remotion';
import { THEME } from '../theme';
import { Background } from '../components/Background';
import { Cochlea } from '../components/Cochlea';
import { AcousticWave } from '../components/AcousticWave';
import { CaptionsOverlay } from '../components/CaptionsOverlay';

export const Scene3_SensoryLimit: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const timeSec = 12.0 + frame / fps;

  // 0 - 2s: continue travelling wave
  // 2 - 4s: wave amplitude increases, distortion rises, hair cells damaged/irregular
  const waveAmp = interpolate(frame, [0, 60, 120], [28, 55, 75], { extrapolateRight: 'clamp' });
  const distortion = interpolate(frame, [40, 110], [0, 0.85], { extrapolateRight: 'clamp' });

  // 4 - 5.6s (frames 120 - 168): ease toward forming blurred speaker circle at frame edge
  const speakerMorph = interpolate(frame, [120, 168], [0, 1], { extrapolateRight: 'clamp' });
  const cochleaOpacity = interpolate(frame, [130, 168], [1, 0.2], { extrapolateRight: 'clamp' });

  return (
    <div style={{ width: THEME.width, height: THEME.height, position: 'relative' }}>
      <Background title="SENSORINEURAL LIMITATION" subtitle="DECIBEL GAIN VS. TRANSDUCTION CAPACITY" />

      <svg
        width={THEME.width}
        height={THEME.height}
        style={{ position: 'absolute', top: 0, left: 0 }}
      >
        {/* Established Translucent Cochlea with Irregular / Reduced Hair Cells */}
        <Cochlea
          x={540}
          y={920}
          scale={1.4}
          rotation={0}
          opacity={cochleaOpacity}
          fluidWaveProgress={0.45 + (frame % 30) / 60}
          hairCellState="damaged" // Medically calibrated: ~50% irregular/faded, some intact
          showElectrode={false}
          showNerveFibers={true}
        />

        {/* Overdriven Crowded Acoustic Waveform representing excessive decibel gain */}
        <g transform="translate(180, 880)">
          <AcousticWave
            x={0}
            y={0}
            width={720}
            amplitude={waveAmp}
            frequency={5.5}
            phase={frame * 0.28}
            color={distortion > 0.4 ? THEME.colors.amber : THEME.colors.ivory}
            strokeWidth={3.5}
            distortion={distortion}
            taper="both"
            glow={distortion > 0.3}
          />
        </g>

        {/* Forming blurred circular silhouette previewing Scene 4 speaker */}
        {speakerMorph > 0 && (
          <g
            transform={`translate(540, 920) scale(${0.4 + speakerMorph * 0.7})`}
            opacity={speakerMorph}
          >
            <circle
              cx="0"
              cy="0"
              r="220"
              fill="rgba(15, 23, 42, 0.75)"
              stroke={THEME.colors.amber}
              strokeWidth="3"
              strokeDasharray="6 6"
              filter="blur(10px)"
            />
          </g>
        )}

        {/* Technical Callout Badge */}
        <g transform="translate(540, 1260)">
          <rect x="-170" y="-18" width="340" height="36" rx="6" fill={THEME.colors.panel} stroke={THEME.colors.line} />
          <text x="0" y="5" textAnchor="middle" fill={THEME.colors.amber} fontFamily={THEME.fonts.mono} fontSize="14">
            REDUCED TRANSDUCTION SENSITIVITY
          </text>
        </g>
      </svg>

      <CaptionsOverlay currentSeconds={timeSec} />
    </div>
  );
};
