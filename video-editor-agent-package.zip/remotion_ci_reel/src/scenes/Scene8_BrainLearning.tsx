import React from 'react';
import { interpolate, useCurrentFrame, useVideoConfig } from 'remotion';
import { THEME } from '../theme';
import { Background } from '../components/Background';
import { BrainSilhouette } from '../components/BrainSilhouette';
import { CaptionsOverlay } from '../components/CaptionsOverlay';

export const Scene8_BrainLearning: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const timeSec = 35.0 + frame / fps;

  // 0 - 1.5s (frames 0 - 45): follow carried pulse into brain silhouette
  const brainEntry = interpolate(frame, [0, 40], [0.3, 1], { extrapolateRight: 'clamp' });
  const signalArrival = interpolate(frame, [0, 45], [0, 1], { extrapolateRight: 'clamp' });

  // 1.5 - 3.5s (frames 45 - 105): neural pathways illuminate sequentially and settle
  const pathwayActivation = interpolate(frame, [45, 105], [0, 1], { extrapolateRight: 'clamp' });

  // 3.5 - 4.5s (frames 105 - 135): waveform resolves into a calm, readable pattern
  const waveformResolved = interpolate(frame, [105, 135], [0, 1], { extrapolateRight: 'clamp' });

  // 4.5 - 5s (frames 135 - 150): calm settle and hold for clean end frame

  return (
    <div style={{ width: THEME.width, height: THEME.height, position: 'relative' }}>
      <Background title="CENTRAL AUDITORY PROCESSING" subtitle="NEUROPLASTIC SPEECH INTERPRETATION" />

      <svg width={THEME.width} height={THEME.height} style={{ position: 'absolute', top: 0, left: 0 }}>
        {/* Brain Silhouette Component with Ascending Nerve Pathway & Cortical Waveform */}
        <BrainSilhouette
          x={540}
          y={860}
          scale={1.22}
          opacity={brainEntry}
          signalArrivalProgress={signalArrival}
          pathwayActivation={pathwayActivation}
          waveformResolved={waveformResolved}
        />

        {/* Clear uncluttered safe area reserved for creator account tag / end card */}
        <g transform="translate(540, 1540)" opacity={interpolate(frame, [125, 145], [0, 1], { extrapolateRight: 'clamp' })}>
          <rect
            x="-180"
            y="-22"
            width="360"
            height="44"
            rx="8"
            fill="rgba(15, 23, 42, 0.9)"
            stroke={THEME.colors.lineBright}
            strokeWidth="1.5"
          />
          <text
            x="0"
            y="6"
            textAnchor="middle"
            fill={THEME.colors.ivory}
            fontFamily={THEME.fonts.title}
            fontSize="18"
            fontWeight="600"
            letterSpacing="0.04em"
          >
            CLINICAL AUDIOLOGY SERIES
          </text>
        </g>
      </svg>

      <CaptionsOverlay currentSeconds={timeSec} />
    </div>
  );
};
