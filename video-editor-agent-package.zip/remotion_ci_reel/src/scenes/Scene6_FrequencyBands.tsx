import React from 'react';
import { interpolate, useCurrentFrame, useVideoConfig } from 'remotion';
import { THEME } from '../theme';
import { Background } from '../components/Background';
import { AcousticWave } from '../components/AcousticWave';
import { CaptionsOverlay } from '../components/CaptionsOverlay';

export const Scene6_FrequencyBands: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const timeSec = 24.8 + frame / fps;

  // 0 - 1s (frames 0 - 30): incoming waveform entering processor
  const waveEntry = interpolate(frame, [0, 30], [0, 1], { extrapolateRight: 'clamp' });

  // 1 - 2.5s (frames 30 - 75): 5 distinct frequency filter bands separate smoothly
  const bandSeparation = interpolate(frame, [30, 75], [0, 1], { extrapolateRight: 'clamp' });

  // 2.5 - 4s (frames 75 - 120): bands bend into a cochlea-shaped spiral arc
  const arcCurvature = interpolate(frame, [75, 120], [0, 1], { extrapolateRight: 'clamp' });

  // 4 - 5s (frames 120 - 150): camera tracks toward first electrode contacts
  const cameraZoom = interpolate(frame, [115, 150], [1.0, 1.25], { extrapolateRight: 'clamp' });

  const bands = [
    { label: 'BAND 1 · LOW (250 Hz)', color: '#38BDF8', yOffset: -80 },
    { label: 'BAND 2 · LOW-MID (500 Hz)', color: '#22D3EE', yOffset: -40 },
    { label: 'BAND 3 · MID (1000 Hz)', color: '#06B6D4', yOffset: 0 },
    { label: 'BAND 4 · MID-HIGH (2000 Hz)', color: '#0EA5E9', yOffset: 40 },
    { label: 'BAND 5 · HIGH (4000 Hz)', color: '#0284C7', yOffset: 80 },
  ];

  return (
    <div style={{ width: THEME.width, height: THEME.height, position: 'relative' }}>
      <Background title="DIGITAL SIGNAL PROCESSING" subtitle="CONTINUOUS INTERLEAVED SAMPLING (CIS)" />

      <svg
        width={THEME.width}
        height={THEME.height}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          transform: `scale(${cameraZoom})`,
          transformOrigin: '540px 900px',
        }}
      >
        {/* Transparent DSP Filterbank Chassis / Enclosure */}
        <g transform="translate(540, 880)">
          <rect
            x="-420"
            y="-220"
            width="840"
            height="440"
            rx="16"
            fill={THEME.colors.panel}
            stroke={THEME.colors.line}
            strokeWidth="2"
          />

          {/* Processor Header Tag */}
          <g transform="translate(0, -180)">
            <text
              x="0"
              y="0"
              textAnchor="middle"
              fill={THEME.colors.cyanBright}
              fontFamily={THEME.fonts.mono}
              fontSize="16"
              fontWeight="600"
              letterSpacing="0.1em"
            >
              FREQUENCY DECOMPOSITION · BANDPASS CHANNELS
            </text>
          </g>

          {/* Incoming Broad-spectrum Audio Waveform */}
          {bandSeparation < 0.6 && (
            <g transform="translate(-360, 0)" opacity={1 - bandSeparation * 1.4}>
              <AcousticWave
                x={0}
                y={0}
                width={200}
                amplitude={35}
                frequency={4.5}
                phase={frame * 0.25}
                color={THEME.colors.ivory}
                strokeWidth={3}
              />
            </g>
          )}

          {/* 5 Distinct Frequency Band Ribbons */}
          {bands.map((b, idx) => {
            const spreadY = b.yOffset * bandSeparation;
            const curve = arcCurvature * (idx * 25);

            // Bending from horizontal parallel lanes into cochlea-shaped curve
            const startX = -120 + arcCurvature * (idx * 15);
            const endX = 340 - arcCurvature * (idx * 30);
            const midY = spreadY + (arcCurvature > 0 ? (idx - 2) * 35 : 0);

            return (
              <g key={`band-${idx}`} opacity={Math.min(1, bandSeparation * 1.5)}>
                {/* Channel Lane Bar */}
                <path
                  d={`M ${startX} ${spreadY} Q ${(startX + endX) / 2} ${midY + curve}, ${endX} ${spreadY + curve * 0.5}`}
                  fill="none"
                  stroke={b.color}
                  strokeWidth="5"
                  strokeLinecap="round"
                />

                {/* Animated Signal Energy Pulse along ribbon */}
                <circle
                  cx={startX + ((frame * 6 + idx * 40) % (endX - startX))}
                  cy={spreadY + curve * 0.2}
                  r="6"
                  fill="#FFFFFF"
                />

                {/* Band Label */}
                {bandSeparation > 0.5 && arcCurvature < 0.8 && (
                  <text
                    x={startX - 15}
                    y={spreadY + 5}
                    textAnchor="end"
                    fill={THEME.colors.ivoryMuted}
                    fontFamily={THEME.fonts.mono}
                    fontSize="12"
                  >
                    {b.label}
                  </text>
                )}
              </g>
            );
          })}
        </g>

        {/* Feature Explanation Card */}
        <g transform="translate(540, 1260)">
          <rect x="-180" y="-18" width="360" height="36" rx="6" fill={THEME.colors.panel} stroke={THEME.colors.line} />
          <text x="0" y="5" textAnchor="middle" fill={THEME.colors.cyanBright} fontFamily={THEME.fonts.mono} fontSize="14" fontWeight="600">
            PARALLEL FREQUENCY-TO-ELECTRODE MAPPING
          </text>
        </g>
      </svg>

      <CaptionsOverlay currentSeconds={timeSec} />
    </div>
  );
};
