import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { AtmosphericBackdrop } from '../../components/AtmosphericBackdrop';
import { DustParticles } from '../../components/DustParticles';
import { BlueprintCaliper } from '../../components/BlueprintCaliper';
import { FaithSubtitles } from '../../components/FaithSubtitles';
import { FAITH_THEME } from '../../theme_faithvsfact';

export const Scene1_ChaosHook: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const cameraScale = interpolate(frame, [0, 96], [1.0, 1.05]);
  const patientEntrance = spring({ frame, fps, config: { damping: 15, stiffness: 120 } });
  const cx = FAITH_THEME.width / 2;
  const cy = 840;

  return (
    <div style={{ position: 'relative', width: FAITH_THEME.width, height: FAITH_THEME.height, transform: `scale(${cameraScale})`, transformOrigin: 'center center' }}>
      <AtmosphericBackdrop spotlightY={cy} />
      <DustParticles count={30} />

      {/* Chaotic noise waves */}
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
        {[200, 290, 380, 470].map((r, i) => {
          const wavePhase = (frame * 3 + i * 35) % 180;
          return (
            <circle
              key={i}
              cx={cx - 320}
              cy={cy - 40}
              r={r + wavePhase * 0.4}
              fill="none"
              stroke={FAITH_THEME.colors.redNoise}
              strokeWidth={3}
              opacity={interpolate(wavePhase, [0, 90, 180], [0.1, 0.7, 0])}
            />
          );
        })}
      </svg>

      {/* Patient Profile */}
      <div style={{ position: 'absolute', left: cx, top: cy, transform: `translate(-50%, -50%) scale(${patientEntrance})`, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <div style={{ width: 220, height: 270, borderRadius: '50% 50% 45% 45%', backgroundColor: FAITH_THEME.colors.paperSkin, position: 'relative', boxShadow: '0 15px 35px rgba(0,0,0,0.6)' }}>
          <div style={{ position: 'absolute', right: 18, top: 105, width: 58, height: 85, borderRadius: '50%', backgroundColor: '#C5A48F' }} />
          <div style={{ position: 'absolute', right: 8, top: 92, width: 14, height: 44, borderRadius: 8, backgroundColor: FAITH_THEME.colors.goldBright, boxShadow: `0 0 16px ${FAITH_THEME.colors.gold}` }} />
        </div>
        <div style={{ width: 80, height: 90, backgroundColor: '#C1A18C', marginTop: -20 }} />
        <div style={{ width: 520, height: 180, borderRadius: '110px 110px 0 0', backgroundColor: '#1E293B', marginTop: -10 }} />
      </div>

      <BlueprintCaliper x1={cx - 360} x2={cx + 360} y={cy + 340} label="RESTAURANT BABBLE: 82 dB SPL" subLabel="CHAOTIC OVERLAPPING NOISE" delay={15} color={FAITH_THEME.colors.redNoise} />
      <FaithSubtitles delay={5} lines={[[{ text: 'WHY DO OLD HEARING AIDS' }], [{ text: 'STRUGGLE IN NOISE?', isGold: true }]]} />
    </div>
  );
};
