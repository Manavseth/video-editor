import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { AtmosphericBackdrop } from '../../components/AtmosphericBackdrop';
import { DustParticles } from '../../components/DustParticles';
import { BlueprintCaliper } from '../../components/BlueprintCaliper';
import { FaithSubtitles } from '../../components/FaithSubtitles';
import { FAITH_THEME } from '../../theme_faithvsfact';

export const Scene2_LinearTrap: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const cameraScale = interpolate(frame, [0, 96], [1.0, 1.05]);
  const cx = FAITH_THEME.width / 2;
  const cy = 820;

  // Volume slider surge
  const volumeHeight = interpolate(frame, [0, 50], [80, 260], { extrapolateRight: 'clamp' });
  const meterGlow = frame > 45 ? 'rgba(239, 68, 68, 0.5)' : 'rgba(255, 200, 59, 0.3)';

  return (
    <div style={{ position: 'relative', width: FAITH_THEME.width, height: FAITH_THEME.height, transform: `scale(${cameraScale})`, transformOrigin: 'center center' }}>
      <AtmosphericBackdrop spotlightY={cy} />
      <DustParticles count={30} />

      {/* Indiscriminate Volume Booster Graphic */}
      <div
        style={{
          position: 'absolute',
          left: cx,
          top: cy,
          transform: 'translate(-50%, -50%)',
          width: 500,
          height: 480,
          backgroundColor: 'rgba(15, 23, 42, 0.9)',
          border: `2px solid ${FAITH_THEME.colors.redNoise}`,
          borderRadius: 24,
          padding: 30,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          boxShadow: `0 0 40px ${meterGlow}`,
        }}
      >
        <div style={{ fontFamily: FAITH_THEME.fonts.serif, fontSize: 24, color: FAITH_THEME.colors.redNoise, fontWeight: 800, letterSpacing: '0.12em' }}>
          LINEAR AMPLIFICATION
        </div>

        {/* Dual Equalizer bars: Speech vs Noise (Both maxed out!) */}
        <div style={{ display: 'flex', gap: 60, marginTop: 40, alignItems: 'flex-end', height: 280 }}>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <div style={{ width: 64, height: volumeHeight, backgroundColor: FAITH_THEME.colors.gold, borderRadius: '8px 8px 0 0', boxShadow: `0 0 15px ${FAITH_THEME.colors.gold}` }} />
            <div style={{ fontFamily: FAITH_THEME.fonts.mono, fontSize: 16, color: '#FFF', marginTop: 12 }}>SPEECH</div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <div style={{ width: 64, height: volumeHeight + 20, backgroundColor: FAITH_THEME.colors.redNoise, borderRadius: '8px 8px 0 0', boxShadow: `0 0 15px ${FAITH_THEME.colors.redNoise}` }} />
            <div style={{ fontFamily: FAITH_THEME.fonts.mono, fontSize: 16, color: FAITH_THEME.colors.redNoise, marginTop: 12 }}>NOISE</div>
          </div>
        </div>
      </div>

      <BlueprintCaliper x1={cx - 360} x2={cx + 360} y={cy + 320} label="BLIND AMPLIFICATION: 0% SELECTIVITY" subLabel="AMPLIFIES HARSH CLATTER EQUALLY" delay={15} color={FAITH_THEME.colors.redNoise} />
      <FaithSubtitles delay={5} lines={[[{ text: 'THEY AMPLIFY BACKGROUND CLATTER' }], [{ text: 'JUST AS LOUD AS SPEECH.', isGold: true }]]} />
    </div>
  );
};
