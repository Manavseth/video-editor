import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { AtmosphericBackdrop } from '../../components/AtmosphericBackdrop';
import { DustParticles } from '../../components/DustParticles';
import { BlueprintCaliper } from '../../components/BlueprintCaliper';
import { FaithSubtitles } from '../../components/FaithSubtitles';
import { FAITH_THEME } from '../../theme_faithvsfact';

export const Scene9_WindCancellation: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const cameraScale = interpolate(frame, [0, 96], [1.0, 1.05]);
  const cardEntrance = spring({ frame, fps, config: { damping: 14, stiffness: 120 } });
  const cx = FAITH_THEME.width / 2;
  const cy = 820;

  return (
    <div style={{ position: 'relative', width: FAITH_THEME.width, height: FAITH_THEME.height, transform: `scale(${cameraScale})`, transformOrigin: 'center center' }}>
      <AtmosphericBackdrop spotlightY={cy} />
      <DustParticles count={30} />

      {/* State Tablet Card */}
      <div
        style={{
          position: 'absolute',
          left: cx,
          top: cy,
          transform: `translate(-50%, -50%) scale(${cardEntrance})`,
          width: 520,
          height: 380,
          backgroundColor: 'rgba(15, 23, 42, 0.92)',
          border: `3px solid ${FAITH_THEME.colors.goldBright}`,
          borderRadius: 24,
          padding: 30,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'space-between',
          boxShadow: `0 0 50px rgba(255, 200, 59, 0.35)`,
        }}
      >
        <div style={{ fontFamily: FAITH_THEME.fonts.serif, fontSize: 32, fontWeight: 800, color: FAITH_THEME.colors.goldBright, letterSpacing: '0.12em' }}>
          OUTDOOR WIND
        </div>
        <div style={{ fontFamily: FAITH_THEME.fonts.mono, fontSize: 20, color: FAITH_THEME.colors.blueAccent }}>
          MODE: PHASE CANCELLATION
        </div>
        <div style={{ fontFamily: FAITH_THEME.fonts.serif, fontSize: 20, color: '#FFF', textAlign: 'center', borderTop: '1px solid rgba(255,255,255,0.1)', paddingTop: 16 }}>
          Dual-mic phase inversion instantly neutralizes turbulence rumble.
        </div>
      </div>

      <BlueprintCaliper x1={cx - 360} x2={cx + 360} y={cy + 300} label="PHASE-INVERTED WIND SHIELD" subLabel="TURBULENCE SUPPRESSION SYSTEM" delay={15} color={FAITH_THEME.colors.gold} />
      <FaithSubtitles delay={5} lines={[[{ text: 'IN WIND: INSTANT' }], [{ text: 'TURBULENCE CANCELLATION.', isGold: true }]]} />
    </div>
  );
};
