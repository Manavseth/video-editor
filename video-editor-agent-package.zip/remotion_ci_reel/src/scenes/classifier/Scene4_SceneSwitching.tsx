import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { AtmosphericBackdrop } from '../../components/AtmosphericBackdrop';
import { DustParticles } from '../../components/DustParticles';
import { BlueprintCaliper } from '../../components/BlueprintCaliper';
import { FaithSubtitles } from '../../components/FaithSubtitles';
import { FAITH_THEME } from '../../theme_faithvsfact';

export const Scene4_SceneSwitching: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const cameraScale = interpolate(frame, [0, 360], [1.0, 1.06]);
  const cx = FAITH_THEME.width / 2;
  const cy = 780;

  const envs = [
    {
      title: 'QUIET HOME',
      mode: 'Omnidirectional 360°',
      gain: 'Natural Acoustic Comfort',
      delay: 0,
    },
    {
      title: 'BUSY DINNER',
      mode: 'Narrow Beamforming',
      gain: '-12 dB Rear Babble Cut',
      delay: 20,
    },
    {
      title: 'OUTDOOR WIND',
      mode: 'Phase Cancellation',
      gain: 'Turbulence Shielding',
      delay: 40,
    },
    {
      title: 'LIVE MUSIC',
      mode: 'High Dynamic Range',
      gain: 'Zero Distortion Limiting',
      delay: 60,
    },
  ];

  return (
    <div
      style={{
        position: 'relative',
        width: FAITH_THEME.width,
        height: FAITH_THEME.height,
        transform: `scale(${cameraScale})`,
        transformOrigin: 'center center',
      }}
    >
      <AtmosphericBackdrop spotlightY={cy} />
      <DustParticles count={35} />

      {/* 2x2 Grid of Floating Environmental Tablets */}
      <div
        style={{
          position: 'absolute',
          left: cx,
          top: cy,
          transform: 'translate(-50%, -50%)',
          display: 'grid',
          gridTemplateColumns: 'repeat(2, 400px)',
          gap: 28,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {envs.map((env, i) => {
          const cardSpring = spring({
            frame: frame - env.delay,
            fps,
            config: { damping: 14, stiffness: 120 },
          });

          // Highlight active card
          const isActive = frame > 80 && i === 1; // Highlight restaurant/busy dinner

          return (
            <div
              key={env.title}
              style={{
                height: 220,
                backgroundColor: isActive
                  ? 'rgba(25, 38, 65, 0.95)'
                  : 'rgba(15, 23, 42, 0.85)',
                border: isActive
                  ? `3px solid ${FAITH_THEME.colors.goldBright}`
                  : `2px solid ${FAITH_THEME.colors.goldMuted}`,
                borderRadius: 20,
                padding: '24px 20px',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                boxShadow: isActive
                  ? `0 0 35px rgba(255, 205, 59, 0.4), inset 0 0 20px rgba(255, 205, 59, 0.2)`
                  : '0 10px 30px rgba(0,0,0,0.6)',
                transform: `scale(${cardSpring})`,
                opacity: interpolate(frame - env.delay, [0, 8], [0, 1], {
                  extrapolateLeft: 'clamp',
                  extrapolateRight: 'clamp',
                }),
              }}
            >
              <div>
                <div
                  style={{
                    fontFamily: FAITH_THEME.fonts.serif,
                    fontSize: 26,
                    fontWeight: 800,
                    color: isActive
                      ? FAITH_THEME.colors.goldBright
                      : FAITH_THEME.colors.cream,
                    letterSpacing: '0.12em',
                  }}
                >
                  {env.title}
                </div>
                <div
                  style={{
                    fontFamily: FAITH_THEME.fonts.mono,
                    fontSize: 18,
                    color: FAITH_THEME.colors.blueAccent,
                    marginTop: 8,
                    letterSpacing: '0.06em',
                  }}
                >
                  {env.mode}
                </div>
              </div>

              <div
                style={{
                  fontFamily: FAITH_THEME.fonts.serif,
                  fontSize: 16,
                  color: FAITH_THEME.colors.gold,
                  fontWeight: 600,
                  borderTop: '1px solid rgba(255,255,255,0.1)',
                  paddingTop: 10,
                }}
              >
                {env.gain}
              </div>
            </div>
          );
        })}
      </div>

      {/* Blueprint Caliper */}
      <BlueprintCaliper
        x1={cx - 380}
        x2={cx + 380}
        y={cy + 340}
        label="AUTOMATIC MULTI-SCENE RECONFIGURATION"
        subLabel="ZERO MANUAL BUTTON PRESSES REQUIRED"
        delay={45}
        color={FAITH_THEME.colors.gold}
      />

      {/* Subtitles */}
      <FaithSubtitles
        delay={15}
        lines={[
          [{ text: 'IT INSTANTLY SWITCHES BETWEEN' }, { text: 'ENVIRONMENTS', isGold: true }],
          [
            { text: 'WITHOUT TOUCHING A' },
            { text: 'SINGLE BUTTON.', isGold: true },
          ],
        ]}
      />
    </div>
  );
};
