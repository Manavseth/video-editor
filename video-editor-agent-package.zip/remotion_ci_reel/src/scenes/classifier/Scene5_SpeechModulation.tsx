import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { AtmosphericBackdrop } from '../../components/AtmosphericBackdrop';
import { DustParticles } from '../../components/DustParticles';
import { BlueprintCaliper } from '../../components/BlueprintCaliper';
import { FaithSubtitles } from '../../components/FaithSubtitles';
import { FAITH_THEME } from '../../theme_faithvsfact';

export const Scene5_SpeechModulation: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const cameraScale = interpolate(frame, [0, 96], [1.0, 1.05]);
  const waveEntrance = spring({ frame, fps, config: { damping: 15, stiffness: 120 } });
  const cx = FAITH_THEME.width / 2;
  const cy = 820;

  const waveWidth = 720;
  const speechPoints: string[] = [];
  for (let x = 0; x <= waveWidth; x += 10) {
    const normX = x / waveWidth;
    const carrier = Math.sin((x + frame * 5) * 0.06);
    const envelope = Math.sin(normX * Math.PI * 4 + frame * 0.08);
    const y = 80 + carrier * 40 * envelope;
    speechPoints.push(`${x},${y}`);
  }

  return (
    <div style={{ position: 'relative', width: FAITH_THEME.width, height: FAITH_THEME.height, transform: `scale(${cameraScale})`, transformOrigin: 'center center' }}>
      <AtmosphericBackdrop spotlightY={cy} />
      <DustParticles count={30} />

      {/* Golden Speech Modulation Envelope Card */}
      <div
        style={{
          position: 'absolute',
          left: cx,
          top: cy,
          transform: `translate(-50%, -50%) scale(${waveEntrance})`,
          width: 820,
          height: 300,
          backgroundColor: 'rgba(15, 23, 42, 0.9)',
          border: `2px solid ${FAITH_THEME.colors.gold}`,
          borderRadius: 24,
          padding: '24px 30px',
          boxShadow: `0 10px 45px rgba(0,0,0,0.7), inset 0 0 30px rgba(255, 200, 59, 0.2)`,
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <div style={{ fontFamily: FAITH_THEME.fonts.serif, fontSize: 26, fontWeight: 700, color: FAITH_THEME.colors.gold, letterSpacing: '0.1em' }}>
            HUMAN SPEECH ENVELOPE (3–4 Hz)
          </div>
          <div style={{ fontFamily: FAITH_THEME.fonts.mono, fontSize: 18, color: FAITH_THEME.colors.goldBright, backgroundColor: 'rgba(255, 200, 59, 0.25)', padding: '6px 14px', borderRadius: 6 }}>
            PRESERVE SPEECH
          </div>
        </div>

        <svg width={waveWidth} height={140} style={{ overflow: 'visible' }}>
          <polyline fill="none" stroke={FAITH_THEME.colors.goldBright} strokeWidth={5} points={speechPoints.join(' ')} filter="drop-shadow(0px 0px 10px rgba(255, 215, 0, 0.8))" />
        </svg>
      </div>

      <BlueprintCaliper x1={cx - 360} x2={cx + 360} y={cy + 280} label="SPEECH MODULATION HARMONICS" subLabel="3–4 Hz COGNITIVE FREQUENCY LOCK" delay={15} color={FAITH_THEME.colors.gold} />
      <FaithSubtitles delay={5} lines={[[{ text: 'IT ISOLATES RHYTHMIC' }], [{ text: 'HUMAN SPEECH ENVELOPES.', isGold: true }]]} />
    </div>
  );
};
