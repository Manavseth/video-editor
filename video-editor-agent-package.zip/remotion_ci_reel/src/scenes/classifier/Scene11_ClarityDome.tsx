import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { AtmosphericBackdrop } from '../../components/AtmosphericBackdrop';
import { DustParticles } from '../../components/DustParticles';
import { BlueprintCaliper } from '../../components/BlueprintCaliper';
import { FaithSubtitles } from '../../components/FaithSubtitles';
import { FAITH_THEME } from '../../theme_faithvsfact';

export const Scene11_ClarityDome: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const cameraScale = interpolate(frame, [0, 105], [1.0, 1.05]);
  const cx = FAITH_THEME.width / 2;
  const cy = 820;

  const domeRadius = spring({ frame, fps, config: { damping: 14, stiffness: 100 } });

  return (
    <div style={{ position: 'relative', width: FAITH_THEME.width, height: FAITH_THEME.height, transform: `scale(${cameraScale})`, transformOrigin: 'center center' }}>
      <AtmosphericBackdrop spotlightY={cy} />
      <DustParticles count={35} />

      {/* Golden Acoustic Clarity Dome */}
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
        {[380, 310, 240].map((baseR, i) => {
          const r = baseR * domeRadius;
          const alpha = 0.28 - i * 0.07;
          return (
            <circle
              key={i}
              cx={cx}
              cy={cy - 40}
              r={r}
              fill="none"
              stroke={FAITH_THEME.colors.goldBright}
              strokeWidth={3}
              opacity={alpha}
              filter="drop-shadow(0px 0px 12px rgba(255, 215, 0, 0.8))"
            />
          );
        })}
      </svg>

      {/* Patient Profile */}
      <div style={{ position: 'absolute', left: cx, top: cy, transform: 'translate(-50%, -50%)', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <div style={{ width: 200, height: 250, borderRadius: '50% 50% 45% 45%', backgroundColor: FAITH_THEME.colors.paperSkin, boxShadow: `0 0 45px rgba(255, 200, 59, 0.4)`, position: 'relative' }}>
          <div style={{ position: 'absolute', right: 16, top: 95, width: 52, height: 75, borderRadius: '50%', backgroundColor: '#C5A48F' }} />
          <div style={{ position: 'absolute', right: 6, top: 84, width: 14, height: 40, borderRadius: 8, backgroundColor: FAITH_THEME.colors.goldBright, boxShadow: `0 0 20px ${FAITH_THEME.colors.goldBright}` }} />
        </div>
        <div style={{ width: 70, height: 80, backgroundColor: '#C1A18C', marginTop: -15 }} />
        <div style={{ width: 480, height: 160, borderRadius: '100px 100px 0 0', backgroundColor: '#1E293B', marginTop: -10 }} />
      </div>

      <BlueprintCaliper x1={cx - 360} x2={cx + 360} y={cy + 300} label="LISTENING EFFORT: -40% | CLARITY: +65%" subLabel="PROVEN CLINICAL ACOUSTIC COMFORT" delay={10} color={FAITH_THEME.colors.goldBright} />
      <FaithSubtitles delay={5} lines={[[{ text: 'LESS BRAIN FATIGUE.' }], [{ text: 'EFFORTLESS NATURAL CONVERSATION.', isGold: true }]]} />
    </div>
  );
};
