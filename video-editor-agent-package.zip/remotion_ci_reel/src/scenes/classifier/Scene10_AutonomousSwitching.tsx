import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { AtmosphericBackdrop } from '../../components/AtmosphericBackdrop';
import { DustParticles } from '../../components/DustParticles';
import { BlueprintCaliper } from '../../components/BlueprintCaliper';
import { FaithSubtitles } from '../../components/FaithSubtitles';
import { FAITH_THEME } from '../../theme_faithvsfact';

export const Scene10_AutonomousSwitching: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const cameraScale = interpolate(frame, [0, 96], [1.0, 1.05]);
  const cx = FAITH_THEME.width / 2;
  const cy = 800;

  const cards = [
    { title: 'QUIET HOME', x: cx - 210, y: cy - 110 },
    { title: 'BUSY DINNER', x: cx + 210, y: cy - 110 },
    { title: 'OUTDOOR WIND', x: cx - 210, y: cy + 110 },
    { title: 'LIVE MUSIC', x: cx + 210, y: cy + 110 },
  ];

  return (
    <div style={{ position: 'relative', width: FAITH_THEME.width, height: FAITH_THEME.height, transform: `scale(${cameraScale})`, transformOrigin: 'center center' }}>
      <AtmosphericBackdrop spotlightY={cy} />
      <DustParticles count={30} />

      {/* 2x2 Matrix with Cross-Connection Beams */}
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
        <line x1={cx - 210} y1={cy - 110} x2={cx + 210} y2={cy + 110} stroke={FAITH_THEME.colors.gold} strokeWidth={2} strokeDasharray="6 4" opacity={0.6} />
        <line x1={cx + 210} y1={cy - 110} x2={cx - 210} y2={cy + 110} stroke={FAITH_THEME.colors.gold} strokeWidth={2} strokeDasharray="6 4" opacity={0.6} />
      </svg>

      {cards.map((c, i) => (
        <div
          key={i}
          style={{
            position: 'absolute',
            left: c.x,
            top: c.y,
            transform: 'translate(-50%, -50%)',
            width: 360,
            height: 160,
            backgroundColor: 'rgba(15, 23, 42, 0.9)',
            border: `2px solid ${FAITH_THEME.colors.gold}`,
            borderRadius: 18,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: `0 0 25px rgba(255, 200, 59, 0.25)`,
          }}
        >
          <div style={{ fontFamily: FAITH_THEME.fonts.serif, fontSize: 24, fontWeight: 700, color: FAITH_THEME.colors.goldBright, letterSpacing: '0.1em' }}>
            {c.title}
          </div>
        </div>
      ))}

      <BlueprintCaliper x1={cx - 360} x2={cx + 360} y={cy + 300} label="AUTONOMOUS SEAMLESS SWITCHING" subLabel="ZERO DELAY • 0 MANUAL BUTTON PRESSES" delay={15} color={FAITH_THEME.colors.gold} />
      <FaithSubtitles delay={5} lines={[[{ text: 'ZERO BUTTON PRESSES.' }], [{ text: '100% AUTOMATIC ADAPTATION.', isGold: true }]]} />
    </div>
  );
};
