import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { AtmosphericBackdrop } from '../../components/AtmosphericBackdrop';
import { DustParticles } from '../../components/DustParticles';
import { BlueprintCaliper } from '../../components/BlueprintCaliper';
import { FaithSubtitles } from '../../components/FaithSubtitles';
import { FAITH_THEME } from '../../theme_faithvsfact';

export const Scene2_DSPChip: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // Slow zoom into the processor
  const cameraScale = interpolate(frame, [0, 300], [0.98, 1.06]);

  const chipEntrance = spring({
    frame,
    fps,
    config: { damping: 16, stiffness: 110 },
  });

  const cx = FAITH_THEME.width / 2;
  const cy = 820;

  // Pulse along the golden circuit traces
  const tracePulse = (frame * 6) % 180;

  return (
    <div
      style={{
        position: 'relative',
        width: FAITH_THEME.width,
        height: FAITH_THEME.height,
        transform: `scale(${cameraScale})`,
        transformOrigin: 'center center',
      }}
    >
      <AtmosphericBackdrop spotlightY={cy} />
      <DustParticles count={35} />

      {/* Blueprint Grid Lines */}
      <svg
        style={{
          position: 'absolute',
          inset: 0,
          width: '100%',
          height: '100%',
          opacity: 0.22,
          pointerEvents: 'none',
        }}
      >
        {Array.from({ length: 12 }).map((_, i) => (
          <line
            key={`grid-x-${i}`}
            x1={80 + i * 85}
            y1={200}
            x2={80 + i * 85}
            y2={1400}
            stroke={FAITH_THEME.colors.blueAccent}
            strokeWidth={1}
            strokeDasharray="4 6"
          />
        ))}
        {Array.from({ length: 14 }).map((_, i) => (
          <line
            key={`grid-y-${i}`}
            x1={80}
            y1={220 + i * 85}
            x2={1000}
            y2={220 + i * 85}
            stroke={FAITH_THEME.colors.blueAccent}
            strokeWidth={1}
            strokeDasharray="4 6"
          />
        ))}
      </svg>

      {/* The Central DSP Classifier Chip Card */}
      <div
        style={{
          position: 'absolute',
          left: cx,
          top: cy,
          width: 520,
          height: 520,
          transform: `translate(-50%, -50%) scale(${chipEntrance})`,
          backgroundColor: 'rgba(12, 22, 38, 0.9)',
          border: `3px solid ${FAITH_THEME.colors.gold}`,
          borderRadius: 24,
          boxShadow: `0 0 50px rgba(255, 200, 59, 0.25), inset 0 0 40px rgba(0, 0, 0, 0.8)`,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: 30,
        }}
      >
        {/* Golden Pins on sides */}
        {[-160, -80, 0, 80, 160].map((offset, i) => (
          <React.Fragment key={i}>
            {/* Left Pin */}
            <div
              style={{
                position: 'absolute',
                left: -32,
                top: 260 + offset - 8,
                width: 32,
                height: 16,
                backgroundColor: FAITH_THEME.colors.goldMuted,
                borderRadius: '4px 0 0 4px',
                boxShadow: `0 0 8px ${FAITH_THEME.colors.gold}`,
              }}
            />
            {/* Right Pin */}
            <div
              style={{
                position: 'absolute',
                right: -32,
                top: 260 + offset - 8,
                width: 32,
                height: 16,
                backgroundColor: FAITH_THEME.colors.goldMuted,
                borderRadius: '0 4px 4px 0',
                boxShadow: `0 0 8px ${FAITH_THEME.colors.gold}`,
              }}
            />
          </React.Fragment>
        ))}

        {/* Central Core Emblem */}
        <div
          style={{
            width: 140,
            height: 140,
            borderRadius: '50%',
            border: `2px dashed ${FAITH_THEME.colors.gold}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: 20,
            transform: `rotate(${frame * 0.4}deg)`,
          }}
        >
          <div
            style={{
              width: 80,
              height: 80,
              borderRadius: 12,
              backgroundColor: FAITH_THEME.colors.gold,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: `0 0 25px ${FAITH_THEME.colors.goldBright}`,
              transform: `rotate(${-frame * 0.8}deg)`,
            }}
          >
            <div style={{ color: '#000', fontWeight: 900, fontSize: 32 }}>AI</div>
          </div>
        </div>

        {/* Typography on the Chip */}
        <div
          style={{
            fontFamily: FAITH_THEME.fonts.serif,
            fontSize: 32,
            fontWeight: 800,
            color: FAITH_THEME.colors.white,
            letterSpacing: '0.14em',
            textTransform: 'uppercase',
            textAlign: 'center',
          }}
        >
          ENVIRONMENTAL
        </div>
        <div
          style={{
            fontFamily: FAITH_THEME.fonts.serif,
            fontSize: 36,
            fontWeight: 800,
            color: FAITH_THEME.colors.gold,
            letterSpacing: '0.14em',
            textTransform: 'uppercase',
            textAlign: 'center',
            marginTop: 4,
          }}
        >
          CLASSIFIER
        </div>
        <div
          style={{
            fontFamily: FAITH_THEME.fonts.mono,
            fontSize: 20,
            color: FAITH_THEME.colors.blueAccent,
            letterSpacing: '0.1em',
            marginTop: 12,
          }}
        >
          DIGITAL SIGNAL PROCESSOR
        </div>
      </div>

      {/* Blueprint Caliper: Sampling Rate */}
      <BlueprintCaliper
        x1={cx - 360}
        x2={cx + 360}
        y={cy + 360}
        label="REAL-TIME SOUNDSCAPE SAMPLING"
        subLabel="500 SCANS PER SECOND • 0.002s LATENCY"
        delay={35}
        color={FAITH_THEME.colors.gold}
      />

      {/* Subtitles */}
      <FaithSubtitles
        delay={15}
        lines={[
          [{ text: "MODERN HEARING AIDS DON'T JUST AMPLIFY." }],
          [
            { text: 'THEY' },
            { text: 'CLASSIFY THE ENTIRE SOUNDSCAPE.', isGold: true },
          ],
        ]}
      />
    </div>
  );
};
