import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { AtmosphericBackdrop } from '../../components/AtmosphericBackdrop';
import { DustParticles } from '../../components/DustParticles';
import { BlueprintCaliper } from '../../components/BlueprintCaliper';
import { FaithSubtitles } from '../../components/FaithSubtitles';
import { FAITH_THEME } from '../../theme_faithvsfact';

export const Scene4_DSPClassifier: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const cameraScale = interpolate(frame, [0, 96], [0.98, 1.05]);
  const chipEntrance = spring({ frame, fps, config: { damping: 15, stiffness: 120 } });
  const cx = FAITH_THEME.width / 2;
  const cy = 820;

  return (
    <div style={{ position: 'relative', width: FAITH_THEME.width, height: FAITH_THEME.height, transform: `scale(${cameraScale})`, transformOrigin: 'center center' }}>
      <AtmosphericBackdrop spotlightY={cy} />
      <DustParticles count={30} />

      {/* Blueprint Grid Lines */}
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.22, pointerEvents: 'none' }}>
        {Array.from({ length: 12 }).map((_, i) => (
          <line key={`gx-${i}`} x1={80 + i * 85} y1={200} x2={80 + i * 85} y2={1400} stroke={FAITH_THEME.colors.blueAccent} strokeWidth={1} strokeDasharray="4 6" />
        ))}
      </svg>

      {/* Central DSP Classifier Chip Card */}
      <div
        style={{
          position: 'absolute',
          left: cx,
          top: cy,
          width: 480,
          height: 480,
          transform: `translate(-50%, -50%) scale(${chipEntrance})`,
          backgroundColor: 'rgba(12, 22, 38, 0.92)',
          border: `3px solid ${FAITH_THEME.colors.gold}`,
          borderRadius: 24,
          boxShadow: `0 0 50px rgba(255, 200, 59, 0.3)`,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: 24,
        }}
      >
        <div style={{ width: 110, height: 110, borderRadius: '50%', border: `2px dashed ${FAITH_THEME.colors.gold}`, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16, transform: `rotate(${frame * 0.8}deg)` }}>
          <div style={{ width: 64, height: 64, borderRadius: 10, backgroundColor: FAITH_THEME.colors.gold, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: `0 0 20px ${FAITH_THEME.colors.goldBright}` }}>
            <div style={{ color: '#000', fontWeight: 900, fontSize: 26 }}>AI</div>
          </div>
        </div>

        <div style={{ fontFamily: FAITH_THEME.fonts.serif, fontSize: 28, fontWeight: 800, color: '#FFF', letterSpacing: '0.12em', textAlign: 'center' }}>ENVIRONMENTAL</div>
        <div style={{ fontFamily: FAITH_THEME.fonts.serif, fontSize: 32, fontWeight: 800, color: FAITH_THEME.colors.gold, letterSpacing: '0.12em', textAlign: 'center', marginTop: 4 }}>CLASSIFIER</div>
        <div style={{ fontFamily: FAITH_THEME.fonts.mono, fontSize: 18, color: FAITH_THEME.colors.blueAccent, marginTop: 8 }}>NEURAL DSP CORE</div>
      </div>

      <BlueprintCaliper x1={cx - 360} x2={cx + 360} y={cy + 340} label="SAMPLING: 500 SCANS PER SECOND" subLabel="CONTINUOUS REAL-TIME ACOUSTIC MAPPING" delay={15} color={FAITH_THEME.colors.gold} />
      <FaithSubtitles delay={5} lines={[[{ text: 'THE ENVIRONMENTAL CLASSIFIER' }], [{ text: 'SCANS IN REAL TIME.', isGold: true }]]} />
    </div>
  );
};
