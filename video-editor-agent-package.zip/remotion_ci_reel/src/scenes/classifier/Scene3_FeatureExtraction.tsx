import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { AtmosphericBackdrop } from '../../components/AtmosphericBackdrop';
import { DustParticles } from '../../components/DustParticles';
import { BlueprintCaliper } from '../../components/BlueprintCaliper';
import { FaithSubtitles } from '../../components/FaithSubtitles';
import { FAITH_THEME } from '../../theme_faithvsfact';

export const Scene3_FeatureExtraction: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const cameraScale = interpolate(frame, [0, 360], [1.0, 1.05]);

  const cardsEntrance = spring({
    frame,
    fps,
    config: { damping: 15, stiffness: 120 },
  });

  const cx = FAITH_THEME.width / 2;
  const cy = 800;

  // Generate dynamic 4 Hz speech modulation wave points
  const speechPoints: string[] = [];
  const waveWidth = 720;
  for (let x = 0; x <= waveWidth; x += 10) {
    const normX = x / waveWidth;
    const carrier = Math.sin((x + frame * 4) * 0.05);
    const envelope = Math.sin(normX * Math.PI * 4 + frame * 0.06);
    const y = 80 + carrier * 35 * envelope;
    speechPoints.push(`${x},${y}`);
  }

  // Generate chaotic steady-state noise wave points
  const noisePoints: string[] = [];
  for (let x = 0; x <= waveWidth; x += 8) {
    // Deterministic pseudo-noise
    const rnd = Math.sin(x * 12.9898 + frame * 0.4) * 43758.5453;
    const frac = rnd - Math.floor(rnd);
    const y = 80 + (frac - 0.5) * 40;
    noisePoints.push(`${x},${y}`);
  }

  return (
    <div
      style={{
        position: 'relative',
        width: FAITH_THEME.width,
        height: FAITH_THEME.height,
        transform: `scale(${cameraScale})`,
        transformOrigin: 'center center',
      }}
    >
      <AtmosphericBackdrop spotlightY={cy} />
      <DustParticles count={35} />

      {/* Container for the Two Frequency Cards */}
      <div
        style={{
          position: 'absolute',
          left: cx,
          top: cy,
          transform: `translate(-50%, -50%) scale(${cardsEntrance})`,
          display: 'flex',
          flexDirection: 'column',
          gap: 40,
          alignItems: 'center',
        }}
      >
        {/* Card 1: Golden Speech Envelope (4 Hz Modulation) */}
        <div
          style={{
            width: 820,
            height: 230,
            backgroundColor: 'rgba(15, 23, 42, 0.85)',
            border: `2px solid ${FAITH_THEME.colors.gold}`,
            borderRadius: 20,
            padding: '20px 30px',
            boxShadow: `0 10px 40px rgba(0,0,0,0.7), inset 0 0 25px rgba(255, 200, 59, 0.15)`,
            position: 'relative',
          }}
        >
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: 10,
            }}
          >
            <div
              style={{
                fontFamily: FAITH_THEME.fonts.serif,
                fontSize: 24,
                fontWeight: 700,
                color: FAITH_THEME.colors.gold,
                letterSpacing: '0.1em',
              }}
            >
              HUMAN SPEECH ENVELOPE (3–4 Hz)
            </div>
            <div
              style={{
                fontFamily: FAITH_THEME.fonts.mono,
                fontSize: 18,
                color: FAITH_THEME.colors.goldBright,
                backgroundColor: 'rgba(255, 200, 59, 0.2)',
                padding: '4px 12px',
                borderRadius: 6,
              }}
            >
              DETECTED: PRESERVE
            </div>
          </div>

          <svg width={waveWidth} height={130} style={{ overflow: 'visible' }}>
            <polyline
              fill="none"
              stroke={FAITH_THEME.colors.goldBright}
              strokeWidth={4}
              points={speechPoints.join(' ')}
              filter="drop-shadow(0px 0px 8px rgba(255, 215, 0, 0.7))"
            />
          </svg>
        </div>

        {/* Card 2: Background Clatter / Babble Noise */}
        <div
          style={{
            width: 820,
            height: 230,
            backgroundColor: 'rgba(15, 23, 42, 0.85)',
            border: `2px solid ${FAITH_THEME.colors.blueBorder}`,
            borderRadius: 20,
            padding: '20px 30px',
            boxShadow: `0 10px 40px rgba(0,0,0,0.7)`,
            position: 'relative',
          }}
        >
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: 10,
            }}
          >
            <div
              style={{
                fontFamily: FAITH_THEME.fonts.serif,
                fontSize: 24,
                fontWeight: 700,
                color: FAITH_THEME.colors.slateNoise,
                letterSpacing: '0.1em',
              }}
            >
              DIFFUSE BACKGROUND BABBLE
            </div>
            <div
              style={{
                fontFamily: FAITH_THEME.fonts.mono,
                fontSize: 18,
                color: FAITH_THEME.colors.blueAccent,
                backgroundColor: 'rgba(100, 181, 246, 0.15)',
                padding: '4px 12px',
                borderRadius: 6,
              }}
            >
              ATTENUATE: -12 dB
            </div>
          </div>

          <svg width={waveWidth} height={130} style={{ overflow: 'visible' }}>
            <polyline
              fill="none"
              stroke={FAITH_THEME.colors.slateNoise}
              strokeWidth={2.5}
              points={noisePoints.join(' ')}
              opacity={0.7}
            />
          </svg>
        </div>
      </div>

      {/* Blueprint Caliper: Signal to Noise Advantage */}
      <BlueprintCaliper
        x1={cx - 360}
        x2={cx + 360}
        y={cy + 340}
        label="REAL-TIME SNR SEPARATION: +8.5 dB"
        subLabel="MODULATION FILTERING • SPECTRAL SUBTRACTION"
        delay={35}
        color={FAITH_THEME.colors.gold}
      />

      {/* Subtitles */}
      <FaithSubtitles
        delay={15}
        lines={[
          [{ text: 'THE CHIP EXTRACTS' }, { text: 'SPEECH ENVELOPES', isGold: true }],
          [
            { text: 'FROM CONSTANT' },
            { text: 'BACKGROUND NOISE IN REAL TIME.', isGold: true },
          ],
        ]}
      />
    </div>
  );
};
