import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { AtmosphericBackdrop } from '../../components/AtmosphericBackdrop';
import { DustParticles } from '../../components/DustParticles';
import { BlueprintCaliper } from '../../components/BlueprintCaliper';
import { FaithSubtitles } from '../../components/FaithSubtitles';
import { FAITH_THEME } from '../../theme_faithvsfact';

export const Scene1_Chaos: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // Subtle continuous slow camera push-in
  const cameraScale = interpolate(frame, [0, 240], [1.0, 1.07]);

  // Entrance of patient silhouette
  const patientEntrance = spring({
    frame,
    fps,
    config: { damping: 15, stiffness: 100 },
  });

  const cx = FAITH_THEME.width / 2;
  const cy = 840;

  return (
    <div
      style={{
        position: 'relative',
        width: FAITH_THEME.width,
        height: FAITH_THEME.height,
        transform: `scale(${cameraScale})`,
        transformOrigin: 'center center',
      }}
    >
      <AtmosphericBackdrop spotlightY={cy} />
      <DustParticles count={30} />

      {/* Acoustic Chaos: Converging Noise Waves */}
      <svg
        style={{
          position: 'absolute',
          inset: 0,
          width: '100%',
          height: '100%',
          pointerEvents: 'none',
        }}
      >
        {/* Left red babble waves */}
        {[220, 310, 400, 490].map((r, i) => {
          const wavePhase = (frame * 3 + i * 40) % 200;
          return (
            <circle
              key={`left-${i}`}
              cx={cx - 360}
              cy={cy - 40}
              r={r + wavePhase * 0.4}
              fill="none"
              stroke={FAITH_THEME.colors.redNoise}
              strokeWidth={3}
              opacity={interpolate(wavePhase, [0, 100, 200], [0.1, 0.7, 0])}
            />
          );
        })}

        {/* Right slate clatter waves */}
        {[200, 290, 380, 470].map((r, i) => {
          const wavePhase = (frame * 2.5 + i * 45) % 200;
          return (
            <circle
              key={`right-${i}`}
              cx={cx + 360}
              cy={cy - 20}
              r={r + wavePhase * 0.4}
              fill="none"
              stroke={FAITH_THEME.colors.slateNoise}
              strokeWidth={2.5}
              strokeDasharray="6 4"
              opacity={interpolate(wavePhase, [0, 100, 200], [0.1, 0.6, 0])}
            />
          );
        })}
      </svg>

      {/* Patient Silhouette (Paper-cut Vector Style) */}
      <div
        style={{
          position: 'absolute',
          left: cx,
          top: cy,
          transform: `translate(-50%, -50%) scale(${patientEntrance})`,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        {/* Head */}
        <div
          style={{
            width: 220,
            height: 270,
            borderRadius: '50% 50% 45% 45%',
            backgroundColor: FAITH_THEME.colors.paperSkin,
            boxShadow: '0 15px 35px rgba(0,0,0,0.6)',
            position: 'relative',
          }}
        >
          {/* Ear Profile */}
          <div
            style={{
              position: 'absolute',
              right: 18,
              top: 105,
              width: 58,
              height: 85,
              borderRadius: '50%',
              backgroundColor: '#C5A48F',
              border: '2px solid #AD8D78',
            }}
          />

          {/* Golden Discreet RIC Hearing Aid */}
          <div
            style={{
              position: 'absolute',
              right: 8,
              top: 92,
              width: 14,
              height: 44,
              borderRadius: 8,
              backgroundColor: FAITH_THEME.colors.goldBright,
              boxShadow: `0 0 16px ${FAITH_THEME.colors.gold}`,
            }}
          >
            {/* Earwire */}
            <div
              style={{
                position: 'absolute',
                top: 4,
                left: 6,
                width: 22,
                height: 38,
                borderTop: `3px solid ${FAITH_THEME.colors.gold}`,
                borderRight: `3px solid ${FAITH_THEME.colors.gold}`,
                borderRadius: '0 14px 0 0',
              }}
            />
          </div>
        </div>

        {/* Neck */}
        <div
          style={{
            width: 80,
            height: 90,
            backgroundColor: '#C1A18C',
            marginTop: -20,
          }}
        />

        {/* Torso / Shoulders */}
        <div
          style={{
            width: 520,
            height: 180,
            borderRadius: '110px 110px 0 0',
            backgroundColor: '#1E293B',
            marginTop: -10,
            boxShadow: '0 20px 40px rgba(0,0,0,0.8)',
          }}
        />
      </div>

      {/* Blueprint Caliper: Restaurant Noise Level */}
      <BlueprintCaliper
        x1={cx - 380}
        x2={cx + 380}
        y={cy + 340}
        label="RESTAURANT BABBLE: 82 dB SPL"
        subLabel="CHAOTIC OVERLAPPING NOISE ENVELOPE"
        delay={30}
        color={FAITH_THEME.colors.redNoise}
      />

      {/* Lower-Third Subtitles */}
      <FaithSubtitles
        delay={15}
        lines={[
          [{ text: 'WHY DO TRADITIONAL HEARING AIDS' }],
          [
            { text: 'STRUGGLE IN A' },
            { text: 'CROWDED, NOISY ROOM?', isGold: true },
          ],
        ]}
      />
    </div>
  );
};
