import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { AtmosphericBackdrop } from '../../components/AtmosphericBackdrop';
import { DustParticles } from '../../components/DustParticles';
import { BlueprintCaliper } from '../../components/BlueprintCaliper';
import { FaithSubtitles } from '../../components/FaithSubtitles';
import { FAITH_THEME } from '../../theme_faithvsfact';

export const Scene5_ClarityDome: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const cameraScale = interpolate(frame, [0, 90], [1.0, 1.04]);
  const cx = FAITH_THEME.width / 2;
  const cy = 820;

  // Expanding Golden Acoustic Clarity Dome
  const domeRadius = spring({
    frame,
    fps,
    config: { damping: 14, stiffness: 90 },
  });

  return (
    <div
      style={{
        position: 'relative',
        width: FAITH_THEME.width,
        height: FAITH_THEME.height,
        transform: `scale(${cameraScale})`,
        transformOrigin: 'center center',
      }}
    >
      <AtmosphericBackdrop spotlightY={cy} />
      <DustParticles count={40} />

      {/* The Illuminated Golden Clarity Protection Dome */}
      <svg
        style={{
          position: 'absolute',
          inset: 0,
          width: '100%',
          height: '100%',
          pointerEvents: 'none',
        }}
      >
        {[380, 310, 240].map((baseR, i) => {
          const r = baseR * domeRadius;
          const alpha = 0.25 - i * 0.06;
          return (
            <circle
              key={i}
              cx={cx}
              cy={cy - 40}
              r={r}
              fill="none"
              stroke={FAITH_THEME.colors.goldBright}
              strokeWidth={3}
              opacity={alpha}
              filter="drop-shadow(0px 0px 12px rgba(255, 215, 0, 0.8))"
            />
          );
        })}
      </svg>

      {/* Patient Silhouette (Relaxed, Natural Hearing) */}
      <div
        style={{
          position: 'absolute',
          left: cx,
          top: cy,
          transform: 'translate(-50%, -50%)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        {/* Head */}
        <div
          style={{
            width: 200,
            height: 250,
            borderRadius: '50% 50% 45% 45%',
            backgroundColor: FAITH_THEME.colors.paperSkin,
            boxShadow: `0 0 45px rgba(255, 200, 59, 0.4)`,
            position: 'relative',
          }}
        >
          {/* Ear Profile */}
          <div
            style={{
              position: 'absolute',
              right: 16,
              top: 95,
              width: 52,
              height: 75,
              borderRadius: '50%',
              backgroundColor: '#C5A48F',
            }}
          />

          {/* Golden Hearing Aid */}
          <div
            style={{
              position: 'absolute',
              right: 6,
              top: 84,
              width: 14,
              height: 40,
              borderRadius: 8,
              backgroundColor: FAITH_THEME.colors.goldBright,
              boxShadow: `0 0 20px ${FAITH_THEME.colors.goldBright}`,
            }}
          />
        </div>

        {/* Neck */}
        <div
          style={{
            width: 70,
            height: 80,
            backgroundColor: '#C1A18C',
            marginTop: -15,
          }}
        />

        {/* Torso */}
        <div
          style={{
            width: 480,
            height: 160,
            borderRadius: '100px 100px 0 0',
            backgroundColor: '#1E293B',
            marginTop: -10,
          }}
        />
      </div>

      {/* Clinical Telemetry Outcome Badge */}
      <BlueprintCaliper
        x1={cx - 380}
        x2={cx + 380}
        y={cy + 320}
        label="LISTENING EFFORT: -40% | SPEECH CLARITY: +65%"
        subLabel="PROVEN CLINICAL PATIENT COMFORT IN NOISE"
        delay={10}
        color={FAITH_THEME.colors.goldBright}
      />

      {/* Subtitles */}
      <FaithSubtitles
        delay={5}
        lines={[
          [{ text: 'ZERO EFFORT.' }, { text: 'ZERO STRUGGLE.', isGold: true }],
          [
            { text: 'JUST' },
            { text: 'EFFORTLESS NATURAL CONVERSATION.', isGold: true },
          ],
        ]}
      />
    </div>
  );
};
