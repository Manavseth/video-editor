import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { AtmosphericBackdrop } from '../../components/AtmosphericBackdrop';
import { DustParticles } from '../../components/DustParticles';
import { BlueprintCaliper } from '../../components/BlueprintCaliper';
import { FaithSubtitles } from '../../components/FaithSubtitles';
import { FAITH_THEME } from '../../theme_faithvsfact';

export const Scene3_MicroArchitecture: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const cameraScale = interpolate(frame, [0, 96], [1.0, 1.08]);
  const cx = FAITH_THEME.width / 2;
  const cy = 820;

  const deviceEntrance = spring({ frame, fps, config: { damping: 14, stiffness: 120 } });

  return (
    <div style={{ position: 'relative', width: FAITH_THEME.width, height: FAITH_THEME.height, transform: `scale(${cameraScale})`, transformOrigin: 'center center' }}>
      <AtmosphericBackdrop spotlightY={cy} />
      <DustParticles count={30} />

      {/* Modern Hearing Aid Exploded / Translucent Blueprint */}
      <div
        style={{
          position: 'absolute',
          left: cx,
          top: cy,
          transform: `translate(-50%, -50%) scale(${deviceEntrance})`,
          width: 380,
          height: 480,
          border: `2px dashed ${FAITH_THEME.colors.gold}`,
          borderRadius: '50px 180px 180px 50px',
          backgroundColor: 'rgba(12, 22, 38, 0.85)',
          boxShadow: `0 0 45px rgba(255, 200, 59, 0.3)`,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {/* Microphones */}
        <div style={{ position: 'absolute', top: 30, right: 80, width: 22, height: 22, borderRadius: '50%', backgroundColor: FAITH_THEME.colors.blueAccent, boxShadow: `0 0 10px ${FAITH_THEME.colors.blueAccent}` }} />
        <div style={{ position: 'absolute', top: 75, right: 60, width: 22, height: 22, borderRadius: '50%', backgroundColor: FAITH_THEME.colors.blueAccent, boxShadow: `0 0 10px ${FAITH_THEME.colors.blueAccent}` }} />
        <div style={{ position: 'absolute', top: 40, right: 120, fontFamily: FAITH_THEME.fonts.mono, fontSize: 14, color: FAITH_THEME.colors.blueAccent }}>DUAL BEAM MICS</div>

        {/* Central Microprocessor Core */}
        <div
          style={{
            width: 130,
            height: 130,
            borderRadius: 16,
            backgroundColor: 'rgba(255, 200, 59, 0.2)',
            border: `2px solid ${FAITH_THEME.colors.goldBright}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: `0 0 25px ${FAITH_THEME.colors.gold}`,
          }}
        >
          <div style={{ fontFamily: FAITH_THEME.fonts.serif, fontSize: 24, fontWeight: 800, color: '#FFF' }}>AI CORE</div>
        </div>
      </div>

      <BlueprintCaliper x1={cx - 360} x2={cx + 360} y={cy + 320} label="MICRO-SIGNAL ARCHITECTURE" subLabel="INTEGRATED DUAL-MICROPHONE ARRAY" delay={15} color={FAITH_THEME.colors.gold} />
      <FaithSubtitles delay={5} lines={[[{ text: 'MODERN DEVICES CONTAIN A' }], [{ text: 'DEDICATED AI PROCESSOR.', isGold: true }]]} />
    </div>
  );
};
