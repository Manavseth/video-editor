import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { AtmosphericBackdrop } from '../../components/AtmosphericBackdrop';
import { DustParticles } from '../../components/DustParticles';
import { BlueprintCaliper } from '../../components/BlueprintCaliper';
import { FaithSubtitles } from '../../components/FaithSubtitles';
import { FAITH_THEME } from '../../theme_faithvsfact';

export const Scene6_NoiseSubtraction: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const cameraScale = interpolate(frame, [0, 96], [1.0, 1.05]);
  const waveEntrance = spring({ frame, fps, config: { damping: 15, stiffness: 120 } });
  const cx = FAITH_THEME.width / 2;
  const cy = 820;

  // Squashing of noise amplitude over 96 frames
  const noiseScale = interpolate(frame, [0, 60], [1.0, 0.28], { extrapolateRight: 'clamp' });

  const waveWidth = 720;
  const noisePoints: string[] = [];
  for (let x = 0; x <= waveWidth; x += 8) {
    const rnd = Math.sin(x * 14.123 + frame * 0.5) * 43758.5453;
    const frac = rnd - Math.floor(rnd);
    const y = 80 + (frac - 0.5) * 60 * noiseScale;
    noisePoints.push(`${x},${y}`);
  }

  return (
    <div style={{ position: 'relative', width: FAITH_THEME.width, height: FAITH_THEME.height, transform: `scale(${cameraScale})`, transformOrigin: 'center center' }}>
      <AtmosphericBackdrop spotlightY={cy} />
      <DustParticles count={30} />

      {/* Noise Attenuation Card */}
      <div
        style={{
          position: 'absolute',
          left: cx,
          top: cy,
          transform: `translate(-50%, -50%) scale(${waveEntrance})`,
          width: 820,
          height: 300,
          backgroundColor: 'rgba(15, 23, 42, 0.9)',
          border: `2px solid ${FAITH_THEME.colors.blueAccent}`,
          borderRadius: 24,
          padding: '24px 30px',
          boxShadow: `0 10px 45px rgba(0,0,0,0.7)`,
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <div style={{ fontFamily: FAITH_THEME.fonts.serif, fontSize: 26, fontWeight: 700, color: FAITH_THEME.colors.slateNoise, letterSpacing: '0.1em' }}>
            DIFFUSE BACKGROUND NOISE
          </div>
          <div style={{ fontFamily: FAITH_THEME.fonts.mono, fontSize: 18, color: FAITH_THEME.colors.blueAccent, backgroundColor: 'rgba(100, 181, 246, 0.18)', padding: '6px 14px', borderRadius: 6 }}>
            ATTENUATED: -12 dB
          </div>
        </div>

        <svg width={waveWidth} height={140} style={{ overflow: 'visible' }}>
          <polyline fill="none" stroke={FAITH_THEME.colors.slateNoise} strokeWidth={3} points={noisePoints.join(' ')} opacity={0.8} />
        </svg>
      </div>

      <BlueprintCaliper x1={cx - 360} x2={cx + 360} y={cy + 280} label="SIGNAL-TO-NOISE: +8.5 dB" subLabel="SPECTRAL SUBTRACTION IN PROGRESS" delay={15} color={FAITH_THEME.colors.gold} />
      <FaithSubtitles delay={5} lines={[[{ text: 'AND SUPPRESSES RANDOM,' }], [{ text: 'CHAOTIC BACKGROUND BABBLE.', isGold: true }]]} />
    </div>
  );
};
