import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { AtmosphericBackdrop } from '../../components/AtmosphericBackdrop';
import { DustParticles } from '../../components/DustParticles';
import { BlueprintCaliper } from '../../components/BlueprintCaliper';
import { FaithSubtitles } from '../../components/FaithSubtitles';
import { FAITH_THEME } from '../../theme_faithvsfact';

export const Scene7_QuietState: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const cameraScale = interpolate(frame, [0, 96], [1.0, 1.05]);
  const cardEntrance = spring({ frame, fps, config: { damping: 14, stiffness: 120 } });
  const cx = FAITH_THEME.width / 2;
  const cy = 820;

  // Expanding omnidirectional sound ripples
  const ripple = (frame * 3) % 120;

  return (
    <div style={{ position: 'relative', width: FAITH_THEME.width, height: FAITH_THEME.height, transform: `scale(${cameraScale})`, transformOrigin: 'center center' }}>
      <AtmosphericBackdrop spotlightY={cy} />
      <DustParticles count={30} />

      {/* Omnidirectional 360 Degree Rings */}
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
        {[180, 260, 340].map((r, i) => (
          <circle
            key={i}
            cx={cx}
            cy={cy}
            r={r + ripple}
            fill="none"
            stroke={FAITH_THEME.colors.gold}
            strokeWidth={2}
            opacity={interpolate(ripple, [0, 60, 120], [0.5, 0.2, 0])}
          />
        ))}
      </svg>

      {/* State Tablet Card */}
      <div
        style={{
          position: 'absolute',
          left: cx,
          top: cy,
          transform: `translate(-50%, -50%) scale(${cardEntrance})`,
          width: 520,
          height: 380,
          backgroundColor: 'rgba(15, 23, 42, 0.92)',
          border: `3px solid ${FAITH_THEME.colors.goldBright}`,
          borderRadius: 24,
          padding: 30,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'space-between',
          boxShadow: `0 0 50px rgba(255, 200, 59, 0.35)`,
        }}
      >
        <div style={{ fontFamily: FAITH_THEME.fonts.serif, fontSize: 32, fontWeight: 800, color: FAITH_THEME.colors.goldBright, letterSpacing: '0.12em' }}>
          QUIET CONVERSATION
        </div>
        <div style={{ fontFamily: FAITH_THEME.fonts.mono, fontSize: 20, color: FAITH_THEME.colors.blueAccent }}>
          MODE: OMNIDIRECTIONAL 360°
        </div>
        <div style={{ fontFamily: FAITH_THEME.fonts.serif, fontSize: 20, color: '#FFF', textAlign: 'center', borderTop: '1px solid rgba(255,255,255,0.1)', paddingTop: 16 }}>
          Full spatial awareness & natural acoustic comfort.
        </div>
      </div>

      <BlueprintCaliper x1={cx - 360} x2={cx + 360} y={cy + 300} label="OMNIDIRECTIONAL ACOUSTICS" subLabel="360° NATURAL SOUNDFIELD" delay={15} color={FAITH_THEME.colors.gold} />
      <FaithSubtitles delay={5} lines={[[{ text: 'IN QUIET: 360°' }], [{ text: 'NATURAL SURROUND SOUND.', isGold: true }]]} />
    </div>
  );
};
