import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { THEME } from '../theme';
import { Background } from '../components/Background';
import { EarOutline } from '../components/EarOutline';
import { AcousticWave } from '../components/AcousticWave';
import { CaptionsOverlay } from '../components/CaptionsOverlay';

export const Scene1_Comparison: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const timeSec = frame / fps;

  // 0 - 1.5s (frames 0 - 45): slow push toward incoming waveform
  const cameraZoom = interpolate(frame, [0, 45, 150, 180], [0.92, 1.0, 1.05, 1.12], {
    extrapolateRight: 'clamp',
  });

  // 1.5 - 3.5s (frames 45 - 105): Waveform enters and draws the ear outline
  const waveEntry = interpolate(frame, [0, 45], [0, 1], { extrapolateRight: 'clamp' });
  const earReveal = interpolate(frame, [35, 80], [0, 1], { extrapolateRight: 'clamp' });
  const haGlow = interpolate(frame, [60, 110], [0, 1], { extrapolateRight: 'clamp' });

  // 3.5 - 5s (frames 105 - 150): Vertical comparison split emerges
  const splitProgress = interpolate(frame, [105, 135], [0, 1], { extrapolateRight: 'clamp' });
  const implantSignal = interpolate(frame, [115, 160], [0, 1], { extrapolateRight: 'clamp' });

  // Cyan foreshadowing curve toward cochlea at 5 - 6s (frames 150 - 180)
  const curveProgress = interpolate(frame, [145, 180], [0, 1], { extrapolateRight: 'clamp' });

  return (
    <div style={{ width: THEME.width, height: THEME.height, position: 'relative' }}>
      <Background title="HEARING AID VS. COCHLEAR IMPLANT" subtitle="MECHANISM COMPARISON" />

      {/* SVG Canvas for Anatomical Scene */}
      <svg
        width={THEME.width}
        height={THEME.height}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          transform: `scale(${cameraZoom})`,
          transformOrigin: '540px 920px',
        }}
      >
        {/* Left Side: Acoustic Waveform Entering */}
        <AcousticWave
          x={100}
          y={860}
          width={380}
          amplitude={interpolate(frame, [0, 60, 120], [15, 38, 48])}
          frequency={3.5}
          phase={frame * 0.18}
          color={THEME.colors.amber}
          strokeWidth={3}
          opacity={waveEntry}
          taper="right"
          glow
        />

        {/* Central Ear Anatomy */}
        <EarOutline
          x={540}
          y={880}
          scale={0.95}
          opacity={earReveal}
          showHearingAid={true}
          hearingAidGlow={haGlow}
          showImplantProcessor={splitProgress > 0.1}
          implantSignalProgress={implantSignal}
        />

        {/* Split Comparison Divider Line */}
        {splitProgress > 0 && (
          <g opacity={splitProgress}>
            <line
              x1={540}
              y1={320}
              x2={540}
              y2={1280}
              stroke={THEME.colors.line}
              strokeWidth={2}
              strokeDasharray="6 6"
            />
            {/* Pathway Labels */}
            <g transform="translate(320, 380)">
              <rect x="-100" y="-18" width="200" height="36" rx="6" fill={THEME.colors.panel} stroke={THEME.colors.line} />
              <text x="0" y="5" textAnchor="middle" fill={THEME.colors.amber} fontFamily={THEME.fonts.mono} fontSize="14" fontWeight="600">
                ACOUSTIC AMPLIFICATION
              </text>
            </g>
            <g transform="translate(760, 380)">
              <rect x="-100" y="-18" width="200" height="36" rx="6" fill={THEME.colors.panel} stroke={THEME.colors.line} />
              <text x="0" y="5" textAnchor="middle" fill={THEME.colors.cyanBright} fontFamily={THEME.fonts.mono} fontSize="14" fontWeight="600">
                DIRECT NEURAL STIMULATION
              </text>
            </g>
          </g>
        )}

        {/* Cyan line curving toward cochlea at end of scene */}
        {curveProgress > 0 && (
          <path
            d={`M 540 880 C 640 880, 720 960, 760 ${960 + curveProgress * 80}`}
            fill="none"
            stroke={THEME.colors.cyanBright}
            strokeWidth={3}
            strokeDasharray="8 4"
            opacity={curveProgress}
          />
        )}
      </svg>

      <CaptionsOverlay currentSeconds={timeSec} />
    </div>
  );
};
