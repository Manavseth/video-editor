import React from 'react';
import { interpolate, useCurrentFrame, useVideoConfig } from 'remotion';
import { THEME } from '../theme';
import { Background } from '../components/Background';
import { Cochlea } from '../components/Cochlea';
import { CaptionsOverlay } from '../components/CaptionsOverlay';

export const Scene5_Bypass: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const timeSec = 20.2 + frame / fps;

  // 0 - 1s (frames 0 - 30): cyan line draws the cochlear curve
  const curveDraw = interpolate(frame, [0, 30], [0, 1], { extrapolateRight: 'clamp' });

  // 1 - 2.5s (frames 30 - 75): camera eases into cochlea cutaway, array threads in
  const cameraZoom = interpolate(frame, [30, 80], [1.0, 1.35], { extrapolateRight: 'clamp' });
  const arrayInsertion = interpolate(frame, [35, 75], [0, 1], { extrapolateRight: 'clamp' });

  // 2.5 - 3.8s (frames 75 - 114): signal travels from external processor to array
  const signalTravel = interpolate(frame, [75, 114], [0, 1], { extrapolateRight: 'clamp' });

  return (
    <div style={{ width: THEME.width, height: THEME.height, position: 'relative' }}>
      <Background title="BYPASSING MECHANICAL TRANSDUCTION" subtitle="DIRECT SCALA TYMPANI ACCESS" />

      <svg
        width={THEME.width}
        height={THEME.height}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          transform: `scale(${cameraZoom})`,
          transformOrigin: '540px 920px',
        }}
      >
        {/* External Sound Processor Icon (Small, positioned at upper left) */}
        <g transform="translate(240, 680)">
          <rect
            x="-35"
            y="-45"
            width="70"
            height="90"
            rx="12"
            fill={THEME.colors.panel}
            stroke={THEME.colors.cyanBright}
            strokeWidth="2.5"
          />
          <circle cx="0" cy="-20" r="10" fill={THEME.colors.cyan} opacity="0.8" />
          <path d="M -15 15 L 15 15" stroke={THEME.colors.lineBright} strokeWidth="2" strokeLinecap="round" />
          <text x="0" y="65" textAnchor="middle" fill={THEME.colors.cyan} fontFamily={THEME.fonts.mono} fontSize="12" fontWeight="600">
            PROCESSOR
          </text>
        </g>

        {/* Lead wire from processor into cochlea round window */}
        <path
          d="M 275 680 C 360 680, 420 780, 480 840"
          fill="none"
          stroke={THEME.colors.cyan}
          strokeWidth="3"
          strokeDasharray="6 4"
          opacity={0.85}
        />

        {/* Signal packet travelling down wire */}
        {signalTravel > 0 && signalTravel <= 1 && (
          <circle
            cx={275 + signalTravel * 205}
            cy={680 + signalTravel * 160}
            r="8"
            fill="#FFFFFF"
            stroke={THEME.colors.cyanBright}
            strokeWidth="3"
          />
        )}

        {/* Translucent Cochlea with Electrode Array threading into Scala Tympani */}
        <Cochlea
          x={540}
          y={920}
          scale={1.35}
          rotation={0}
          opacity={1}
          hairCellState="damaged" // damaged hair cells remain in background, untouched
          showElectrode={true}
          electrodeInsertion={arrayInsertion}
          showNerveFibers={true}
        />

        {/* Technical Callout Card */}
        <g transform="translate(540, 1280)">
          <rect x="-160" y="-18" width="320" height="36" rx="6" fill={THEME.colors.panel} stroke={THEME.colors.line} />
          <text x="0" y="5" textAnchor="middle" fill={THEME.colors.cyanBright} fontFamily={THEME.fonts.mono} fontSize="14" fontWeight="600">
            ELECTRODE ARRAY IN SCALA TYMPANI
          </text>
        </g>
      </svg>

      <CaptionsOverlay currentSeconds={timeSec} />
    </div>
  );
};
