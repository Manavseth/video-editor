import React from 'react';
import { interpolate, useCurrentFrame, useVideoConfig } from 'remotion';
import { THEME } from '../theme';
import { Background } from '../components/Background';
import { Cochlea } from '../components/Cochlea';
import { CaptionsOverlay } from '../components/CaptionsOverlay';

export const Scene7_ElectricalPulse: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const timeSec = 29.8 + frame / fps;

  // 0 - 1.5s (frames 0 - 45): slow reveal of contacts
  const revealContacts = interpolate(frame, [0, 40], [0.6, 1.0], { extrapolateRight: 'clamp' });

  // 1.5 - 3.8s (frames 45 - 114): pulses fire sequentially along array
  // Biphasic pulses alternate between contacts 2, 5, 8, 11
  const pulsePhase = Math.floor((frame - 40) / 18) % 4;
  const activeContacts = frame >= 40 && frame <= 125
    ? [pulsePhase * 3 + 2]
    : [];

  const pulseIntensity = frame >= 40 && frame <= 125
    ? ((frame - 40) % 18) / 18
    : 0;

  // 3.8 - 5.2s (frames 114 - 156): camera tracks signal outward toward brain preview
  const cameraX = interpolate(frame, [110, 156], [540, 480], { extrapolateRight: 'clamp' });
  const cameraScale = interpolate(frame, [110, 156], [1.5, 1.2], { extrapolateRight: 'clamp' });
  const nervePulseOut = interpolate(frame, [125, 156], [0, 1], { extrapolateRight: 'clamp' });

  return (
    <div style={{ width: THEME.width, height: THEME.height, position: 'relative' }}>
      <Background title="NEURAL EXCITATION" subtitle="BIPHASIC CHARGE-BALANCED CURRENT PULSES" />

      <svg
        width={THEME.width}
        height={THEME.height}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          transform: `scale(${cameraScale})`,
          transformOrigin: `${cameraX}px 900px`,
        }}
      >
        {/* Established Translucent Cochlea with Active Contacts */}
        <Cochlea
          x={cameraX}
          y={900}
          scale={1.5}
          rotation={0}
          opacity={1}
          showElectrode={true}
          electrodeInsertion={revealContacts}
          activeElectrodeIndices={activeContacts}
          pulseIntensity={pulseIntensity}
          showNerveFibers={true}
          highlightTonotopy={false}
        />

        {/* Auditory Nerve Trunk Signal Leading Outward (Bridge to Scene 8) */}
        {nervePulseOut > 0 && (
          <g opacity={nervePulseOut}>
            <path
              d="M 480 900 C 440 920, 380 960, 320 1020"
              fill="none"
              stroke={THEME.colors.cyanBright}
              strokeWidth="4"
              strokeDasharray="8 4"
            />
            <circle
              cx={480 - nervePulseOut * 160}
              cy={900 + nervePulseOut * 120}
              r="7"
              fill="#FFFFFF"
              stroke={THEME.colors.cyanBright}
              strokeWidth="2.5"
            />
          </g>
        )}

        {/* Technical Callout Card */}
        <g transform="translate(540, 1260)">
          <rect x="-170" y="-18" width="340" height="36" rx="6" fill={THEME.colors.panel} stroke={THEME.colors.line} />
          <text x="0" y="5" textAnchor="middle" fill={THEME.colors.cyanBright} fontFamily={THEME.fonts.mono} fontSize="14" fontWeight="600">
            SPIRAL GANGLION NEURON EXCITATION
          </text>
        </g>
      </svg>

      <CaptionsOverlay currentSeconds={timeSec} />
    </div>
  );
};
