import React from 'react';
import { interpolate, useCurrentFrame, useVideoConfig } from 'remotion';
import { THEME } from '../theme';
import { Background } from '../components/Background';
import { Cochlea } from '../components/Cochlea';
import { AcousticWave } from '../components/AcousticWave';
import { CaptionsOverlay } from '../components/CaptionsOverlay';

export const Scene2_InnerEar: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const timeSec = 6.0 + frame / fps;

  // Camera progression through ear canal into cochlea
  const cameraScale = interpolate(frame, [0, 45, 90, 180], [0.85, 1.0, 1.15, 1.25], {
    extrapolateRight: 'clamp',
  });

  const canalWaveProgress = interpolate(frame, [0, 60], [0, 1], { extrapolateRight: 'clamp' });
  const cochleaOpacity = interpolate(frame, [45, 95], [0.1, 1], { extrapolateRight: 'clamp' });
  const cochleaRotation = interpolate(frame, [60, 140], [-10, 0], { extrapolateRight: 'clamp' });

  // 4.5 - 6s (frames 135 - 180): travelling fluid wave and hair cell response
  const waveProgress = interpolate(frame, [110, 180], [0, 0.85], { extrapolateRight: 'clamp' });

  // Hair cell sequential activation responding to wave
  const activations = Array.from({ length: 20 }, (_, i) => {
    const cellT = i / 19;
    const dist = Math.abs(cellT - (1 - waveProgress));
    return dist < 0.15 ? Math.max(0, 1 - dist * 6) : 0;
  });

  return (
    <div style={{ width: THEME.width, height: THEME.height, position: 'relative' }}>
      <Background title="COCHLEAR PHYSIOLOGY" subtitle="ACOUSTIC FLUID-WAVE TRANSDUCTION" />

      <svg
        width={THEME.width}
        height={THEME.height}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          transform: `scale(${cameraScale})`,
          transformOrigin: '540px 920px',
        }}
      >
        {/* Middle Ear / Ossicular Chain Representation (Malleus, Incus, Stapes Footplate) */}
        <g opacity={interpolate(frame, [0, 80], [1, 0.25], { extrapolateRight: 'clamp' })}>
          <path
            d="M 220 880 L 320 880 L 370 850 L 420 880"
            fill="none"
            stroke={THEME.colors.ivory}
            strokeWidth="4"
            strokeLinecap="round"
          />
          {/* Incoming sound wave through canal */}
          <AcousticWave
            x={100}
            y={880}
            width={300 * canalWaveProgress}
            amplitude={24}
            frequency={3}
            phase={frame * 0.22}
            color={THEME.colors.amber}
            strokeWidth={3}
            glow
          />
        </g>

        {/* Central Reusable Translucent Cochlea */}
        <Cochlea
          x={540}
          y={920}
          scale={1.4}
          rotation={cochleaRotation}
          opacity={cochleaOpacity}
          fluidWaveProgress={waveProgress}
          hairCellState="healthy"
          hairCellActivation={activations}
          showElectrode={false}
          showNerveFibers={true}
        />

        {/* Feature Callout Tag */}
        <g transform="translate(540, 1260)" opacity={interpolate(frame, [90, 130], [0, 1], { extrapolateRight: 'clamp' })}>
          <rect x="-140" y="-18" width="280" height="36" rx="6" fill={THEME.colors.panel} stroke={THEME.colors.line} />
          <text x="0" y="5" textAnchor="middle" fill={THEME.colors.ivory} fontFamily={THEME.fonts.mono} fontSize="14">
            ORGAN OF CORTI · BASILAR MEMBRANE
          </text>
        </g>
      </svg>

      <CaptionsOverlay currentSeconds={timeSec} />
    </div>
  );
};
