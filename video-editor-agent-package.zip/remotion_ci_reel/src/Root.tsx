import React from 'react';
import { Composition } from 'remotion';
import { THEME } from './theme';
import { FAITH_THEME } from './theme_faithvsfact';
import { MasterReel } from './MasterReel';
import { ClassifierMasterReel } from './ClassifierMasterReel';
import { Scene1_Comparison } from './scenes/Scene1_Comparison';
import { Scene2_InnerEar } from './scenes/Scene2_InnerEar';
import { Scene3_SensoryLimit } from './scenes/Scene3_SensoryLimit';
import { Scene4_SpeakerMetaphor } from './scenes/Scene4_SpeakerMetaphor';
import { Scene5_Bypass } from './scenes/Scene5_Bypass';
import { Scene6_FrequencyBands } from './scenes/Scene6_FrequencyBands';
import { Scene7_ElectricalPulse } from './scenes/Scene7_ElectricalPulse';
import { Scene8_BrainLearning } from './scenes/Scene8_BrainLearning';
import { AudiogramPart3Master } from './audiogram3/AudiogramPart3Master';
import { AudiogramPart1Master } from './audiogram1/Root';
import { AudiogramPart2Master } from './audiogram2/AudiogramPart2Master';
import { AudiogramPart4Master } from './audiogram4/AudiogramPart4Master';

export const RemotionRoot: React.FC = () => {
  return (
    <>
      {/* Audiogram Part 4: Equalizer & Notch (48.64s @ 30 FPS, 1459 frames) */}
      <Composition
        id="AudiogramPart4"
        component={AudiogramPart4Master}
        durationInFrames={1459}
        fps={30}
        width={1080}
        height={1920}
      />

      {/* Audiogram Part 2: Normal Line & Levels (56.833s @ 30 FPS, 1705 frames) */}
      <Composition
        id="AudiogramPart2"
        component={AudiogramPart2Master}
        durationInFrames={1705}
        fps={30}
        width={1080}
        height={1920}
      />

      {/* Audiogram Part 1: Graph Pe Dimaag Ka Hisab (48.00s @ 30 FPS, 1440 frames) */}
      <Composition
        id="AudiogramPart1"
        component={AudiogramPart1Master}
        durationInFrames={1440}
        fps={30}
        width={1080}
        height={1920}
      />

      {/* Audiogram Part 3: Do Lines Ka Raaz (71.23s @ 30 FPS, 2137 frames) */}
      <Composition
        id="AudiogramPart3"
        component={AudiogramPart3Master}
        durationInFrames={2137}
        fps={30}
        width={1080}
        height={1920}
      />

      {/* Faith vs Fact Re-engineered Environmental Classifier Reel (45s @ 30 FPS) */}
      <Composition
        id="ClassifierMasterReel"
        component={ClassifierMasterReel}
        durationInFrames={FAITH_THEME.totalFrames}
        fps={FAITH_THEME.fps}
        width={FAITH_THEME.width}
        height={FAITH_THEME.height}
      />

      {/* 1. Assembled 40-Second Master Reel (1200 frames @ 30 FPS) */}
      <Composition
        id="MasterReel"
        component={MasterReel}
        durationInFrames={THEME.totalFrames}
        fps={THEME.fps}
        width={THEME.width}
        height={THEME.height}
      />

      {/* 2. Independently Renderable Scene 1 (180 frames) */}
      <Composition
        id="Scene1"
        component={Scene1_Comparison}
        durationInFrames={180}
        fps={THEME.fps}
        width={THEME.width}
        height={THEME.height}
      />

      {/* 3. Independently Renderable Scene 2 (180 frames) */}
      <Composition
        id="Scene2"
        component={Scene2_InnerEar}
        durationInFrames={180}
        fps={THEME.fps}
        width={THEME.width}
        height={THEME.height}
      />

      {/* 4. Independently Renderable Scene 3 (168 frames) */}
      <Composition
        id="Scene3"
        component={Scene3_SensoryLimit}
        durationInFrames={168}
        fps={THEME.fps}
        width={THEME.width}
        height={THEME.height}
      />

      {/* 5. Independently Renderable Scene 4 (78 frames) */}
      <Composition
        id="Scene4"
        component={Scene4_SpeakerMetaphor}
        durationInFrames={78}
        fps={THEME.fps}
        width={THEME.width}
        height={THEME.height}
      />

      {/* 6. Independently Renderable Scene 5 (138 frames) */}
      <Composition
        id="Scene5"
        component={Scene5_Bypass}
        durationInFrames={138}
        fps={THEME.fps}
        width={THEME.width}
        height={THEME.height}
      />

      {/* 7. Independently Renderable Scene 6 (150 frames) */}
      <Composition
        id="Scene6"
        component={Scene6_FrequencyBands}
        durationInFrames={150}
        fps={THEME.fps}
        width={THEME.width}
        height={THEME.height}
      />

      {/* 8. Independently Renderable Scene 7 (156 frames) */}
      <Composition
        id="Scene7"
        component={Scene7_ElectricalPulse}
        durationInFrames={156}
        fps={THEME.fps}
        width={THEME.width}
        height={THEME.height}
      />

      {/* 9. Independently Renderable Scene 8 (150 frames) */}
      <Composition
        id="Scene8"
        component={Scene8_BrainLearning}
        durationInFrames={150}
        fps={THEME.fps}
        width={THEME.width}
        height={THEME.height}
      />
    </>
  );
};
