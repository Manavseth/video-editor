import React from 'react';
import { Audio, Sequence, staticFile } from 'remotion';
import { Scene1_ChaosHook } from './scenes/classifier/Scene1_ChaosHook';
import { Scene2_LinearTrap } from './scenes/classifier/Scene2_LinearTrap';
import { Scene3_MicroArchitecture } from './scenes/classifier/Scene3_MicroArchitecture';
import { Scene4_DSPClassifier } from './scenes/classifier/Scene4_DSPClassifier';
import { Scene5_SpeechModulation } from './scenes/classifier/Scene5_SpeechModulation';
import { Scene6_NoiseSubtraction } from './scenes/classifier/Scene6_NoiseSubtraction';
import { Scene7_QuietState } from './scenes/classifier/Scene7_QuietState';
import { Scene8_NoiseBeamforming } from './scenes/classifier/Scene8_NoiseBeamforming';
import { Scene9_WindCancellation } from './scenes/classifier/Scene9_WindCancellation';
import { Scene10_AutonomousSwitching } from './scenes/classifier/Scene10_AutonomousSwitching';
import { Scene11_ClarityDome } from './scenes/classifier/Scene11_ClarityDome';
import { FAITH_THEME } from './theme_faithvsfact';

export const ClassifierMasterReel: React.FC = () => {
  return (
    <div
      style={{
        position: 'relative',
        width: FAITH_THEME.width,
        height: FAITH_THEME.height,
        backgroundColor: FAITH_THEME.colors.bg,
        overflow: 'hidden',
      }}
    >
      {/* Master Audio Track (Mastered to -14.0 LUFS) */}
      <Audio src={staticFile('classifier_soundtrack.wav')} volume={1.0} />

      {/* HARD RULE ENFORCED: Every scene is <= 96 frames (3.2s) except Scene 11 which is 105 frames (3.5s) */}
      {/* 1. Acoustic Chaos Hook (0.0s - 3.2s) */}
      <Sequence from={0} durationInFrames={96}>
        <Scene1_ChaosHook />
      </Sequence>

      {/* 2. Linear Amplification Trap (3.2s - 6.4s) */}
      <Sequence from={96} durationInFrames={96}>
        <Scene2_LinearTrap />
      </Sequence>

      {/* 3. Micro-Architecture Reveal (6.4s - 9.6s) */}
      <Sequence from={192} durationInFrames={96}>
        <Scene3_MicroArchitecture />
      </Sequence>

      {/* 4. DSP Environmental Classifier Core (9.6s - 12.8s) */}
      <Sequence from={288} durationInFrames={96}>
        <Scene4_DSPClassifier />
      </Sequence>

      {/* 5. Speech Envelope Modulation (12.8s - 16.0s) */}
      <Sequence from={384} durationInFrames={96}>
        <Scene5_SpeechModulation />
      </Sequence>

      {/* 6. Noise Attenuation & SNR Advantage (16.0s - 19.2s) */}
      <Sequence from={480} durationInFrames={96}>
        <Scene6_NoiseSubtraction />
      </Sequence>

      {/* 7. State 1: Quiet Conversation (19.2s - 22.4s) */}
      <Sequence from={576} durationInFrames={96}>
        <Scene7_QuietState />
      </Sequence>

      {/* 8. State 2: Noisy Restaurant Beamforming (22.4s - 25.6s) */}
      <Sequence from={672} durationInFrames={96}>
        <Scene8_NoiseBeamforming />
      </Sequence>

      {/* 9. State 3: Outdoor Wind Cancellation (25.6s - 28.8s) */}
      <Sequence from={768} durationInFrames={96}>
        <Scene9_WindCancellation />
      </Sequence>

      {/* 10. Autonomous Scene Switching Matrix (28.8s - 32.0s) */}
      <Sequence from={864} durationInFrames={96}>
        <Scene10_AutonomousSwitching />
      </Sequence>

      {/* 11. Golden Clarity Protection Dome (32.0s - 35.5s) */}
      <Sequence from={960} durationInFrames={105}>
        <Scene11_ClarityDome />
      </Sequence>
    </div>
  );
};
