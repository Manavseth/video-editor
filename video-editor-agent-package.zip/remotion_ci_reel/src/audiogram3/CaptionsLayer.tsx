import React from 'react';
import { useCurrentFrame } from 'remotion';
import { CUES, CueItem } from './data';
import { PAPER, INK, AIR, BONE, OK, STOP, CAP } from './tokens';

export const CaptionsLayer: React.FC = () => {
  const frame = useCurrentFrame();
  const time = frame / 30;

  // Find matching cue
  const activeCue: CueItem | undefined = CUES.find(
    (c) => time >= c.start && time < c.end
  );

  if (!activeCue) return null;

  const renderHighlightedText = (text: string, highlights?: string[]) => {
    if (!highlights || highlights.length === 0) {
      return <span>{text}</span>;
    }

    // Replace first matching highlight
    let parts: React.ReactNode[] = [text];

    highlights.forEach((hl) => {
      const newParts: React.ReactNode[] = [];
      parts.forEach((p) => {
        if (typeof p === 'string') {
          const idx = p.indexOf(hl);
          if (idx !== -1) {
            const before = p.substring(0, idx);
            const match = p.substring(idx, idx + hl.length);
            const after = p.substring(idx + hl.length);
            if (before) newParts.push(before);

            // Determine highlight accent color
            let hlColor = AIR;
            if (hl.includes('Bone') || hl.includes('andar') || hl.includes('cochlea') || hl.includes('nerve')) {
              hlColor = BONE;
            } else if (hl.includes('theek') || hl.includes('normal') || hl.includes('confusion')) {
              hlColor = OK;
            } else if (hl.includes('blockage') || hl.includes('fail') || hl.includes('wax') || hl.includes('parde') || hl.includes('gir gayi')) {
              hlColor = STOP;
            }

            newParts.push(
              <span
                key={hl}
                style={{
                  color: hlColor,
                  fontWeight: 800,
                  borderBottom: `4px solid ${hlColor}`,
                  paddingBottom: 2,
                }}
              >
                {match}
              </span>
            );
            if (after) newParts.push(after);
          } else {
            newParts.push(p);
          }
        } else {
          newParts.push(p);
        }
      });
      parts = newParts;
    });

    return parts;
  };

  return (
    <div
      style={{
        position: 'absolute',
        top: CAP.top,
        left: 0,
        width: 1080,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        pointerEvents: 'none',
        zIndex: 9000,
      }}
    >
      <div
        style={{
          maxWidth: 940,
          backgroundColor: 'rgba(246, 242, 233, 0.92)',
          border: `2px solid ${INK}`,
          borderRadius: 20,
          padding: '16px 28px',
          boxShadow: '0 8px 30px rgba(0, 0, 0, 0.25)',
          textAlign: 'center',
          fontFamily: 'Inter, "Segoe UI", system-ui, sans-serif',
          fontSize: 48,
          lineHeight: '62px',
          fontWeight: 650,
          color: INK,
        }}
      >
        {renderHighlightedText(activeCue.text, activeCue.highlight)}
      </div>
    </div>
  );
};
