export const CURVES = {
  CASE_A: {
    AIR: [45, 50, 50, 55, 60, 65],
    BONE: [5, 5, 10, 10, 10, 10],
  },
  CASE_B: {
    AIR: [40, 45, 50, 60, 70, 75],
    BONE: [40, 45, 50, 60, 70, 75],
  },
  CASE_C: {
    AIR: [60, 65, 65, 70, 70, 75],
    BONE: [25, 30, 35, 40, 45, 45],
  },
  NEUTRAL: {
    AIR: [15, 15, 15, 15, 15, 15],
    BONE: [10, 10, 10, 10, 10, 10],
  },
};

export interface CueItem {
  i: number;
  start: number;
  end: number;
  text: string;
  highlight?: string[];
}

export const CUES: CueItem[] = [
  { i: 1, start: 0.0, end: 4.09, text: 'Pichhli baar maine bola tha ki graph pe 2 alag-alag lines banti hain,', highlight: ['2 alag-alag lines'] },
  { i: 2, start: 4.09, end: 5.33, text: 'chalo unka raaz samjhata hoon.', highlight: ['raaz'] },
  { i: 3, start: 5.33, end: 9.07, text: 'Hum awaaz 2 alag-alag raaston se check karte hain.', highlight: ['2 alag-alag raaston'] },
  { i: 4, start: 9.07, end: 13.17, text: 'Pehla: headphones, jo kaan ke normal raaste se jaate hain,', highlight: ['Pehla: headphones,', 'normal raaste'] },
  { i: 5, start: 13.17, end: 15.9, text: 'ise hum Air Conduction kehte hain.', highlight: ['Air Conduction'] },
  { i: 6, start: 15.9, end: 18.33, text: 'Aur doosra: kaan ke peeche Bone Vibrator se,', highlight: ['kaan ke peeche Bone Vibrator'] },
  { i: 7, start: 18.33, end: 22.16, text: 'jo cochlea tak ek seedha shortcut leti hai.', highlight: ['seedha shortcut'] },
  { i: 8, start: 22.16, end: 23.25, text: 'Ab simple logic lagao:', highlight: ['simple logic'] },
  { i: 9, start: 23.25, end: 25.41, text: 'agar headphones wali line neeche gir gayi,', highlight: ['headphones wali line'] },
  { i: 10, start: 25.41, end: 28.68, text: 'aur Bone Vibrator wali line upar hai,', highlight: ['Bone Vibrator wali line upar'] },
  { i: 11, start: 28.68, end: 30.49, text: 'matlab Inner Ear bilkul theek hai,', highlight: ['Inner Ear bilkul theek hai,'] },
  { i: 12, start: 30.69, end: 32.12, text: 'bas bahar ke raaste me blockage hai,', highlight: ['bahar ke raaste me blockage'] },
  { i: 13, start: 32.12, end: 35.99, text: 'jaise wax, infection ya parde ka koi issue.', highlight: ['wax, infection ya parde'] },
  { i: 14, start: 35.99, end: 38.17, text: 'Lekin agar dono lines neeche gir gayi,', highlight: ['dono lines neeche'] },
  { i: 15, start: 38.17, end: 40.55, text: 'iska matlab shortcut bhi fail,', highlight: ['shortcut bhi fail'] },
  { i: 16, start: 40.55, end: 45.77, text: 'aur problem seedha andar cochlea ya nerve me hai.', highlight: ['seedha andar', 'cochlea ya nerve'] },
  { i: 17, start: 45.77, end: 47.57, text: 'Aur agar dono lines neeche hain,', highlight: ['dono lines neeche'] },
  { i: 18, start: 47.57, end: 49.97, text: 'par unke beech bahut bada gap hai,', highlight: ['bahut bada gap'] },
  { i: 19, start: 49.97, end: 52.23, text: 'matlab yeh situation mixed hai.', highlight: ['mixed'] },
  { i: 20, start: 52.23, end: 53.81, text: 'Bahar blockage bhi hai,', highlight: ['Bahar blockage'] },
  { i: 21, start: 53.81, end: 56.53, text: 'aur andar cochlea ya nerve weakness bhi hai.', highlight: ['andar cochlea ya nerve weakness'] },
  { i: 22, start: 56.53, end: 58.84, text: 'Yahi gap aapke audiologist ko', highlight: ['Yahi gap'] },
  { i: 23, start: 58.84, end: 60.75, text: 'bina kisi confusion ke bata deta hai,', highlight: ['bina kisi confusion'] },
  { i: 24, start: 60.75, end: 63.91, text: 'ki problem bahar hai ya andar.', highlight: ['bahar', 'andar'] },
  { i: 25, start: 63.91, end: 66.31, text: 'Agli baar graph dekh ke bataunga,', highlight: ['Agli baar graph'] },
  { i: 26, start: 66.31, end: 69.11, text: 'ki problem loud headphones ki wajah se hai,', highlight: ['loud headphones'] },
  { i: 27, start: 69.11, end: 71.22, text: 'ya aging ki wajah se hai!', highlight: ['aging'] },
];

export interface SceneMeta {
  id: string;
  startFrame: number;
  endFrame: number;
  duration: number;
}

export const SCENES: SceneMeta[] = [
  { id: 'S01Recap', startFrame: 0, endFrame: 39, duration: 39 },
  { id: 'S02LinesForm', startFrame: 39, endFrame: 123, duration: 84 },
  { id: 'S03Title', startFrame: 123, endFrame: 160, duration: 37 },
  { id: 'S04TwoRoads', startFrame: 160, endFrame: 272, duration: 112 },
  { id: 'S05DockHeadphones', startFrame: 272, endFrame: 327, duration: 55 },
  { id: 'S06AirRun', startFrame: 327, endFrame: 395, duration: 68 },
  { id: 'S07AirLabel', startFrame: 395, endFrame: 477, duration: 82 },
  { id: 'S08DockBone', startFrame: 477, endFrame: 550, duration: 73 },
  { id: 'S09Shortcut', startFrame: 550, endFrame: 665, duration: 115 },
  { id: 'S10LogicPivot', startFrame: 665, endFrame: 698, duration: 33 },
  { id: 'S11Case1Fall', startFrame: 698, endFrame: 762, duration: 64 },
  { id: 'S12Case1Gap', startFrame: 762, endFrame: 860, duration: 98 },
  { id: 'S13Case1Verdict', startFrame: 860, endFrame: 964, duration: 104 },
  { id: 'S14Suspects', startFrame: 964, endFrame: 1080, duration: 116 },
  { id: 'S15Case2Fall', startFrame: 1080, endFrame: 1145, duration: 65 },
  { id: 'S16Case2Fail', startFrame: 1145, endFrame: 1217, duration: 72 },
  { id: 'S17Case2Inside', startFrame: 1217, endFrame: 1293, duration: 76 },
  { id: 'S18Case2Which', startFrame: 1293, endFrame: 1373, duration: 80 },
  { id: 'S19Case3Setup', startFrame: 1373, endFrame: 1427, duration: 54 },
  { id: 'S20Case3BigGap', startFrame: 1427, endFrame: 1499, duration: 72 },
  { id: 'S21Case3Mixed', startFrame: 1499, endFrame: 1567, duration: 68 },
  { id: 'S22Case3Outer', startFrame: 1567, endFrame: 1614, duration: 47 },
  { id: 'S23Case3Inner', startFrame: 1614, endFrame: 1696, duration: 82 },
  { id: 'S24Decision', startFrame: 1696, endFrame: 1765, duration: 69 },
  { id: 'S25NoConfusion', startFrame: 1765, endFrame: 1823, duration: 58 },
  { id: 'S26TwoDoors', startFrame: 1823, endFrame: 1917, duration: 94 },
  { id: 'S27NextStage', startFrame: 1917, endFrame: 1989, duration: 72 },
  { id: 'S28Suspect1', startFrame: 1989, endFrame: 2073, duration: 84 },
  { id: 'S29Suspect2', startFrame: 2073, endFrame: 2137, duration: 64 },
];
