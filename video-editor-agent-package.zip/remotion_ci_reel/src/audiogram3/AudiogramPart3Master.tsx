import React from 'react';
import {
  useCurrentFrame,
  Sequence,
  Audio,
  OffthreadVideo,
  staticFile,
} from 'remotion';

import { PAPER, GRID, INK, INK_SOFT, AIR, BONE, OK, STOP, W, H, easeSettle, easeStamp } from './tokens';
import { CURVES } from './data';
import { CaptionsLayer } from './CaptionsLayer';

import { AudSheet } from './assets/sheet';
import { HeadCut } from './assets/head';
import { HeadphoneDevice, BoneVibratorDevice } from './assets/devices';
import { Chip, TabCard, Rubric, ProgressSpine, ArrowDown } from './assets/labels';
import { AudiologistFigure, SplitCardDoors, SuspectCard } from './assets/misc';

export const AudiogramPart3Master: React.FC = () => {
  const frame = useCurrentFrame();

  return (
    <div
      style={{
        width: W,
        height: H,
        backgroundColor: PAPER,
        position: 'relative',
        overflow: 'hidden',
        fontFamily: 'Inter, "Segoe UI", system-ui, sans-serif',
      }}
    >
      {/* 1. Global Master Voice Audio Track (48kHz Stereo, -14 LUFS, 0 flaws) */}
      <Audio src={staticFile('audiogram3_master_voice.wav')} />

      {/* 2. Global Static Grid Background (for ISO registers) */}
      <svg
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: W,
          height: H,
          pointerEvents: 'none',
        }}
      >
        <defs>
          <pattern
            id="global-grid-pattern"
            width={48}
            height={48}
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M 48 0 L 0 0 0 48"
              fill="none"
              stroke={GRID}
              strokeWidth={1.5}
              opacity={0.65}
            />
          </pattern>
        </defs>
        <rect width={W} height={H} fill="url(#global-grid-pattern)" />
      </svg>

      {/* =========================================================================
          REGISTER 1: HOST CLIP 1 (Frames 0 to 159 · 5.29s)
          "Pichhli baar maine bola tha ki graph pe 2 alag-alag lines banti hain,
           chalo unka raaz samjhata hoon."
          ========================================================================= */}
      {frame >= 0 && frame < 159 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          {/* Full frame host footage */}
          <OffthreadVideo
            src={staticFile('clips/clip1_norm.mp4')}
            style={{ width: W, height: H, objectFit: 'cover' }}
          />

          {/* S01-S03 Overlays in safe zone */}
          <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H, pointerEvents: 'none' }}>
            {/* S01: Recap Chip (Frames 0-39) */}
            {frame < 39 && (
              <Chip
                x={200}
                y={180}
                text="Pichhli video"
                variant="black"
                scale={easeStamp(frame / 14)}
              />
            )}

            {/* S02: 2 Lines Chip (Frames 39-123) */}
            {frame >= 39 && frame < 123 && (
              <Chip
                x={540}
                y={180}
                text="AIR-LINE × BONE-LINE"
                variant="white"
                scale={easeStamp((frame - 39) / 14)}
              />
            )}

            {/* S03: Title Stinger on pause (Frames 123-159) */}
            {frame >= 123 && (
              <TabCard
                x={540}
                y={220}
                title="AAJ KA RAAZ"
                ruleColor={AIR}
                scale={easeSettle((frame - 123) / 16)}
              />
            )}
          </svg>
        </div>
      )}

      {/* =========================================================================
          REGISTER 2: ISO SCENE 1 — THE TWO ROADS (Frames 159 to 663 · 16.81s)
          Pinna -> Canal -> Eardrum -> Ossicles -> Cochlea (Air) vs Mastoid (Bone)
          ========================================================================= */}
      {frame >= 159 && frame < 663 && (
        <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          {/* S04: World Builds (Frames 159 - 272) */}
          {frame >= 159 && frame < 272 && (
            <>
              <HeadCut
                scale={easeSettle((frame - 159) / 24)}
                airRouteProgress={(frame - 159) > 80 ? 0.4 : 0}
                boneRouteProgress={(frame - 159) > 80 ? 0.4 : 0}
              />
              <Chip
                x={200}
                y={180}
                text="2 RAASTE"
                variant="black"
                scale={easeStamp((frame - 240) / 14)}
              />
            </>
          )}

          {/* S05: Headphones Dock (Frames 272 - 327) */}
          {frame >= 272 && frame < 327 && (
            <>
              <HeadCut hasHeadphones />
              <HeadphoneDevice
                x={600}
                y={720}
                pulseRings
                ringsFrame={frame - 272}
                scale={easeSettle((frame - 272) / 16)}
              />
              <Chip x={240} y={180} text="PEHLA RASTA" variant="tangerine" />
            </>
          )}

          {/* S06: Air Path Run (Frames 327 - 395) */}
          {frame >= 327 && frame < 395 && (
            <>
              <HeadCut
                hasHeadphones
                airRouteProgress={1}
                tokensTraveling
                tokensProgress={(frame - 327) / 24}
              />
              <HeadphoneDevice x={600} y={720} pulseRings ringsFrame={frame - 327} />
              <Chip x={540} y={180} text="NORMAL RASTA" variant="white" />
            </>
          )}

          {/* S07: AIR CONDUCTION Label (Frames 395 - 477) */}
          {frame >= 395 && frame < 477 && (
            <>
              <HeadCut hasHeadphones airRouteProgress={1} />
              <HeadphoneDevice x={600} y={720} />
              <TabCard
                x={540}
                y={220}
                title="AIR CONDUCTION"
                ruleColor={AIR}
                scale={easeSettle((frame - 395) / 16)}
              />
            </>
          )}

          {/* S08: Bone Vibrator Docks (Frames 477 - 550) */}
          {frame >= 477 && frame < 550 && (
            <>
              <HeadCut hasBoneVibrator />
              <BoneVibratorDevice
                x={500}
                y={830}
                vibrating
                vibFrame={frame - 477}
                scale={easeSettle((frame - 477) / 16)}
              />
              <TabCard
                x={540}
                y={220}
                title="BONE VIBRATOR"
                ruleColor={BONE}
                scale={easeSettle((frame - 477) / 16)}
              />
            </>
          )}

          {/* S09: THE SHORTCUT (Frames 550 - 663) */}
          {frame >= 550 && frame < 663 && (
            <>
              <HeadCut
                hasBoneVibrator
                boneRouteProgress={1}
                chevronsProgress={(frame - 550) / 15}
              />
              <BoneVibratorDevice x={500} y={830} vibrating vibFrame={frame - 550} />
              <Chip
                x={540}
                y={240}
                text="SEEDHA SHORTCUT"
                variant="cobalt"
                scale={easeStamp((frame - 550) / 14)}
              />
            </>
          )}
        </svg>
      )}

      {/* =========================================================================
          REGISTER 3: HOST CLIP 2 — LOGIC PIVOT (Frames 663 to 859 · 6.53s)
          "Ab simple logic lagao: agar headphones wali line neeche gir gayi,
           aur Bone Vibrator wali line upar hai..."
          ========================================================================= */}
      {frame >= 663 && frame < 859 && (
        <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          {/* Full frame host footage */}
          <OffthreadVideo
            src={staticFile('clips/clip2_norm.mp4')}
            style={{ width: W, height: H, objectFit: 'cover' }}
          />

          <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H, pointerEvents: 'none' }}>
            {/* S10: Simple Logic Tab Card (Frames 663 - 698) */}
            {frame < 698 && (
              <TabCard
                x={540}
                y={220}
                title="SIMPLE LOGIC"
                ruleColor={BONE}
                scale={easeSettle((frame - 663) / 14)}
              />
            )}

            {/* S11: Headphones line falling indicator (Frames 698 - 762) */}
            {frame >= 698 && frame < 762 && (
              <>
                <Chip x={540} y={180} text="HEADPHONES LINE ↓" variant="tangerine" />
                <ArrowDown x={540} y={260} scale={1.5} />
              </>
            )}

            {/* S12: Bone Vibrator line stays up indicator (Frames 762 - 859) */}
            {frame >= 762 && (
              <>
                <Chip x={540} y={180} text="BONE LINE UPAR ↑" variant="cobalt" />
                <Chip x={540} y={260} text="GAP FORMING" variant="white" />
              </>
            )}
          </svg>
        </div>
      )}

      {/* =========================================================================
          REGISTER 4: ISO SCENE 2 — THE THREE CLINICAL CASES (Frames 859 to 1696)
          Case 1 (Conductive), Case 2 (Sensorineural), Case 3 (Mixed)
          ========================================================================= */}
      {frame >= 859 && frame < 1696 && (
        <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          {/* Case 1: Conductive (Frames 859 to 1080) */}
          {frame >= 859 && frame < 964 && (
            <>
              <ProgressSpine activeCase={1} />
              <Rubric caseNum={1} />
              {/* Audiogram Sheet with Case A: Air dropped, Bone normal, 40 dB gap */}
              <AudSheet
                airValues={CURVES.CASE_A.AIR}
                boneValues={CURVES.CASE_A.BONE}
                highlightGap={{
                  freq: 1000,
                  startDb: 10,
                  endDb: 50,
                  label: 'GAP ~40 dB',
                }}
              />
              <Chip x={540} y={240} text="BAHAR BLOCKAGE" variant="red" />
            </>
          )}

          {/* S14: Three Suspects Cards (Wax, Infection, Drum) (Frames 964 - 1080) */}
          {frame >= 964 && frame < 1080 && (
            <>
              <ProgressSpine activeCase={1} />
              <Rubric caseNum={1} />
              {/* Three suspect badges */}
              <g transform="translate(180, 720)">
                <rect x={-110} y={-140} width={220} height={280} rx={20} fill="#FFFFFF" stroke={INK} strokeWidth={4} />
                <ellipse cx={0} cy={-20} rx={45} ry={25} fill="#C9A227" stroke={INK} strokeWidth={3} />
                <text x={0} y={60} textAnchor="middle" fill={INK} fontFamily='Fraunces, serif' fontSize={32} fontWeight={700}>WAX</text>
                <text x={0} y={95} textAnchor="middle" fill={INK_SOFT} fontFamily='Inter, sans-serif' fontSize={18}>wax plug</text>
              </g>
              <g transform="translate(540, 720)">
                <rect x={-110} y={-140} width={220} height={280} rx={20} fill="#FFFFFF" stroke={INK} strokeWidth={4} />
                <circle cx={-15} cy={-25} r={18} fill={STOP} />
                <circle cx={15} cy={-15} r={14} fill={STOP} />
                <text x={0} y={60} textAnchor="middle" fill={INK} fontFamily='Fraunces, serif' fontSize={32} fontWeight={700}>INFECTION</text>
                <text x={0} y={95} textAnchor="middle" fill={INK_SOFT} fontFamily='Inter, sans-serif' fontSize={18}>middle ear</text>
              </g>
              <g transform="translate(900, 720)">
                <rect x={-110} y={-140} width={220} height={280} rx={20} fill="#FFFFFF" stroke={INK} strokeWidth={4} />
                <ellipse cx={0} cy={-20} rx={36} ry={46} fill="#ECD5CB" stroke={INK} strokeWidth={3} />
                <circle cx={10} cy={-20} r={10} fill={PAPER} />
                <text x={0} y={60} textAnchor="middle" fill={INK} fontFamily='Fraunces, serif' fontSize={32} fontWeight={700}>PARDE</text>
                <text x={0} y={95} textAnchor="middle" fill={INK_SOFT} fontFamily='Inter, sans-serif' fontSize={18}>eardrum issue</text>
              </g>
            </>
          )}

          {/* Case 2: Sensorineural (Frames 1080 to 1373) */}
          {frame >= 1080 && frame < 1217 && (
            <>
              <ProgressSpine activeCase={2} />
              <Rubric caseNum={2} />
              <AudSheet
                airValues={CURVES.CASE_B.AIR}
                boneValues={CURVES.CASE_B.BONE}
              />
              <Chip
                x={540}
                y={240}
                text="SHORTCUT BHI FAIL"
                variant="red"
                scale={easeStamp((frame - 1145) / 14)}
              />
            </>
          )}

          {/* S17-S18: Problem inside cochlea/nerve (Frames 1217 - 1373) */}
          {frame >= 1217 && frame < 1373 && (
            <>
              <ProgressSpine activeCase={2} />
              <Rubric caseNum={2} />
              <TabCard x={540} y={220} title="PROBLEM ANDAR" ruleColor={BONE} />
              <HeadCut scale={1.2} cochleaState="damaged" nerveState="weak" />
              <g transform="translate(540, 1140)">
                <Chip x={-140} y={0} text="COCHLEA" variant="cobalt" />
                <Chip x={140} y={0} text="NERVE" variant="white" />
              </g>
            </>
          )}

          {/* Case 3: Mixed (Frames 1373 to 1696) */}
          {frame >= 1373 && frame < 1567 && (
            <>
              <ProgressSpine activeCase={3} />
              <Rubric caseNum={3} />
              <AudSheet
                airValues={CURVES.CASE_C.AIR}
                boneValues={CURVES.CASE_C.BONE}
                highlightGap={{
                  freq: 500,
                  startDb: 30,
                  endDb: 65,
                  label: 'BIG GAP',
                }}
              />
              {frame >= 1499 && (
                <TabCard
                  x={540}
                  y={220}
                  title="MIXED HEARING LOSS"
                  ruleColor={STOP}
                  scale={easeStamp((frame - 1499) / 14)}
                />
              )}
            </>
          )}

          {/* S22-S23: Both Outside blockage + Inside weakness (Frames 1567 - 1696) */}
          {frame >= 1567 && frame < 1696 && (
            <>
              <ProgressSpine activeCase={3} />
              <Rubric caseNum={3} />
              <HeadCut
                hasWaxBlock
                cochleaState="damaged"
                nerveState="weak"
              />
              <g transform="translate(540, 240)">
                <Chip x={-180} y={0} text="BAAHAR BLOCKAGE" variant="red" />
                <Chip x={180} y={0} text="ANDAR BHI WEAK" variant="cobalt" />
              </g>
            </>
          )}
        </svg>
      )}

      {/* =========================================================================
          REGISTER 5: ISO SCENE 3 — AUDIOLOGIST CLINICAL VERDICT (Frames 1696 to 1917)
          Clip 3 is skipped by user instruction, promoted to 100% procedural isometric:
          Gap becomes vertical divider, AUDI-FIG audiologist figure with pointer pencil,
          BAAHAR vs ANDAR doors, and 3 key chips!
          ========================================================================= */}
      {frame >= 1696 && frame < 1917 && (
        <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          <TabCard x={540} y={220} title="AUDIOLOGIST VERDICT" ruleColor={OK} />

          {/* Split-Card Doors: BAAHAR vs ANDAR */}
          <SplitCardDoors
            doorsProgress={frame >= 1823 ? Math.min(1, (frame - 1823) / 20) : 0}
          />

          {/* Audiologist Figure with nod */}
          <AudiologistFigure
            x={860}
            y={820}
            nodAngle={frame >= 1765 && frame < 1823 ? 4 : 0}
            scale={1.1}
          />

          {/* S25: Check Ring + BINA CONFUSION */}
          {frame >= 1765 && (
            <Chip
              x={540}
              y={560}
              text="BINA CONFUSION"
              variant="mint"
              scale={easeStamp((frame - 1765) / 14)}
            />
          )}

          {/* S26: Three mini key chips mapping cases to doors */}
          {frame >= 1823 && (
            <g transform="translate(540, 1140)">
              <Chip x={-260} y={0} text="Case 1: Baahar" variant="tangerine" fontSize={24} />
              <Chip x={0} y={0} text="Case 2: Andar" variant="cobalt" fontSize={24} />
              <Chip x={260} y={0} text="Case 3: Dono" variant="red" fontSize={24} />
            </g>
          )}
        </svg>
      )}

      {/* =========================================================================
          REGISTER 6: ISO SCENE 4 — OUTRO TEASER (Frames 1917 to 2137 · 7.14s)
          "Agli baar graph dekh ke bataunga, ki problem loud headphones ki wajah se hai,
           ya aging ki wajah se hai!"
          ========================================================================= */}
      {frame >= 1917 && (
        <svg style={{ position: 'absolute', top: 0, left: 0, width: W, height: H }}>
          {/* S27: Fresh Audiogram Sheet with central "?" */}
          <AudSheet opacity={0.35} />

          {/* Big Central Question Mark */}
          <text
            x={540}
            y={760}
            textAnchor="middle"
            fill={INK}
            fontFamily='Fraunces, serif'
            fontSize={160}
            fontWeight={900}
            opacity={0.85}
          >
            ?
          </text>

          {/* S28: Suspect 1 — Loud Headphones */}
          {frame >= 1989 && (
            <SuspectCard
              x={frame < 2073 ? 540 : 300}
              y={frame < 2073 ? 740 : 740}
              type="headphones"
              cycle={frame - 1989}
              scale={frame < 2073 ? 1.05 : 0.88}
            />
          )}

          {/* S29: Suspect 2 — Aging Clock */}
          {frame >= 2073 && (
            <SuspectCard
              x={780}
              y={740}
              type="aging"
              cycle={Math.min(45, frame - 2073)}
              scale={0.88}
            />
          )}

          {/* Title Card Teaser */}
          <TabCard x={540} y={220} title="NEXT: PART 4" ruleColor={AIR} />
        </svg>
      )}

      {/* 3. Global Verbatim Captions Layer (Safe Margins y: 1460 to 1636) */}
      <CaptionsLayer />
    </div>
  );
};
