import React from 'react';
import { Audio, Series, staticFile, useCurrentFrame, useVideoConfig } from 'remotion';
import { THEME } from './theme';
import { Scene1_Comparison } from './scenes/Scene1_Comparison';
import { Scene2_InnerEar } from './scenes/Scene2_InnerEar';
import { Scene3_SensoryLimit } from './scenes/Scene3_SensoryLimit';
import { Scene4_SpeakerMetaphor } from './scenes/Scene4_SpeakerMetaphor';
import { Scene5_Bypass } from './scenes/Scene5_Bypass';
import { Scene6_FrequencyBands } from './scenes/Scene6_FrequencyBands';
import { Scene7_ElectricalPulse } from './scenes/Scene7_ElectricalPulse';
import { Scene8_BrainLearning } from './scenes/Scene8_BrainLearning';

export const MasterReel: React.FC = () => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();

  // Thin top progress bar for cognitive fluency
  const progressPercent = (frame / (durationInFrames - 1)) * 100;

  return (
    <div
      style={{
        width: THEME.width,
        height: THEME.height,
        position: 'relative',
        backgroundColor: THEME.colors.bg,
        overflow: 'hidden',
      }}
    >
      {/* 40-Second Master Audio Voiceover & Sound Design (EBU R128 -14 LUFS) */}
      <Audio src={staticFile('audio_master_exact_14lufs.wav')} />

      {/* Sequential Assembly of all 8 Scenes matching Storyboard Frame Locks */}
      <Series>
        {/* Scene 1: 00:00 - 00:06 (180 frames) */}
        <Series.Sequence durationInFrames={180}>
          <Scene1_Comparison />
        </Series.Sequence>

        {/* Scene 2: 00:06 - 00:12 (180 frames) */}
        <Series.Sequence durationInFrames={180}>
          <Scene2_InnerEar />
        </Series.Sequence>

        {/* Scene 3: 00:12 - 00:17.6 (168 frames) */}
        <Series.Sequence durationInFrames={168}>
          <Scene3_SensoryLimit />
        </Series.Sequence>

        {/* Scene 4: 00:17.6 - 00:20.2 (78 frames) */}
        <Series.Sequence durationInFrames={78}>
          <Scene4_SpeakerMetaphor />
        </Series.Sequence>

        {/* Scene 5: 00:20.2 - 00:24.8 (138 frames) */}
        <Series.Sequence durationInFrames={138}>
          <Scene5_Bypass />
        </Series.Sequence>

        {/* Scene 6: 00:24.8 - 00:29.8 (150 frames) */}
        <Series.Sequence durationInFrames={150}>
          <Scene6_FrequencyBands />
        </Series.Sequence>

        {/* Scene 7: 00:29.8 - 00:35.0 (156 frames) */}
        <Series.Sequence durationInFrames={156}>
          <Scene7_ElectricalPulse />
        </Series.Sequence>

        {/* Scene 8: 00:35.0 - 00:40.0 (150 frames) */}
        <Series.Sequence durationInFrames={150}>
          <Scene8_BrainLearning />
        </Series.Sequence>
      </Series>

      {/* Top 4px Progress Line */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: `${progressPercent}%`,
          height: 4,
          backgroundColor: THEME.colors.cyanBright,
          boxShadow: `0 0 10px ${THEME.colors.cyanBright}`,
          zIndex: 100,
        }}
      />
    </div>
  );
};
