import React from 'react';
import { useCurrentFrame } from 'remotion';
import { CUES, CueItem } from './data';
import { PAPER, INK, AIR, GOLD, OK, CAP } from './tokens';

export const CaptionsLayer: React.FC = () => {
  const frame = useCurrentFrame();
  const time = frame / 30;

  // Active cue matching current time
  const activeCue: CueItem | undefined = CUES.find(
    (c) => time >= c.start && time < c.end
  );

  if (!activeCue) return null;

  const renderFormattedText = (cue: CueItem) => {
    if (!cue.highlights || cue.highlights.length === 0) {
      return <span>{cue.text}</span>;
    }

    let segments: Array<{ text: string; hl?: { text: string; type: string } }> = [
      { text: cue.text },
    ];

    cue.highlights.forEach((hl) => {
      const nextSegments: typeof segments = [];
      segments.forEach((seg) => {
        if (seg.hl) {
          nextSegments.push(seg);
          return;
        }

        const idx = seg.text.indexOf(hl.text);
        if (idx !== -1) {
          const before = seg.text.substring(0, idx);
          const match = seg.text.substring(idx, idx + hl.text.length);
          const after = seg.text.substring(idx + hl.text.length);

          if (before) nextSegments.push({ text: before });
          nextSegments.push({ text: match, hl });
          if (after) nextSegments.push({ text: after });
        } else {
          nextSegments.push(seg);
        }
      });
      segments = nextSegments;
    });

    return segments.map((seg, idx) => {
      if (!seg.hl) {
        return <span key={idx}>{seg.text}</span>;
      }

      let color = INK;
      let fontWeight: string | number = 600;
      let borderBottom = 'none';

      if (seg.hl.type === 'ink_bold') {
        color = INK;
        fontWeight = 700;
        borderBottom = `3px solid ${INK}`;
      } else if (seg.hl.type === 'mint') {
        color = OK;
        fontWeight = 700;
        borderBottom = `3px solid ${OK}`;
      } else if (seg.hl.type === 'gold') {
        color = GOLD;
        fontWeight = 700;
        borderBottom = `3px solid ${GOLD}`;
      } else if (seg.hl.type === 'tangerine') {
        color = AIR;
        fontWeight = 700;
        borderBottom = `3px solid ${AIR}`;
      }

      return (
        <span
          key={idx}
          style={{
            color,
            fontWeight,
            borderBottom,
            paddingBottom: 2,
            borderRadius: 2,
          }}
        >
          {seg.text}
        </span>
      );
    });
  };

  return (
    <div
      style={{
        position: 'absolute',
        top: CAP.top,
        left: 0,
        width: 1080,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'flex-start',
        pointerEvents: 'none',
        zIndex: 9000,
      }}
    >
      <div
        style={{
          maxWidth: 920,
          backgroundColor: 'rgba(246, 242, 233, 0.72)',
          border: `2px solid ${INK}`,
          borderRadius: 18,
          padding: '12px 24px',
          boxShadow: '0 8px 24px rgba(38, 36, 48, 0.12)',
          textAlign: 'center',
          fontFamily: 'Archivo, "Segoe UI", system-ui, sans-serif',
          fontSize: 52,
          lineHeight: '62px',
          fontWeight: 600,
          color: INK,
          backdropFilter: 'blur(4px)',
        }}
      >
        {renderFormattedText(activeCue)}
      </div>
    </div>
  );
};
