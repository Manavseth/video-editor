export interface CueItem {
  i: number;
  start: number;
  end: number;
  text: string;
  highlights?: Array<{
    text: string;
    type: 'mint' | 'gold' | 'tangerine' | 'ink_bold';
  }>;
}

export const CURVES = {
  SCATTER: { AIR: [15, 25, 20, 35, 40, 45] }, // alag-alag pitch aur volume ke symbols
  P1_DROP: { AIR: [30, 35, 40, 45, 55, 60] }, // thresholds neeche girne lagte hain
  NEUTRAL: { AIR: [15, 15, 15, 15, 15, 15] }, // typical hearing demo
};

export const CUES: CueItem[] = [
  {
    i: 1,
    start: 0.0,
    end: 1.7,
    text: 'Jab aap clinic me hearing test karate ho,',
    highlights: [{ text: 'hearing test', type: 'ink_bold' }],
  },
  {
    i: 2,
    start: 1.88,
    end: 3.7,
    text: 'aur audiologist aapko ek graph deta hai,',
    highlights: [
      { text: 'audiologist', type: 'ink_bold' },
      { text: 'graph', type: 'tangerine' },
    ],
  },
  {
    i: 3,
    start: 3.8,
    end: 5.55,
    text: 'jise hum audiogram kehte hain.',
    highlights: [{ text: 'audiogram', type: 'ink_bold' }],
  },
  {
    i: 4,
    start: 5.74,
    end: 8.85,
    text: 'Is graph par jo alag-alag pitch aur volume ke symbols bane hote hain,',
    highlights: [{ text: 'alag-alag pitch aur volume', type: 'tangerine' }],
  },
  {
    i: 5,
    start: 9.2,
    end: 12.3,
    text: 'ye batate hain ki normal baat-cheet samajhne ke liye',
    highlights: [{ text: 'normal baat-cheet', type: 'mint' }],
  },
  {
    i: 6,
    start: 12.35,
    end: 14.8,
    text: 'aapke dimaag ko roz kitni gadha-mazdoori karni padti hai.',
    highlights: [
      { text: 'dimaag', type: 'ink_bold' },
      { text: 'gadha-mazdoori', type: 'gold' },
    ],
  },
  {
    i: 7,
    start: 14.98,
    end: 16.7,
    text: '0 dB sabse upar hota hai,',
    highlights: [{ text: '0 dB', type: 'ink_bold' }],
  },
  {
    i: 8,
    start: 16.72,
    end: 18.15,
    text: 'aur loud sounds neeche.',
    highlights: [
      { text: 'loud sounds', type: 'ink_bold' },
      { text: 'neeche', type: 'gold' },
    ],
  },
  {
    i: 9,
    start: 18.2,
    end: 21.1,
    text: 'Jab ye thresholds neeche girne lagte hain,',
    highlights: [
      { text: 'thresholds', type: 'ink_bold' },
      { text: 'neeche girne', type: 'gold' },
    ],
  },
  {
    i: 10,
    start: 21.2,
    end: 24.3,
    text: 'to iska matlab hai aapko normal baat-cheet samajhne ke liye',
    highlights: [{ text: 'normal baat-cheet', type: 'mint' }],
  },
  {
    i: 11,
    start: 24.35,
    end: 26.5,
    text: 'zyada volume aur clarity chahiye.',
    highlights: [
      { text: 'zyada volume', type: 'tangerine' },
      { text: 'clarity', type: 'ink_bold' },
    ],
  },
  {
    i: 12,
    start: 26.6,
    end: 28.3,
    text: 'Woh clarity aapke dimaag ko',
    highlights: [{ text: 'dimaag', type: 'ink_bold' }],
  },
  {
    i: 13,
    start: 28.3,
    end: 30.2,
    text: 'khud mehnat karke decode karni padti hai,',
    highlights: [
      { text: 'khud mehnat', type: 'gold' },
      { text: 'decode', type: 'ink_bold' },
    ],
  },
  {
    i: 14,
    start: 30.7,
    end: 32.95,
    text: 'isliye aap mere clinic me aake bolte ho:',
    highlights: [
      { text: 'clinic', type: 'tangerine' },
      { text: 'bolte ho', type: 'ink_bold' },
    ],
  },
  {
    i: 15,
    start: 33.1,
    end: 35.1,
    text: '"Ki sun to raha hai, par samajh nahi aa raha!"',
    highlights: [
      { text: 'sun to raha hai', type: 'mint' },
      { text: 'samajh nahi aa raha', type: 'gold' },
    ],
  },
  {
    i: 16,
    start: 35.3,
    end: 37.2,
    text: 'Test saaf bata dete hain ki brain',
    highlights: [{ text: 'brain', type: 'ink_bold' }],
  },
  {
    i: 17,
    start: 37.2,
    end: 39.65,
    text: 'speech ko smoothly process kar raha hai,',
    highlights: [{ text: 'smoothly process', type: 'mint' }],
  },
  {
    i: 18,
    start: 39.68,
    end: 42.65,
    text: 'ya har sentence guess karke thak raha hai!',
    highlights: [{ text: 'guess karke thak raha hai', type: 'gold' }],
  },
  {
    i: 19,
    start: 43.1,
    end: 44.2,
    text: 'Agli baar dikhaunga:',
    highlights: [{ text: 'Agli baar', type: 'ink_bold' }],
  },
  {
    i: 20,
    start: 44.5,
    end: 46.4,
    text: 'sirf ek graph se ye kaise pata chalta hai',
    highlights: [{ text: 'sirf ek graph', type: 'tangerine' }],
  },
  {
    i: 21,
    start: 46.4,
    end: 47.95,
    text: 'ki duniya aapko kitni loud lagti hai!',
    highlights: [{ text: 'kitni loud', type: 'gold' }],
  },
];
