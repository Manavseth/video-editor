import React from 'react';
import {
  PAPER,
  INK,
  INK_SOFT,
  AIR,
  GOLD,
  OK,
  SLATE,
  SKIN,
  CHARCOAL_FACE,
} from '../tokens';

interface PatientFigureProps {
  x?: number;
  y?: number;
  torsoLean?: number; // degrees
  scale?: number;
  opacity?: number;
  rightArmPose?: 'on-paddle' | 'receive-card';
  squashY?: number;
}

export const PatientFigure: React.FC<PatientFigureProps> = ({
  x = 720,
  y = 920,
  torsoLean = 4,
  scale = 1,
  opacity = 1,
  rightArmPose = 'on-paddle',
  squashY = 1,
}) => {
  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale}, ${scale * squashY})`}
      opacity={opacity}
      style={{ transformOrigin: 'center bottom' }}
    >
      {/* Trousers & Legs seated */}
      {/* Thighs */}
      <line
        x1={-15}
        y1={60}
        x2={-70}
        y2={95}
        stroke={INK_SOFT}
        strokeWidth={22}
        strokeLinecap="round"
      />
      {/* Calves */}
      <line
        x1={-70}
        y1={95}
        x2={-75}
        y2={155}
        stroke={INK_SOFT}
        strokeWidth={18}
        strokeLinecap="round"
      />
      {/* Charcoal Slip-ons */}
      <ellipse
        cx={-85}
        cy={160}
        rx={18}
        ry={10}
        fill={CHARCOAL_FACE}
        stroke={INK}
        strokeWidth={3}
      />

      {/* Torso with 4 deg lean toward viewer-left */}
      <g transform={`rotate(${-torsoLean}, 0, 60)`}>
        {/* Shirt s200 */}
        <path
          d="M -30 -30 L 30 -30 L 35 60 L -35 60 Z"
          fill={SLATE.s200}
          stroke={INK}
          strokeWidth={4}
          strokeLinejoin="round"
        />
        {/* Collar band & 2 px center placket */}
        <line x1={0} y1={-30} x2={0} y2={60} stroke={INK} strokeWidth={2} />
        <path
          d="M -16 -30 L 0 -18 L 16 -30"
          fill="none"
          stroke={INK}
          strokeWidth={2.5}
        />

        {/* Left arm resting on thigh */}
        <path
          d="M 25 -20 Q 35 20 -20 65"
          fill="none"
          stroke={SLATE.s200}
          strokeWidth={14}
          strokeLinecap="round"
        />
        {/* Left nub hand Ø 22 */}
        <circle cx={-20} cy={65} r={11} fill={SKIN} stroke={INK} strokeWidth={2.5} />

        {/* Right arm */}
        {rightArmPose === 'on-paddle' ? (
          <g>
            {/* Reaches toward paddle on armrest */}
            <path
              d="M -25 -20 Q -45 20 -60 70"
              fill="none"
              stroke={SLATE.s200}
              strokeWidth={14}
              strokeLinecap="round"
            />
            {/* Right hand nub resting on paddle */}
            <circle
              cx={-60}
              cy={70}
              r={11}
              fill={SKIN}
              stroke={INK}
              strokeWidth={2.5}
            />
          </g>
        ) : (
          <g>
            {/* Lifts 6 px to receive card at chest */}
            <path
              d="M -25 -20 Q -50 0 -35 30"
              fill="none"
              stroke={SLATE.s200}
              strokeWidth={14}
              strokeLinecap="round"
            />
            <circle
              cx={-35}
              cy={30}
              r={11}
              fill={SKIN}
              stroke={INK}
              strokeWidth={2.5}
            />
          </g>
        )}

        {/* Head Center (0, -70) */}
        <g transform="translate(0, -70)">
          {/* Neck */}
          <line x1={0} y1={30} x2={0} y2={40} stroke={SKIN} strokeWidth={14} />
          {/* Head profile */}
          <ellipse
            cx={0}
            cy={0}
            rx={26}
            ry={32}
            fill={SKIN}
            stroke={INK}
            strokeWidth={3.5}
          />
          {/* Short black crop with straight fringe */}
          <path
            d="M -26 -6 C -26 -35, 26 -35, 26 -6 C 18 -18, -10 -20, -26 -6 Z"
            fill={INK}
          />
          {/* Straight fringe line */}
          <line x1={-20} y1={-8} x2={10} y2={-8} stroke={INK} strokeWidth={3} />

          {/* Abstract Face (smile arc + faint brow only - NO eyes, series rule) */}
          <path
            d="M -15 -12 Q -8 -16 -2 -12"
            fill="none"
            stroke={INK_SOFT}
            strokeWidth={2}
            strokeLinecap="round"
          />
          <path
            d="M -14 8 Q -6 16 2 8"
            fill="none"
            stroke={INK}
            strokeWidth={2.5}
            strokeLinecap="round"
          />
        </g>
      </g>
    </g>
  );
};

export const PatientChair: React.FC<{
  x?: number;
  y?: number;
  scale?: number;
  opacity?: number;
}> = ({ x = 720, y = 1080, scale = 1, opacity = 1 }) => {
  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      opacity={opacity}
      style={{ transformOrigin: 'center' }}
    >
      {/* 5-Star base Ø 240 INK lines */}
      <line x1={0} y1={80} x2={-110} y2={95} stroke={INK} strokeWidth={4} strokeLinecap="round" />
      <line x1={0} y1={80} x2={110} y2={95} stroke={INK} strokeWidth={4} strokeLinecap="round" />
      <line x1={0} y1={80} x2={-60} y2={115} stroke={INK} strokeWidth={4} strokeLinecap="round" />
      <line x1={0} y1={80} x2={60} y2={115} stroke={INK} strokeWidth={4} strokeLinecap="round" />
      <line x1={0} y1={80} x2={0} y2={120} stroke={INK} strokeWidth={4} strokeLinecap="round" />

      {/* Post Ø 24 x 96 */}
      <rect
        x={-12}
        y={-10}
        width={24}
        height={90}
        rx={6}
        fill={SLATE.s300}
        stroke={INK}
        strokeWidth={3}
      />

      {/* Seat 112x112 charcoal #43424B (isometric plane) */}
      <polygon
        points="-70,-20 0,-45 70,-20 0,5"
        fill={CHARCOAL_FACE}
        stroke={INK}
        strokeWidth={4}
      />
      {/* Seat thickness */}
      <polygon
        points="-70,-20 0,5 0,20 -70,-5"
        fill="#2A2930"
        stroke={INK}
        strokeWidth={3}
      />
      <polygon
        points="70,-20 0,5 0,20 70,-5"
        fill="#2A2930"
        stroke={INK}
        strokeWidth={3}
      />

      {/* Near-side armrest bar 90x14 at seat + 26 px */}
      <rect
        x={-80}
        y={-45}
        width={90}
        height={14}
        rx={5}
        fill={CHARCOAL_FACE}
        stroke={INK}
        strokeWidth={2.5}
      />
      <line x1={-35} y1={-30} x2={-35} y2={0} stroke={INK} strokeWidth={6} strokeLinecap="round" />
    </g>
  );
};

interface AudiFigProps {
  x?: number;
  y?: number;
  leanAngle?: number;
  pointerTarget?: { x: number; y: number } | null;
  scale?: number;
  opacity?: number;
}

export const AudiologistFigure: React.FC<AudiFigProps> = ({
  x = 280,
  y = 830,
  leanAngle = 0,
  pointerTarget = null,
  scale = 1,
  opacity = 1,
}) => {
  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      opacity={opacity}
      style={{ transformOrigin: 'center bottom' }}
    >
      {/* Ground contact shadow */}
      <ellipse cx={0} cy={160} rx={60} ry={18} fill="rgba(38, 36, 48, 0.16)" />

      {/* Legs & INK Trousers */}
      <line x1={-16} y1={60} x2={-18} y2={155} stroke={INK} strokeWidth={15} strokeLinecap="round" />
      <line x1={16} y1={60} x2={18} y2={155} stroke={INK} strokeWidth={15} strokeLinecap="round" />

      {/* Torso & Lab coat with leanAngle */}
      <g transform={`rotate(${leanAngle}, 0, 60)`}>
        {/* Lab coat (s50) */}
        <path
          d="M -36 -25 L 36 -25 L 45 65 L -45 65 Z"
          fill={SLATE.s50}
          stroke={INK}
          strokeWidth={4}
          strokeLinejoin="round"
        />
        {/* Cobalt shirt & single lapel line */}
        <polygon points="-14,-25 0,0 14,-25" fill="#2E56C9" />
        <line x1={0} y1={-25} x2={0} y2={65} stroke={INK} strokeWidth={2.5} />

        {/* Left arm */}
        <path
          d="M -36 -20 C -50 10, -45 30, -30 45"
          fill="none"
          stroke={SLATE.s50}
          strokeWidth={12}
          strokeLinecap="round"
        />

        {/* Right arm & Pointer pencil */}
        {pointerTarget ? (
          <g>
            <path
              d="M 36 -20 C 55 5, 70 20, 90 35"
              fill="none"
              stroke={SLATE.s50}
              strokeWidth={12}
              strokeLinecap="round"
            />
            {/* Pointer pencil 90 px */}
            <line
              x1={90}
              y1={35}
              x2={165}
              y2={65}
              stroke={INK}
              strokeWidth={5}
              strokeLinecap="round"
            />
            <polygon points="165,65 172,68 168,74" fill={PAPER} />
          </g>
        ) : (
          <g>
            {/* Rest pose */}
            <path
              d="M 36 -20 C 50 10, 45 30, 20 35"
              fill="none"
              stroke={SLATE.s50}
              strokeWidth={12}
              strokeLinecap="round"
            />
            <line
              x1={20}
              y1={35}
              x2={40}
              y2={100}
              stroke={INK}
              strokeWidth={4.5}
              strokeLinecap="round"
            />
          </g>
        )}

        {/* Head Center (0, -65) */}
        <g transform="translate(0, -65)">
          <line x1={0} y1={30} x2={0} y2={40} stroke={SKIN} strokeWidth={14} />
          <ellipse cx={0} cy={0} rx={26} ry={32} fill={SKIN} stroke={INK} strokeWidth={3.5} />
          {/* Hair */}
          <path
            d="M -26 -6 C -26 -35, 26 -35, 26 -6 C 18 -18, -10 -20, -26 -6 Z"
            fill={INK}
          />
          {/* Face: glasses & smile */}
          <circle cx={-8} cy={-2} r={3.5} fill={INK} />
          <circle cx={10} cy={-2} r={3.5} fill={INK} />
          <path d="M -3 10 Q 2 16 8 10" fill="none" stroke={INK} strokeWidth={2.5} strokeLinecap="round" />
        </g>
      </g>
    </g>
  );
};

export const QuoteCard: React.FC<{
  x?: number;
  y?: number;
  scale?: number;
  opacity?: number;
  showSunTick?: boolean;
  showSamajhTick?: boolean;
  sunTickPulse?: boolean;
  samajhTickPulse?: boolean;
  showHeadGlyph?: boolean;
}> = ({
  x = 540,
  y = 810,
  scale = 1,
  opacity = 1,
  showSunTick = true,
  showSamajhTick = true,
  sunTickPulse = false,
  samajhTickPulse = false,
  showHeadGlyph = true,
}) => {
  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      opacity={opacity}
      style={{ transformOrigin: 'center' }}
    >
      {/* 6 px Long Shadow */}
      <rect
        x={-456}
        y={-204}
        width={920}
        height={420}
        rx={28}
        fill="rgba(38, 36, 48, 0.16)"
      />
      {/* Card Body: 920x420, white chip fill, INK 4 px */}
      <rect
        x={-460}
        y={-210}
        width={920}
        height={420}
        rx={28}
        fill="#FFFFFF"
        stroke={INK}
        strokeWidth={4}
      />

      {/* Line 1: "SUN TO RAHA HAI," */}
      <g transform="translate(0, -60)">
        <text
          x={0}
          y={0}
          textAnchor="middle"
          fill={INK}
          fontFamily='Fraunces, "Playfair Display", Georgia, serif'
          fontSize={54}
          fontWeight={700}
        >
          &ldquo;SUN TO RAHA HAI,&rdquo;
        </text>
        {/* SUN 6 px MINT underline-tick */}
        {showSunTick && (
          <line
            x1={-230}
            y1={16}
            x2={-120}
            y2={16}
            stroke={OK}
            strokeWidth={sunTickPulse ? 9 : 6}
            strokeLinecap="round"
          />
        )}
      </g>

      {/* Line 2: "PAR SAMAJH NAHI AA RAHA!" */}
      <g transform="translate(0, 50)">
        <text
          x={0}
          y={0}
          textAnchor="middle"
          fill={INK}
          fontFamily='Fraunces, "Playfair Display", Georgia, serif'
          fontSize={48}
          fontWeight={700}
        >
          &ldquo;PAR SAMAJH NAHI AA RAHA!&rdquo;
        </text>
        {/* SAMAJH 6 px GOLD underline-tick */}
        {showSamajhTick && (
          <line
            x1={-190}
            y1={16}
            x2={-30}
            y2={16}
            stroke={GOLD}
            strokeWidth={samajhTickPulse ? 9 : 6}
            strokeLinecap="round"
          />
        )}
      </g>

      {/* HEAD-GLYPH: 48 px head circle + smile arc on card's bottom-left corner */}
      {showHeadGlyph && (
        <g transform="translate(-390, 140)">
          <circle cx={0} cy={0} r={24} fill={SKIN} stroke={INK} strokeWidth={3} />
          {/* Hair */}
          <path d="M -24 -4 C -24 -24, 24 -24, 24 -4 Z" fill={INK} />
          {/* Smile arc */}
          <path d="M -8 6 Q 0 14 8 6" fill="none" stroke={INK} strokeWidth={2.5} strokeLinecap="round" />
          {/* Small speech tick */}
          <polygon points="18,12 28,16 22,22" fill={INK} />
        </g>
      )}
    </g>
  );
};

export const BrainChip: React.FC<{
  x: number;
  y: number;
  scale?: number;
  opacity?: number;
}> = ({ x, y, scale = 1, opacity = 1 }) => {
  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      opacity={opacity}
      style={{ transformOrigin: 'center' }}
    >
      <rect
        x={-90}
        y={-30}
        width={180}
        height={60}
        rx={12}
        fill="#FFFFFF"
        stroke={INK}
        strokeWidth={2.5}
      />
      {/* 60x60 mini brain glyph (ridge arcs only) */}
      <g transform="translate(-55, 0)">
        <ellipse cx={0} cy={0} rx={18} ry={14} fill={SLATE.s100} stroke={INK} strokeWidth={2} />
        <path d="M -8 -4 Q 0 -8 8 -4" fill="none" stroke={INK} strokeWidth={1.5} />
        <path d="M -6 4 Q 0 8 6 4" fill="none" stroke={INK} strokeWidth={1.5} />
      </g>
      <text
        x={12}
        y={8}
        textAnchor="middle"
        fill={INK}
        fontFamily='Archivo, "Segoe UI", sans-serif'
        fontSize={32}
        fontWeight={700}
      >
        BRAIN
      </text>
    </g>
  );
};

export const SpeechBubble: React.FC<{
  x?: number;
  y?: number;
  scale?: number;
  opacity?: number;
}> = ({ x = 620, y = 860, scale = 1, opacity = 1 }) => {
  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      opacity={opacity}
      style={{ transformOrigin: 'bottom left' }}
    >
      {/* Bubble 200x110, radius 18, INK 3 px stroke, PAPER 80% fill */}
      <rect
        x={-20}
        y={-110}
        width={200}
        height={110}
        rx={18}
        fill={PAPER}
        fillOpacity={0.8}
        stroke={INK}
        strokeWidth={3}
      />
      {/* Tail pointing to patient mouth */}
      <polygon points="10,-2 25,-12 5,-12" fill={PAPER} stroke={INK} strokeWidth={2.5} />

      {/* 3 faint dot placeholders */}
      <circle cx={40} cy={-55} r={5} fill={INK_SOFT} opacity={0.5} />
      <circle cx={70} cy={-55} r={5} fill={INK_SOFT} opacity={0.5} />
      <circle cx={100} cy={-55} r={5} fill={INK_SOFT} opacity={0.5} />
    </g>
  );
};
