import React from 'react';
import {
  PAPER,
  GRID,
  INK,
  INK_SOFT,
  AIR,
  AIR_PALE,
  OCTAVES,
  fx,
  dy,
  SHEET,
  PLOT,
} from '../tokens';

export interface SymbolSpec {
  freq: 250 | 500 | 1000 | 2000 | 4000 | 8000;
  db: number;
  scale?: number;
  alpha?: number;
  bobY?: number;
  strokeWidth?: number;
  pop?: boolean;
}

export interface DepthBrace {
  freq: 250 | 500 | 1000 | 2000 | 4000 | 8000;
  db: number;
  progress?: number; // 0..1
  alpha?: number;
}

export interface DebtBandSpec {
  freq: 250 | 500 | 1000 | 2000 | 4000 | 8000;
  topDb: number;
  bottomDb: number;
  growProgress: number; // 0..1
  caliperProgress?: number; // 0..1
  caretTicksProgress?: number; // 0..1
  widthScale?: number;
}

interface AudSheetProps {
  opacity?: number;
  scale?: number;
  breatheY?: number;
  clipPathWipe?: string; // for SHEET-SWAP wipe
  showHeader?: boolean;
  headerOpacity?: number;
  headerTranslateY?: number;
  legendPopScale?: number;
  showGrid?: boolean;
  gridAlpha?: number;
  showLabels?: boolean;
  axisChips?: boolean; // S07 PITCH -> and VOLUME v chips
  dotAxisRunProgress?: number; // 0..1 dot running along x-axis in S07
  dbLabelsHighlightProgress?: number; // top to bottom stagger 0..1
  curveValues?: number[]; // [250, 500, 1k, 2k, 4k, 8k]
  curveProgress?: number; // 0..1 draw progress
  showTipDot?: boolean;
  symbols?: SymbolSpec[];
  depthBraces?: DepthBrace[];
  debtBand?: DebtBandSpec | null;
  transformOrigin?: string;
  arrowsDown?: Array<{ x: number; y: number; progress: number }>;
}

export const AudSheet: React.FC<AudSheetProps> = ({
  opacity = 1,
  scale = 1,
  breatheY = 0,
  clipPathWipe,
  showHeader = true,
  headerOpacity = 1,
  headerTranslateY = 0,
  legendPopScale = 1,
  showGrid = true,
  gridAlpha = 1,
  showLabels = true,
  axisChips = false,
  dotAxisRunProgress = 0,
  dbLabelsHighlightProgress = 0,
  curveValues,
  curveProgress = 1,
  showTipDot = false,
  symbols = [],
  depthBraces = [],
  debtBand = null,
  transformOrigin = '540px 790px',
  arrowsDown = [],
}) => {
  const dbSteps = [0, 25, 50, 75, 100];

  // Helper to interpolate polyline points with exact progress
  const makePoints = (vals: number[], progress: number) => {
    const pts = OCTAVES.map((freq, idx) => ({
      x: fx(freq),
      y: dy(vals[idx]),
    }));
    if (progress <= 0) return { pts: [], tip: null };
    if (progress >= 1) return { pts, tip: pts[pts.length - 1] };

    const totalSegs = pts.length - 1;
    const currentDist = progress * totalSegs;
    const segIdx = Math.min(Math.floor(currentDist), totalSegs - 1);
    const segFrac = currentDist - segIdx;

    const res = pts.slice(0, segIdx + 1);
    const p1 = pts[segIdx];
    const p2 = pts[segIdx + 1];
    const tip = {
      x: p1.x + (p2.x - p1.x) * segFrac,
      y: p1.y + (p2.y - p1.y) * segFrac,
    };
    res.push(tip);
    return { pts: res, tip };
  };

  const { pts: curvePts, tip: curveTip } = curveValues
    ? makePoints(curveValues, curveProgress)
    : { pts: [], tip: null };

  const polylineStr = curvePts.map((p) => `${p.x},${p.y}`).join(' ');

  return (
    <g
      opacity={opacity}
      transform={`translate(0, ${breatheY}) scale(${scale})`}
      style={{ transformOrigin, clipPath: clipPathWipe }}
    >
      {/* 1. Main Sheet Panel */}
      <rect
        x={SHEET.x0}
        y={SHEET.y0}
        width={SHEET.x1 - SHEET.x0}
        height={SHEET.y1 - SHEET.y0}
        rx={SHEET.r}
        fill="rgba(255, 255, 255, 0.60)"
        stroke={INK}
        strokeWidth={4}
      />

      {/* 2. Header Strip (y 300-372) */}
      {showHeader && (
        <g
          opacity={headerOpacity}
          transform={`translate(0, ${headerTranslateY})`}
        >
          {/* Left: AUDIOGRAM */}
          <text
            x={SHEET.x0 + 36}
            y={SHEET.y0 + 52}
            fill={INK}
            fontFamily='Fraunces, "Playfair Display", Georgia, serif'
            fontSize={44}
            fontWeight={700}
          >
            AUDIOGRAM
          </text>

          {/* Right: Legend Chip [O] SYMBOLS */}
          <g
            transform={`translate(${SHEET.x1 - 250}, ${SHEET.y0 + 20}) scale(${legendPopScale})`}
            style={{ transformOrigin: 'center' }}
          >
            <rect
              x={0}
              y={0}
              width={220}
              height={44}
              rx={10}
              fill="#FFFFFF"
              stroke={INK}
              strokeWidth={2}
            />
            {/* Open circle glyph 22 px ring, 4.5 px stroke, AIR */}
            <circle
              cx={28}
              cy={22}
              r={11}
              fill="none"
              stroke={AIR}
              strokeWidth={4.5}
            />
            <text
              x={54}
              y={30}
              fill={INK}
              fontFamily='Archivo, "Segoe UI", sans-serif'
              fontSize={30}
              fontWeight={600}
            >
              SYMBOLS
            </text>
          </g>
        </g>
      )}

      {/* 3. Grid (Plot: x 168-958, y 380-1180) */}
      {showGrid && (
        <g opacity={gridAlpha}>
          {/* Vertical octave hairlines */}
          {OCTAVES.map((freq) => {
            const x = fx(freq);
            return (
              <line
                key={`v-${freq}`}
                x1={x}
                y1={PLOT.y0}
                x2={x}
                y2={PLOT.y1}
                stroke={GRID}
                strokeWidth={2}
              />
            );
          })}

          {/* Horizontal dB hairlines every 25 dB */}
          {dbSteps.map((db) => {
            const y = dy(db);
            return (
              <line
                key={`h-${db}`}
                x1={PLOT.x0}
                y1={y}
                x2={PLOT.x1}
                y2={y}
                stroke={GRID}
                strokeWidth={2}
              />
            );
          })}
        </g>
      )}

      {/* 4. Axis Labels */}
      {showLabels && (
        <g>
          {/* Frequency row at y 1210 */}
          {OCTAVES.map((freq) => {
            const x = fx(freq);
            const label = freq >= 1000 ? `${freq / 1000}k` : `${freq}`;
            return (
              <text
                key={`lbl-f-${freq}`}
                x={x}
                y={1210}
                textAnchor="middle"
                fill={INK_SOFT}
                fontFamily='Archivo, "Segoe UI", sans-serif'
                fontSize={26}
                fontWeight={500}
              >
                {label}
              </text>
            );
          })}

          {/* dB column at x 970 */}
          {dbSteps.map((db, idx) => {
            const y = dy(db);
            const isHighlighted =
              dbLabelsHighlightProgress > 0 &&
              idx / (dbSteps.length - 1) <= dbLabelsHighlightProgress;
            return (
              <text
                key={`lbl-db-${db}`}
                x={970}
                y={y + 8}
                textAnchor="start"
                fill={isHighlighted ? INK : INK_SOFT}
                fontFamily='Archivo, "Segoe UI", sans-serif'
                fontSize={26}
                fontWeight={isHighlighted ? 700 : 500}
              >
                {db}
              </text>
            );
          })}
        </g>
      )}

      {/* S07-only Axis Chips & Dots */}
      {axisChips && (
        <g>
          {/* PITCH -> white chip cleanly under the frequency row */}
          <g transform="translate(240, 1252)">
            <rect
              x={-60}
              y={-18}
              width={120}
              height={36}
              rx={8}
              fill="#FFFFFF"
              stroke={INK}
              strokeWidth={2}
            />
            <text
              x={0}
              y={7}
              textAnchor="middle"
              fill={INK}
              fontFamily='Archivo, "Segoe UI", sans-serif'
              fontSize={22}
              fontWeight={700}
            >
              PITCH →
            </text>
          </g>

          {/* VOLUME v white chip next to dB column */}
          <g transform="translate(870, 470)">
            <rect
              x={-65}
              y={-18}
              width={130}
              height={36}
              rx={8}
              fill="#FFFFFF"
              stroke={INK}
              strokeWidth={2}
            />
            <text
              x={0}
              y={7}
              textAnchor="middle"
              fill={INK}
              fontFamily='Archivo, "Segoe UI", sans-serif'
              fontSize={22}
              fontWeight={700}
            >
              VOLUME ↓
            </text>
          </g>
        </g>
      )}

      {/* S07 dot running along x-axis 168->958 */}
      {dotAxisRunProgress > 0 && dotAxisRunProgress < 1 && (
        <circle
          cx={168 + (958 - 168) * dotAxisRunProgress}
          cy={1180}
          r={5}
          fill={AIR}
        />
      )}

      {/* 5. Depth Braces (S04) */}
      {depthBraces.map((b, i) => {
        const sx = fx(b.freq);
        const sy = dy(b.db);
        const targetX = 958;
        const p = b.progress ?? 1;
        const currX = sx + (targetX - sx) * p;
        return (
          <g key={`brace-${i}`} opacity={b.alpha ?? 0.4}>
            <line
              x1={sx}
              y1={sy}
              x2={currX}
              y2={sy}
              stroke={INK_SOFT}
              strokeWidth={1.5}
              strokeDasharray="4 4"
            />
            <circle cx={currX} cy={sy} r={3} fill={INK_SOFT} />
          </g>
        );
      })}

      {/* 6. Volume-Debt Band (S09) */}
      {debtBand && (
        <g>
          {/* Vertical band at 1 kHz column: x 484 +/- 26 */}
          {(() => {
            const bx = fx(debtBand.freq);
            const topY = dy(debtBand.topDb);
            const targetBottomY = dy(debtBand.bottomDb);
            const currentBottomY =
              topY + (targetBottomY - topY) * debtBand.growProgress;
            const h = Math.max(0, currentBottomY - topY);
            const w = 52 * (debtBand.widthScale ?? 1);

            return (
              <g>
                <rect
                  x={bx - w / 2}
                  y={topY}
                  width={w}
                  height={h}
                  fill={AIR_PALE}
                  fillOpacity={0.35}
                  stroke={INK}
                  strokeWidth={2}
                />

                {/* Caliper bracket strokes on left edge measuring 0->40 */}
                {debtBand.caliperProgress && debtBand.caliperProgress > 0 && (
                  <g opacity={debtBand.caliperProgress}>
                    <line
                      x1={bx - w / 2 - 12}
                      y1={topY}
                      x2={bx - w / 2 - 12}
                      y2={currentBottomY}
                      stroke={INK}
                      strokeWidth={3}
                    />
                    {/* Top caliper tick */}
                    <line
                      x1={bx - w / 2 - 20}
                      y1={topY}
                      x2={bx - w / 2 - 8}
                      y2={topY}
                      stroke={INK}
                      strokeWidth={3}
                    />
                    {/* Bottom caliper tick */}
                    <line
                      x1={bx - w / 2 - 20}
                      y1={currentBottomY}
                      x2={bx - w / 2 - 8}
                      y2={currentBottomY}
                      stroke={INK}
                      strokeWidth={3}
                    />
                  </g>
                )}

                {/* Down-caret ticks inside band */}
                {debtBand.caretTicksProgress && debtBand.caretTicksProgress > 0 && (
                  <g>
                    <path
                      d={`M ${bx - 8} ${topY + h * 0.35} L ${bx} ${topY + h * 0.35 + 8} L ${bx + 8} ${topY + h * 0.35}`}
                      fill="none"
                      stroke={INK}
                      strokeWidth={2.5}
                      strokeLinecap="round"
                    />
                    <path
                      d={`M ${bx - 8} ${topY + h * 0.65} L ${bx} ${topY + h * 0.65 + 8} L ${bx + 8} ${topY + h * 0.65}`}
                      fill="none"
                      stroke={INK}
                      strokeWidth={2.5}
                      strokeLinecap="round"
                    />
                  </g>
                )}
              </g>
            );
          })()}
        </g>
      )}

      {/* 7. Threshold Line (AIR tangerine, 7 px stroke, round joins, no smoothing) */}
      {curvePts.length > 1 && (
        <polyline
          points={polylineStr}
          fill="none"
          stroke={AIR}
          strokeWidth={7}
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      )}

      {/* Tip Dot (8 px ink tip-dot with 60% alpha leading the draw-on) */}
      {showTipDot && curveTip && (
        <circle
          cx={curveTip.x}
          cy={curveTip.y}
          r={6}
          fill={INK}
          opacity={0.6}
        />
      )}

      {/* 8. Open-Circle Symbols at each point */}
      {symbols.map((sym, i) => {
        const sx = fx(sym.freq);
        const sy = dy(sym.db) + (sym.bobY ?? 0);
        const alpha = sym.alpha ?? 1;
        const scaleVal = sym.scale ?? 1;
        const strokeW = sym.strokeWidth ?? 4.5;

        return (
          <g
            key={`sym-${i}`}
            transform={`translate(${sx}, ${sy}) scale(${scaleVal})`}
            opacity={alpha}
            style={{ transformOrigin: 'center' }}
          >
            {/* Ring Ø 22 (radius 11), 4.5 px stroke, PAPER fill */}
            <circle
              cx={0}
              cy={0}
              r={11}
              fill={PAPER}
              stroke={AIR}
              strokeWidth={strokeW}
            />
          </g>
        );
      })}

      {/* 9. Cascading ARROW-DOWNs */}
      {arrowsDown.map((arr, i) => {
        const p = arr.progress;
        const travel = 24 * p;
        return (
          <g
            key={`arr-${i}`}
            transform={`translate(${arr.x}, ${arr.y + travel})`}
            opacity={p > 0 ? 1 : 0}
          >
            <line
              x1={0}
              y1={0}
              x2={0}
              y2={40}
              stroke={INK}
              strokeWidth={3}
              strokeLinecap="round"
            />
            <polygon points="-8,40 0,54 8,40" fill={INK} />
          </g>
        );
      })}
    </g>
  );
};
