import React from 'react';
import {
  PAPER,
  GRID,
  INK,
  INK_SOFT,
  AIR,
  OK,
  SLATE,
  CHARCOAL_FACE,
} from '../tokens';

interface AudiometerProps {
  x?: number;
  y?: number;
  scale?: number;
  opacity?: number;
  ledActive?: boolean;
  beepArcsProgress?: number; // 0..1 for concentric beep rings in S01
}

export const AudiometerCube: React.FC<AudiometerProps> = ({
  x = 300,
  y = 950,
  scale = 1,
  opacity = 1,
  ledActive = true,
  beepArcsProgress = 0,
}) => {
  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      opacity={opacity}
      style={{ transformOrigin: 'center' }}
    >
      {/* Contact shadow */}
      <ellipse cx={130} cy={165} rx={140} ry={36} fill="rgba(38, 36, 48, 0.16)" />

      {/* Main chamfered block 260x150x120 */}
      {/* Side face */}
      <polygon
        points="0,60 40,20 300,20 260,60"
        fill={SLATE.s50}
        stroke={INK}
        strokeWidth={4}
      />
      {/* Front face */}
      <rect
        x={0}
        y={60}
        width={260}
        height={90}
        rx={8}
        fill={SLATE.s100}
        stroke={INK}
        strokeWidth={4}
      />
      {/* Right extruded face */}
      <polygon
        points="260,60 300,20 300,110 260,150"
        fill={SLATE.s200}
        stroke={INK}
        strokeWidth={4}
      />

      {/* Front slot 120x36 for printout paper */}
      <rect
        x={70}
        y={75}
        width={120}
        height={22}
        rx={4}
        fill={INK}
      />

      {/* 3 LED dots Ø 14 */}
      {[0, 1, 2].map((i) => {
        const isLit = ledActive && i === 0;
        return (
          <circle
            key={`led-${i}`}
            cx={40 + i * 24}
            cy={120}
            r={7}
            fill={isLit ? OK : SLATE.s300}
            stroke={INK}
            strokeWidth={2}
          />
        );
      })}

      {/* Blank status screen 90x64 on top plane */}
      <polygon
        points="70,52 100,28 190,28 160,52"
        fill={SLATE.s300}
        stroke={INK}
        strokeWidth={2.5}
      />

      {/* Beep quarter-arcs pulsing from screen corner */}
      {beepArcsProgress > 0 && (
        <g transform="translate(190, 28)">
          {[0, 1, 2].map((i) => {
            const p = Math.max(0, Math.min(1, beepArcsProgress * 1.5 - i * 0.25));
            if (p <= 0) return null;
            const r = 20 + 40 * p;
            return (
              <path
                key={`beep-${i}`}
                d={`M ${r} 0 A ${r} ${r} 0 0 0 0 ${-r}`}
                fill="none"
                stroke={AIR}
                strokeWidth={3}
                opacity={1 - p}
              />
            );
          })}
        </g>
      )}
    </g>
  );
};

interface PrintoutCardProps {
  x?: number;
  y?: number;
  scale?: number;
  rotation?: number; // degrees
  opacity?: number;
  showMiniDots?: boolean;
  dotsAlpha?: number;
}

export const PrintoutCard: React.FC<PrintoutCardProps> = ({
  x = 200,
  y = 960,
  scale = 1,
  rotation = 0,
  opacity = 1,
  showMiniDots = true,
  dotsAlpha = 1,
}) => {
  // Mini SCATTER dots inside card (normalized to 96x150 plot)
  const miniScatter = [
    { x: 18, y: 35 },
    { x: 34, y: 50 },
    { x: 50, y: 42 },
    { x: 66, y: 65 },
    { x: 82, y: 75 },
    { x: 98, y: 85 },
  ];

  return (
    <g
      transform={`translate(${x}, ${y}) rotate(${rotation}) scale(${scale})`}
      opacity={opacity}
      style={{ transformOrigin: 'top left' }}
    >
      {/* 4 px drop shadow */}
      <rect
        x={4}
        y={6}
        width={300}
        height={220}
        rx={12}
        fill="rgba(38, 36, 48, 0.15)"
      />
      {/* Card body 300x220 */}
      <rect
        x={0}
        y={0}
        width={300}
        height={220}
        rx={12}
        fill={PAPER}
        stroke={INK}
        strokeWidth={4}
      />

      {/* Mini Header line */}
      <line x1={20} y1={28} x2={140} y2={28} stroke={INK} strokeWidth={3} />

      {/* Mini Grid 96x150 */}
      <rect
        x={20}
        y={45}
        width={150}
        height={130}
        fill="#FFFFFF"
        stroke={INK_SOFT}
        strokeWidth={1.5}
      />
      {[1, 2, 3, 4, 5].map((i) => (
        <line
          key={`mv-${i}`}
          x1={20 + i * 25}
          y1={45}
          x2={20 + i * 25}
          y2={175}
          stroke={GRID}
          strokeWidth={1}
        />
      ))}
      {[1, 2, 3].map((i) => (
        <line
          key={`mh-${i}`}
          x1={20}
          y1={45 + i * 32}
          x2={170}
          y2={45 + i * 32}
          stroke={GRID}
          strokeWidth={1}
        />
      ))}

      {/* Mini SCATTER Tangerine Dots */}
      {showMiniDots && (
        <g opacity={dotsAlpha} transform="translate(25, 45)">
          {miniScatter.map((dot, idx) => (
            <circle
              key={`mdot-${idx}`}
              cx={dot.x}
              cy={dot.y}
              r={4}
              fill={AIR}
              stroke={INK}
              strokeWidth={1.5}
            />
          ))}
        </g>
      )}

      {/* Mini text lines on right side */}
      <line x1={190} y1={60} x2={270} y2={60} stroke={INK_SOFT} strokeWidth={3} />
      <line x1={190} y1={80} x2={250} y2={80} stroke={INK_SOFT} strokeWidth={2} />
      <line x1={190} y1={100} x2={260} y2={100} stroke={INK_SOFT} strokeWidth={2} />
    </g>
  );
};

interface ResponsePaddleProps {
  x?: number;
  y?: number;
  isPressed?: boolean;
  scale?: number;
  opacity?: number;
}

export const ResponsePaddle: React.FC<ResponsePaddleProps> = ({
  x = 764,
  y = 1002,
  isPressed = false,
  scale = 1,
  opacity = 1,
}) => {
  const squashY = isPressed ? 0.92 : 1.0;

  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale}, ${scale * squashY})`}
      opacity={opacity}
      style={{ transformOrigin: 'center bottom' }}
    >
      {/* 3 px Cable running to console */}
      <path
        d="M 48 10 C 120 40, 20 -20, -446 -62"
        fill="none"
        stroke={INK}
        strokeWidth={3}
        strokeLinecap="round"
      />

      {/* Iso puck footprint 96x64, height 22 */}
      {/* Bottom base / body */}
      <ellipse
        cx={0}
        cy={11}
        rx={48}
        ry={26}
        fill={SLATE.s200}
        stroke={INK}
        strokeWidth={4}
      />
      {/* Top face */}
      <ellipse
        cx={0}
        cy={0}
        rx={48}
        ry={26}
        fill={PAPER}
        stroke={INK}
        strokeWidth={4}
      />

      {/* Mint indicator dot Ø 26 */}
      <ellipse
        cx={0}
        cy={0}
        rx={13}
        ry={7}
        fill={isPressed ? INK : OK}
        stroke={INK}
        strokeWidth={2}
      />
    </g>
  );
};

interface HeadphoneDeviceProps {
  x?: number;
  y?: number;
  scale?: number;
  opacity?: number;
}

export const HeadphoneDevice: React.FC<HeadphoneDeviceProps> = ({
  x = 720,
  y = 920,
  scale = 1,
  opacity = 1,
}) => {
  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      opacity={opacity}
      style={{ transformOrigin: 'center' }}
    >
      {/* Headband arc INK 12 px */}
      <path
        d="M -55 -20 C -55 -110, 55 -110, 55 -20"
        fill="none"
        stroke={INK}
        strokeWidth={12}
        strokeLinecap="round"
      />
      {/* Left cup */}
      <ellipse
        cx={-56}
        cy={-15}
        rx={16}
        ry={28}
        fill={CHARCOAL_FACE}
        stroke={SLATE.s200}
        strokeWidth={3}
      />
      {/* Right cup */}
      <ellipse
        cx={56}
        cy={-15}
        rx={16}
        ry={28}
        fill={CHARCOAL_FACE}
        stroke={SLATE.s200}
        strokeWidth={3}
      />
    </g>
  );
};
