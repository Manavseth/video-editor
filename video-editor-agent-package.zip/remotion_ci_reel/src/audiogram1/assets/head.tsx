import React from 'react';
import {
  PAPER,
  SLATE,
  INK,
  INK_SOFT,
  AIR,
  GOLD,
  OK,
  TM_FILL,
  HEAD,
} from '../tokens';

interface HeadCutProps {
  x?: number;
  y?: number;
  scale?: number;
  opacity?: number;
  cutawayWipeProgress?: number; // 0..1 sweep from ear to center
  airRouteProgress?: number; // 0..1
  tokenProgress?: number; // 0..1 along air route
  tokenActive?: boolean;
  tokenColor?: string;
  isTokenGoldAtBrain?: boolean;
  tokenTrio?: {
    active: boolean;
    cycleProgress: number; // 0..1
  } | null;
  pistonCadence?: 'off' | 'idle' | 'labor'; // idle 12 f/cycle, labor 6 f/cycle
  pistonFrame?: number;
  apexTicksCount?: number; // gold chevrons ejecting above brain
  brainYOffset?: number; // e.g. rises into position
  brainCheckRing?: boolean; // mint check ring at brain
  showHeadphones?: boolean;
  headphoneDockProgress?: number; // 0..1
}

export const HeadCut: React.FC<HeadCutProps> = ({
  x = HEAD.x0,
  y = HEAD.y0,
  scale = 1,
  opacity = 1,
  cutawayWipeProgress = 1,
  airRouteProgress = 0,
  tokenProgress = 0,
  tokenActive = false,
  tokenColor = AIR,
  isTokenGoldAtBrain = false,
  tokenTrio = null,
  pistonCadence = 'idle',
  pistonFrame = 0,
  apexTicksCount = 0,
  brainYOffset = 0,
  brainCheckRing = false,
  showHeadphones = false,
  headphoneDockProgress = 1,
}) => {
  // Origin offset for relative coordinates inside 640x680 bbox
  const ox = 0;
  const oy = 0;

  // Waypoints for AIR-ROUTE
  const WAYPOINTS = [
    { x: 400, y: 385 }, // canal mouth
    { x: 480, y: 400 }, // canal mid
    { x: 545, y: 425 }, // TM
    { x: 550, y: 415 }, // malleus
    { x: 566, y: 440 }, // incus
    { x: 595, y: 468 }, // stapes
    { x: 600, y: 505 }, // oval window
    { x: 612, y: 535 }, // cochlea entry
    { x: 610, y: 555 }, // CL
    { x: 585, y: 545 }, // nerve exit
    { x: 480, y: 520 }, // nerve mid
    { x: 330, y: 500 }, // BRAIN-CORE
  ];

  // Helper to get point on waypoints path
  const getWaypointPos = (prog: number) => {
    prog = Math.max(0, Math.min(1, prog));
    const totalSegs = WAYPOINTS.length - 1;
    const d = prog * totalSegs;
    const idx = Math.min(Math.floor(d), totalSegs - 1);
    const rem = d - idx;
    const p1 = WAYPOINTS[idx];
    const p2 = WAYPOINTS[idx + 1];
    return {
      x: p1.x + (p2.x - p1.x) * rem,
      y: p1.y + (p2.y - p1.y) * rem,
    };
  };

  // Piston animation logic
  const getPistonOffset = (barrelIdx: number) => {
    if (pistonCadence === 'off') return 0;
    const period = pistonCadence === 'labor' ? 6 : 12;
    const stagger = barrelIdx * (period / 3);
    const phase = ((pistonFrame + stagger) % period) / period;
    // 6 px bob upward
    return Math.sin(phase * Math.PI * 2) * 6;
  };

  const isTransitSolid = tokenActive && tokenProgress > 0.7;

  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      opacity={opacity}
      style={{ transformOrigin: '330px 500px' }}
    >
      <defs>
        {/* Cutaway clip path: sweep from ear-side (right) to center (left) */}
        <clipPath id="cutaway-clip">
          <rect
            x={ox + 650 - 350 * cutawayWipeProgress}
            y={oy + 230}
            width={370 * cutawayWipeProgress}
            height={360}
          />
        </clipPath>
      </defs>

      {/* 1. Ground Contact Shadow */}
      <ellipse
        cx={ox + 460}
        cy={oy + 620}
        rx={220}
        ry={48}
        fill="rgba(38, 36, 48, 0.14)"
      />

      {/* 2. SKULL Silhouette (Profile facing lower-left) */}
      <path
        d={`
          M ${ox + 260} ${oy + 220}
          C ${ox + 340} ${oy + 140}, ${ox + 480} ${oy + 140}, ${ox + 580} ${oy + 220}
          C ${ox + 660} ${oy + 290}, ${ox + 680} ${oy + 420}, ${ox + 640} ${oy + 520}
          C ${ox + 600} ${oy + 600}, ${ox + 480} ${oy + 620}, ${ox + 380} ${oy + 610}
          C ${ox + 300} ${oy + 600}, ${ox + 230} ${oy + 530}, ${ox + 220} ${oy + 440}
          C ${ox + 210} ${oy + 340}, ${ox + 220} ${oy + 260}, ${ox + 260} ${oy + 220}
          Z
        `}
        fill={SLATE.s100}
        stroke={INK}
        strokeWidth={4}
      />
      {/* Top skull highlight */}
      <path
        d={`
          M ${ox + 280} ${oy + 230}
          C ${ox + 360} ${oy + 160}, ${ox + 470} ${oy + 160}, ${ox + 550} ${oy + 230}
          C ${ox + 480} ${oy + 260}, ${ox + 360} ${oy + 260}, ${ox + 280} ${oy + 230}
          Z
        `}
        fill={SLATE.s50}
        opacity={0.8}
      />

      {/* Mastoid patch at MS (300, 400), 90x70, s200 */}
      <rect
        x={ox + 255}
        y={oy + 365}
        width={90}
        height={70}
        rx={18}
        fill={SLATE.s200}
        opacity={0.6}
        stroke={INK_SOFT}
        strokeWidth={2}
      />

      {/* 3. CUTAWAY Window & Interior Components */}
      {cutawayWipeProgress > 0 && (
        <g clipPath="url(#cutaway-clip)">
          {/* Rounded-rect window (300,240)-(650,570), radius 36, fill PAPER, 10px s300 lip */}
          <rect
            x={ox + 295}
            y={oy + 235}
            width={360}
            height={340}
            rx={40}
            fill={SLATE.s300}
          />
          <rect
            x={ox + 300}
            y={oy + 240}
            width={350}
            height={330}
            rx={36}
            fill={PAPER}
            stroke={INK}
            strokeWidth={4}
          />

          {/* ME Chamber (585,380)-(700,500), radius 24, s50 */}
          <rect
            x={ox + 575}
            y={oy + 375}
            width={110}
            height={120}
            rx={24}
            fill={SLATE.s50}
            stroke={INK_SOFT}
            strokeWidth={2}
          />

          {/* Ear Canal tube (400,385) -> TM (545,425) */}
          <path
            d={`M ${ox + 400} ${oy + 370} Q ${ox + 470} ${oy + 395} ${ox + 545} ${oy + 405}
               L ${ox + 545} ${oy + 445} Q ${ox + 470} ${oy + 430} ${ox + 400} ${oy + 400} Z`}
            fill={SLATE.s50}
            stroke={INK}
            strokeWidth={3.5}
          />
          {/* Cartilage arcs */}
          <path
            d={`M ${ox + 440} ${oy + 378} Q ${ox + 445} ${oy + 405} ${ox + 440} ${oy + 420}`}
            fill="none"
            stroke={INK_SOFT}
            strokeWidth={2.5}
          />
          <path
            d={`M ${ox + 480} ${oy + 386} Q ${ox + 485} ${oy + 412} ${ox + 480} ${oy + 430}`}
            fill="none"
            stroke={INK_SOFT}
            strokeWidth={2.5}
          />

          {/* Tympanic Membrane (TM): iso oval 100x64 at (545,425), fill TM_FILL, 4px INK */}
          <ellipse
            cx={ox + 545}
            cy={oy + 425}
            rx={50}
            ry={32}
            transform={`rotate(-25, ${ox + 545}, ${oy + 425})`}
            fill={TM_FILL}
            stroke={INK}
            strokeWidth={4}
          />
          {/* Cone of light line */}
          <line
            x1={ox + 545}
            y1={oy + 425}
            x2={ox + 560}
            y2={oy + 445}
            stroke={SLATE.s400}
            strokeWidth={2.5}
          />

          {/* OSSICLES: Malleus, Incus, Stapes */}
          {/* Malleus (545,405) lean 20° */}
          <line
            x1={ox + 545}
            y1={oy + 405}
            x2={ox + 555}
            y2={oy + 440}
            stroke={INK}
            strokeWidth={7}
            strokeLinecap="round"
          />
          {/* Incus (566,440) lean -15° */}
          <line
            x1={ox + 555}
            y1={oy + 430}
            x2={ox + 580}
            y2={oy + 455}
            stroke={INK}
            strokeWidth={7}
            strokeLinecap="round"
          />
          {/* Stapes (595,468) */}
          <polygon
            points={`${ox + 580},${oy + 455} ${ox + 598},${oy + 475} ${ox + 588},${oy + 485}`}
            fill={SLATE.s200}
            stroke={INK}
            strokeWidth={4}
          />

          {/* COCHLEA: spiral shell center CL = (610,555), 2.5 turn Archimedean */}
          <g transform={`translate(${ox + 610}, ${oy + 555})`}>
            {/* Outer shell backing */}
            <ellipse
              cx={0}
              cy={0}
              rx={55}
              ry={48}
              fill={SLATE.s100}
              stroke={INK}
              strokeWidth={4}
            />
            {/* Healthy mint health-ring */}
            <ellipse
              cx={0}
              cy={0}
              rx={50}
              ry={43}
              fill="none"
              stroke={OK}
              strokeWidth={3}
              opacity={0.85}
            />
            {/* Spiral line */}
            <path
              d="M 35 0 C 35 25, -25 35, -30 5 C -35 -20, 15 -25, 15 -5 C 15 10, -5 12, -8 0"
              fill="none"
              stroke={INK}
              strokeWidth={3}
              strokeLinecap="round"
            />
          </g>

          {/* NERVE: tapered bundle (585,545) -> (480,520) */}
          <path
            d={`M ${ox + 585} ${oy + 535} L ${ox + 480} ${oy + 513} L ${ox + 480} ${oy + 527} L ${ox + 585} ${oy + 555} Z`}
            fill={SLATE.s300}
            stroke={INK}
            strokeWidth={3}
          />
          <line
            x1={ox + 535}
            y1={oy + 522}
            x2={ox + 535}
            y2={oy + 540}
            stroke={INK_SOFT}
            strokeWidth={2}
          />
          <line
            x1={ox + 510}
            y1={oy + 518}
            x2={ox + 510}
            y2={oy + 533}
            stroke={INK_SOFT}
            strokeWidth={2}
          />

          {/* NERVE-EXT (480,520) -> (330,500) width 14->10 */}
          {isTransitSolid ? (
            <path
              d={`M ${ox + 480} ${oy + 513} L ${ox + 330} ${oy + 495} L ${ox + 330} ${oy + 505} L ${ox + 480} ${oy + 527} Z`}
              fill={SLATE.s300}
              stroke={INK}
              strokeWidth={3}
            />
          ) : (
            <line
              x1={ox + 480}
              y1={oy + 520}
              x2={ox + 330}
              y2={oy + 500}
              stroke={INK_SOFT}
              strokeWidth={2.5}
              strokeDasharray="6 5"
            />
          )}

          {/* 4. BRAIN-CORE (Center bbox-rel (330,500)) */}
          <g
            transform={`translate(${ox + 330}, ${oy + 500 + brainYOffset})`}
            style={{ transformOrigin: 'center' }}
          >
            {/* Pedestal plinth 190x150x18 */}
            <ellipse
              cx={0}
              cy={60}
              rx={95}
              ry={28}
              fill={SLATE.s300}
              stroke={INK}
              strokeWidth={3.5}
            />

            {/* Brain two-lobe rounded blob body */}
            <path
              d="M -75 25 C -90 -20, -60 -60, -20 -65 C 10 -68, 50 -40, 75 0 C 85 30, 40 55, 0 55 C -40 55, -65 50, -75 25 Z"
              fill={SLATE.s100}
              stroke={INK}
              strokeWidth={4}
            />
            {/* Top faces highlight */}
            <path
              d="M -60 -10 C -70 -45, -40 -60, -15 -62 C 10 -65, 40 -40, 55 -10 C 20 -25, -30 -25, -60 -10 Z"
              fill={SLATE.s50}
              opacity={0.85}
            />
            {/* 3 Ridge squiggle arcs */}
            <path
              d="M -45 -35 Q -30 -45 -15 -35 Q 0 -25 15 -35"
              fill="none"
              stroke={INK}
              strokeWidth={3}
              strokeLinecap="round"
            />
            <path
              d="M -40 -20 Q -25 -30 -10 -20 Q 5 -10 20 -20"
              fill="none"
              stroke={INK}
              strokeWidth={3}
              strokeLinecap="round"
            />
            <path
              d="M -30 -5 Q -15 -15 0 -5 Q 15 5 30 -5"
              fill="none"
              stroke={INK}
              strokeWidth={3}
              strokeLinecap="round"
            />

            {/* SE Face: 3 Piston barrels 18x28 with rod heads Ø 10 */}
            {[0, 1, 2].map((idx) => {
              const bx = 18 + idx * 22;
              const by = 22 + idx * 8;
              const bob = getPistonOffset(idx);
              return (
                <g key={`piston-${idx}`} transform={`translate(${bx}, ${by})`}>
                  {/* Barrel */}
                  <rect
                    x={-9}
                    y={0}
                    width={18}
                    height={28}
                    rx={4}
                    fill={SLATE.s300}
                    stroke={INK}
                    strokeWidth={2.5}
                  />
                  {/* Piston Rod & Head */}
                  <line
                    x1={0}
                    y1={0}
                    x2={0}
                    y2={-12 + bob}
                    stroke={INK}
                    strokeWidth={4}
                    strokeLinecap="round"
                  />
                  <circle
                    cx={0}
                    cy={-14 + bob}
                    r={5}
                    fill={SLATE.s50}
                    stroke={INK}
                    strokeWidth={2.5}
                  />
                </g>
              );
            })}

            {/* Gold APEX-TICKs ejecting 4 px above brain */}
            {apexTicksCount > 0 && (
              <g transform="translate(45, -75)">
                <path
                  d="M -9 4 L 0 -4 L 9 4"
                  fill="none"
                  stroke={GOLD}
                  strokeWidth={3.5}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </g>
            )}

            {/* Mint CHECK-RING at brain if enabled (S16) */}
            {brainCheckRing && (
              <g transform="translate(0, -20)">
                <circle
                  cx={0}
                  cy={0}
                  r={28}
                  fill={PAPER}
                  stroke={OK}
                  strokeWidth={5}
                />
                <polyline
                  points="-10,0 -3,8 12,-8"
                  fill="none"
                  stroke={OK}
                  strokeWidth={4.5}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </g>
            )}
          </g>

          {/* AIR-ROUTE Active Trace Line */}
          {airRouteProgress > 0 && (
            <polyline
              points={WAYPOINTS.slice(0, Math.ceil(airRouteProgress * WAYPOINTS.length))
                .map((p) => `${ox + p.x},${oy + p.y}`)
                .join(' ')}
              fill="none"
              stroke={AIR}
              strokeWidth={5}
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}

          {/* Traveling Token along AIR-ROUTE */}
          {tokenActive && (
            (() => {
              const pos = getWaypointPos(tokenProgress);
              const color =
                isTokenGoldAtBrain && tokenProgress > 0.9 ? GOLD : tokenColor;
              return (
                <circle
                  cx={ox + pos.x}
                  cy={oy + pos.y}
                  r={8}
                  fill={color}
                  stroke={INK}
                  strokeWidth={2}
                />
              );
            })()
          )}

          {/* Token Trio for S16 (Mint-tinted tokens hopping in metronome cadence) */}
          {tokenTrio && tokenTrio.active && (
            [0, 1, 2].map((i) => {
              const prog = (tokenTrio.cycleProgress + i * 0.3) % 1;
              const pos = getWaypointPos(prog);
              return (
                <circle
                  key={`trio-${i}`}
                  cx={ox + pos.x}
                  cy={oy + pos.y}
                  r={7}
                  fill={OK}
                  stroke={INK}
                  strokeWidth={2}
                />
              );
            })
          )}
        </g>
      )}

      {/* PINNA (Ear): EA = (400, 350) */}
      <g transform={`translate(${ox + 400}, ${oy + 350})`}>
        {/* Outer C-curl 140x90, s200 */}
        <path
          d="M -30 -60 C 25 -70, 70 -30, 60 20 C 50 60, 10 75, -20 60 C -10 40, -5 20, -10 -10 C -15 -35, -25 -50, -30 -60 Z"
          fill={SLATE.s200}
          stroke={INK}
          strokeWidth={4}
        />
        {/* Inner swirl 3 px */}
        <path
          d="M 25 -30 C 40 -15, 35 25, 10 35 C -5 40, -10 20, 5 10"
          fill="none"
          stroke={INK_SOFT}
          strokeWidth={3}
          strokeLinecap="round"
        />
        {/* Lobe Ø 34 */}
        <ellipse
          cx={-15}
          cy={55}
          rx={17}
          ry={14}
          fill={SLATE.s100}
          stroke={INK}
          strokeWidth={3}
        />
      </g>

      {/* Docked Headphones (HP-PHONE) over pinna if visible */}
      {showHeadphones && (
        <g
          transform={`translate(${ox + 400 - 60 * (1 - headphoneDockProgress)}, ${oy + 356 - 100 * (1 - headphoneDockProgress)})`}
          opacity={headphoneDockProgress}
        >
          {/* Headband arc INK 12 px */}
          <path
            d="M 0 0 C 0 -180, 200 -240, 320 -150"
            fill="none"
            stroke={INK}
            strokeWidth={12}
            strokeLinecap="round"
          />
          {/* Cup = iso cylinder Ø 110x52, fill #43424B */}
          <ellipse
            cx={0}
            cy={0}
            rx={55}
            ry={38}
            fill="#43424B"
            stroke={SLATE.s200}
            strokeWidth={4}
          />
          <ellipse cx={0} cy={0} rx={42} ry={28} fill={SLATE.s100} />
          {/* Port dot 10 px */}
          <circle cx={-12} cy={8} r={5} fill={INK} />
        </g>
      )}
    </g>
  );
};
