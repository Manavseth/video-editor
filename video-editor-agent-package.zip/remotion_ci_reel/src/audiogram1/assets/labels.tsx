import React from 'react';
import {
  PAPER,
  INK,
  INK_SOFT,
  AIR,
  GOLD,
  OK,
  METER,
} from '../tokens';

interface ChipProps {
  x: number;
  y: number;
  text: string;
  variant?: 'ink' | 'white' | 'tangerine' | 'gold' | 'mint';
  scale?: number;
  opacity?: number;
  fontSize?: number;
}

export const Chip: React.FC<ChipProps> = ({
  x,
  y,
  text,
  variant = 'ink',
  scale = 1,
  opacity = 1,
  fontSize = 32,
}) => {
  let bg = INK;
  let fg = PAPER;
  let stroke = INK;

  if (variant === 'white') {
    bg = '#FFFFFF';
    fg = INK;
    stroke = INK;
  } else if (variant === 'tangerine') {
    bg = AIR;
    fg = '#FFFFFF';
    stroke = AIR;
  } else if (variant === 'gold') {
    bg = GOLD;
    fg = '#FFFFFF';
    stroke = GOLD;
  } else if (variant === 'mint') {
    bg = OK;
    fg = '#FFFFFF';
    stroke = OK;
  }

  const approxWidth = text.length * (fontSize * 0.60) + 32;
  const height = fontSize + 20;

  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      opacity={opacity}
      style={{ transformOrigin: 'center' }}
    >
      <rect
        x={-approxWidth / 2}
        y={-height / 2}
        width={approxWidth}
        height={height}
        rx={10}
        fill={bg}
        stroke={stroke}
        strokeWidth={2.5}
      />
      <text
        x={0}
        y={fontSize * 0.35}
        textAnchor="middle"
        fill={fg}
        fontFamily='Archivo, "Segoe UI", sans-serif'
        fontSize={fontSize}
        fontWeight={600}
      >
        {text}
      </text>
    </g>
  );
};

interface TabCardProps {
  x: number;
  y: number;
  title: string;
  ruleColor?: string; // tangerine / gold / mint
  scale?: number;
  opacity?: number;
  fontSize?: number;
}

export const TabCard: React.FC<TabCardProps> = ({
  x,
  y,
  title,
  ruleColor = AIR,
  scale = 1,
  opacity = 1,
  fontSize = 64,
}) => {
  const approxWidth = title.length * (fontSize * 0.58) + 40;
  const height = fontSize + 36;

  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      opacity={opacity}
      style={{ transformOrigin: 'center' }}
    >
      <rect
        x={-approxWidth / 2}
        y={-height / 2}
        width={approxWidth}
        height={height}
        rx={16}
        fill="rgba(255, 255, 255, 0.72)"
        stroke={INK}
        strokeWidth={3}
      />
      <text
        x={0}
        y={fontSize * 0.25}
        textAnchor="middle"
        fill={INK}
        fontFamily='Fraunces, "Playfair Display", Georgia, serif'
        fontSize={fontSize}
        fontWeight={700}
      >
        {title}
      </text>
      {/* 6 px color rule underneath */}
      <line
        x1={-approxWidth / 2 + 16}
        y1={height / 2 - 10}
        x2={approxWidth / 2 - 16}
        y2={height / 2 - 10}
        stroke={ruleColor}
        strokeWidth={6}
        strokeLinecap="round"
      />
    </g>
  );
};

interface MehnatMeterProps {
  x?: number;
  y?: number;
  fillPercent: number; // 0..100
  needleOvershoot?: number; // px
  needleWobble?: number; // px
  showLabel?: boolean;
  scale?: number;
  opacity?: number;
}

export const MehnatMeter: React.FC<MehnatMeterProps> = ({
  x = METER.dialCx,
  y = METER.dialCy,
  fillPercent = 16,
  needleOvershoot = 0,
  needleWobble = 0,
  showLabel = true,
  scale = 1,
  opacity = 1,
}) => {
  const pillW = 34;
  const pillH = 96;
  const r = 17;

  // Fill height from bottom
  const clampedFill = Math.max(0, Math.min(100, fillPercent));
  const fillH = (clampedFill / 100) * (pillH - 10);
  const needleY = pillH / 2 - 5 - fillH + needleOvershoot + needleWobble;

  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      opacity={opacity}
      style={{ transformOrigin: 'center' }}
    >
      {/* Pill 34x96, radius 17, PAPER 72% fill, INK 3 px stroke */}
      <rect
        x={-pillW / 2}
        y={-pillH / 2}
        width={pillW}
        height={pillH}
        rx={r}
        fill={PAPER}
        fillOpacity={0.72}
        stroke={INK}
        strokeWidth={3}
      />

      {/* 5 Notch rows 20x2 px (INK_SOFT, every 16 px) */}
      {[-2, -1, 0, 1, 2].map((i) => (
        <line
          key={`notch-${i}`}
          x1={-10}
          y1={i * 16}
          x2={10}
          y2={i * 16}
          stroke={INK_SOFT}
          strokeWidth={2}
        />
      ))}

      {/* Fill = GOLD 85% rising from bottom */}
      <g clipPath="url(#meter-pill-clip)">
        <defs>
          <clipPath id="meter-pill-clip">
            <rect
              x={-pillW / 2 + 2}
              y={-pillH / 2 + 2}
              width={pillW - 4}
              height={pillH - 4}
              rx={r - 2}
            />
          </clipPath>
        </defs>
        <rect
          x={-pillW / 2 + 2}
          y={pillH / 2 - 2 - fillH}
          width={pillW - 4}
          height={fillH}
          fill={GOLD}
          fillOpacity={0.85}
        />
      </g>

      {/* 4 px INK needle horizontally at fill top */}
      <line
        x1={-pillW / 2 - 6}
        y1={needleY}
        x2={pillW / 2 + 6}
        y2={needleY}
        stroke={INK}
        strokeWidth={4}
        strokeLinecap="round"
      />

      {/* Label chip `MEHNAT METER` pinned below dial at y 584 (offset +72 from dialCy 512) */}
      {showLabel && (
        <g transform="translate(0, 72)">
          <Chip x={0} y={0} text="MEHNAT METER" variant="white" fontSize={26} />
        </g>
      )}
    </g>
  );
};

export interface TileSpec {
  type: 'solid' | 'dashed' | 'decoded';
  x: number;
  y: number;
  opacity?: number;
  scale?: number;
  bobY?: number;
}

export const QueueTiles: React.FC<{ tiles: TileSpec[] }> = ({ tiles }) => {
  return (
    <g>
      {tiles.map((t, idx) => {
        const sx = t.x;
        const sy = t.y + (t.bobY ?? 0);
        const sc = t.scale ?? 1;
        const op = t.opacity ?? 1;

        return (
          <g
            key={`tile-${idx}`}
            transform={`translate(${sx}, ${sy}) scale(${sc})`}
            opacity={op}
            style={{ transformOrigin: 'center' }}
          >
            {/* Tile 64x36, radius 8 */}
            {t.type === 'solid' && (
              <g>
                <rect
                  x={-32}
                  y={-18}
                  width={64}
                  height={36}
                  rx={8}
                  fill={PAPER}
                  stroke={INK}
                  strokeWidth={2.5}
                />
                {/* 2 gray tick lines (22/14 px) inside */}
                <line
                  x1={-18}
                  y1={-5}
                  x2={4}
                  y2={-5}
                  stroke={INK_SOFT}
                  strokeWidth={2}
                  strokeLinecap="round"
                />
                <line
                  x1={-18}
                  y1={5}
                  x2={-4}
                  y2={5}
                  stroke={INK_SOFT}
                  strokeWidth={2}
                  strokeLinecap="round"
                />
              </g>
            )}

            {t.type === 'dashed' && (
              <g>
                <rect
                  x={-32}
                  y={-18}
                  width={64}
                  height={36}
                  rx={8}
                  fill="none"
                  stroke={INK_SOFT}
                  strokeWidth={2.5}
                  strokeDasharray="6 5"
                />
                <text
                  x={0}
                  y={8}
                  textAnchor="middle"
                  fill={INK}
                  fillOpacity={0.7}
                  fontFamily='Fraunces, "Playfair Display", Georgia, serif'
                  fontSize={28}
                  fontWeight={700}
                >
                  ?
                </text>
              </g>
            )}

            {t.type === 'decoded' && (
              <g>
                <rect
                  x={-32}
                  y={-18}
                  width={64}
                  height={36}
                  rx={8}
                  fill={PAPER}
                  stroke={INK}
                  strokeWidth={2.5}
                />
                {/* Mint CHECK-RING Ø 24 */}
                <circle
                  cx={0}
                  cy={0}
                  r={12}
                  fill="none"
                  stroke={OK}
                  strokeWidth={2.5}
                />
                <polyline
                  points="-5,-1 -1,4 6,-4"
                  fill="none"
                  stroke={OK}
                  strokeWidth={2.5}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </g>
            )}
          </g>
        );
      })}
    </g>
  );
};

export const LoudRuler: React.FC<{
  x?: number;
  y?: number;
  ticksCascadeProgress?: number; // 0..1
  scale?: number;
  opacity?: number;
}> = ({
  x = 200,
  y = 480,
  ticksCascadeProgress = 0,
  scale = 1,
  opacity = 1,
}) => {
  return (
    <g
      transform={`translate(${x}, ${y}) scale(${scale})`}
      opacity={opacity}
      style={{ transformOrigin: 'top center' }}
    >
      {/* Vertical ruler strip 14x240 inside sheet left edge */}
      <rect
        x={-7}
        y={0}
        width={14}
        height={640}
        rx={4}
        fill={SLATE_S50}
        stroke={INK}
        strokeWidth={3}
      />

      {/* 5 Tick marks 22 px wide every 56 px */}
      {[0, 1, 2, 3, 4].map((i) => {
        const ty = i * 140;
        const isPulsed =
          ticksCascadeProgress > 0 &&
          Math.abs(ticksCascadeProgress * 4 - i) < 0.6;
        const tickLen = isPulsed ? 32 : 22;

        return (
          <g key={`tick-${i}`} transform={`translate(0, ${ty})`}>
            <line
              x1={-tickLen / 2}
              y1={0}
              x2={tickLen / 2}
              y2={0}
              stroke={isPulsed ? AIR : INK}
              strokeWidth={isPulsed ? 3.5 : 2}
            />
            {i === 0 && (
              <text
                x={-24}
                y={6}
                textAnchor="end"
                fill={INK}
                fontFamily='Archivo, "Segoe UI", sans-serif'
                fontSize={26}
                fontWeight={700}
              >
                0
              </text>
            )}
          </g>
        );
      })}

      {/* LOUD white chip pinned at its foot y 1148 (offset +668) */}
      <g transform="translate(0, 668)">
        <Chip x={0} y={0} text="LOUD" variant="white" fontSize={28} />
      </g>
    </g>
  );
};

const SLATE_S50 = '#F2F5F9';
