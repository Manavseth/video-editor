import React from 'react';
import {
  Composition,
  Sequence,
  Audio,
  staticFile,
} from 'remotion';

import { PAPER, GRID, W, H } from './tokens';
import { CaptionsLayer } from './CaptionsLayer';

import { S01ClinicOpen } from './scenes/S01ClinicOpen';
import { S02Handoff } from './scenes/S02Handoff';
import { S03SheetBorn } from './scenes/S03SheetBorn';
import { S04Symbols } from './scenes/S04Symbols';
import { S05LineForms } from './scenes/S05LineForms';
import { S06LaboringHead } from './scenes/S06LaboringHead';
import { S07AxisLesson } from './scenes/S07AxisLesson';
import { S08ThresholdsFall } from './scenes/S08ThresholdsFall';
import { S09DebtBand } from './scenes/S09DebtBand';
import { S10WhatItCosts } from './scenes/S10WhatItCosts';
import { S11SymbolLeap } from './scenes/S11SymbolLeap';
import { S12DecodeLabor } from './scenes/S12DecodeLabor';
import { S13BackToClinic } from './scenes/S13BackToClinic';
import { S14Quote } from './scenes/S14Quote';
import { S15FreshSheet } from './scenes/S15FreshSheet';
import { S16SmoothPath } from './scenes/S16SmoothPath';
import { S17GuessingBrain } from './scenes/S17GuessingBrain';
import { S18ClearStage } from './scenes/S18ClearStage';
import { S19TeaseFreeze } from './scenes/S19TeaseFreeze';

const SceneSvg: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <svg
    viewBox={`0 0 ${W} ${H}`}
    style={{
      position: 'absolute',
      top: 0,
      left: 0,
      width: W,
      height: H,
    }}
  >
    {children}
  </svg>
);

export const AudiogramPart1Master: React.FC = () => {
  return (
    <div
      style={{
        width: W,
        height: H,
        backgroundColor: PAPER,
        position: 'relative',
        overflow: 'hidden',
        fontFamily: 'Archivo, "Segoe UI", system-ui, sans-serif',
      }}
    >
      {/* Local font definitions */}
      <style>
        {`
          @font-face {
            font-family: 'Fraunces';
            src: url('${staticFile('fonts/Fraunces-700.woff2')}') format('woff2');
            font-weight: 700;
            font-style: normal;
          }
          @font-face {
            font-family: 'Fraunces';
            src: url('${staticFile('fonts/Fraunces-600.woff2')}') format('woff2');
            font-weight: 600;
            font-style: normal;
          }
          @font-face {
            font-family: 'Archivo';
            src: url('${staticFile('fonts/Archivo-500.woff2')}') format('woff2');
            font-weight: 500;
            font-style: normal;
          }
          @font-face {
            font-family: 'Archivo';
            src: url('${staticFile('fonts/Archivo-600.woff2')}') format('woff2');
            font-weight: 600;
            font-style: normal;
          }
          @font-face {
            font-family: 'Archivo';
            src: url('${staticFile('fonts/Archivo-700.woff2')}') format('woff2');
            font-weight: 700;
            font-style: normal;
          }
        `}
      </style>

      {/* 1. Master Audio Track bound at frame 0 */}
      <Audio src={staticFile('audio/part1.wav')} />

      {/* 2. Global Static Grid Background (48x48 GRID pattern) */}
      <svg
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: W,
          height: H,
          pointerEvents: 'none',
        }}
      >
        <defs>
          <pattern
            id="part1-grid-pattern"
            width={48}
            height={48}
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M 48 0 L 0 0 0 48"
              fill="none"
              stroke={GRID}
              strokeWidth={1.5}
              opacity={0.65}
            />
          </pattern>
        </defs>
        <rect
          width="100%"
          height="100%"
          fill="url(#part1-grid-pattern)"
        />
      </svg>

      {/* 3. All 19 Scene Sequences (Frame ranges start-inclusive, end-exclusive) */}
      {/* S01: 0-51 (51 f) */}
      <Sequence from={0} durationInFrames={51} name="S01ClinicOpen">
        <SceneSvg>
          <S01ClinicOpen />
        </SceneSvg>
      </Sequence>

      {/* S02: 51-114 (63 f) */}
      <Sequence from={51} durationInFrames={63} name="S02Handoff">
        <SceneSvg>
          <S02Handoff />
        </SceneSvg>
      </Sequence>

      {/* S03: 114-172 (58 f) */}
      <Sequence from={114} durationInFrames={58} name="S03SheetBorn">
        <SceneSvg>
          <S03SheetBorn />
        </SceneSvg>
      </Sequence>

      {/* S04: 172-276 (104 f) */}
      <Sequence from={172} durationInFrames={104} name="S04Symbols">
        <SceneSvg>
          <S04Symbols />
        </SceneSvg>
      </Sequence>

      {/* S05: 276-371 (95 f) */}
      <Sequence from={276} durationInFrames={95} name="S05LineForms">
        <SceneSvg>
          <S05LineForms />
        </SceneSvg>
      </Sequence>

      {/* S06: 371-449 (78 f) */}
      <Sequence from={371} durationInFrames={78} name="S06LaboringHead">
        <SceneSvg>
          <S06LaboringHead />
        </SceneSvg>
      </Sequence>

      {/* S07: 449-546 (97 f) */}
      <Sequence from={449} durationInFrames={97} name="S07AxisLesson">
        <SceneSvg>
          <S07AxisLesson />
        </SceneSvg>
      </Sequence>

      {/* S08: 546-636 (90 f) */}
      <Sequence from={546} durationInFrames={90} name="S08ThresholdsFall">
        <SceneSvg>
          <S08ThresholdsFall />
        </SceneSvg>
      </Sequence>

      {/* S09: 636-731 (95 f) */}
      <Sequence from={636} durationInFrames={95} name="S09DebtBand">
        <SceneSvg>
          <S09DebtBand />
        </SceneSvg>
      </Sequence>

      {/* S10: 731-798 (67 f) */}
      <Sequence from={731} durationInFrames={67} name="S10WhatItCosts">
        <SceneSvg>
          <S10WhatItCosts />
        </SceneSvg>
      </Sequence>

      {/* S11: 798-849 (51 f) */}
      <Sequence from={798} durationInFrames={51} name="S11SymbolLeap">
        <SceneSvg>
          <S11SymbolLeap />
        </SceneSvg>
      </Sequence>

      {/* S12: 849-921 (72 f) */}
      <Sequence from={849} durationInFrames={72} name="S12DecodeLabor">
        <SceneSvg>
          <S12DecodeLabor />
        </SceneSvg>
      </Sequence>

      {/* S13: 921-993 (72 f) */}
      <Sequence from={921} durationInFrames={72} name="S13BackToClinic">
        <SceneSvg>
          <S13BackToClinic />
        </SceneSvg>
      </Sequence>

      {/* S14: 993-1059 (66 f) */}
      <Sequence from={993} durationInFrames={66} name="S14Quote">
        <SceneSvg>
          <S14Quote />
        </SceneSvg>
      </Sequence>

      {/* S15: 1059-1116 (57 f) */}
      <Sequence from={1059} durationInFrames={57} name="S15FreshSheet">
        <SceneSvg>
          <S15FreshSheet />
        </SceneSvg>
      </Sequence>

      {/* S16: 1116-1190 (74 f) */}
      <Sequence from={1116} durationInFrames={74} name="S16SmoothPath">
        <SceneSvg>
          <S16SmoothPath />
        </SceneSvg>
      </Sequence>

      {/* S17: 1190-1293 (103 f) */}
      <Sequence from={1190} durationInFrames={103} name="S17GuessingBrain">
        <SceneSvg>
          <S17GuessingBrain />
        </SceneSvg>
      </Sequence>

      {/* S18: 1293-1335 (42 f) */}
      <Sequence from={1293} durationInFrames={42} name="S18ClearStage">
        <SceneSvg>
          <S18ClearStage />
        </SceneSvg>
      </Sequence>

      {/* S19: 1335-1440 (105 f) */}
      <Sequence from={1335} durationInFrames={105} name="S19TeaseFreeze">
        <SceneSvg>
          <S19TeaseFreeze />
        </SceneSvg>
      </Sequence>

      {/* 4. Global Captions Layer on top of everything */}
      <CaptionsLayer />
    </div>
  );
};

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="AudiogramPart1"
      component={AudiogramPart1Master}
      durationInFrames={1440}
      fps={30}
      width={1080}
      height={1920}
    />
  );
};
