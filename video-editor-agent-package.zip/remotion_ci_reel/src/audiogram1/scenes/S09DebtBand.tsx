import React from 'react';
import { useCurrentFrame } from 'remotion';
import { AudSheet, DebtBandSpec, SymbolSpec } from '../assets/sheet';
import { CURVES } from '../data';
import { easeDrive, easeSettle, easeSnap, clamp } from '../tokens';

export const S09DebtBand: React.FC = () => {
  const f = useCurrentFrame();

  const freqs = [250, 500, 1000, 2000, 4000, 8000] as const;

  // 0-20: Band grows at 1 kHz column (dy 380 down to dy 700 = 40 dB)
  const growProg = easeSettle(clamp(f / 20));

  // 24-38: Caliper bracket strokes on band left edge
  const caliperProg = f >= 24 ? easeDrive(clamp((f - 24) / 14)) : 0;

  // 40-58: Down-caret ticks
  const caretProg = f >= 40 ? easeSnap(clamp((f - 40) / 18)) : 0;

  // 58-95: Band breathes 3% width (12 f period)
  const widthScale = f >= 58 ? 1.0 + 0.03 * Math.sin(((f - 58) / 12) * Math.PI * 2) : 1.0;

  const debtBand: DebtBandSpec = {
    freq: 1000,
    topDb: 0,
    bottomDb: 40,
    growProgress: growProg,
    caliperProgress: caliperProg,
    caretTicksProgress: caretProg,
    widthScale,
  };

  const symbols: SymbolSpec[] = CURVES.P1_DROP.AIR.map((db, idx) => ({
    freq: freqs[idx],
    db,
    scale: 1.0,
    alpha: 1.0,
  }));

  return (
    <g>
      <AudSheet
        showHeader={true}
        showGrid={true}
        showLabels={true}
        axisChips={true}
        curveValues={CURVES.P1_DROP.AIR}
        curveProgress={1.0}
        symbols={symbols}
        debtBand={debtBand}
      />
    </g>
  );
};
