import React from 'react';
import { useCurrentFrame } from 'remotion';
import { HeadCut } from '../assets/head';
import { MehnatMeter, QueueTiles, TileSpec, Chip } from '../assets/labels';
import { easeDrive, easeSettle, easeStamp, clamp, METER, HEAD } from '../tokens';

export const S12DecodeLabor: React.FC = () => {
  const f = useCurrentFrame();

  // 0-16: PUSH-IN: world group 1.0 -> 1.8, BRAIN-CORE recentered at (540, 760)
  const zoomProg = easeDrive(clamp(f / 16));
  const worldScale = 1.0 + 0.8 * zoomProg;

  // Camera shift to recenter BRAIN-CORE
  // BRAIN-CORE was at HEAD.x0 + 330 = 550, HEAD.y0 + 500 = 940
  // Target center = (540, 760)
  const shiftX = zoomProg * -180;
  const shiftY = zoomProg * -280;

  // 16-34: QUEUE-TILES enter toward brain face (approx x 460, y 520 in head coords)
  // 2 solid tiles + 1 dashed-? tile, staggered 6 f
  const t1Prog = easeDrive(clamp((f - 16) / 8));
  const t2Prog = easeDrive(clamp((f - 22) / 8));
  const t3Prog = easeDrive(clamp((f - 28) / 8));

  // Meter 70 -> 74% (8 f E-SETTLE) at 16-34
  let meterFill = 70;
  if (f >= 16) {
    meterFill = 70 + easeSettle(clamp((f - 16) / 8)) * 4;
  }

  // 34-46: Labor apex, 2 gold APEX-TICKS
  const apexTicksCount = (f >= 36 && f <= 38) || (f >= 42 && f <= 44) ? 1 : 0;

  // 46-58: DECODE: ? tile fills, pops solid with mint CHECK-RING (E-STAMP)
  const isDecoded = f >= 50;
  const decodeChipScale = f >= 52 ? easeStamp(clamp((f - 52) / 8)) : 0;

  // 58-72: Hold 2 px bob
  const bobY = f >= 58 ? Math.sin(((f - 58) / 8) * Math.PI * 2) * 2 : 0;
  const hoverY = f >= 34 && f < 46 ? -2 : 0;

  // Base tile positions near brain SE face: x ~ 650, y ~ 920 in world coords
  const tiles: TileSpec[] = [
    {
      type: 'solid',
      x: 760 - (1 - t1Prog) * 120,
      y: 920,
      opacity: clamp((f - 16) / 4),
      bobY,
    },
    {
      type: 'solid',
      x: 684 - (1 - t2Prog) * 120,
      y: 920,
      opacity: clamp((f - 22) / 4),
      bobY,
    },
    {
      type: isDecoded ? 'decoded' : 'dashed',
      x: 608 - (1 - t3Prog) * 120,
      y: 920 + hoverY,
      opacity: clamp((f - 28) / 4),
      bobY,
    },
  ];

  return (
    <g>
      {/* Zooming World Group */}
      <g
        transform={`translate(${shiftX}, ${shiftY}) scale(${worldScale})`}
        style={{ transformOrigin: '540px 940px' }}
      >
        <HeadCut
          x={HEAD.x0}
          y={HEAD.y0}
          cutawayWipeProgress={1.0}
          pistonCadence="labor"
          pistonFrame={f}
          apexTicksCount={apexTicksCount}
        />

        {/* Queue Tiles entering brain */}
        {f >= 16 && <QueueTiles tiles={tiles} />}

        {/* White chip DECODE stamped above tile row */}
        {f >= 52 && (
          <Chip
            x={608}
            y={865}
            text="DECODE"
            variant="white"
            scale={decodeChipScale}
            fontSize={28}
          />
        )}
      </g>

      {/* MEHNAT-METER stays fixed / unscaled on UI overlay */}
      <MehnatMeter
        x={METER.dialCx}
        y={METER.dialCy}
        fillPercent={meterFill}
        showLabel={true}
      />
      <Chip
        x={METER.dialCx}
        y={METER.dialCy + 130}
        text="GADHA-MAZDOORI"
        variant="gold"
        fontSize={26}
      />
    </g>
  );
};
