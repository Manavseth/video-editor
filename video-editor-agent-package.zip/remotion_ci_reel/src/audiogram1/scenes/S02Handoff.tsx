import React from 'react';
import { useCurrentFrame } from 'remotion';
import { AudiometerCube, ResponsePaddle, PrintoutCard, HeadphoneDevice } from '../assets/devices';
import { PatientChair, PatientFigure, AudiologistFigure } from '../assets/misc';
import { Chip } from '../assets/labels';
import { easeDrive, easeSettle, clamp } from '../tokens';

export const S02Handoff: React.FC = () => {
  const f = useCurrentFrame();

  // 0-12: Audiologist leans 6° toward console, raises pointer to console slot rim
  const leanProg = clamp(f / 12);
  const audiLean = f < 24 ? easeDrive(leanProg) * 6 : Math.max(0, 6 - (f - 24) * 0.5);
  const pointerActive = f >= 8 && f <= 28;

  // 8-24: PRINTOUT-CARD feeds out along slot axis (+42, -6) px, E-DRIVE 12 f
  // 24-40: Card floats to patient side (+380, -120) px on an arc, tilts -8°
  let cardX = 370;
  let cardY = 1010;
  let cardTilt = 0;
  let cardVisible = f >= 8;

  if (f >= 8 && f < 24) {
    const feedProg = easeDrive(clamp((f - 8) / 12));
    cardX = 370 + feedProg * 42;
    cardY = 1010 - feedProg * 6;
  } else if (f >= 24) {
    const floatProg = easeDrive(clamp((f - 24) / 16));
    // arc with midpoint +40 px
    const arcY = Math.sin(floatProg * Math.PI) * 40;
    cardX = 412 + floatProg * 268;
    cardY = 1004 - floatProg * 120 - arcY;
    cardTilt = floatProg * -8;
  }

  // 46-63 Hold: card bobs 2 px per 10 f
  if (f >= 46) {
    cardY += Math.sin(((f - 46) / 10) * Math.PI * 2) * 2;
  }

  // 38-46: Patient lifts right nub to receive card
  const patientReceiving = f >= 38;
  const patientLean = f >= 46 ? 4 + Math.min(4, (f - 46) * 1.3) : 4;

  return (
    <g>
      {/* PART 1 Chip stays in corner */}
      <Chip x={120} y={140} text="PART 1" variant="ink" />

      {/* Audiometer Console */}
      <AudiometerCube x={300} y={950} ledActive={true} />

      {/* Audiologist Figure */}
      <AudiologistFigure
        x={280}
        y={830}
        leanAngle={audiLean}
        pointerTarget={pointerActive ? { x: 370, y: 1010 } : null}
      />

      {/* Patient Chair */}
      <PatientChair x={720} y={1080} />

      {/* Response Paddle on armrest */}
      <ResponsePaddle x={764} y={1002} />

      {/* Patient Figure */}
      <PatientFigure
        x={720}
        y={920}
        torsoLean={patientLean}
        rightArmPose={patientReceiving ? 'receive-card' : 'on-paddle'}
      />

      {/* Headphones on patient head */}
      <HeadphoneDevice x={720} y={920} />

      {/* Printout Card */}
      {cardVisible && (
        <PrintoutCard
          x={cardX}
          y={cardY}
          scale={0.7}
          rotation={cardTilt}
          showMiniDots={true}
        />
      )}
    </g>
  );
};
