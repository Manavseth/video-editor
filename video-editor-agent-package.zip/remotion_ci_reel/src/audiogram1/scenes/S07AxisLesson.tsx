import React from 'react';
import { useCurrentFrame } from 'remotion';
import { AudSheet, DepthBrace, SymbolSpec } from '../assets/sheet';
import { TabCard, Chip } from '../assets/labels';
import { CURVES } from '../data';
import { easeDrive, easeSnap, easeStamp, clamp } from '../tokens';

export const S07AxisLesson: React.FC = () => {
  const f = useCurrentFrame();

  const freqs = [250, 500, 1000, 2000, 4000, 8000] as const;

  // 8-18: PITCH -> and dot runs along x-axis
  const dotProgress = f >= 8 && f <= 18 ? easeDrive(clamp((f - 8) / 10)) : 0;
  const showAxisChips = f >= 8;

  // 20-30: dB column labels light top->bottom
  const dbLightProgress = f >= 20 ? clamp((f - 20) / 10) : 0;

  // 34-46: 0 dB TAB-CARD stamps at (820, 404); UPAR white chip pops beside it 6 f later
  const card0dBScale = f >= 34 ? easeStamp(clamp((f - 34) / 8)) : 0;
  const uparChipScale = f >= 40 ? easeStamp(clamp((f - 40) / 8)) : 0;

  // 48-60: LOUD white chip stamps near dy(95) = 1140; NEECHE white chip pops beneath 6 f later
  const loudChipScale = f >= 48 ? easeStamp(clamp((f - 48) / 8)) : 0;
  const neecheChipScale = f >= 54 ? easeStamp(clamp((f - 54) / 8)) : 0;

  // 62-86: Three ARROW-DOWNs cascade at x 326, 484, 642 (6 f apart)
  const arrows = [
    { x: 326, y: 700, progress: f >= 62 ? easeSnap(clamp((f - 62) / 8)) : 0 },
    { x: 484, y: 700, progress: f >= 68 ? easeSnap(clamp((f - 68) / 8)) : 0 },
    { x: 642, y: 700, progress: f >= 74 ? easeSnap(clamp((f - 74) / 8)) : 0 },
  ];

  // 86-97: Re-light: line + symbols 100%, braces to 60%
  const braceAlpha = f >= 86 ? 0.6 : 0.4;

  const symbols: SymbolSpec[] = CURVES.SCATTER.AIR.map((db, idx) => ({
    freq: freqs[idx],
    db,
    scale: 1.0,
    alpha: 1.0,
  }));

  const braces: DepthBrace[] = [
    { freq: 2000, db: 35, progress: 1.0, alpha: braceAlpha },
    { freq: 4000, db: 45, progress: 1.0, alpha: braceAlpha },
  ];

  return (
    <g>
      <AudSheet
        showHeader={true}
        showGrid={true}
        showLabels={true}
        axisChips={showAxisChips}
        dotAxisRunProgress={dotProgress}
        dbLabelsHighlightProgress={dbLightProgress}
        curveValues={CURVES.SCATTER.AIR}
        curveProgress={1.0}
        symbols={symbols}
        depthBraces={braces}
        arrowsDown={arrows}
      />

      {/* 0 dB TAB-CARD at (680, 404) */}
      {f >= 34 && (
        <TabCard
          x={680}
          y={404}
          title="0 dB"
          ruleColor="#DF7A2B"
          scale={card0dBScale}
          fontSize={52}
        />
      )}

      {/* UPAR white chip beside it */}
      {f >= 40 && (
        <Chip
          x={800}
          y={404}
          text="UPAR"
          variant="white"
          scale={uparChipScale}
          fontSize={28}
        />
      )}

      {/* LOUD white chip near dy(95) = 1140 */}
      {f >= 48 && (
        <Chip
          x={760}
          y={1140}
          text="LOUD"
          variant="white"
          scale={loudChipScale}
          fontSize={30}
        />
      )}

      {/* NEECHE white chip beneath */}
      {f >= 54 && (
        <Chip
          x={760}
          y={1195}
          text="NEECHE"
          variant="white"
          scale={neecheChipScale}
          fontSize={28}
        />
      )}
    </g>
  );
};
