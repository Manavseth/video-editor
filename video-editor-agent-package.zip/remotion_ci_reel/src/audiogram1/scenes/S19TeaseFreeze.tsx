import React from 'react';
import { useCurrentFrame } from 'remotion';
import { AudSheet } from '../assets/sheet';
import { LoudRuler, Chip } from '../assets/labels';
import { easeDrive, easeStamp, clamp, INK } from '../tokens';

export const S19TeaseFreeze: React.FC = () => {
  const f = useCurrentFrame();

  // 0-18: LOUD-RULER slides in along sheet's inner-left edge (x 200, rising bottom->top)
  const rulerProg = easeDrive(clamp(f / 14));
  const rulerSlideY = (1 - rulerProg) * 80;
  const rulerAlpha = clamp(f / 8);

  // 20-36: Serif ? (Fraunces 140 px, 80% alpha) reveals at (620, 760) mask-wipe left->right 14 f
  const qProg = easeDrive(clamp((f - 20) / 14));
  const qClip = `inset(0px ${Math.max(0, (1 - qProg) * 100)}% 0px 0px)`;

  // 36-52: Ruler ticks pulse once top->bottom cascade
  const ticksProg = f >= 36 ? clamp((f - 36) / 16) : 0;

  // 56-74: PART 2 INK chip stamps at (880, 1440) E-STAMP
  const part2Prog = clamp((f - 56) / 12);
  const part2Scale = f >= 56 ? easeStamp(part2Prog) : 0;

  // 74-105: FREEZE tableau (loop-friendly): ? drifts 2 px per 10 f, ruler breathes 2%
  const qDriftY = f >= 74 ? Math.sin(((f - 74) / 10) * Math.PI * 2) * 2 : 0;
  const rulerBreathe = f >= 74 ? 1.0 + 0.02 * Math.sin(((f - 74) / 10) * Math.PI * 2) : 1.0;

  return (
    <g>
      {/* AUD-SHEET Background (Empty plot) */}
      <AudSheet
        showHeader={true}
        showGrid={true}
        showLabels={true}
        curveValues={[]}
        symbols={[]}
      />

      {/* AGLI BAAR chip persisting from S18 */}
      <Chip
        x={540}
        y={240}
        text="AGLI BAAR"
        variant="ink"
        fontSize={36}
      />

      {/* LOUD-RULER along sheet inner-left edge at x 200, y 480 */}
      <g
        transform={`translate(0, ${rulerSlideY}) scale(1, ${rulerBreathe})`}
        opacity={rulerAlpha}
        style={{ transformOrigin: '200px 480px' }}
      >
        <LoudRuler
          x={200}
          y={480}
          ticksCascadeProgress={ticksProg}
        />
      </g>

      {/* Serif `?` (Fraunces 140 px, 80% alpha) revealed at (620, 760) */}
      {f >= 20 && (
        <g
          transform={`translate(620, ${760 + qDriftY})`}
          style={{ clipPath: qClip }}
        >
          <text
            x={0}
            y={0}
            textAnchor="middle"
            fill={INK}
            fillOpacity={0.8}
            fontFamily='Fraunces, "Playfair Display", Georgia, serif'
            fontSize={140}
            fontWeight={700}
          >
            ?
          </text>
        </g>
      )}

      {/* PART 2 INK chip at (880, 1440) */}
      {f >= 56 && (
        <Chip
          x={880}
          y={1440}
          text="PART 2"
          variant="ink"
          scale={part2Scale}
          fontSize={34}
        />
      )}
    </g>
  );
};
