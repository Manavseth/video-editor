import React from 'react';
import { useCurrentFrame } from 'remotion';
import { AudSheet, DepthBrace, SymbolSpec } from '../assets/sheet';
import { CURVES } from '../data';
import { easeDrive, clamp, fx, dy, AIR, OCTAVES } from '../tokens';

export const S05LineForms: React.FC = () => {
  const f = useCurrentFrame();

  const freqs = [250, 500, 1000, 2000, 4000, 8000] as const;

  // 0-30: LINE-AIR traces L->R through the 6 anchors (E-DRIVE, 5 f per segment)
  const lineProgress = easeDrive(clamp(f / 30));

  // 34-48: 4 kHz symbol pops scale 1.12 (4 f) and settles; its brace lifts to 100%
  const pop4kProg = clamp((f - 34) / 4);
  const scale4k = f >= 34 && f <= 48 ? 1.0 + 0.12 * Math.sin(pop4kProg * Math.PI) : 1.0;
  const brace4kAlpha = f >= 34 ? 1.0 : 0.4;

  // 64-88: Hold: line breathes 2 px (8 f period); 2 kHz ring micro-pulse 6%
  const breatheY = f >= 64 && f <= 88 ? Math.sin(((f - 64) / 8) * Math.PI * 2) * 2 : 0;
  const pulse2k = f >= 64 && f <= 88 ? 1.0 + 0.06 * Math.sin(((f - 64) / 8) * Math.PI * 2) : 1.0;

  // 88-95: MIRROR pre-roll: 4 kHz anchor pulses 8% once
  const mirrorPreRoll = f >= 88 ? 1.0 + 0.08 * Math.sin(clamp((f - 88) / 7) * Math.PI) : scale4k;

  const symbols: SymbolSpec[] = CURVES.SCATTER.AIR.map((db, idx) => {
    let scale = 1.0;
    if (idx === 3) scale = pulse2k;
    if (idx === 4) scale = mirrorPreRoll;

    return {
      freq: freqs[idx],
      db,
      scale,
      alpha: 1.0,
    };
  });

  const braces: DepthBrace[] = [
    { freq: 2000, db: 35, progress: 1.0, alpha: 0.4 },
    { freq: 4000, db: 45, progress: 1.0, alpha: brace4kAlpha },
  ];

  // 50-64: One 3 px tangerine token leaves 250 Hz anchor, rolls along line's upper edge
  let tokenPoint: { x: number; y: number } | null = null;
  if (f >= 50 && f <= 64) {
    const tokenProg = easeDrive(clamp((f - 50) / 14));
    const totalSegs = freqs.length - 1;
    const d = tokenProg * totalSegs;
    const segIdx = Math.min(Math.floor(d), totalSegs - 1);
    const rem = d - segIdx;
    const p1 = { x: fx(freqs[segIdx]), y: dy(CURVES.SCATTER.AIR[segIdx]) };
    const p2 = { x: fx(freqs[segIdx + 1]), y: dy(CURVES.SCATTER.AIR[segIdx + 1]) };
    tokenPoint = {
      x: p1.x + (p2.x - p1.x) * rem,
      y: p1.y + (p2.y - p1.y) * rem - 6, // upper edge offset
    };
  }

  return (
    <g>
      <AudSheet
        showHeader={true}
        showGrid={true}
        showLabels={true}
        breatheY={breatheY}
        curveValues={CURVES.SCATTER.AIR}
        curveProgress={lineProgress}
        showTipDot={f < 30}
        symbols={symbols}
        depthBraces={braces}
      />
      {tokenPoint && (
        <circle cx={tokenPoint.x} cy={tokenPoint.y} r={4} fill={AIR} />
      )}
    </g>
  );
};
