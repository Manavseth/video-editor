import React from 'react';
import { useCurrentFrame } from 'remotion';
import { AudSheet, DepthBrace, SymbolSpec } from '../assets/sheet';
import { CURVES } from '../data';
import { easeDrive, easeStamp, clamp, fx, dy, INK } from '../tokens';

export const S04Symbols: React.FC = () => {
  const f = useCurrentFrame();

  const freqs = [250, 500, 1000, 2000, 4000, 8000] as const;
  const popStartFrames = [6, 16, 26, 36, 46, 56];

  // 6-62: Six symbols pop at SCATTER anchors
  const symbols: SymbolSpec[] = CURVES.SCATTER.AIR.map((db, idx) => {
    const pStart = popStartFrames[idx];
    const hasPopped = f >= pStart;
    const popProg = clamp((f - pStart) / 6);
    const scale = hasPopped ? easeStamp(popProg) : 0.9;
    let alpha = hasPopped ? 1.0 : 0.45;

    // 78-96: Hold: all six symbols bob 2 px (6 f period, staggered 3 f)
    let bobY = 0;
    if (f >= 78 && f <= 96) {
      bobY = Math.sin(((f - 78 + idx * 3) / 6) * Math.PI * 2) * 2;
    }

    // 96-104: Focus gates: 250/500/1k symbols dim to 70%; 2 kHz & 4 kHz stay 100%
    if (f >= 96 && idx < 3) {
      alpha = 0.7;
    }

    return {
      freq: freqs[idx],
      db,
      scale,
      alpha,
      bobY,
    };
  });

  // 62-78: Depth braces for 2 kHz and 4 kHz
  const braces: DepthBrace[] = [];
  if (f >= 62) {
    const b1Prog = easeDrive(clamp((f - 62) / 10));
    braces.push({
      freq: 2000,
      db: 35,
      progress: b1Prog,
      alpha: 0.4,
    });
  }
  if (f >= 68) {
    const b2Prog = easeDrive(clamp((f - 68) / 10));
    braces.push({
      freq: 4000,
      db: 45,
      progress: b2Prog,
      alpha: 0.4,
    });
  }

  // f102 pre-roll tip dot at 250 Hz anchor's left
  const showPreRollDot = f >= 102;
  const tipX = fx(250) - 10;
  const tipY = dy(CURVES.SCATTER.AIR[0]);

  return (
    <g>
      <AudSheet
        showHeader={true}
        showGrid={true}
        showLabels={true}
        symbols={symbols}
        depthBraces={braces}
      />
      {showPreRollDot && (
        <circle cx={tipX} cy={tipY} r={6} fill={INK} opacity={0.6} />
      )}
    </g>
  );
};
