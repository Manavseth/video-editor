import React from 'react';
import { useCurrentFrame } from 'remotion';
import { AudSheet, SymbolSpec } from '../assets/sheet';
import { HeadCut } from '../assets/head';
import { MehnatMeter, QueueTiles, TileSpec } from '../assets/labels';
import { BrainChip } from '../assets/misc';
import { CURVES } from '../data';
import { easeDrive, easeSettle, clamp, HEAD, METER } from '../tokens';

export const S16SmoothPath: React.FC = () => {
  const f = useCurrentFrame();

  const freqs = [250, 500, 1000, 2000, 4000, 8000] as const;

  // 0-18: NEUTRAL.AIR draws L->R at dy ~ 500 (tip-dot, 18 f E-DRIVE)
  const drawProg = easeDrive(clamp(f / 18));

  // 3 symbols pop at 500 Hz / 1k / 4k (4 f stagger)
  const symbols: SymbolSpec[] = [
    { freq: 500, db: 15, alpha: f >= 6 ? 1 : 0 },
    { freq: 1000, db: 15, alpha: f >= 10 ? 1 : 0 },
    { freq: 4000, db: 15, alpha: f >= 14 ? 1 : 0 },
  ];

  // 18-28: Head world enters as a clear ghost (60%, scale 0.62) right-of-center
  const ghostProg = clamp((f - 18) / 10);
  const ghostAlpha = easeSettle(ghostProg) * 0.6;
  const ghostX = HEAD.x0 + 120;
  const ghostY = HEAD.y0 - 20;

  // 28-54: Token trio hopping canal -> cochlea -> brain in metronome cadence
  const trioActive = f >= 28;
  const trioCycle = trioActive ? ((f - 28) % 16) / 16 : 0;

  // 54-66: Mint CHECK-RING stamps at brain (E-STAMP); queue shows 3 solid tiles
  const checkRingBrain = f >= 54;

  // 66-74: Hold ghost breathing 2 px
  const breatheY = f >= 66 ? Math.sin(((f - 66) / 8) * Math.PI * 2) * 2 : 0;

  const queueTiles: TileSpec[] = f >= 54 ? [
    { type: 'solid', x: 620, y: 780 },
    { type: 'solid', x: 696, y: 780 },
    { type: 'solid', x: 772, y: 780 },
  ] : [];

  return (
    <g>
      {/* AUD-SHEET Layer with NEUTRAL line */}
      <AudSheet
        showHeader={true}
        showGrid={true}
        showLabels={true}
        curveValues={CURVES.NEUTRAL.AIR}
        curveProgress={drawProg}
        showTipDot={f < 18}
        symbols={symbols}
      />

      <BrainChip x={240} y={470} />

      {/* Ghost Head World Layer */}
      {f >= 18 && (
        <g opacity={ghostAlpha} transform={`translate(0, ${breatheY})`}>
          <HeadCut
            x={ghostX}
            y={ghostY}
            scale={0.62}
            cutawayWipeProgress={1.0}
            pistonCadence="idle"
            pistonFrame={f}
            tokenTrio={trioActive ? { active: true, cycleProgress: trioCycle } : null}
            brainCheckRing={checkRingBrain}
          />

          {/* Queue Tiles inside ghost head view */}
          {f >= 54 && <QueueTiles tiles={queueTiles} />}

          {/* Small MEHNAT-METER inside ghost at 16% idle */}
          <MehnatMeter
            x={ghostX + 380}
            y={ghostY + 80}
            scale={0.65}
            fillPercent={16}
            showLabel={false}
          />
        </g>
      )}
    </g>
  );
};
