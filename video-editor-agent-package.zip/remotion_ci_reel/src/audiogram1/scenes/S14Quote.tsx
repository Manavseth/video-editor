import React from 'react';
import { useCurrentFrame } from 'remotion';
import { QuoteCard } from '../assets/misc';
import { AudiometerCube, ResponsePaddle, HeadphoneDevice } from '../assets/devices';
import { PatientChair, PatientFigure, AudiologistFigure } from '../assets/misc';
import { easeStamp, easeDrive, clamp } from '../tokens';

export const S14Quote: React.FC = () => {
  const f = useCurrentFrame();

  // 0-8: QUOTE-CARD drops center: E-STAMP 1.12 -> 1.00 with 2 f drop-shake
  const dropProg = clamp(f / 8);
  const cardScale = easeStamp(dropProg);
  const dropShake = f >= 8 && f <= 10 ? (f % 2 === 0 ? 3 : -3) : 0;

  // 8-26: Text resolves: SUN tick draw-on, SAMAJH tick draw-on 6 f later
  const showSunTick = f >= 8;
  const showSamajhTick = f >= 14;

  // 26-40: Semantic pulses 12 f apart: SUN tick once, SAMAJH tick once
  const sunPulse = f >= 26 && f <= 32;
  const samajhPulse = f >= 38 && f <= 44;

  // 40-58: HEAD-GLYPH slides onto bottom-left corner (8 f)
  const showHeadGlyph = f >= 40;

  // 58-66: Hold: card drifts 2 px (8 f period)
  const driftY = f >= 58 ? Math.sin(((f - 58) / 8) * Math.PI * 2) * 2 : 0;

  return (
    <g>
      {/* Clinic ghost persisting at 25% behind card */}
      <g opacity={0.25}>
        <AudiometerCube x={300} y={950} />
        <AudiologistFigure x={280} y={830} />
        <PatientChair x={720} y={1080} />
        <ResponsePaddle x={764} y={1002} />
        <PatientFigure x={720} y={920} />
        <HeadphoneDevice x={720} y={920} />
      </g>

      {/* Primary QUOTE-CARD at (540, 810) */}
      <QuoteCard
        x={540}
        y={810 + dropShake + driftY}
        scale={cardScale}
        showSunTick={showSunTick}
        showSamajhTick={showSamajhTick}
        sunTickPulse={sunPulse}
        samajhTickPulse={samajhPulse}
        showHeadGlyph={showHeadGlyph}
      />
    </g>
  );
};
