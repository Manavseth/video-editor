import React from 'react';
import { useCurrentFrame } from 'remotion';
import { AudiometerCube, ResponsePaddle, HeadphoneDevice } from '../assets/devices';
import { PatientChair, PatientFigure, AudiologistFigure, SpeechBubble } from '../assets/misc';
import { HeadCut } from '../assets/head';
import { easeDrive, easeSettle, clamp, HEAD } from '../tokens';

export const S13BackToClinic: React.FC = () => {
  const f = useCurrentFrame();

  // 0-14: PULL-BACK zoom 1.8 -> 1.0
  const pullProg = easeDrive(clamp(f / 14));
  const zoomScale = 1.8 - 0.8 * pullProg;

  // 10-24: Head world recedes to a 0.22-scale ghost drifting top-right (at 850, 480)
  const ghostProg = clamp((f - 10) / 14);
  const ghostScale = zoomScale * (1 - ghostProg) + 0.22 * ghostProg;
  const ghostAlpha = Math.max(0.25, 1 - ghostProg * 0.7);
  const ghostX = HEAD.x0 + ghostProg * 400;
  const ghostY = HEAD.y0 - ghostProg * 180;

  // 6-22: Clinic re-stands as ONE composed set (translate up 24 px + fade-in 12 f)
  const clinicProg = clamp((f - 6) / 14);
  const clinicFade = easeSettle(clinicProg);
  const clinicSlideY = (1 - easeSettle(clinicProg)) * 24;

  // 22-36: Console LED pulses x2; patient right nub presses paddle once (PADDLE-PRESS at f28-30)
  const isPaddlePressed = f >= 28 && f <= 30;

  // 36-58: Speech bubble expands from mouth point (620, 860) E-SETTLE 10 f
  const bubbleProg = clamp((f - 36) / 10);
  const bubbleScale = easeSettle(bubbleProg);
  // 58-72: bubble breathes 4%
  const bubbleBreathe = f >= 58 ? 1.0 + 0.04 * Math.sin(((f - 58) / 10) * Math.PI * 2) : 1.0;

  // Audiologist turns head 8° toward patient starting f36
  const audiTurnProg = clamp((f - 36) / 12);
  const audiLean = easeSettle(audiTurnProg) * 8;

  return (
    <g>
      {/* Receding Ghost Head World */}
      <g opacity={ghostAlpha}>
        <HeadCut
          x={ghostX}
          y={ghostY}
          scale={ghostScale}
          cutawayWipeProgress={1.0}
          pistonCadence="idle"
          pistonFrame={f}
        />
      </g>

      {/* Clinic Set Assembled */}
      {clinicFade > 0 && (
        <g opacity={clinicFade} transform={`translate(0, ${clinicSlideY})`}>
          <AudiometerCube x={300} y={950} ledActive={true} />
          <AudiologistFigure x={280} y={830} leanAngle={audiLean} />
          <PatientChair x={720} y={1080} />
          <ResponsePaddle x={764} y={1002} isPressed={isPaddlePressed} />
          <PatientFigure x={720} y={920} rightArmPose="on-paddle" />
          <HeadphoneDevice x={720} y={920} />

          {/* Speech Bubble expanding from patient mouth */}
          {f >= 36 && (
            <SpeechBubble
              x={620}
              y={860}
              scale={bubbleScale * bubbleBreathe}
            />
          )}
        </g>
      )}
    </g>
  );
};
