import React from 'react';
import { useCurrentFrame } from 'remotion';
import { HeadCut } from '../assets/head';
import { MehnatMeter, Chip } from '../assets/labels';
import { easeSettle, easeStamp, clamp, METER, HEAD } from '../tokens';

export const S06LaboringHead: React.FC = () => {
  const f = useCurrentFrame();

  // 0-12: CUTAWAY wipes open ear-side->center; meter rail slides down from -160 px
  const openProg = easeSettle(clamp(f / 12));
  const meterSlideY = (1 - openProg) * -160;

  // 26-40: BRAIN-CORE rises into position (translate y +40->0, 4 px overshoot)
  let brainYOffset = 0;
  if (f < 26) {
    brainYOffset = 40;
  } else if (f >= 26 && f <= 40) {
    const riseProg = easeSettle(clamp((f - 26) / 12));
    brainYOffset = (1 - riseProg) * 40;
  }

  // MIRROR #1: meter fill 0 -> 62% (14 f E-SETTLE) at 26-40
  let meterFill = 0;
  let needleOvershoot = 0;
  if (f >= 26 && f <= 40) {
    const fillProg = easeSettle(clamp((f - 26) / 14));
    meterFill = fillProg * 62;
    needleOvershoot = Math.sin(clamp((f - 26) / 14) * Math.PI) * 4;
  } else if (f > 40) {
    meterFill = 62;
  }

  // 40-56: GADHA-MAZDOORI gold chip stamps under meter label; pistons shift to labor 6 f/cycle
  const showGadhaChip = f >= 40;
  const chipScale = f >= 40 ? easeStamp(clamp((f - 40) / 10)) : 0;
  const pistonCadence = f >= 40 ? 'labor' : f >= 26 ? 'idle' : 'off';

  // 2 Gold APEX-TICKS during 40-56
  const apexTicksCount = (f >= 46 && f <= 48) || (f >= 54 && f <= 56) ? 1 : 0;

  // 56-78: needle micro-wobble 4 px once (12 f)
  let needleWobble = 0;
  if (f >= 56 && f <= 68) {
    needleWobble = Math.sin(((f - 56) / 12) * Math.PI * 2) * 4;
  }

  // Tangerine token rides AIR-ROUTE to just inside canal mouth (progress ~0.15)
  const tokenActive = f >= 56;
  const tokenProgress = clamp((f - 56) / 16) * 0.15;

  return (
    <g>
      {/* Isometric Head Cut World */}
      <HeadCut
        x={HEAD.x0}
        y={HEAD.y0}
        cutawayWipeProgress={openProg}
        pistonCadence={pistonCadence}
        pistonFrame={f}
        brainYOffset={brainYOffset}
        apexTicksCount={apexTicksCount}
        tokenActive={tokenActive}
        tokenProgress={tokenProgress}
      />

      {/* MEHNAT-METER on right column */}
      <g transform={`translate(0, ${meterSlideY})`}>
        <MehnatMeter
          x={METER.dialCx}
          y={METER.dialCy}
          fillPercent={meterFill}
          needleOvershoot={needleOvershoot}
          needleWobble={needleWobble}
          showLabel={true}
        />

        {/* GADHA-MAZDOORI Gold Chip stamped under meter */}
        {showGadhaChip && (
          <Chip
            x={METER.dialCx}
            y={METER.dialCy + 130}
            text="GADHA-MAZDOORI"
            variant="gold"
            scale={chipScale}
            fontSize={26}
          />
        )}
      </g>
    </g>
  );
};
