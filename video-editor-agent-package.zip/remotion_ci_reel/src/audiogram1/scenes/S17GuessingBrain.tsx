import React from 'react';
import { useCurrentFrame } from 'remotion';
import { AudSheet, SymbolSpec } from '../assets/sheet';
import { HeadCut } from '../assets/head';
import { MehnatMeter, QueueTiles, TileSpec } from '../assets/labels';
import { BrainChip } from '../assets/misc';
import { CURVES } from '../data';
import { easeDrive, easeSettle, clamp, HEAD } from '../tokens';

export const S17GuessingBrain: React.FC = () => {
  const f = useCurrentFrame();

  const freqs = [250, 500, 1000, 2000, 4000, 8000] as const;

  // 0-16: SHEET-SWAP left->right: NEUTRAL -> P1_DROP rides the same wipe (16 f E-DRIVE)
  const swapProg = easeDrive(clamp(f / 16));
  // Wipe clip traveling left->right
  const wipeClip = `inset(0px 0px 0px ${Math.max(0, (1 - swapProg) * 100)}%)`;

  // Ghost pulls 10% closer: scale 0.62 -> 0.72
  const ghostScale = 0.62 + 0.10 * swapProg;
  const ghostX = HEAD.x0 + 120 - 40 * swapProg;
  const ghostY = HEAD.y0 - 20;

  // 40-54: METER RISE: fill 74 -> 88% (12 f E-SETTLE)
  let meterFill = 74;
  let needleOvershoot = 0;
  if (f >= 40) {
    const riseProg = easeSettle(clamp((f - 40) / 12));
    meterFill = 74 + riseProg * 14;
    needleOvershoot = Math.sin(clamp((f - 40) / 12) * Math.PI) * 4;
  }

  // 70-86: MIRROR duet: sheet curve micro-pulse +/-2% AND meter needle wobble 4 px
  let curvePulse = 1.0;
  let needleWobble = 0;
  if (f >= 70 && f <= 86) {
    const duetPhase = Math.sin(((f - 70) / 10) * Math.PI * 2);
    curvePulse = 1.0 + 0.02 * duetPhase;
    needleWobble = 4 * duetPhase;
  }

  // 16-40: QUEUE-TILES reset: 2 dashed-? + 1 solid enter
  // 54-70: First ? decodes fine; second ? attempts, shakes 2x4 f, re-dashes and holds
  const firstTileDecoded = f >= 54;
  const isSecondShaking = f >= 58 && f <= 66;
  const shakeX = isSecondShaking ? (f % 2 === 0 ? 3 : -3) : 0;
  const secondApexTick = f >= 66;

  // 86-103: Hold 2 px bob
  const bobY = f >= 86 ? Math.sin(((f - 86) / 8) * Math.PI * 2) * 2 : 0;

  const queueTiles: TileSpec[] = [
    {
      type: 'solid',
      x: 620,
      y: 780,
      bobY,
    },
    {
      type: firstTileDecoded ? 'decoded' : 'dashed',
      x: 696,
      y: 780,
      bobY,
    },
    {
      type: 'dashed',
      x: 772 + shakeX,
      y: 780,
      bobY,
    },
  ];

  const symbols: SymbolSpec[] = CURVES.P1_DROP.AIR.map((db, idx) => ({
    freq: freqs[idx],
    db,
    scale: 1.0,
    alpha: 1.0,
  }));

  const apexTicksCount = (f >= 24 && f <= 26) || (secondApexTick && f <= 72) ? 1 : 0;

  return (
    <g>
      {/* Background NEUTRAL sheet before wipe completes */}
      {f < 16 && (
        <AudSheet
          showHeader={true}
          showGrid={true}
          showLabels={true}
          curveValues={CURVES.NEUTRAL.AIR}
          curveProgress={1.0}
        />
      )}

      {/* Foreground P1_DROP sheet wiping in left->right */}
      <g style={f < 16 ? { clipPath: wipeClip } : undefined}>
        <AudSheet
          showHeader={true}
          showGrid={true}
          showLabels={true}
          scale={curvePulse}
          curveValues={CURVES.P1_DROP.AIR}
          curveProgress={1.0}
          symbols={symbols}
        />
      </g>

      <BrainChip x={240} y={470} />

      {/* Ghost Head World Layer */}
      <g opacity={0.65}>
        <HeadCut
          x={ghostX}
          y={ghostY}
          scale={ghostScale}
          cutawayWipeProgress={1.0}
          pistonCadence="labor"
          pistonFrame={f}
          apexTicksCount={apexTicksCount}
        />

        {/* Queue Tiles */}
        <QueueTiles tiles={queueTiles} />

        {/* Small MEHNAT-METER inside ghost */}
        <MehnatMeter
          x={ghostX + 390}
          y={ghostY + 80}
          scale={0.65}
          fillPercent={meterFill}
          needleOvershoot={needleOvershoot}
          needleWobble={needleWobble}
          showLabel={false}
        />
      </g>
    </g>
  );
};
