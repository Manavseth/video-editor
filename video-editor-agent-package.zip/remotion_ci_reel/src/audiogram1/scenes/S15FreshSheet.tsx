import React from 'react';
import { useCurrentFrame } from 'remotion';
import { QuoteCard, BrainChip } from '../assets/misc';
import { AudSheet } from '../assets/sheet';
import { easeDrive, easeStamp, clamp } from '../tokens';

export const S15FreshSheet: React.FC = () => {
  const f = useCurrentFrame();

  // 0-14: QUOTE-CARD exits right (+160 px, fade 10 f E-DRIVE)
  const exitProg = easeDrive(clamp(f / 12));
  const cardExitX = exitProg * 160;
  const cardAlpha = 1 - clamp(f / 10);

  // 6-22: Fresh AUD-SHEET wipes in bottom->up (SHEET-SWAP 14 f)
  const wipeProg = easeDrive(clamp((f - 6) / 14));
  // bottom->up wipe: clip-path inset from top
  const wipeClip = `inset(${Math.max(0, (1 - wipeProg) * 100)}% 0px 0px 0px)`;

  // 26-40: BRAIN-CHIP pops top-left inside plot at (240, 470)
  const chipScale = f >= 26 ? easeStamp(clamp((f - 26) / 10)) : 0;

  // 44-57: Hold: sheet breathes 2 px
  const breatheY = f >= 44 ? Math.sin(((f - 44) / 10) * Math.PI * 2) * 2 : 0;

  return (
    <g>
      {/* Exiting Quote Card */}
      {cardAlpha > 0 && (
        <QuoteCard
          x={540 + cardExitX}
          y={810}
          opacity={cardAlpha}
        />
      )}

      {/* Fresh AUD-SHEET wiping in bottom->up */}
      {f >= 6 && (
        <g style={{ clipPath: wipeClip }}>
          <AudSheet
            showHeader={true}
            showGrid={true}
            showLabels={true}
            breatheY={breatheY}
            curveValues={[]} // plot EMPTY
            symbols={[]}
          />

          {/* BRAIN-CHIP at (240, 470) */}
          {f >= 26 && (
            <BrainChip
              x={240}
              y={470}
              scale={chipScale}
            />
          )}
        </g>
      )}
    </g>
  );
};
