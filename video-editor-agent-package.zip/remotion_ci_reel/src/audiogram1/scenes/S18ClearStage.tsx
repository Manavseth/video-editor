import React from 'react';
import { useCurrentFrame } from 'remotion';
import { AudSheet } from '../assets/sheet';
import { Chip } from '../assets/labels';
import { CURVES } from '../data';
import { easeDrive, easeStamp, clamp } from '../tokens';

export const S18ClearStage: React.FC = () => {
  const f = useCurrentFrame();

  // 0-14: Verdict set exits upward
  const exitProg = easeDrive(clamp(f / 12));
  const exitY = -40 * exitProg;
  const exitAlpha = 1 - exitProg;

  // 10-24: AGLI BAAR INK chip stamps top-center (Archivo 36, E-STAMP)
  const chipProg = clamp((f - 10) / 10);
  const chipScale = f >= 10 ? easeStamp(chipProg) : 0;

  // 26-42: Fresh AUD-SHEET wipes in bottom->up (12 f); empty plot
  const wipeProg = easeDrive(clamp((f - 26) / 12));
  const wipeClip = `inset(${Math.max(0, (1 - wipeProg) * 100)}% 0px 0px 0px)`;

  return (
    <g>
      {/* Exiting old sheet with curve */}
      {exitAlpha > 0 && (
        <g opacity={exitAlpha} transform={`translate(0, ${exitY})`}>
          <AudSheet
            showHeader={true}
            showGrid={true}
            showLabels={true}
            curveValues={CURVES.P1_DROP.AIR}
            curveProgress={1.0}
          />
        </g>
      )}

      {/* Fresh AUD-SHEET wiping in bottom->up from f26 */}
      {f >= 26 && (
        <g style={{ clipPath: wipeClip }}>
          <AudSheet
            showHeader={true}
            showGrid={true}
            showLabels={true}
            curveValues={[]} // empty plot
            symbols={[]}
          />
        </g>
      )}

      {/* AGLI BAAR INK chip top-center at (540, 240) */}
      {f >= 10 && (
        <Chip
          x={540}
          y={240}
          text="AGLI BAAR"
          variant="ink"
          scale={chipScale}
          fontSize={36}
        />
      )}
    </g>
  );
};
