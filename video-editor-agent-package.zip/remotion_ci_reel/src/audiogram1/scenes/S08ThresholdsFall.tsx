import React from 'react';
import { useCurrentFrame } from 'remotion';
import { AudSheet, SymbolSpec } from '../assets/sheet';
import { Chip } from '../assets/labels';
import { CURVES } from '../data';
import { easeSettle, clamp, fx, dy, INK } from '../tokens';

export const S08ThresholdsFall: React.FC = () => {
  const f = useCurrentFrame();

  const freqs = [250, 500, 1000, 2000, 4000, 8000] as const;

  // 0-10: 0 dB/UPAR/LOUD/NEECHE exit upward 8 px + fade
  const exitProg = clamp(f / 8);
  const exitY = -8 * exitProg;
  const exitAlpha = 1 - exitProg;

  // 14-46: THE FALL: morph SCATTER -> P1_DROP
  // Delta dB: SCATTER [15, 25, 20, 35, 40, 45] -> P1_DROP [30, 35, 40, 45, 55, 60]
  // L->R with 3 f stagger
  const currentAirValues = CURVES.SCATTER.AIR.map((startDb, idx) => {
    const endDb = CURVES.P1_DROP.AIR[idx];
    const startF = 14 + idx * 3;
    if (f < startF) return startDb;
    const p = easeSettle(clamp((f - startF) / 22));
    return startDb + (endDb - startDb) * p;
  });

  // 48-62: Settle bounce: whole line 4 px dip + return (4 f)
  let dipY = 0;
  if (f >= 48 && f <= 56) {
    dipY = Math.sin(clamp((f - 48) / 8) * Math.PI) * 4;
  }

  // 64-90: Hold: 2 px breathing; 1 kHz point holds a steady 6% pulse
  const breatheY = f >= 64 ? Math.sin(((f - 64) / 10) * Math.PI * 2) * 2 : 0;
  const pulse1k = f >= 64 ? 1.0 + 0.06 * Math.sin(((f - 64) / 8) * Math.PI * 2) : 1.0;

  const symbols: SymbolSpec[] = currentAirValues.map((db, idx) => {
    let scale = 1.0;
    if (idx === 2) scale = pulse1k;

    return {
      freq: freqs[idx],
      db,
      scale,
      bobY: dipY,
      alpha: 1.0,
    };
  });

  // 18-40: One ARROW-DOWN rides 2 kHz point's descent (+18 px below symbol)
  const arrow2kX = fx(2000);
  const arrow2kY = dy(currentAirValues[3]) + 18;
  const showArrow2k = f >= 18 && f <= 44;

  return (
    <g>
      <AudSheet
        showHeader={true}
        showGrid={true}
        showLabels={true}
        axisChips={true}
        breatheY={breatheY + dipY}
        curveValues={currentAirValues}
        curveProgress={1.0}
        symbols={symbols}
      />

      {/* Exiting chips from S07 */}
      {exitAlpha > 0 && (
        <g opacity={exitAlpha} transform={`translate(0, ${exitY})`}>
          <Chip x={840} y={404} text="UPAR" variant="white" fontSize={28} />
          <Chip x={760} y={1140} text="LOUD" variant="white" fontSize={30} />
          <Chip x={760} y={1195} text="NEECHE" variant="white" fontSize={28} />
        </g>
      )}

      {/* ARROW-DOWN riding 2 kHz descent */}
      {showArrow2k && (
        <g transform={`translate(${arrow2kX}, ${arrow2kY})`}>
          <line x1={0} y1={0} x2={0} y2={30} stroke={INK} strokeWidth={3} strokeLinecap="round" />
          <polygon points="-6,30 0,40 6,30" fill={INK} />
        </g>
      )}
    </g>
  );
};
