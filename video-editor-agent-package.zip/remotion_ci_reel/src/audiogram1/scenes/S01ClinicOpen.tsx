import React from 'react';
import { useCurrentFrame } from 'remotion';
import { AudiometerCube, ResponsePaddle } from '../assets/devices';
import { PatientChair, PatientFigure, AudiologistFigure } from '../assets/misc';
import { HeadphoneDevice } from '../assets/devices';
import { Chip } from '../assets/labels';
import { easeSettle, easeStamp, clamp } from '../tokens';

export const S01ClinicOpen: React.FC = () => {
  const f = useCurrentFrame();

  // 0-10: PART 1 chip stamps at (72, 140) E-STAMP
  const part1Progress = clamp(f / 10);
  const part1Scale = easeStamp(part1Progress);

  // 8-20: PATIENT-CHAIR slides 24 px from right; PATIENT-FIG enters traveling -40 px x
  const enterProg = clamp((f - 8) / 12);
  const chairSlideX = (1 - easeSettle(enterProg)) * 24;
  const patientSlideX = (1 - easeSettle(enterProg)) * -40;
  // 2 f squat squash on landing
  const squashY = f >= 20 && f <= 22 ? 0.96 : 1.0;

  // 16-28: HP-PHONE floats in from upper-left (-60, -100) to head dock; E-SETTLE 12 f
  const hpProg = clamp((f - 16) / 12);
  const hpX = 720 - 60 * (1 - easeSettle(hpProg));
  const hpY = 920 - 100 * (1 - easeSettle(hpProg));
  const hpOpacity = clamp((f - 16) / 6);

  // 26-42: AUDIOMETER-CUBE slides in from left (+32->0 px, E-SETTLE 10 f)
  const audioProg = clamp((f - 26) / 10);
  const audioSlideX = (1 - easeSettle(audioProg)) * 32;
  const audioOpacity = clamp((f - 26) / 6);

  // Beep quarter-arcs pulse once from screen corner (20->60 px, 8 f each, staggered 7 f)
  const beepProg = clamp((f - 30) / 15);

  // 30-46: AUDI-FIG rises behind console (translate y +24->0, 10 f)
  const audiProg = clamp((f - 30) / 10);
  const audiSlideY = (1 - easeSettle(audiProg)) * 24;
  const audiOpacity = clamp((f - 30) / 6);

  // 44-51: Hold: LED idle pulse, patient right nub settles onto paddle
  const ledPulse = f >= 35;

  return (
    <g>
      {/* PART 1 Chip */}
      <Chip
        x={120}
        y={140}
        text="PART 1"
        variant="ink"
        scale={part1Scale}
      />

      {/* Audiometer Console */}
      <AudiometerCube
        x={300 - audioSlideX}
        y={950}
        opacity={audioOpacity}
        ledActive={ledPulse}
        beepArcsProgress={beepProg}
      />

      {/* Audiologist Figure behind console */}
      <AudiologistFigure
        x={280}
        y={830 + audiSlideY}
        opacity={audiOpacity}
      />

      {/* Patient Chair */}
      <PatientChair
        x={720 + chairSlideX}
        y={1080}
        opacity={clamp(f / 6)}
      />

      {/* Response Paddle on armrest */}
      <ResponsePaddle
        x={764 + chairSlideX}
        y={1002}
        opacity={clamp(f / 6)}
      />

      {/* Patient Figure */}
      <PatientFigure
        x={720 + patientSlideX}
        y={920}
        squashY={squashY}
        rightArmPose="on-paddle"
        opacity={clamp(f / 6)}
      />

      {/* Headphones docking over patient head */}
      {f >= 16 && (
        <HeadphoneDevice
          x={hpX}
          y={hpY}
          opacity={hpOpacity}
        />
      )}
    </g>
  );
};
