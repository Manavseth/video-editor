import React from 'react';
import { useCurrentFrame } from 'remotion';
import { AudiometerCube, ResponsePaddle, PrintoutCard, HeadphoneDevice } from '../assets/devices';
import { PatientChair, PatientFigure, AudiologistFigure } from '../assets/misc';
import { AudSheet } from '../assets/sheet';
import { CURVES } from '../data';
import { easeDrive, easeStamp, clamp } from '../tokens';

export const S03SheetBorn: React.FC = () => {
  const f = useCurrentFrame();

  // 0-10: Card lifts 40 px, rotates face-flat (-8°->0°, 10 f E-DRIVE)
  const liftProg = easeDrive(clamp(f / 10));
  const cardLiftY = liftProg * 40;
  const cardTilt = -8 * (1 - liftProg);
  const audiStepBackX = -12 * liftProg;

  // 10-26: MORPH: card translates to center (540, 790) scaling 0.33x -> 1.0x
  const morphProg = easeDrive(clamp((f - 10) / 16));
  const cardStartX = 680;
  const cardStartY = 884 - cardLiftY;
  const cardX = cardStartX + (72 - cardStartX) * morphProg;
  const cardY = cardStartY + (300 - cardStartY) * morphProg;
  const cardScale = 0.7 + (1.0 - 0.7) * morphProg;
  const cardFadeOut = clamp((f - 16) / 10);

  // Sheet reveal starting at f10
  const sheetOpacity = clamp((f - 10) / 8);
  const gridAlpha = clamp((f - 18) / 8);

  // 26-34: Header lift-in; legend pops right 4 f later (E-STAMP)
  const headerProg = clamp((f - 26) / 8);
  const headerTranslateY = (1 - easeDrive(headerProg)) * -16;
  const legendScale = f >= 30 ? easeStamp(clamp((f - 30) / 8)) : 0;

  // 34-46: Mini-dots resolve to SCATTER anchors and recede to 45% alpha as previews
  const dotsAlpha = f >= 34 ? 0.45 : 1.0;

  // 46-58: Hold: 2 px breathing on sheet frame
  const breatheY = f >= 46 ? Math.sin(((f - 46) / 10) * Math.PI * 2) * 2 : 0;

  // 40-58: Patient + clinic exit cleanly (translate down 40 px + fade 8 f)
  const exitProg = clamp((f - 40) / 8);
  const clinicFade = 1 - exitProg;
  const clinicYOffset = exitProg * 40;

  // SCATTER preview symbols at 45% alpha
  const previewSymbols = CURVES.SCATTER.AIR.map((db, idx) => {
    const freqs = [250, 500, 1000, 2000, 4000, 8000] as const;
    return {
      freq: freqs[idx],
      db,
      alpha: f >= 26 ? dotsAlpha : 0,
      scale: 0.9,
    };
  });

  return (
    <g>
      {/* Clinic Background Layer (Fades out cleanly after f40) */}
      {clinicFade > 0 && (
        <g opacity={clinicFade} transform={`translate(0, ${clinicYOffset})`}>
          <AudiometerCube x={300} y={950} />
          <AudiologistFigure x={280 + audiStepBackX} y={830} />
          <PatientChair x={720} y={1080} />
          <ResponsePaddle x={764} y={1002} />
          <PatientFigure x={720} y={920} rightArmPose="receive-card" />
          <HeadphoneDevice x={720} y={920} />
        </g>
      )}

      {/* Sheet forming at center */}
      {sheetOpacity > 0 && (
        <AudSheet
          opacity={sheetOpacity}
          breatheY={breatheY}
          showHeader={f >= 26}
          headerOpacity={headerProg}
          headerTranslateY={headerTranslateY}
          legendPopScale={legendScale}
          showGrid={f >= 16}
          gridAlpha={gridAlpha}
          showLabels={f >= 20}
          symbols={previewSymbols}
        />
      )}

      {/* Morphing Printout Card (fades as sheet takes over) */}
      {cardFadeOut < 1 && (
        <g opacity={1 - cardFadeOut}>
          <PrintoutCard
            x={cardX}
            y={cardY}
            scale={cardScale}
            rotation={cardTilt}
            showMiniDots={true}
          />
        </g>
      )}
    </g>
  );
};
