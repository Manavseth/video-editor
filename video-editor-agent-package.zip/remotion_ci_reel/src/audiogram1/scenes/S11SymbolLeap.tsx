import React from 'react';
import { useCurrentFrame } from 'remotion';
import { HeadCut } from '../assets/head';
import { MehnatMeter, Chip } from '../assets/labels';
import { AudSheet, SymbolSpec } from '../assets/sheet';
import { CURVES } from '../data';
import { easeSnap, easeSettle, clamp, fx, dy, METER, HEAD, AIR } from '../tokens';

export const S11SymbolLeap: React.FC = () => {
  const f = useCurrentFrame();

  const freqs = [250, 500, 1000, 2000, 4000, 8000] as const;

  // 0-10: SYMBOL-LEAP from sheet
  const showSheet = f <= 12;
  const leapProg = easeSnap(clamp(f / 8));
  const leapingY = dy(40) - leapProg * 450;
  const leapAlpha = f >= 8 ? clamp(1 - (f - 8) / 2) : 1.0;

  const symbols: SymbolSpec[] = CURVES.P1_DROP.AIR.map((db, idx) => ({
    freq: freqs[idx],
    db,
    scale: 1.0,
    alpha: idx === 2 && f > 0 ? 0 : 1.0, // 1k leaps
  }));

  // 8-51: Head world enters at S06 state
  const showHeadWorld = f >= 8;
  const headAlpha = clamp((f - 8) / 4);

  // 12-20: Re-entry token falling into pinna mouth
  let reEntryToken: { x: number; y: number } | null = null;
  if (f >= 12 && f < 20) {
    const fallProg = easeSnap(clamp((f - 12) / 8));
    reEntryToken = {
      x: 620,
      y: 700 + fallProg * 125,
    };
  }

  // 20-41: TOKEN RUN along AIR-ROUTE
  const tokenActive = f >= 20 && f <= 45;
  const tokenProgress = clamp((f - 20) / 21);

  // 41-51: Receive: token turns gold, meter fill 62 -> 70% (6 f E-SETTLE)
  let meterFill = 62;
  let apexTicksCount = 0;
  if (f >= 41) {
    const riseProg = easeSettle(clamp((f - 41) / 6));
    meterFill = 62 + riseProg * 8;
    if (f >= 42 && f <= 45) {
      apexTicksCount = 1;
    }
  }

  return (
    <g>
      {/* Chart layer (exits by f12) */}
      {showSheet && (
        <g opacity={1 - clamp((f - 8) / 4)}>
          <AudSheet
            showHeader={true}
            showGrid={true}
            showLabels={true}
            curveValues={CURVES.P1_DROP.AIR}
            curveProgress={1.0}
            symbols={symbols}
          />
          {/* Leaping 1 kHz Symbol departing */}
          {f <= 10 && (
            <circle
              cx={fx(1000)}
              cy={leapingY}
              r={11}
              fill="#F6F2E9"
              stroke={AIR}
              strokeWidth={4.5}
              opacity={leapAlpha}
            />
          )}
        </g>
      )}

      {/* Head World Layer */}
      {showHeadWorld && (
        <g opacity={headAlpha}>
          <HeadCut
            x={HEAD.x0}
            y={HEAD.y0}
            cutawayWipeProgress={1.0}
            pistonCadence="labor"
            pistonFrame={f}
            apexTicksCount={apexTicksCount}
            tokenActive={tokenActive}
            tokenProgress={tokenProgress}
            isTokenGoldAtBrain={f >= 41}
          />

          {/* Falling token before entering canal mouth */}
          {reEntryToken && (
            <circle
              cx={reEntryToken.x}
              cy={reEntryToken.y}
              r={13}
              fill="none"
              stroke={AIR}
              strokeWidth={4.5}
            />
          )}

          {/* MEHNAT-METER */}
          <MehnatMeter
            x={METER.dialCx}
            y={METER.dialCy}
            fillPercent={meterFill}
            showLabel={true}
          />
          <Chip
            x={METER.dialCx}
            y={METER.dialCy + 130}
            text="GADHA-MAZDOORI"
            variant="gold"
            fontSize={26}
          />
        </g>
      )}
    </g>
  );
};
