import React from 'react';
import { useCurrentFrame } from 'remotion';
import { AudSheet, SymbolSpec } from '../assets/sheet';
import { Chip } from '../assets/labels';
import { CURVES } from '../data';
import { easeStamp, clamp } from '../tokens';

export const S10WhatItCosts: React.FC = () => {
  const f = useCurrentFrame();

  const freqs = [250, 500, 1000, 2000, 4000, 8000] as const;

  // 0-14: Tangerine chip ZYADA VOLUME stamps at (560, 480) E-STAMP
  const volChipScale = easeStamp(clamp(f / 14));

  // 16-28: White chip CLARITY stamps below at (560, 545)
  const clarityScale = f >= 16 ? easeStamp(clamp((f - 16) / 12)) : 0;

  // 32-48: 1 kHz symbol flashes ring 6% wider, stroke thickens 4.5 -> 6 px
  const isFlash = f >= 32 && f <= 48;
  const strokeW1k = isFlash ? 6 : 4.5;
  const flashScale = isFlash ? 1.0 + 0.06 * Math.sin(clamp((f - 32) / 16) * Math.PI) : 1.0;

  // 48-67: Pre-leap: symbol scales 0.94 and rises 4 px (accelerating)
  let preLeapY = 0;
  let preLeapScale = flashScale;
  if (f >= 48) {
    const leapProg = Math.pow(clamp((f - 48) / 19), 2);
    preLeapY = -4 * leapProg;
    preLeapScale = 1.0 - 0.06 * leapProg;
  }

  const symbols: SymbolSpec[] = CURVES.P1_DROP.AIR.map((db, idx) => {
    let scale = 1.0;
    let bobY = 0;
    let strokeWidth = 4.5;

    if (idx === 2) {
      scale = preLeapScale;
      bobY = preLeapY;
      strokeWidth = strokeW1k;
    }

    return {
      freq: freqs[idx],
      db,
      scale,
      bobY,
      strokeWidth,
      alpha: 1.0,
    };
  });

  return (
    <g>
      <AudSheet
        showHeader={true}
        showGrid={true}
        showLabels={true}
        axisChips={true}
        curveValues={CURVES.P1_DROP.AIR}
        curveProgress={1.0}
        symbols={symbols}
      />

      {/* Tangerine chip ZYADA VOLUME */}
      <Chip
        x={560}
        y={480}
        text="ZYADA VOLUME"
        variant="tangerine"
        scale={volChipScale}
        fontSize={32}
      />

      {/* White chip CLARITY */}
      {f >= 16 && (
        <Chip
          x={560}
          y={545}
          text="CLARITY"
          variant="white"
          scale={clarityScale}
          fontSize={32}
        />
      )}
    </g>
  );
};
