export const PAPER = '#F6F2E9';
export const GRID = '#E4DECC';
export const INK = '#262430';
export const INK_SOFT = '#5B5970';
export const SLATE = {
  s50: '#F2F5F9',
  s100: '#E3E9F1',
  s200: '#D3DCE7',
  s300: '#C0CAD6',
  s400: '#9FA9B8',
};
export const AIR = '#DF7A2B';
export const AIR_PALE = '#F7D9B4';
export const GOLD = '#C9A227'; // effort/labor accent (meter fill, labor ticks, effort highlights)
export const OK = '#2E9E6B';
export const OK_PALE = '#D9F0DF';
export const CHARCOAL_FACE = '#43424B'; // headphone cup fill / chair seats / slip-ons
export const SKIN = '#A9745A'; // both figures
export const TM_FILL = '#ECD5CB';
export const COAT = '#F4F6F9';

// Layout
export const W = 1080;
export const H = 1920;
export const SHEET = { x0: 72, x1: 1008, y0: 300, y1: 1280, r: 28 };
export const PLOT = { x0: 168, x1: 958, y0: 380, y1: 1180 }; // 0–100 dB HL, 250 Hz–8 kHz
export const CAP = { cx: 540, top: 1460, maxLines: 2, bottomLimit: 1636 };
export const HEAD = { x0: 220, x1: 860, y0: 440, y1: 1120 }; // world bbox (world scenes)
export const METER = { x0: 890, x1: 1008, dialCx: 928, dialCy: 512 }; // MEHNAT-METER column (world scenes)

// Axis mappers (doc-contract; import everywhere, never hardcode)
export const fx = (f: 250 | 500 | 1000 | 2000 | 4000 | 8000 | number) =>
  168 + 158 * Math.log2(f / 250); // octave x: 168/326/484/642/800/958
export const dy = (db: number) => 380 + 8 * db; // dB HL maps DOWNWARD (audiogram convention)

export const OCTAVES = [250, 500, 1000, 2000, 4000, 8000] as const;

// Easing helpers (pure deterministic functions of progress 0..1 or frames)
export const clamp = (v: number, min = 0, max = 1) => Math.max(min, Math.min(max, v));

export const easeSettle = (t: number) => {
  // E-SETTLE: cubic-bezier(0.22, 1, 0.36, 1) approx 240-280ms
  t = clamp(t);
  return 1 - Math.pow(1 - t, 3.2);
};

export const easeDrive = (t: number) => {
  // E-DRIVE: cubic-bezier(0.45, 0, 0.15, 1) approx 260-420ms
  t = clamp(t);
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
};

export const easeSnap = (t: number) => {
  // E-SNAP: cubic-bezier(0.85, 0, 0.15, 1) approx 160-200ms
  t = clamp(t);
  return Math.pow(t, 2.5);
};

export const easeStamp = (t: number) => {
  // E-STAMP spring scale 1.18 -> 0.94 -> 1.02 -> 1.00 over 14 frames
  t = clamp(t);
  if (t <= 0) return 1.0;
  if (t < 0.3) {
    const p = t / 0.3;
    return 1.0 + 0.18 * Math.sin(p * (Math.PI / 2));
  }
  if (t < 0.7) {
    const p = (t - 0.3) / 0.4;
    return 1.18 - 0.24 * p;
  }
  if (t < 0.9) {
    const p = (t - 0.7) / 0.2;
    return 0.94 + 0.08 * p;
  }
  const p = (t - 0.9) / 0.1;
  return 1.02 - 0.02 * p;
};
