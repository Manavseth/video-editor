# Nishant's video editing skills — 1.0 · 6 Oct 2026

These are the exact skills I use to edit my reels, my YouTube long-form and my vlogs with Claude Code
(and Codex). Same files, same rules, same numbers. Copied out of my working repo, cleaned of my own disk
paths and private notes. Nothing else changed.

**25 skills · 11 style specs · 5 tools.**

## Start in 3 steps

1. **Copy the skills in.** Put every folder from `skills/` into your project's `.claude/skills/`
   (Claude Code). For Codex or another agent, put them wherever it reads skills (the shared standard is
   `.agents/skills/`). For claude.ai, zip one skill folder at a time and upload it under
   Settings → Capabilities → Skills.
2. **Copy `CLAUDE.template.md` to your project as `CLAUDE.md`.** It tells the agent to route every edit
   through `reel-edit` and to run the pipeline in order.
3. **Do the setup once** (`SETUP.md`): ffmpeg, a Python 3.11 venv with WhisperX, Node 22+, and the editor
   you want (HyperFrames, Remotion, Palmier Pro or DaVinci).

Then say:

> Use the reel-edit skill. Here is my raw take: `/path/to/take.mp4`. Make the asset plan first.

## What's inside

| Group | Skill | What it does |
|---|---|---|
| Start here | `reel-edit` | The router. Picks the format, enforces the pipeline order, names the skill for each stage. |
| Pipeline | `asset-plan` | Step 0. Classify every visual, fact-check every claim, ask what moves in each beat. |
| | `shortform-cutaway` | The rough cut. WhisperX words, the red thread, envelope-exact edges (v2). |
| | `cut-audit` | Prove the cut is clean before styling it. |
| | `take-geometry` | Measure where your face is, so text never lands on it. |
| | `screen-capture` | Real screen recordings that move and stay legible on a phone. |
| | `broll-select` | Pick b-roll from your own indexed library. |
| | `design-asset` | Animated demo cards as HTML, recorded frame-exact. |
| | `genvideo` | Generated b-roll (Veo, Omni, Sora, image models) behind a cost gate. |
| | `omni-restyle` | Restyle your own footage with Gemini Omni video-to-video. |
| | `mg-kit` | Reuse your motion-graphics kit before building anything new. |
| | `shortform-finish` | Styling: hook zoom, type, sound design, levels, loudness (v2). |
| | `caption-align` | Captions on the right frames. |
| | `sfx-design` | Sound effects that land on the peak, at the right level. |
| | `render-ops` | Renders that land on disk correctly; −14 LUFS measured on the encoded file. |
| | `reel-review` | The review gate: a script, then a different model looks at the frames. |
| Formats | `split-screen` | The 60-40 split: screen card, caption lane, face card. |
| | `paper-drawer-edit` | One grid-paper world; your face card slides away for diagrams. |
| | `whiteout-edit` | Clean face ⟷ one white page per idea. |
| | `caption-edit` | "Just a basic edit": the take stays whole, overlays only. |
| | `layered-head-edit` | Graphics behind and around your head, flash-cut registers. |
| | `broll-style-edit` | The fast b-roll-led creator essay. |
| | `card-list-edit` | Curated-resource listicle with real YouTube cards. |
| | `vlog-edit` | Day-in-the-life vlogs: coverage, not graphics. |
| | `longform-edit` | 16:9 long-form: layered over your cut, or cut from raw in HyperFrames. |

`docs/` holds the style specs the format skills cite (measured from real reels). `tools/` holds the scripts
the skills call: the review gate (`review_reel.py`), the doubled-take scanner (`repeat_scan.py`), the face
guard, the motion gate, the fake-example generator.

## Reading these files

- They were written for me. "He" and "his" = the creator, i.e. you now. Swap in your own accounts and style.
- `<project>` = your project folder. `<media-drive>` = wherever you keep footage, b-roll and renders.
- Some skills point at my own libraries (535 b-roll clips, a 522-file SFX library, a motion-graphics kit).
  Those are not included — they're my footage and licensed sounds. The skills tell the agent how to build
  and index your own.
- Every rule has a reason next to it, usually a real mistake. Keep the reasons when you edit a rule.

## The two ideas that make it work

1. **The model that edits is not the model that reviews.** A model grading its own work passes its own work.
2. **Rules come from mistakes, written down once.** When an edit goes wrong, fix the skill, not just the video.

## Terms

For your personal and client work. Please don't re-share or resell the pack. If it helps you ship something,
tag me. I'd love to see it.
