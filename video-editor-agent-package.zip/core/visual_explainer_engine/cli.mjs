#!/usr/bin/env node
// =========================================================================================
// VISUAL EXPLAINER CLI: End-to-End Procedural Video Generation
// =========================================================================================

import fs from 'fs';
import path from 'path';
import { CANONICAL_ARC_PHASES, buildStoryboard } from './story_architect.js';
import { compileSceneScript } from './scene_compiler.js';
import { renderExplainerVideo } from './render_runner.mjs';

const args = process.argv.slice(2);
const command = args[0] || 'info';

function getArg(flag, defaultValue = null) {
  const idx = args.indexOf(flag);
  if (idx !== -1 && idx + 1 < args.length) return args[idx + 1];
  return defaultValue;
}

if (command === 'info' || command === '--help' || command === '-h') {
  console.log(`
=========================================================================================
  VISUAL EXPLAINER STORY & PROCEDURAL MOTION SYSTEM (v1.0)
=========================================================================================
An autonomous engine to generate broadcast-ready, code-driven scientific, medical, and
technical explainer videos ($0.00 cost, 1080x1920 9:16 vertical, -14.0 LUFS EBU R128).

CANONICAL 8-BEAT NARRATIVE ARC:
${CANONICAL_ARC_PHASES.map(p => `  Phase ${p.phase} [${p.id}]: ${p.name}\n    -> Goal: ${p.narrativeGoal}\n    -> Visual: ${p.visualGrammar}`).join('\n\n')}

COMMANDS:
  node cli.mjs storyboard --topic <topic> --script <file_or_text> [--duration <seconds>] [--out <file>]
    Parses script into the canonical 8-beat visual explainer storyboard.

  node cli.mjs compile --storyboard <json_file> --out <scene_js_file>
    Compiles storyboard spec into executable Canvas 2D scene.js.

  node cli.mjs render --workdir <dir> --audio <audio_wav> [--frames <N>] [--out <dir>]
    Executes headless browser rendering, FFmpeg piping, and audio muxing.
=========================================================================================
  `);
  process.exit(0);
}

if (command === 'storyboard') {
  const topic = getArg('--topic', 'Scientific Explainer');
  const scriptInput = getArg('--script');
  const duration = parseFloat(getArg('--duration', '41.7'));
  const outFile = getArg('--out', 'storyboard.json');

  if (!scriptInput) {
    console.error('Error: --script is required (file path or quoted text)');
    process.exit(1);
  }

  let text = scriptInput;
  if (fs.existsSync(scriptInput)) {
    text = fs.readFileSync(scriptInput, 'utf-8');
  }

  // Parse lines or sentences into basic subtitle timeline
  const sentences = text.split(/[.\n]+/).map(s => s.trim()).filter(Boolean);
  const durPerSentence = duration / Math.max(1, sentences.length);
  const subtitles = sentences.map((s, idx) => ({
    start: Number((idx * durPerSentence).toFixed(2)),
    end: Number(((idx + 1) * durPerSentence).toFixed(2)),
    text: s,
    highlight: s.split(' ').slice(0, 2).join(' ')
  }));

  const sb = buildStoryboard(topic, subtitles, duration);
  fs.writeFileSync(outFile, JSON.stringify(sb, null, 2));
  console.log(`Successfully generated storyboard at: ${path.resolve(outFile)}`);
  process.exit(0);
}

if (command === 'compile') {
  const sbPath = getArg('--storyboard', 'storyboard.json');
  const outPath = getArg('--out', 'scene.js');

  if (!fs.existsSync(sbPath)) {
    console.error(`Error: Storyboard file not found at: ${sbPath}`);
    process.exit(1);
  }

  const sb = JSON.parse(fs.readFileSync(sbPath, 'utf-8'));
  compileSceneScript(sb, outPath);
  console.log(`Successfully compiled scene script at: ${path.resolve(outPath)}`);
  process.exit(0);
}

if (command === 'render') {
  const workDir = path.resolve(getArg('--workdir', 'work/explainer_render'));
  const audioPath = getArg('--audio');
  const outputDir = path.resolve(getArg('--out', 'out'));
  const totalFrames = parseInt(getArg('--frames', '1251'), 10);

  console.log('Starting render runner...');
  renderExplainerVideo({
    workDir,
    outputDir,
    audioPath,
    totalFrames
  }).then(masterPath => {
    console.log('Video render finished:', masterPath);
    process.exit(0);
  }).catch(err => {
    console.error('Render failed:', err);
    process.exit(1);
  });
}
