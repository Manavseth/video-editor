# Visual Explainer Story & Procedural Motion System

A production-grade, $0.00-cost autonomous engine that turns educational, medical, biological, physical, and technical scripts into broadcast-quality 9:16 vertical motion graphic videos.

---

## 1. How the Visual Explainer Story Progresses (The 8-Beat Arc)

Through the reverse-engineering and recreation of high-performing visual explainers (e.g. `@thebrainmaze`, Kurzgesagt, and medical cinematography), every successful explainer follows an 8-beat cognitive progression:

```
[1. Everyday Hook]        Relatable macro human observation ("Why do your eyes roll up when you sleep?")
        │
[2. Quantitative Scope]   100-node demographic ring establishing scale ("Happens in 90% of people")
        │
[3. Core Protagonist]     Technical optical/sagittal cross-section of the delicate asset ("The cornea: 0.54mm")
        │
[4. Environmental Threat] Aerodynamic hazard vectors & micro-gap ("Tears drop, eyelids don't seal completely")
        │
[5. Biomechanical Defense]Kinematic rotation into safe harbor pocket ("Cornea tucks under upper lid into fornix")
        │
[6. Deep Control Circuit] Cranial silhouette & Pontine reflex core firing white-hot action-potential packets
        │
[7. Physical Actuator]    Orbital extraocular rectus muscles with striated red fascicles & tendon tension
        │
[8. Empirical Proof]      Clinical bedside examination: eyelids retracted, 100% white sclera exposed, iris hidden
```

---

## 2. Motion Design & Transition Grammar

### Zone Budgeting (1080 × 1920 @ 30 FPS)
- **$y = 0..6$**: Neon Emerald 5px continuous global progress bar.
- **$y = 50..85$**: Top Category HUD Breadcrumb (`CLINICAL NEUROLOGY • OCULAR BIOMECHANICS`) & Chapter Tag.
- **$y = 135..220$**: Hero Bold Title (`WHY DO YOUR EYES ROLL UP...`) & Category Subtitle.
- **$y = 380..1380$**: Hero Visual Stage (60% negative space on deep obsidian radial vignette).
- **$y = 1420..1540$**: Frosted glass Telemetry HUD Card with live pulsing status LED.
- **$y = 1620..1680$**: Floating borderless dual-tone synchronized subtitles.
- **$y = 1750..1920$**: Safe bottom platform clearance.

### Semantic Color System
- **Cyan (`#00f0ff`)**: Delicate vulnerable asset, optical window, CN III nerve, keyword highlight.
- **Radiant Gold (`#fbbf24`)**: Pontine reflex core, CN VII nerve, demographic percentage, electrical impulse.
- **Warning Coral (`#ff4466`)**: Desiccation risk, nocturnal lagophthalmos gap, shear vectors, exposure hazard.
- **Emerald (`#10b981`)**: Safe harbor, physiological tolerance, progress bar, clinical confirmation.
- **Pearlescent White (`#f1f5f9`)**: Sclera, action-potential spark packets, primary headlines.

### Morphological Continuity & Transitions
- **No Disorienting Jump-Cuts**: Scenes sharing anatomical geometry (e.g. Scene 4 exposure gap and Scene 5 safe harbor) maintain continuous camera scale and angle.
- **Damped Harmonic Spring Physics**: All pops, rotations, reveals, and card entrances use `springVal(t, t0, dur, stiffness = 220, damping = 24)`.

---

## 3. Command-Line Interface (CLI)

```bash
# Analyze script and generate canonical 8-beat storyboard:
node core/visual_explainer_engine/cli.mjs storyboard --topic "Topic Name" --script "script.txt" --duration 41.7 --out storyboard.json

# Compile storyboard into executable Canvas 2D scene:
node core/visual_explainer_engine/cli.mjs compile --storyboard storyboard.json --out work/scene.js

# Render 1080x1920 frames via headless Puppeteer and mux with -14.0 LUFS audio:
node core/visual_explainer_engine/cli.mjs render --workdir work/render --audio audio.wav --frames 1251 --out out/
```
