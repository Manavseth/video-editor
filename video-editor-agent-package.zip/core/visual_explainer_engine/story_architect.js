// =========================================================================================
// STORY ARCHITECT: Narrative & Visual Explainer Progression Engine
// Maps scripts and topics into the Canonical 8-Beat Visual Explainer Arc
// =========================================================================================

export const CANONICAL_ARC_PHASES = [
  {
    phase: 1,
    id: "everyday_hook",
    name: "The Everyday Hook / Relatable Mystery",
    narrativeGoal: "Ground the viewer in an immediate, relatable observation or striking biological/physical question.",
    visualGrammar: "Macro recognizable actor (human face, eyes, engine, cell). Organic slow breathing movement.",
    sceneTemplate: "macro_hero_observation",
    defaultDurationRatio: 0.12
  },
  {
    phase: 2,
    id: "quantitative_scope",
    name: "Quantitative Scope & Prevalence",
    narrativeGoal: "Establish universal scale, prevalence, or statistical significance.",
    visualGrammar: "100-node demographic ring, animated percentage counter (0 -> N%), golden headline, clinical badge.",
    sceneTemplate: "demographic_metric_ring",
    defaultDurationRatio: 0.11
  },
  {
    phase: 3,
    id: "structural_protagonist",
    name: "Core Structural Protagonist",
    narrativeGoal: "Introduce and isolate the delicate asset/organ that requires defense or study.",
    visualGrammar: "High-contrast technical cross-section (optical sagittal or coronal), dimension callout (0.54mm), avascular highlight.",
    sceneTemplate: "anatomical_cross_section",
    defaultDurationRatio: 0.11
  },
  {
    phase: 4,
    id: "environmental_conflict",
    name: "The Environmental Conflict & Vulnerability",
    narrativeGoal: "Introduce the physics failure mode, physiological vulnerability, or environmental threat.",
    visualGrammar: "Interpalpebral exposure gap, desiccating air vectors, red warning aura, evaporative particles.",
    sceneTemplate: "threat_exposure_gap",
    defaultDurationRatio: 0.14
  },
  {
    phase: 5,
    id: "biomechanical_defense",
    name: "Biomechanical Defense / Safe Harbor",
    narrativeGoal: "Reveal the elegant natural mechanism that neutralizes the threat.",
    visualGrammar: "Seamless kinematic continuation of Phase 4; upward rotation tucking cornea under upper lid into moist fornix; tough sclera buffer exposed.",
    sceneTemplate: "kinematic_safe_harbor",
    defaultDurationRatio: 0.14
  },
  {
    phase: 6,
    id: "control_circuit",
    name: "Deep Control Circuit & Neural Wiring",
    narrativeGoal: "Demystify the central intelligence / reflex arc driving the movement.",
    visualGrammar: "Lateral cranium silhouette, illuminated brainstem core (Pons), dual branched nerve tracts (CN VII & CN III) firing white-hot action-potential packets.",
    sceneTemplate: "brainstem_neural_arc",
    defaultDurationRatio: 0.13
  },
  {
    phase: 7,
    id: "physical_actuator",
    name: "The Physical Actuator / Muscle Engine",
    narrativeGoal: "Expose the motor hardware executing the movement.",
    visualGrammar: "Coronal orbit with bilateral extraocular muscles situated strictly on lateral sides; red striated fascicles, silvery tendon insertions, and entering cyan motor nerve tracts.",
    sceneTemplate: "orbital_muscle_actuator",
    defaultDurationRatio: 0.13
  },
  {
    phase: 8,
    id: "empirical_proof",
    name: "Empirical Proof / Real-World Payoff",
    narrativeGoal: "Provide direct real-world verification or clinical test proof.",
    visualGrammar: "Clinical bedside examination: eyelids gently retracted with indicator vectors, 100% glistening white sclera exposed, iris hidden, diagnostic reticle.",
    sceneTemplate: "clinical_sclera_verification",
    defaultDurationRatio: 0.12
  }
];

/**
 * Automatically builds an 8-beat storyboard from script text and topic context.
 * @param {string} topic - e.g. "Bell's Phenomenon", "Acoustic Reflex", "Adrenaline Surge"
 * @param {Array<{start: number, end: number, text: string, highlight?: string}>} subtitles - Spoken transcript beats
 * @param {number} totalDuration - Video duration in seconds
 */
export function buildStoryboard(topic, subtitles, totalDuration = 41.7) {
  // If subtitles provide specific scene breaks or if duration needs to be apportioned:
  const scenes = [];
  let currentTime = 0;

  for (let i = 0; i < CANONICAL_ARC_PHASES.length; i++) {
    const phase = CANONICAL_ARC_PHASES[i];
    const targetDur = totalDuration * phase.defaultDurationRatio;
    const startTime = currentTime;
    const endTime = (i === CANONICAL_ARC_PHASES.length - 1) ? totalDuration : Math.min(totalDuration, currentTime + targetDur);
    currentTime = endTime;

    // Find overlapping spoken subtitles
    const phaseSubs = subtitles.filter(s => (s.start < endTime && s.end > startTime));
    const combinedText = phaseSubs.map(s => s.text).join(" ");

    scenes.push({
      sceneId: i + 1,
      phaseId: phase.id,
      title: phase.name,
      timeStart: Number(startTime.toFixed(2)),
      timeEnd: Number(endTime.toFixed(2)),
      duration: Number((endTime - startTime).toFixed(2)),
      frameStart: Math.round(startTime * 30),
      frameEnd: Math.round(endTime * 30) - 1,
      template: phase.sceneTemplate,
      narration: combinedText,
      subtitles: phaseSubs,
      hud: {
        category: "CLINICAL NEUROLOGY • OCULAR BIOMECHANICS",
        chapter: `CHAPTER ${i + 1}: ${phase.id.replace(/_/g, ' ').toUpperCase()}`
      }
    });
  }

  return {
    meta: {
      topic,
      totalDuration,
      fps: 30,
      totalFrames: Math.round(totalDuration * 30),
      aspectRatio: "9:16",
      resolution: { width: 1080, height: 1920 }
    },
    scenes
  };
}
