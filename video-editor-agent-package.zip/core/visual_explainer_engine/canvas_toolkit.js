// =========================================================================================
// VISUAL EXPLAINER MOTION DESIGN TOOLKIT (Canvas 2D)
// Standard: 1080x1920 (9:16 vertical) • 30 FPS • Broadcast Grade • $0.00 Cost
// =========================================================================================

export const W = 1080;
export const H = 1920;
export const FPS = 30;

// 1. Semantic Color Palette
export const COLORS = {
  bgDark: "#06080d",          // Deep obsidian base
  bgRadial: "#0c1424",        // Subtle radial vignette core
  textWhite: "#f8fafc",       // Primary high-contrast text
  textMuted: "#94a3b8",       // Secondary technical label text
  textDim: "#475569",         // Terse indicator text
  cyan: "#00f0ff",            // Hero asset / cornea / optical / delicate structure
  cyanGlow: "rgba(0, 240, 255, 0.4)",
  amber: "#fbbf24",           // Neural action potential / reflex / electrical core
  amberGlow: "rgba(251, 191, 36, 0.45)",
  coral: "#ff4466",           // Danger / desiccation / shear hazard / exposure risk
  coralGlow: "rgba(255, 68, 102, 0.4)",
  emerald: "#10b981",         // Optimal / safe / biological tolerance
  emeraldGlow: "rgba(16, 185, 129, 0.35)",
  whiteSclera: "#f1f5f9",     // Pearlescent protective tissue / sclera
  irisBlue: "#1d4ed8",        // Iris deep stroma
  cardBg: "rgba(8, 14, 24, 0.85)", // Obsidian frosted glass card
  cardBorder: "rgba(56, 189, 248, 0.28)"
};

// 2. Mathematical & Physics Helpers
export function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

export function lerp(a, b, t) {
  return a + (b - a) * t;
}

export function easeOutCubic(t) {
  const p = clamp(t, 0, 1);
  return 1 - Math.pow(1 - p, 3);
}

export function easeInOutCubic(t) {
  const p = clamp(t, 0, 1);
  return p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2;
}

// Sub-stepped Damped Harmonic Spring
export function springVal(t, t0, dur, stiffness = 220, damping = 24) {
  if (t < t0) return 0;
  const dt = t - t0;
  if (dt >= dur) return 1;
  const omega = Math.sqrt(stiffness);
  const zeta = damping / (2 * omega);
  const omegaD = omega * Math.sqrt(Math.max(0, 1 - zeta * zeta));
  const envelope = Math.exp(-zeta * omega * dt);
  const osc = Math.cos(omegaD * dt) + (zeta / Math.sqrt(Math.max(0.0001, 1 - zeta * zeta))) * Math.sin(omegaD * dt);
  return clamp(1 - envelope * osc, 0, 1.25);
}

// 3. Pre-seeded Deterministic Ambient Bokeh Particles
export function createParticleSystem(count = 45) {
  const particles = [];
  for (let i = 0; i < count; i++) {
    particles.push({
      x: (i * 12345.67) % W,
      y: (i * 98765.43) % H,
      r: 2.5 + ((i * 37) % 12),
      speedY: 0.12 + ((i * 13) % 0.28),
      speedX: (((i % 2 === 0) ? 1 : -1) * (0.04 + ((i * 7) % 0.12))),
      alpha: 0.06 + ((i * 19) % 0.14)
    });
  }
  return particles;
}

// -----------------------------------------------------------------------------------------
// FOUNDATIONAL SCENE ARCHITECTURE (Zone Budgeting)
// -----------------------------------------------------------------------------------------

// Deep Obsidian Studio Canvas Background with Subtle Drifting Particles
export function drawObsidianBackground(ctx, t, particles) {
  ctx.save();
  ctx.fillStyle = COLORS.bgDark;
  ctx.fillRect(0, 0, W, H);

  // Radial illumination centered at stage
  const grad = ctx.createRadialGradient(W / 2, H * 0.44, 120, W / 2, H * 0.44, 820);
  grad.addColorStop(0, COLORS.bgRadial);
  grad.addColorStop(0.7, "rgba(8, 14, 24, 0.45)");
  grad.addColorStop(1, "rgba(6, 8, 13, 0)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, W, H);

  // Ambient motes
  if (particles) {
    for (const p of particles) {
      const curX = (p.x + p.speedX * t * 30 + W) % W;
      const curY = (p.y - p.speedY * t * 30 + H) % H;
      ctx.fillStyle = `rgba(56, 189, 248, ${p.alpha * 0.5})`;
      ctx.beginPath();
      ctx.arc(curX, curY, p.r, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.restore();
}

// Continuous 5px Top Global Progress Bar (y = 0..6)
export function drawGlobalProgressBar(ctx, t, duration) {
  const p = clamp(t / duration, 0, 1);
  ctx.save();
  ctx.fillStyle = "rgba(255, 255, 255, 0.08)";
  ctx.fillRect(0, 0, W, 6);

  ctx.fillStyle = COLORS.emerald;
  ctx.shadowColor = COLORS.emerald;
  ctx.shadowBlur = 10;
  ctx.fillRect(0, 0, W * p, 6);
  ctx.shadowBlur = 0;

  // Active playhead tip
  ctx.fillStyle = COLORS.textWhite;
  ctx.fillRect(W * p - 3, 0, 6, 6);
  ctx.restore();
}

// Top Category & Chapter Breadcrumb HUD (y = 50..85)
export function drawTopHUD(ctx, category, chapter) {
  ctx.save();
  ctx.font = "600 19px 'SF Pro Display', -apple-system, sans-serif";
  ctx.fillStyle = COLORS.cyan;
  ctx.textAlign = "left";
  ctx.letterSpacing = "2px";
  ctx.fillText(category.toUpperCase(), 75, 75);

  ctx.font = "500 17px 'SF Mono', monospace";
  ctx.fillStyle = COLORS.textMuted;
  ctx.textAlign = "right";
  ctx.letterSpacing = "1px";
  ctx.fillText(`• ${chapter.toUpperCase()}`, W - 75, 75);

  ctx.strokeStyle = "rgba(56, 189, 248, 0.16)";
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(75, 96);
  ctx.lineTo(W - 75, 96);
  ctx.stroke();
  ctx.restore();
}

// Hero Title & Category Hook (y = 135..230)
export function drawHeroTitle(ctx, mainTitle, subtitle, subColor = COLORS.cyan) {
  ctx.save();
  ctx.textAlign = "center";

  ctx.font = "900 42px 'SF Pro Display', -apple-system, sans-serif";
  ctx.fillStyle = COLORS.textWhite;
  ctx.letterSpacing = "0.5px";
  ctx.fillText(mainTitle, W / 2, 160);

  ctx.font = "700 22px 'SF Pro Display', -apple-system, sans-serif";
  ctx.fillStyle = subColor;
  ctx.letterSpacing = "2.5px";
  ctx.shadowColor = subColor;
  ctx.shadowBlur = 8;
  ctx.fillText(subtitle.toUpperCase(), W / 2, 204);
  ctx.shadowBlur = 0;
  ctx.restore();
}

// Technical Telemetry Card (y = 1420..1540)
export function drawTelemetryCard(ctx, cx, cy, w, h, badge, title, desc, tone = "cyan", t = 0) {
  ctx.save();
  const left = cx - w / 2;
  const top = cy - h / 2;

  let accent = COLORS.cyan;
  let accentGlow = COLORS.cyanGlow;
  if (tone === "amber" || tone === "gold") { accent = COLORS.amber; accentGlow = COLORS.amberGlow; }
  else if (tone === "coral" || tone === "red") { accent = COLORS.coral; accentGlow = COLORS.coralGlow; }
  else if (tone === "emerald" || tone === "green") { accent = COLORS.emerald; accentGlow = COLORS.emeraldGlow; }

  // Frosted obsidian card background
  ctx.fillStyle = COLORS.cardBg;
  ctx.strokeStyle = `rgba(${tone === "coral" ? "255, 68, 102" : tone === "amber" ? "251, 191, 36" : "56, 189, 248"}, 0.28)`;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.roundRect(left, top, w, h, 14);
  ctx.fill();
  ctx.stroke();

  // Specular top highlight sheen
  const sheen = ctx.createLinearGradient(left, top, left + w, top);
  sheen.addColorStop(0, "rgba(255, 255, 255, 0)");
  sheen.addColorStop(0.5, "rgba(255, 255, 255, 0.12)");
  sheen.addColorStop(1, "rgba(255, 255, 255, 0)");
  ctx.fillStyle = sheen;
  ctx.fillRect(left + 2, top + 1, w - 4, 2);

  // Status indicator LED with gentle breathing pulse
  const pulse = 0.7 + 0.3 * Math.sin(t * 5);
  ctx.fillStyle = accent;
  ctx.shadowColor = accentGlow;
  ctx.shadowBlur = 10 * pulse;
  ctx.beginPath();
  ctx.arc(left + 28, top + 26, 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;

  // Badge pill
  ctx.font = "800 15px 'SF Mono', monospace";
  ctx.fillStyle = accent;
  ctx.textAlign = "left";
  ctx.letterSpacing = "1.5px";
  ctx.fillText(badge.toUpperCase(), left + 44, top + 31);

  // Card primary title
  ctx.font = "700 21px 'SF Pro Display', -apple-system, sans-serif";
  ctx.fillStyle = COLORS.textWhite;
  ctx.letterSpacing = "0.5px";
  ctx.fillText(title, left + 26, top + 64);

  // Card technical description
  ctx.font = "500 17px 'SF Pro Display', -apple-system, sans-serif";
  ctx.fillStyle = COLORS.textMuted;
  ctx.fillText(desc, left + 26, top + 94);

  ctx.restore();
}

// Floating Borderless Dual-Tone Subtitles (y = 1620..1680)
export function drawFloatingSubtitles(ctx, t, subtitles, subY = 1650) {
  const curSub = subtitles.find(s => t >= s.start && t < s.end);
  if (!curSub) return;

  ctx.save();
  const fontSize = curSub.text.length > 52 ? 31 : 35;
  ctx.font = `600 ${fontSize}px 'SF Pro Display', -apple-system, sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  const words = curSub.text.split(" ");
  const hlWords = (curSub.highlight || "").toLowerCase().split(" ");

  // Pre-measure words for centered alignment
  let totalWidth = 0;
  const wordMetrics = words.map(w => {
    const cleanWord = w.replace(/[.,!?:;"]/g, "").toLowerCase();
    const isHL = hlWords.includes(cleanWord);
    ctx.font = isHL ? `800 ${fontSize}px 'SF Pro Display', -apple-system, sans-serif` : `600 ${fontSize}px 'SF Pro Display', -apple-system, sans-serif`;
    const m = ctx.measureText(w + " ");
    totalWidth += m.width;
    return { word: w, width: m.width, isHL };
  });

  let curX = W / 2 - totalWidth / 2;
  for (const wm of wordMetrics) {
    if (wm.isHL) {
      ctx.font = `800 ${fontSize}px 'SF Pro Display', -apple-system, sans-serif`;
      ctx.fillStyle = COLORS.cyan;
      ctx.shadowColor = COLORS.cyanGlow;
      ctx.shadowBlur = 12;
      ctx.fillText(wm.word, curX + wm.width / 2, subY);
      ctx.shadowBlur = 0;
    } else {
      ctx.font = `600 ${fontSize}px 'SF Pro Display', -apple-system, sans-serif`;
      ctx.fillStyle = COLORS.textWhite;
      ctx.fillText(wm.word, curX + wm.width / 2, subY);
    }
    curX += wm.width;
  }
  ctx.restore();
}

// -----------------------------------------------------------------------------------------
// PARAMETRIC REUSABLE VISUAL ACTORS & GLYPHS
// -----------------------------------------------------------------------------------------

// 1. Demographic Prevalence / Statistical Ring (Act 2)
export function drawDemographicRing(ctx, cx, cy, radius, percent, title, badgeText, t) {
  ctx.save();
  const totalNodes = 100;
  const activeNodes = Math.round((clamp(percent, 0, 100) / 100) * totalNodes);

  // Outer ambient glow ring
  ctx.strokeStyle = "rgba(56, 189, 248, 0.12)";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, Math.PI * 2);
  ctx.stroke();

  // Draw 100 biological micro-nodes
  for (let i = 0; i < totalNodes; i++) {
    const angle = (i / totalNodes) * Math.PI * 2 - Math.PI / 2;
    const nx = cx + Math.cos(angle) * radius;
    const ny = cy + Math.sin(angle) * radius;
    const isActive = i < activeNodes;

    ctx.beginPath();
    ctx.arc(nx, ny, isActive ? 4.5 : 2.5, 0, Math.PI * 2);
    if (isActive) {
      ctx.fillStyle = COLORS.cyan;
      ctx.shadowColor = COLORS.cyanGlow;
      ctx.shadowBlur = 8;
      ctx.fill();
      ctx.shadowBlur = 0;
    } else {
      ctx.fillStyle = "rgba(255, 255, 255, 0.16)";
      ctx.fill();
    }
  }

  // Central kinetic percentage readout
  ctx.textAlign = "center";
  ctx.font = "900 110px 'SF Pro Display', -apple-system, sans-serif";
  ctx.fillStyle = COLORS.textWhite;
  ctx.fillText(`${Math.round(percent)}%`, cx, cy + 28);

  ctx.font = "700 20px 'SF Pro Display', -apple-system, sans-serif";
  ctx.fillStyle = COLORS.textMuted;
  ctx.letterSpacing = "2px";
  ctx.fillText(title.toUpperCase(), cx, cy + 76);

  ctx.font = "700 16px 'SF Mono', monospace";
  ctx.fillStyle = COLORS.emerald;
  ctx.letterSpacing = "1px";
  ctx.fillText(badgeText.toUpperCase(), cx, cy + 110);

  ctx.restore();
}

// 2. Action Potential Electrical Nerve Tract (Act 6)
export function drawActionPotentialTract(ctx, points, color, pulseSpeed, t) {
  if (points.length < 2) return;
  ctx.save();

  // Draw baseline nerve sheath
  ctx.strokeStyle = `rgba(${color === COLORS.amber ? "251, 191, 36" : "0, 240, 255"}, 0.35)`;
  ctx.lineWidth = 3.5;
  ctx.setLineDash([8, 8]);
  ctx.beginPath();
  ctx.moveTo(points[0].x, points[0].y);
  for (let i = 1; i < points.length; i++) {
    ctx.lineTo(points[i].x, points[i].y);
  }
  ctx.stroke();
  ctx.setLineDash([]);

  // Calculate length and animate white-hot action-potential packets
  const numPackets = 4;
  for (let p = 0; p < numPackets; p++) {
    const progress = (t * pulseSpeed + p / numPackets) % 1.0;
    const pt = interpolatePath(points, progress);

    ctx.fillStyle = "#ffffff";
    ctx.shadowColor = color;
    ctx.shadowBlur = 16;
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, 6.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
  }
  ctx.restore();
}

function interpolatePath(points, progress) {
  let totalLen = 0;
  const lens = [];
  for (let i = 0; i < points.length - 1; i++) {
    const dx = points[i + 1].x - points[i].x;
    const dy = points[i + 1].y - points[i].y;
    const l = Math.sqrt(dx * dx + dy * dy);
    lens.push(l);
    totalLen += l;
  }
  let target = progress * totalLen;
  for (let i = 0; i < lens.length; i++) {
    if (target <= lens[i] || i === lens.length - 1) {
      const segT = lens[i] === 0 ? 0 : target / lens[i];
      return {
        x: points[i].x + (points[i + 1].x - points[i].x) * segT,
        y: points[i].y + (points[i + 1].y - points[i].y) * segT
      };
    }
    target -= lens[i];
  }
  return points[points.length - 1];
}

// 3. Dynamic Hazard & Desiccation Streamline Vectors (Act 4)
export function drawHazardVectors(ctx, startX, startY, endX, endY, count, label, t) {
  ctx.save();
  ctx.strokeStyle = COLORS.coral;
  ctx.fillStyle = COLORS.coral;
  ctx.lineWidth = 2.5;

  for (let i = 0; i < count; i++) {
    const offset = (i / count) * 40 - 20;
    const phase = (t * 2.5 + i / count) % 1.0;
    const curX = lerp(startX, endX, phase);
    const curY = lerp(startY + offset, endY + offset, phase);

    ctx.beginPath();
    ctx.arc(curX, curY, 3, 0, Math.PI * 2);
    ctx.shadowColor = COLORS.coralGlow;
    ctx.shadowBlur = 8;
    ctx.fill();
    ctx.shadowBlur = 0;

    // Streamline tail
    ctx.beginPath();
    ctx.moveTo(curX - 25, curY);
    ctx.lineTo(curX, curY);
    ctx.stroke();
  }

  // Label
  if (label) {
    ctx.font = "700 16px 'SF Mono', monospace";
    ctx.fillStyle = COLORS.coral;
    ctx.textAlign = "center";
    ctx.fillText(label.toUpperCase(), (startX + endX) / 2, startY - 32);
  }
  ctx.restore();
}

// 4. Clinical Diagnostic Reticle (Act 8)
export function drawClinicalReticle(ctx, cx, cy, radius, label, status, t) {
  ctx.save();
  const pulse = 1 + 0.05 * Math.sin(t * 4);
  const r = radius * pulse;

  // Target circle
  ctx.strokeStyle = "rgba(56, 189, 248, 0.4)";
  ctx.lineWidth = 2;
  ctx.setLineDash([8, 12]);
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);

  // Corner tick brackets
  const tickLen = 22;
  ctx.strokeStyle = COLORS.cyan;
  ctx.lineWidth = 3;

  // Top-left
  ctx.beginPath();
  ctx.moveTo(cx - r - 10, cy - r + tickLen);
  ctx.lineTo(cx - r - 10, cy - r - 10);
  ctx.lineTo(cx - r + tickLen, cy - r - 10);
  ctx.stroke();

  // Top-right
  ctx.beginPath();
  ctx.moveTo(cx + r + 10 - tickLen, cy - r - 10);
  ctx.lineTo(cx + r + 10, cy - r - 10);
  ctx.lineTo(cx + r + 10, cy - r + tickLen);
  ctx.stroke();

  // Bottom-left
  ctx.beginPath();
  ctx.moveTo(cx - r - 10, cy + r - tickLen);
  ctx.lineTo(cx - r - 10, cy + r + 10);
  ctx.lineTo(cx - r + tickLen, cy + r + 10);
  ctx.stroke();

  // Bottom-right
  ctx.beginPath();
  ctx.moveTo(cx + r + 10 - tickLen, cy + r + 10);
  ctx.lineTo(cx + r + 10, cy + r + 10);
  ctx.lineTo(cx + r + 10, cy + r - tickLen);
  ctx.stroke();

  // Center crosshairs
  ctx.strokeStyle = "rgba(0, 240, 255, 0.6)";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(cx - 15, cy);
  ctx.lineTo(cx + 15, cy);
  ctx.moveTo(cx, cy - 15);
  ctx.lineTo(cx, cy + 15);
  ctx.stroke();

  // Callout status badge
  if (label && status) {
    ctx.textAlign = "center";
    ctx.font = "800 16px 'SF Mono', monospace";
    ctx.fillStyle = COLORS.emerald;
    ctx.fillText(`[ ${status.toUpperCase()} ]`, cx, cy + r + 42);

    ctx.font = "600 18px 'SF Pro Display', -apple-system, sans-serif";
    ctx.fillStyle = COLORS.textWhite;
    ctx.fillText(label, cx, cy + r + 70);
  }

  ctx.restore();
}
