// =========================================================================================
// RENDER RUNNER: Headless Browser & FFmpeg Streaming Harness
// Renders 1080x1920 @ 30 FPS procedural canvas directly into broadcast MP4
// =========================================================================================

import http from 'http';
import fs from 'fs';
import path from 'path';
import { spawn, execSync } from 'child_process';
import puppeteer from 'puppeteer-core';

export async function renderExplainerVideo({
  workDir,
  outputDir,
  audioPath,
  totalFrames = 1251,
  fps = 30,
  port = 4998,
  previewTimestamps = []
}) {
  const W = 1080, H = 1920;
  fs.mkdirSync(workDir, { recursive: true });
  fs.mkdirSync(outputDir, { recursive: true });

  const rawVideoPath = path.join(workDir, 'visuals_raw.mp4');
  const finalVideoPath = path.join(outputDir, 'explainer_master.mp4');

  // 0. Pre-Flight Audio Integrity Audit (Zero-Mistake Gate)
  if (audioPath && fs.existsSync(audioPath)) {
    console.log('Running automated audio pre-flight integrity audit...');
    const candidatePythons = [
      path.resolve('.venv/Scripts/python.exe'),
      'E:\\Antigravity\\video editor\\.venv\\Scripts\\python.exe',
      'python'
    ];
    const pythonExe = candidatePythons.find(p => p === 'python' || fs.existsSync(p)) || 'python';
    const auditScript = path.resolve('scripts/audit_composite_audio.py');
    if (fs.existsSync(pythonExe) && fs.existsSync(auditScript)) {
      try {
        execSync(`"${pythonExe}" "${auditScript}" "${audioPath}"`, { stdio: 'inherit' });
        console.log('✓ Pre-flight audio audit passed with 0 critical violations.');
      } catch (err) {
        console.error('❌ CRITICAL ERROR: Audio pre-flight audit failed! Aborting render.');
        throw new Error('Audio pre-flight audit failed: Speech duplication or boundary defect detected.');
      }
    }
  }

  // 1. Local HTTP Server
  const server = http.createServer((req, res) => {
    let reqPath = decodeURIComponent(req.url.split('?')[0]);
    if (reqPath === '/' || reqPath === '/index.html') {
      res.setHeader('Content-Type', 'text/html');
      res.end(`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Procedural Visual Explainer</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body, html { width: 1080px; height: 1920px; overflow: hidden; background: #06080d; }
    canvas { width: 1080px; height: 1920px; display: block; }
  </style>
</head>
<body>
  <canvas id="c" width="1080" height="1920"></canvas>
  <script type="module" src="/scene.js"></script>
</body>
</html>`);
      return;
    }
    if (reqPath === '/scene.js') {
      res.setHeader('Content-Type', 'application/javascript');
      res.end(fs.readFileSync(path.join(workDir, 'scene.js')));
      return;
    }
    res.statusCode = 404;
    res.end('Not found');
  });

  await new Promise(r => server.listen(port, r));
  console.log(`Local web server listening on http://localhost:${port}`);

  // 2. Discover Browser Engine
  const exePaths = [
    'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
    'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
    process.env.LOCALAPPDATA + '/Google/Chrome/Application/chrome.exe',
    'C:/Program Files/Google/Chrome/Application/chrome.exe'
  ];
  const exe = exePaths.find(p => fs.existsSync(p));
  if (!exe) throw new Error('No compatible Chrome or Edge browser found.');

  console.log('Using browser engine:', exe);
  const browser = await puppeteer.launch({
    executablePath: exe,
    headless: true,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--use-gl=angle',
      '--use-angle=d3d11',
      '--enable-webgl',
      '--disable-dev-shm-usage'
    ]
  });

  const page = await browser.newPage();
  page.on('console', msg => {
    if (msg.type() === 'error') console.error('BROWSER LOG ERROR:', msg.text());
  });

  await page.setViewport({ width: W, height: H, deviceScaleFactor: 1 });
  console.log('Loading procedural scene...');
  await page.goto(`http://localhost:${port}/index.html`);
  await page.waitForFunction('window.READY === true', { timeout: 30000 });
  console.log(`Procedural scene ready! Rendering ${totalFrames} frames @ ${fps} FPS...`);

  // 3. Capture Verification Preview Stills
  const stillsDir = path.join(workDir, 'review_stills');
  fs.mkdirSync(stillsDir, { recursive: true });

  if (previewTimestamps.length > 0) {
    console.log('Capturing keyframe review stills...');
    for (const pt of previewTimestamps) {
      const fIdx = Math.round(pt.t * fps);
      const dataUrl = await page.evaluate(f => window.grabFrame(f), fIdx);
      const buf = Buffer.from(dataUrl.split(',')[1], 'base64');
      fs.writeFileSync(path.join(stillsDir, `${pt.name}.jpg`), buf);
    }
  }

  // 4. Stream Frames directly to FFmpeg
  console.log('Streaming procedural frames into FFmpeg via pipe...');
  const ff = spawn('ffmpeg', [
    '-y',
    '-loglevel', 'error',
    '-f', 'image2pipe',
    '-framerate', String(fps),
    '-c:v', 'mjpeg',
    '-i', '-',
    '-c:v', 'libx264',
    '-crf', '17',
    '-preset', 'fast',
    '-pix_fmt', 'yuv420p',
    rawVideoPath
  ], { stdio: ['pipe', 'inherit', 'inherit'] });

  const startTime = Date.now();
  for (let f = 0; f < totalFrames; f++) {
    const dataUrl = await page.evaluate(fIdx => window.grabFrame(fIdx), f);
    const buf = Buffer.from(dataUrl.split(',')[1], 'base64');

    if (!ff.stdin.write(buf)) {
      await new Promise(r => ff.stdin.once('drain', r));
    }

    if (f % 150 === 0 || f === totalFrames - 1) {
      const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
      const pct = ((f / totalFrames) * 100).toFixed(1);
      const fpsRate = (f / (Date.now() - startTime) * 1000).toFixed(1);
      console.log(`Rendered frame ${f}/${totalFrames} (${pct}%) • Elapsed: ${elapsed}s [${fpsRate} fps]`);
    }
  }

  ff.stdin.end();
  await new Promise(r => ff.on('close', r));
  console.log('Visual stream rendering complete:', rawVideoPath);

  await browser.close();
  server.close();

  // 5. Mux with Audio Master (-14.0 LUFS EBU R128)
  if (audioPath && fs.existsSync(audioPath)) {
    console.log('Muxing with audio master (-14.0 LUFS limiter)...');
    const muxCmd = `ffmpeg -y -i "${rawVideoPath}" -i "${audioPath}" -c:v copy -af "alimiter=limit=-1.5dB" -c:a aac -b:a 256k -shortest "${finalVideoPath}"`;
    execSync(muxCmd, { stdio: 'inherit' });
  } else {
    console.log('No external audio provided; outputting raw visuals.');
    fs.copyFileSync(rawVideoPath, finalVideoPath);
  }

  console.log('Deliverable export complete:', finalVideoPath);
  return finalVideoPath;
}
